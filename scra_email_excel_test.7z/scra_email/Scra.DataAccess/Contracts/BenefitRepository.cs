﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.Tasks;

namespace Scra.DataAccess.Contracts
{
    internal class BenefitRepository : IBenefitRepository
    {
        private const string LOAD_SQL = @"
SELECT	Id, BenefitIntervalId, ContractID, PersonID, ActiveDutyID, IsPromo, StartDate, EndDate, 
        Status, DenialReason, TaskID
FROM	dbo.Benefit
WHERE   {WHERE}
ORDER	BY StartDate, Id";

        private const string GET_BENEFIT_BY_TASK = @"
SELECT ID, BenefitIntervalId, ContractID,Timestamp,ModifiedBy,PersonID,ActiveDutyID,IsPromo,StartDate,EndDate,Status,DenialReason,TaskID 
FROM dbo.Benefit
WHERE {ID}";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public BenefitRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public Task<IList<Benefit>> LoadByContract(ContractId contractId)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "ContractID=" + contractId);
            return _sqlExecutor.Execute(sql, Convert);
        }

        public Task<Benefit> LoadById(int benefitId)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "ID=" + benefitId);            
            return _sqlExecutor.ExecuteOne(sql, Convert); 
        }

        public Task<IList<Benefit>> LoadByPerson(int id)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "PersonId=" + id);
            return _sqlExecutor.Execute(sql, Convert);
        }

        public async Task<IList<BenefitEvent>> LoadEvent(PersonId personId)
        {
            var parameters = new[]
            {
                SpParameter.Create("PersonId", personId.Value)
            };

            return await _spExecutor.GetRecords("dbo.spBenefitEvent_List", parameters, ToBenefitEvent);
        }

        public async Task<IList<BenefitEvent>> LoadEvent(ContractId contractId)
        {
            var parameters = new[]
            {
                SpParameter.Create("ContractId", contractId.Value)
            };

            return await _spExecutor.GetRecords("dbo.spBenefitEvent_List", parameters, ToBenefitEvent);
        }

        public async Task<IList<BenefitEvent>> LoadEvent(int benefitId)
        {
            var parameters = new[]
            {
                SpParameter.Create("BenefitId", benefitId)
            };

            return await _spExecutor.GetRecords("dbo.spBenefitEvent_List", parameters, ToBenefitEvent);
        }

	    public async Task<IList<BenefitEvent>> LoadAllEvents()
	    {
		    var parameters = new[]
		    {
			    SpParameter.Create("BenefitId", 0),
			    SpParameter.Create("PersonId", 0),
			    SpParameter.Create("ContractId", 0),
		    };

			return await _spExecutor.GetRecords("dbo.spBenefitEvent_List", parameters, ToBenefitEvent);
		}

	    //public async Task<IList<BenefitEvent>> LoadEvent(ContractId contractId)
        //{
        //    var sql = GET_BENEFIT_EVENTS_BY_CONTRACT.Replace("{ContractId}", contractId.Value.ToString());
        //    return await _sqlExecutor.Execute(sql, ToBenefitEvent);
        //}

        private BenefitEvent ToBenefitEvent(IRowData row)
        {
            var benefitStatus = BenefitStatus.Parse(row.AsString("BenefitStatus"));
            var taskType = TaskType.Parse(row.AsString("TaskType"));
            var taskStatus = TascStatus.Parse(row.AsString("TaskStatus"));

            var benefitEvent = new BenefitEvent()
            {
                BenefitId = row.AsInt("BenefitId"),
                BenefitIntervalId = row.AsInt("BenefitIntervalId"),
                BenefitDetailId = row.AsInt("BenefitDetailId"),
                ActiveDutyId = row.AsInt("ActiveDutyId"),
                ContractId = row.AsInt("ContractId"),
                TaskId = row.AsInt("TaskID"),
                InquiryId = row.AsInt("InquiryId"),
                InquiryDate = row.AsDateTime("InquiryDate"),
                InquiryTaskId = row.AsInt("InquiryTaskId"),
                BenefitStatus = benefitStatus,
                BenefitAppliedDate = row.AsDateTime("BenefitAppliedDate"),
                BenefitEffectiveDate = row.AsDateTime("BenefitEffectiveDate"),
                ExpectedRemovalDate = row.AsDateTime("ExpectedRemovalDate"),
                BenefitRemovedDate = row.AsDateTime("BenefitRemovedDate"),
	            ExtendDate = row.AsDateTime("ExtendDate"),
	            DenialReason = row.AsString("DenialReason"),
                //ActionDate = row.AsDateTime("BenefitDate"),
                ActionDate = row.AsDateTime("ActionDate"),
	            ActiveDutyStartDate = row.AsDateTime("ActiveDutyStartDate"),
                ActiveDutyEndDate = row.AsDateTime("ActiveDutyEndDate"),
                SubProductName = row.AsString("SUB_PRODUCT_NAME"),
                AccountNumber = row.AsString("AccountNumber"),
                ContractNo = row.AsString("ContractNo"),
                SCRA_Code = row.AsString("SCRA_Code"),
                OpenDate = row.AsDateTime("OpenDate"),
                CloseDate = row.AsDateTime("CloseDate"),                
                TaskType = taskType,
                TaskStatus = taskStatus,
                PersonId = row.AsInt("PersonId")
            };

            benefitEvent.CustomerName = row.AsString("CustomerFirstName") + " " + row.AsString("CustomerLastName");
            benefitEvent.ServicememberName = row.AsString("ServiceMemberFirstName") + " " + row.AsString("ServiceMemberLastName");
            benefitEvent.ActiveDutyPeriod = string.Format("{0:MM/dd/yyyy}", row.AsDateTime("ActiveDutyStartDate")) + " - " + string.Format("{0:MM/dd/yyyy}", row.AsDateTime("ActiveDutyEndDate")) + "\n";

            return benefitEvent;
        }


        public async Task Save(Benefit benefit)
        {
            if (benefit.Id.IsNew())
            {
                await Create(benefit);
            }

            await Update(benefit);
        }

        public async Task<Benefit> GetBenefitByTask(int taskId)
        {
            var sql = GET_BENEFIT_BY_TASK.Replace("{ID}", "TaskID = " + taskId);
            var result = await _sqlExecutor.Execute(sql, Convert);

            return result.FirstOrDefault();
        }

        public async Task<IList<Benefit>> GetBenefitListByTask(int taskId)
        {
            var sql = GET_BENEFIT_BY_TASK.Replace("{ID}", "TaskID = " + taskId);
            var result = await _sqlExecutor.Execute(sql, Convert);

            return result;
        }

        private Benefit Convert(IRowData row)
        {
            var id = row.AsInt(RefColumn.ID);
            var benefitIntervalId = row.AsInt("BenefitIntervalId");
	        var contractId = new ContractId(row.AsInt(BenefitColumn.CONTRACT_ID));
            var personId = row.AsInt(BenefitColumn.PERSON_ID);
            var adId = row.AsInt(BenefitColumn.ACTIVE_DUTY_ID);
            var isPromo = row.AsBool(BenefitColumn.IS_PROMO);
            var startDate = row.AsDateTime(BenefitColumn.START_DATE);
            var endDate = row.AsDateTime(BenefitColumn.END_DATE);
            var statusCode = row.AsString(BenefitColumn.STATUS);
            var status = BenefitStatus.Parse(statusCode);
            var denialReason = row.AsString(BenefitColumn.DENIAL_REASON);
            var taskId = row.AsInt(BenefitColumn.TASK_ID);
            return new Benefit(id, contractId, new PersonId(personId), adId, isPromo, startDate, endDate, status, denialReason, taskId, benefitIntervalId, 0);
        }

        private int Convert(IDataRecord arg)
        {
            return arg.GetInt32(0);
        }

        private async Task Update(Benefit model)
        {
            var parameters = new[]
            {
                SpParameter.Create(BenefitColumn.STATUS, model.Status.Code),
                SpParameter.Create(BenefitColumn.DENIAL_REASON, model.DenialReason),
                SpParameter.Create(BenefitColumn.START_DATE, model.StartDate),
                SpParameter.Create(BenefitColumn.END_DATE, model.EndDate),
                SpParameter.Create(BenefitColumn.TASK_ID, model.TaskId),
                SpParameter.ModifiedBy(),
                SpParameter.Create(model.Id)
            };

            await _spExecutor.Execute("dbo.spBenefit_Update", parameters);
        }

        private async Task Create(Benefit model)
        {
            var id = SpParameter.CreateInOut(model.Id);
            var parameters = new[]
            {
                SpParameter.Create(BenefitColumn.CONTRACT_ID, model.ContractId),
                SpParameter.Create(BenefitColumn.ACTIVE_DUTY_ID, model.ActiveDutyId),
                SpParameter.Create(BenefitColumn.PERSON_ID, model.PersonId.Value),
                SpParameter.Create(BenefitColumn.STATUS, model.Status.Code),
                SpParameter.Create(BenefitColumn.DENIAL_REASON, model.DenialReason),
                SpParameter.Create(BenefitColumn.IS_PROMO, model.IsPromo),
                SpParameter.Create(BenefitColumn.START_DATE, model.StartDate),
                SpParameter.Create(BenefitColumn.END_DATE, model.EndDate),
                SpParameter.Create("BenefitIntervalId", model.BenefitIntervalId),
                SpParameter.ModifiedBy(),
                id
            };

            var result = await _spExecutor.GetRecord("dbo.spBenefit_Create", parameters, Convert);

            model.Id = (int)id.Value;
            model.BenefitIntervalId = result;
        }
    }
}
