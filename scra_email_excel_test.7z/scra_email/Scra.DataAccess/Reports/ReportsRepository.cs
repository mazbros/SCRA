﻿using Scra.DataAccess.Core;
using Scra.Model.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Threading.Tasks;

namespace Scra.DataAccess.Reports
{
    public class ReportsRepository : IReportsRepository
    {
        private readonly SpExecutor _spExecutor;

        public ReportsRepository(SpExecutor spExecutor)
        {
            _spExecutor = spExecutor;
        }

        public async Task<IEnumerable<WeeklyControlReportItem>> Load(DateTime? reportDate)
        {
            var results = new List<WeeklyControlReportItem>();
            var reportDateParameter = SpParameter.Create("ReportDate", reportDate);
            var data = await _spExecutor.GetDataTable("dbo.spWeeklyReport_Load", reportDateParameter);

            foreach (DataRow dr in data.Rows)
            {
                var item = WeeklyControlReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        public async Task<DataTable> LoadDt(string reportName)
        {
            var data = await _spExecutor.GetDataTableNp("dbo.sp" + reportName + "_Report");
            
            return data;
        }

        public async Task<IEnumerable<object>> Load(object obj, string reportName)
        {
            var data = await _spExecutor.GetDataTableNp("dbo.sp" + reportName + "_Report");
            var results = new List<object>();
            var method = obj.GetType().GetMethod("Create", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(DataRow) }, null);

            foreach (DataRow dr in data.Rows)
            {
                if (method == null) continue;
                var item = method.Invoke(this, new object[] { dr });
                results.Add(item);
            }

            return results;
        }

        //public async Task<IEnumerable<OpenActiveBenefitsReportItem>> LoadOpenActive(DateTime? reportDate, DateTime? reportDate2)
        //public async Task<IEnumerable<BenefitsReportItem>> LoadOpenActive(DateTime? reportDate, DateTime? reportDate2)
        //{
        //    //var results = new List<OpenActiveBenefitsReportItem>();
        //    var results = new List<BenefitsReportItem>();

        //    var parameters = new[]
        //    {
        //        SpParameter.Create("DateStart", reportDate),
        //        SpParameter.Create("DateEnd", reportDate2),
        //    };
        //    var data = await _spExecutor.GetDataTable("dbo.spOpenActiveBenefits_Report", parameters);

        //    foreach (DataRow dr in data.Rows)
        //    {
        //        //var item = OpenActiveBenefitsReportItem.Create(dr);
        //        var item = BenefitsReportItem.Create(dr);

        //        results.Add(item);
        //    }

        //    return results;
        //}

        public async Task<DataTable> LoadOpenActiveDt(DateTime? reportDate, DateTime? reportDate2)
        {
            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2)
            };
            var data = await _spExecutor.GetDataTable("dbo.spOpenActiveBenefits_Report", parameters);

            return data;
        }

        //public async Task<IEnumerable<CurrentlyReceivingBenefitsReportItem>> LoadCurrentlyReceiving(DateTime? reportDate, DateTime? reportDate2, string category)
        public async Task<IEnumerable<BenefitsReportItem>> LoadCurrentlyReceiving(DateTime? reportDate, DateTime? reportDate2, string category)
        {
            //var results = new List<CurrentlyReceivingBenefitsReportItem>();
            var results = new List<BenefitsReportItem>();

            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
                SpParameter.Create("ProductCategory", category)
            };
            var data = await _spExecutor.GetDataTable("dbo.spCurrentlyReceivingBenefits_Report", parameters);

            foreach (DataRow dr in data.Rows)
            {
                //var item = CurrentlyReceivingBenefitsReportItem.Create(dr);
                var item = BenefitsReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        public async Task<DataTable> LoadCurrentlyReceivingDt(DateTime? reportDate, DateTime? reportDate2, string category)
        {
            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
                SpParameter.Create("ProductCategory", category)
            };
            var data = await _spExecutor.GetDataTable("dbo.spCurrentlyReceivingBenefits_Report", parameters);

            return data;
        }

        public async Task<IEnumerable<BenefitsReportItem>> LoadNewAccounts(DateTime? reportDate, DateTime? reportDate2)
        {
            var results = new List<BenefitsReportItem>();

            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spNewAccounts_Report", parameters);

            foreach (DataRow dr in data.Rows)
            {
                var item = BenefitsReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        public async Task<IEnumerable<BenefitsReportItem>> LoadExpiredAccounts(DateTime? reportDate, DateTime? reportDate2)
        {
            var results = new List<BenefitsReportItem>();

            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spExpiredAccounts_Report", parameters);

            foreach (DataRow dr in data.Rows)
            {
                var item = BenefitsReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        public async Task<DataTable> LoadDeniedAccountsDt(DateTime? reportDate, DateTime? reportDate2)
        {
            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spDeniedAccounts_Report", parameters);

            return data;
        }

        public async Task<DataTable> LoadExpiredAccountsDt(DateTime? reportDate, DateTime? reportDate2)
        {
            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spExpiredAccounts_Report", parameters);

            return data;
        }

        public async Task<DataTable> LoadNewAccountsDt(DateTime? reportDate, DateTime? reportDate2)
        {
            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spNewAccounts_Report", parameters);

            return data;
        }

        public async Task<IEnumerable<DeniedAccountsReportItem>> LoadDeniedAccounts(DateTime? reportDate, DateTime? reportDate2)
        {
            var results = new List<DeniedAccountsReportItem>();

            var parameters = new[]
            {
                SpParameter.Create("DateStart", reportDate),
                SpParameter.Create("DateEnd", reportDate2),
            };
            var data = await _spExecutor.GetDataTable("dbo.spDeniedAccounts_Report", parameters);

            foreach (DataRow dr in data.Rows)
            {
                var item = DeniedAccountsReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        
        //public async Task<IEnumerable<TaskStatusReportItem>> Load(string interval, DateTime? reportDate, string taskType)
        //{
        //    var results = new List<TaskStatusReportItem>();

        //    var parameters = new[]
        //    {
        //        SpParameter.Create("Interval", interval),
        //        SpParameter.Create("ReportDate", reportDate),
        //        SpParameter.Create("TaskType", taskType)
        //    };
        //    var data = await _spExecutor.GetDataTable("dbo.spTaskStatus_Report", parameters);

        //    foreach (DataRow dr in data.Rows)
        //    {
        //        var item = TaskStatusReportItem.Create(dr);

        //        results.Add(item);
        //    }

        //    return results;
        //}
    }


}
