﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.DataAccess.Persons
{
    internal class PersonNoteRepository : IPersonNoteRepository
    {
        private readonly SpExecutor _spExecutor;        

        public PersonNoteRepository(SpExecutor spExecutor)
        {
            _spExecutor = spExecutor;
        }

        public async Task Create(PersonNote note, IUser user)
        {
            var id = SpParameter.CreateInOut(note.Id);
            var parameters = new[]
            {
                SpParameter.Create(PersonNoteColumn.PERSON_ID, note.PersonId),
                SpParameter.Create(PersonNoteColumn.TEXT, note.Text),
                SpParameter.Create("IsDeleted", false),
                id,
                SpParameter.ModifiedBy(user)
            };
            await _spExecutor.Execute("dbo.spNote_Update", parameters);
        }

        public async Task Delete(PersonNote note, IUser user)
        {
            var id = SpParameter.CreateInOut(note.Id);
            var parameters = new[]
            {
                SpParameter.Create(PersonNoteColumn.PERSON_ID, note.PersonId),
                SpParameter.Create(PersonNoteColumn.TEXT, note.Text),
                SpParameter.Create("IsDeleted", true),
                id,
                SpParameter.ModifiedBy(user)
            };
            await _spExecutor.Execute("dbo.spNote_Update", parameters);
        }

        public async Task<IList<PersonNote>> Load(PersonId personId)
        {
            var parameter = new[]
            {
                SpParameter.Create("PersonId", personId.Value)
            };

            return await _spExecutor.GetRecords("dbo.spNote_Get", parameter, ToPersonNote);
        }

        private PersonNote ToPersonNote(IRowData row)
        {
            var modifiedTime = row.AsDateTimeStrict(PersonNoteColumn.TIMESTAMP);
            var text = row.AsString(PersonNoteColumn.TEXT);
            var modifiedByName = row.AsString(PersonNoteColumn.MODIFIED_BY_NAME);
            var id = row.AsInt("ID");
            var personId = row.AsInt("PersonId");

            return new PersonNote(id, text, new PersonId(personId), modifiedTime, modifiedByName);
        }
    }
}
