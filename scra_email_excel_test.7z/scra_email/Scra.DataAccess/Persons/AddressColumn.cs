﻿namespace Scra.DataAccess.Persons
{
    internal static class AddressColumn
    {
        public const string ADDRESS1 = "Address1";
        public const string ADDRESS2 = "Address2";
        public const string STATE = "State";
        public const string CITY = "City";
        public const string ZIP = "Zip";
    }
}