﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Dependents;

namespace Scra.DataAccess.Persons
{
    internal class DependentTypeRepository : IDependentTypeRepository
    {
        private readonly SqlExecutor _sqlExecutor;

        public DependentTypeRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<DependentTypeList> GetList()
        {
            var query = "SELECT ID, Type FROM dbo.DependentType ORDER BY Type";
            var items = await _sqlExecutor.Execute(query, ConvertDependentType);
            return DependentTypeList.Create(items);
        }

        private DependentType ConvertDependentType(IRowData record)
        {
            return DependentType.Create(record.AsInt(RefColumn.ID), record.AsString("Type"));
        }
    }
}