﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Scra.DataAccess.Configs;

namespace Scra.DataAccess.Core
{
    public class SpExecutor
    {
        private readonly IDbConfig _config;

        public SpExecutor(IDbConfig config)
        {
            _config = config;
        }

        public async Task Execute(string spName, IEnumerable<SqlParameter> parameters, ITransaction transaction)
        {
            using (var command = new SqlCommand(spName, transaction.GetConnection(), transaction.GetTransaction()))
            {
                command.CommandTimeout = 900;
                await ExecuteImpl(parameters, command);
            }
        }

        public async Task Execute(string spName, IEnumerable<SqlParameter> parameters)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                await connection.OpenAsync();
                using (var command = new SqlCommand(spName, connection))
                {
                    command.CommandTimeout = 1200;
                    await ExecuteImpl(parameters, command);
                }
            }
        }

        private async Task ExecuteImpl(IEnumerable<SqlParameter> parameters, SqlCommand command)
        {

            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 900;
                foreach (var sqlParameter in parameters)
                {
                    command.Parameters.Add(sqlParameter);
                }

                await command.ExecuteNonQueryAsync();
            }
        }

        public async Task<DataTable> GetDataTable(string spName, SqlParameter parameter)
        {
            var dataSet = await GetDataSet(spName, new[] { parameter });
            return dataSet.Tables[0];
        }

        public async Task<DataTable> GetDataTable(string spName,  IEnumerable<SqlParameter> parameters)
        {
            var dataSet = await GetDataSet(spName, parameters);
            return dataSet.Tables[0];
        }

        public async Task<DataSet> GetDataSet(string spName, SqlParameter parameter)
        {
            return await GetDataSet(spName, new[] { parameter });
        }

        public async Task<DataTable> GetDataTableNp(string spName)
        {
            var dataSet = await GetDataSetNp(spName);
            return dataSet.Tables[0];
        }

        public async Task<DataSet> GetDataSetNp(string spName)
        {
            var dataSet = new DataSet();
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(spName, connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 900
                })
                {
                    await connection.OpenAsync();

                    var dataAdapter = new SqlDataAdapter {SelectCommand = command};
                    dataAdapter.Fill(dataSet);

                    return dataSet;
                }
            }
        }

        public async Task<DataSet> GetDataSet(string spName, IEnumerable<SqlParameter> parameters)
        {
            var dataSet = new DataSet();
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(spName, connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 900
                })
                {
                    foreach (var sqlParameter in parameters)
                    {
                        command.Parameters.Add(sqlParameter);
                    }
                    await connection.OpenAsync();

                    var dataAdapter = new SqlDataAdapter {SelectCommand = command};
                    dataAdapter.Fill(dataSet);

                    return dataSet;
                }
            }
        }

        public Task<IList<TResult>> GetRecords<TResult>(string spName, SqlParameter parameter, Func<IRowData, TResult> parser)
        {
            return GetRecords(spName, new[] { parameter }, parser);
        }

        public async Task<IList<TResult>> GetRecords<TResult>(string spName, IEnumerable<SqlParameter> parameters, Func<IRowData, TResult> parser)
        {
            try
            {
                using (var connection = new SqlConnection(_config.ConnectionString))
                {
                    using (var command = new SqlCommand(spName, connection)
                    {
                        CommandType = CommandType.StoredProcedure,
                        CommandTimeout = 900
                    })
                    {
                        foreach (var sqlParameter in parameters)
                        {
                            command.Parameters.Add(sqlParameter);
                        }

                        await connection.OpenAsync();
                        var reader = await command.ExecuteReaderAsync();
                        
                        var res = new List<TResult>();
                        while (await reader.ReadAsync())
                        {
                            var row = RowDataFactory.Create(reader);
                            var record = parser(row);
                            res.Add(record);
                        }

                        return res;
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public Task<TResult> GetRecord<TResult>(string spName, SqlParameter parameter, Func<IDataRecord, TResult> parser)
        {
            return GetRecord(spName, new[] { parameter }, parser);
        }

        public async Task<TResult> GetRecord<TResult>(string spName, IEnumerable<SqlParameter> parameters, Func<IDataRecord, TResult> parser)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(spName, connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 900
                })
                {
                    foreach (var sqlParameter in parameters)
                    {
                        command.Parameters.Add(sqlParameter);
                    }
                    await connection.OpenAsync();
                    var reader = await command.ExecuteReaderAsync();
                    await reader.ReadAsync();
                    return parser(reader);
                }
            }
        }
    }
}