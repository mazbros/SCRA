﻿namespace Scra.DataAccess.Configs
{
    public interface IDbConfig
    {
        string ConnectionString { get; }
    }
}