﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.DataAccess.Persons;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.Inquiries;
using Scra.Model.InquiryTypes;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.DataAccess.Inquiries
{
    internal class InquiryRepository : IInquiryRepository
    {
        private const string FIND_TASK = @"
SELECT Id 
	FROM dbo.Task WHERE InquiryId = @id
order by CreateDate
";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public InquiryRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public async Task<Inquiry> Get(int inquiryId)
        {
            var parameters = new[]
            {
                SpParameter.Create("ID", inquiryId),
            };

            var dataSet = await _spExecutor.GetDataSet("dbo.spInquiry_Get", parameters);
            return ConvertToInquiry(dataSet);
        }

        private ContactMethod GetResponseMethod(IRowData row)
        {
            var contactMethodId = row.AsInt(InquiryColumn.RESPONSE_METHOD_ID);
            var name = row.AsString("ResponseMethodName");
            return ContactMethod.Create(contactMethodId, name);
        }

        private ContactMethod GetContactMethod(IRowData row)
        {
            var contactMethodId = row.AsInt(InquiryColumn.CONTACT_METHOD_ID);
            var name = row.AsString("ContactMethodName");
            return ContactMethod.Create(contactMethodId, name);
        }

        public static async Task<DependentType> GetType(IRowData personRow)
        {
            var dependentTypeList = await DependentTypeList.GetInstance();
            var dependentTypeId = personRow.AsInt(DependentLinkColumn.DEPENDENT_TYPE_ID);
            return dependentTypeList.Get(dependentTypeId);
        }

        public async Task Create(Inquiry inquiry)
        {
            var id = SpParameter.CreateInOut(inquiry.Id);
            var parameters = new[]
            {
                SpParameter.Create(InquiryColumn.INQUIRY_DATE, inquiry.InquiryDate),
                SpParameter.Create(InquiryColumn.AGENT_ID, inquiry.Agent.Id),
                SpParameter.Create(InquiryColumn.CONTACT_METHOD_ID, inquiry.ContactMethod.Id),
                SpParameter.Create(InquiryColumn.PERSON_INQUIRING_ID, inquiry.PersonInquiringId),
                SpParameter.Create(InquiryColumn.SERVICEMEMBER_ID, inquiry.ServicememberId),
                SpParameter.Create(InquiryColumn.DEPENDENT_TYPE_ID, inquiry.DependentType.Id),
                SpParameter.Create(InquiryColumn.INQUIRY_TYPE, inquiry.InquiryType.Code),
                SpParameter.Create(InquiryColumn.DESCRIPTION, inquiry.Description),
                SpParameter.Create(InquiryColumn.IS_ON_ACTIVE_DUTY, inquiry.IsOnActiveDuty),
                SpParameter.Create(InquiryColumn.IDENTIFICATION_METHOD, inquiry.IdentificationMethod.Code),
                SpParameter.ModifiedBy(),
                id
            };

            await _spExecutor.Execute("dbo.spInquiry_Create", parameters);

            inquiry.Id = (int)id.Value;
        }

        public async Task UpdateTitle(Inquiry inquiry)
        {            
            var parameters = new[] { SpParameter.Create("InquiryId", inquiry.Id) };
            await _spExecutor.Execute("dbo.spInquiry_UpdateTitle", parameters);

        }

        public async Task Update(Inquiry inquiry)
        {
            var id = SpParameter.Create(inquiry.Id);
            var parameters = new[]
            {
                SpParameter.Create(InquiryColumn.SCUSA_SENT_DATE_1, inquiry.Scusa.SentDate1),
                SpParameter.Create(InquiryColumn.SCUSA_SENT_DATE_2, inquiry.Scusa.SentDate2),
                SpParameter.Create(InquiryColumn.SCUSA_CONFIRMATION_DATE, inquiry.Scusa.ConfirmationDate),
                SpParameter.Create(InquiryColumn.RESPONSE_TEXT, inquiry.Response.Text),
                SpParameter.Create(InquiryColumn.RESPONSE_DATE, inquiry.Response.Date),
                SpParameter.Create(InquiryColumn.RESPONSE_METHOD_ID, inquiry.Response.Method.Id),
                SpParameter.Create(InquiryColumn.IS_ON_ACTIVE_DUTY, inquiry.IsOnActiveDuty),
                SpParameter.Create(InquiryColumn.DMDC_VALIDATION_DATE, inquiry.DmdcValidationDate),
                SpParameter.Create(InquiryColumn.COMMENT, inquiry.Comment),
                SpParameter.Create(InquiryColumn.IS_COMPLETED, inquiry.IsCompleted),
                SpParameter.ModifiedBy(),
                id
            };

            await _spExecutor.Execute("dbo.spInquiry_Update", parameters);
        }

        public async Task<IList<InquirySnapshot>> Load(string searchText)
        {
            var parameters = new[]
            {
                SpParameter.Create("Search", string.IsNullOrEmpty(searchText) ? string.Empty : searchText),
                SpParameter.Create("SortBy", ""),
                SpParameter.Create("SortDir", "")
            };
            
            return await _spExecutor.GetRecords("dbo.spInquiry_SortedList", parameters, ConvertToInquirySnapshot);
        }

        public async Task<IList<InquirySnapshot>> LoadByPerson(PersonId personId)
        {
            var parameters = new[]
            {
                SpParameter.Create("Search", string.Empty),
                SpParameter.Create("SortBy", ""),
                SpParameter.Create("SortDir", ""),
                SpParameter.Create("PersonId", personId.Value),

            };

            return await _spExecutor.GetRecords("dbo.spInquiry_SortedList", parameters, ConvertToInquirySnapshot);
        }

        public async Task<int> GetTaskByInquiry(int inquiryId)
        {
            var sql = FIND_TASK.Replace("@id", inquiryId.ToString());
            var obj = await _sqlExecutor.GetScalar(sql);
            return (int) (obj ?? 0);
        }

        public async Task SetAcknowledge(int inquiryId, DateTime date)
        {
            var parameters = new[]
            {
                SpParameter.Create(inquiryId),
                SpParameter.Create(InquiryColumn.ACKNOWLEDGE_DATE, date),
                SpParameter.ModifiedBy(),
            };

            await _spExecutor.Execute("dbo.spInquiry_SetAcknowledge", parameters);
        }

        public async Task<IList<InquirySnapshot>> Sort(string searchText, string selectedHeaderName, string direction)
        {
            var parameters = new[]
            {
                SpParameter.Create("Search", string.IsNullOrEmpty(searchText) ? string.Empty : searchText),
                SpParameter.Create("SortBy", selectedHeaderName),
                SpParameter.Create("SortDir", direction)
            };
            
            return await _spExecutor.GetRecords("dbo.spInquiry_SortedList", parameters, ConvertToInquirySnapshot);
        }

        private Inquiry ConvertToInquiry(DataSet set)
        {
            var row = set.GetFirstTableRow();
            var id = row.AsInt(RefColumn.ID);
            var personInquiringId = new PersonId(row.AsInt(InquiryColumn.PERSON_INQUIRING_ID));
            var servicememberId = new PersonId(row.AsInt(InquiryColumn.SERVICEMEMBER_ID));
            var description = row.AsString(InquiryColumn.DESCRIPTION);
            var comments = row.AsString(InquiryColumn.COMMENT);
            var inquiryDate = row.AsDateTimeStrict(InquiryColumn.INQUIRY_DATE);
            var acknowledgeDate = row.AsDateTimeStrict(InquiryColumn.ACKNOWLEDGE_DATE);
            var isCompleted = row.AsBool(InquiryColumn.IS_COMPLETED);
            var identificationMethod = IdentificationMethod.Parse(row.AsString(InquiryColumn.IDENTIFICATION_METHOD));
            
            var contactMethod = GetContactMethod(row);
            var agent = GetAgent(row);
            var type = GetInquiryType(row);
            var dependentType = GetDependentType(row);
            var scusa = GetScusa(row);
            var response = GetResponse(row);
            var isOnActiveDuty = row.AsBool(InquiryColumn.IS_ON_ACTIVE_DUTY);
            var dmdcValidationDate = row.AsDateTime(InquiryColumn.DMDC_VALIDATION_DATE);

            return new Inquiry(id, personInquiringId, servicememberId, contactMethod, agent, inquiryDate, description, type, dependentType,
                scusa, response, comments, acknowledgeDate, isCompleted, identificationMethod, isOnActiveDuty, dmdcValidationDate);
        }

        private InquirySnapshot ConvertToInquirySnapshot(IRowData row)
        {
            var id = row.AsInt(RefColumn.ID);
            var inquiryDate = row.AsDateTimeStrict(InquiryColumn.INQUIRY_DATE);
            var description = row.AsString(InquiryColumn.DESCRIPTION);
            var responseDate = row.AsDateTimeStrict(InquiryColumn.RESPONSE_DATE);
            var acknowledgeDate = row.AsDateTimeStrict(InquiryColumn.ACKNOWLEDGE_DATE);
            var isCompleted = row.AsBool(InquiryColumn.IS_COMPLETED);

            var contactMethod = GetContactMethod(row);
            var agent = GetAgent(row);
            var type = GetInquiryType(row);
            var dependentType = GetDependentType(row);

            var personInquiring = GetPerson(row, "PE_");
            var servicemember = GetPerson(row, "SM_");

            return new InquirySnapshot(id, personInquiring, servicemember, contactMethod, agent, inquiryDate, type, dependentType, 
                description, responseDate, acknowledgeDate, isCompleted);
        }

        private InquiryType GetInquiryType(IRowData row)
        {
            var typeStr = row.AsString(InquiryColumn.INQUIRY_TYPE);
            return InquiryType.Parse(typeStr);
        }

        private InquiryScusa GetScusa(IRowData row)
        {
            var sentDate1 = row.AsDateTime(InquiryColumn.SCUSA_SENT_DATE_1);
            var sentDate2 = row.AsDateTime(InquiryColumn.SCUSA_SENT_DATE_2);
            var confirmationDate = row.AsDateTime(InquiryColumn.SCUSA_CONFIRMATION_DATE);
            return new InquiryScusa {SentDate1 = sentDate1, SentDate2 = sentDate2, ConfirmationDate = confirmationDate};
        }

        private InquiryResponse GetResponse(IRowData row)
        {
            var method = GetResponseMethod(row);
            var date = row.AsDateTime(InquiryColumn.RESPONSE_DATE);
            var text = row.AsString(InquiryColumn.RESPONSE_TEXT);
            return new InquiryResponse {Method = method, Date = date, Text = text};
        }

        private PersonSnapshot GetPerson(IRowData row, string prefix)
        {
            var id = new PersonId(row.AsInt(prefix + RefColumn.ID));
            var firstName = row.AsString(prefix + PersonColumn.FIRST_NAME);
            var middleName = row.AsString(prefix + PersonColumn.MIDDLE_INITIAL);
            var lastName = row.AsString(prefix + PersonColumn.LAST_NAME);
            var name = PersonName.Create(firstName, middleName, lastName);
            return new PersonSnapshot(id, name);
        }

        private IUser GetAgent(IRowData row)
        {
            var assigneeId = new UserId(row.AsInt(InquiryColumn.AGENT_ID));
            var name = row.AsString("AgentName");
            var userName = row.AsString("AgentUserName");
            return User.Create(assigneeId, userName, name);
        }

        private DependentType GetDependentType(IRowData row)
        {
            var id = row.AsInt(InquiryColumn.DEPENDENT_TYPE_ID);
            var name = row.AsString("DependentTypeName");
            return DependentType.Create(id, name);
        }
    }
}