﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.State
{
    public class SingleActDispatcher : IDispatcher
    {
        private readonly IActConsumer _actConsumer;

        public SingleActDispatcher(IActConsumer actConsumer)
        {
            _actConsumer = actConsumer;
        }

        public void Dispatch(string act)
        {
            DispatchImpl(new AmorphAct(act));
        }

        public void Dispatch(IAct act)
        {
            DispatchImpl(act);
        }

        public Task DispatchAsync(string act)
        {
            return DispatchAsync(new AmorphAct(act));
        }

        public Task DispatchAsync(IAct act)
        {
            return Task.Run(() => DispatchImpl(act));
        }

        private void DispatchImpl(IAct action)
        {
            _actConsumer.Consume(new List<IAct> { action });
        }
    }
}