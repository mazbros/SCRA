﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Exceptions;
using Scra.Model.Logs;
using Scra.Model.Tools;

namespace Scra.State
{
    public class Store<TState> : IStore<TState> where TState : IState
    {
        private TState _state;
        private readonly IReducer<TState> _reducer;
        private readonly ConcurrentQueue<IStoreMiddleware<TState>> _middlewares;
        private readonly ILogger _logger;

        public IDispatcher Dispatcher { get; private set; }

        public Store(IReducer<TState> reducer)
        {
            _middlewares = new ConcurrentQueue<IStoreMiddleware<TState>>();
            _logger = Di.Get<ILogger>();
            _reducer = reducer;
            _state = _reducer.GetInitial();

            Dispatcher = new SingleActDispatcher(this);
        }

        public TState GetState()
        {
            return _state;
        }

        public void Subscribe(IStoreMiddleware<TState> middleware)
        {
            _middlewares.Enqueue(middleware);
        }

        public void Consume(IList<IAct> acts)
        {
            try
            {
                _state = ReduceActs(_state, acts);
                CallMiddlewares(acts, _state);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Store");
            }
        }

        private void CallMiddlewares(IList<IAct> acts, TState state)
        {
            foreach (var storeMiddleware in _middlewares)
            {
                Task.Run(() =>
                {
                    try
                    {
                        storeMiddleware.Execute(acts, state);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex, "Store");
                    }
                });
            }
        }

        private TState ReduceActs(TState state, IEnumerable<IAct> acts)
        {
            foreach (var stateAction in acts)
            {
                try
                {
                    state = _reducer.Reduce(state, stateAction);
                }
                catch (Exception ex)
                {
                    var act = stateAction.GetType().Name + " " + stateAction.Code;
                    throw new AppException("Reduce error. " + act, ex);
                }
            }
            return state;
        }
    }
}
