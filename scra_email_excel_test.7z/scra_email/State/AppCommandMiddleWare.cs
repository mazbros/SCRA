﻿using Scra.Model.Logs;

namespace Scra.State
{
    public class AppCommandMiddleWare : CommandMiddleware<AppState>
    {
        public AppCommandMiddleWare(ILogger logger) : 
            base(logger)
        {
        }
    }
}