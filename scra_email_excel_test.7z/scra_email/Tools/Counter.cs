﻿namespace Scra.Tools
{
    public class Counter
    {
        private int _value;

        private Counter(int value)
        {
            _value = value;
        }

        public static Counter Create()
        {
            return new Counter(0);
        }

        public Counter Next()
        {
            _value++;
            return this;
        }

        public bool IsOdd()
        {
            return _value % 2 == 1;
        }

        public bool IsEven()
        {
            return _value % 2 == 0;
        }

        public override string ToString()
        {
            return string.Format("{0} Odd={1}", _value, IsOdd());
        }
    }
}
