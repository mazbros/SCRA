﻿namespace Scra.Tools
{
    public class TryCast
    {
        public static bool Cast<T>(object obj, out T result)
        {
            if (obj is T)
            {
                result = (T)obj;
                return true;
            }

            result = default(T);
            return false;
        }
    }
}