﻿namespace Scra.Tools.Logs
{
    public enum LogSeverity
    {
        None = 0,
        Error = 1,
        Warning = 2,
        Debug = 3
    }
}