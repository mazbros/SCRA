﻿using System;
using System.Threading;
using System.Windows.Input;
using Scra.Model.Tools;
using Scra.State;

namespace Scra.AppCore
{
    public class Command : ICommand
    {
        private readonly Action _targetMethod;
        private readonly Action<object> _targetMethodWithArgs;
        private readonly Func<bool> _targetCanExecuteMethod;
        private readonly int _throttleTimeout;
        private Timer _throttleTimer;
        private object _throttleParameter;

        public Command(Action executeMethod)
            : this(executeMethod, () => true, 0)
        {
            _targetMethod = executeMethod;
        }

        public Command(Action executeMethod, int throttleTimeout)
            : this(executeMethod, () => true, throttleTimeout)
        {
            _targetMethod = executeMethod;
        }

        public Command(Action executeMethod, Func<bool> canExecuteMethod, int throttleTimeout)
        {
            _throttleTimeout = throttleTimeout;
            _targetMethod = executeMethod;
            _targetCanExecuteMethod = canExecuteMethod;
        }

        public Command(Action<object> executeMethod)
            : this(executeMethod, () => true, 0)
        {
        }

        public Command(Action<object> executeMethod, int throttleTimeout)
            : this(executeMethod, () => true, throttleTimeout)
        {
        }

        public Command(Action<object> executeMethod, Func<bool> canExecuteMethod, int throttleTimeout)
        {
            _throttleTimeout = throttleTimeout;
            _targetMethodWithArgs = executeMethod;
            _targetCanExecuteMethod = canExecuteMethod;
        }

        public Command(IAct act)
            : this(act, () => true)
        {
        }

        //public Command(Benefit executeMethod, string act)
        //    : this(new Act(act))
        //{
        //}

        public Command(IAct act, Func<bool> canExecuteMethod)
        {
            var dispatcher = Di.Get<IDispatcher>();
            _targetMethod = () => dispatcher.Dispatch(act);
            _targetCanExecuteMethod = canExecuteMethod;
        }

        public void RaiseCanExecuteChanged()
        {
            if (CanExecuteChanged != null)
            {
                CanExecuteChanged(this, EventArgs.Empty);
            }
        }

        public bool CanExecute()
        {
            return CanExecute(null);
        }

        public bool CanExecute(object parameter)
        {

            if (_targetCanExecuteMethod != null)
            {
                return _targetCanExecuteMethod();
            }
            if (_targetMethod != null)
            {
                return true;
            }
            if (_targetMethodWithArgs != null)
            {
                return true;
            }

            return false;
        }

        public void Execute()
        {
            Execute(null);
        }

        public void Execute(object parameter)
        {
            if (_throttleTimeout > 0)
            {
                if (_throttleTimer == null)
                {
                    _throttleTimer = new Timer(execute, null, _throttleTimeout, Timeout.Infinite);
                }
                _throttleParameter = parameter;
            }
            else
            {
                execute(parameter);
            }
        }

        private void execute(object parameter)
        {
            if (_throttleTimer != null)
            {
                if (_targetMethod != null)
                {
                    _targetMethod();
                }
                if (_targetMethodWithArgs != null)
                {
                    _targetMethodWithArgs(_throttleParameter);
                }
                _throttleTimer.Dispose();
                _throttleTimer = null;
            }
            else
            {
                if (_targetMethod != null)
                {
                    _targetMethod();
                }
                if (_targetMethodWithArgs != null)
                {
                    _targetMethodWithArgs(_throttleParameter);
                }
            }
        }

        public event EventHandler CanExecuteChanged;
    }
}
