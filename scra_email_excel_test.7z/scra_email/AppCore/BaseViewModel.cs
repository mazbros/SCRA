﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Scra.AppCore
{
    public class BaseViewModel : INotifyPropertyChanged, IViewModel
    {
        private bool _isBusy;
        public Action OnViewLoaded { get; set; }
        public Action OnViewClosed { get; set; }

        public Action CloseView { get; set; }
        public object View { get; set; }
        public object Arguments { get; set; }

        public bool IsBusy
        {
            get { return _isBusy;}
            set
            {
                _isBusy = value; OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void SetProperty<T>(ref T member, T val, [CallerMemberName] string propertyName = null)
        {
            if (Equals(member, val)) return;

            member = val;
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [NotifyPropertyChangedInvocator]
        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        protected bool InDesignMode()
        {
            return !(System.Windows.Application.Current is App);
        }

        protected void UpdateAll()
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(null));
            }
        }
    }
}
