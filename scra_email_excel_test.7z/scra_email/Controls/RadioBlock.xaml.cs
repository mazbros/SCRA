﻿using System.Windows;

namespace Scra.Controls
{
    public partial class RadioBlock
    {
        public RadioBlock()
        {
            InitializeComponent();
        }

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }

        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(RadioBlock), new PropertyMetadata(""));


        public string BoolProperty
        {
            get { return (string)GetValue(RadioButtonProperty); }
            set { SetValue(RadioButtonProperty, value);}
        }

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(RadioBlock), new PropertyMetadata("*"));
        
        public static readonly DependencyProperty RadioButtonProperty = DependencyProperty.Register(
            "BoolProperty", typeof(string), typeof(RadioBlock), new PropertyMetadata(""));

        private void ToggleButton_OnChecked(object sender, RoutedEventArgs e)
        {
            var t = BoolProperty;
        }
    }
}
