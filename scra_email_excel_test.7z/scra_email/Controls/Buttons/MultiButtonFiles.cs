﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Scra.Controls.Buttons
{
    public class MultiButtonFiles: Button
    {
        public MultiButtonFiles()
        {
            var items = new Binding
            {
                Source = this,
                Path = new PropertyPath("Props.Items"),
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            BindingOperations.SetBinding(this, ItemsProperty, items);

            MouseRightButtonUp += MultiButton_Click;
        }

        private void MultiButton_Click(object sender, RoutedEventArgs e)
        {
            var template = Template;
            var contextMenu = (ContextMenu)template.FindName("ContextMenu", this);
            contextMenu.IsOpen = true;
        }

        public ObservableCollection<MultiButtonProps.Item> Items
        {
            get { return (ObservableCollection<MultiButtonProps.Item>)GetValue(ItemsProperty); }
            set { SetValue(ItemsProperty, value); }
        }
        public static readonly DependencyProperty ItemsProperty = DependencyProperty.Register(
            "Items", typeof(ObservableCollection<MultiButtonProps.Item>), typeof(MultiButtonFiles), new FrameworkPropertyMetadata(new ObservableCollection<MultiButtonProps.Item>())
        );

        public MultiButtonProps Props
        {
            get { return (MultiButtonProps)GetValue(PropsProperty); }
            set { SetValue(PropsProperty, value); }
        }
        public static readonly DependencyProperty PropsProperty = DependencyProperty.Register(
            "Props", typeof(MultiButtonProps), typeof(MultiButtonFiles), new FrameworkPropertyMetadata(new MultiButtonProps())
        );
    }
}