using System;
using System.Globalization;
using System.Windows.Data;

namespace Scra.Controls.Converters
{
    public class ToolTipDisplay : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is bool && (bool)value)
            {
                return "QA must be done by someone other than yourself";
            }
            return "";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return false;
        }
    }
}