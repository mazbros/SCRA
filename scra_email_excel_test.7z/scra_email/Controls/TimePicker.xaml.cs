﻿using System;
using System.Windows;
using System.Windows.Controls;
using Scra.Extensions;

namespace Scra.Controls
{
    /// <inheritdoc cref="UserControl" />
    /// <summary>
    /// Interaction logic for TimePicker.xaml
    /// </summary>
    public partial class TimePicker
    {
        public string Hours
        {
            get { return (string)GetValue(HoursProperty); }
            set { SetValue(HoursProperty, value); }
        }
        public static readonly DependencyProperty HoursProperty = DependencyProperty.Register(
            "Hours", typeof(string), typeof(TimePicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string Minutes
        {
            get { return (string)GetValue(MinutesProperty); }
            set { SetValue(MinutesProperty, value); }
        }
        public static readonly DependencyProperty MinutesProperty = DependencyProperty.Register(
            "Minutes", typeof(string), typeof(TimePicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string AmPm
        {
            get { return (string) GetValue(AmPmProperty); }
            set { SetValue(AmPmProperty, value); }
        }
        public static readonly DependencyProperty AmPmProperty = DependencyProperty.Register(
            "AmPm", typeof(string), typeof(TimePicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public bool? DisplayCurrentTime
        {
            get { return (bool?) GetValue(DisplayCurrentTimeProperty); }
            set { SetValue(DisplayCurrentTimeProperty, value); }
        }
        public static readonly DependencyProperty DisplayCurrentTimeProperty = DependencyProperty.Register(
            "DisplayCurrentTime", typeof(bool?), typeof(TimePicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public DateTime? TimeValue
        {
            get { return (DateTime?) GetValue(TimeValueProperty); }
            set { SetValue(TimeValueProperty, value); }
        }

        public static DependencyProperty TimeValueProperty  = DependencyProperty.Register(
            "TimeValue", typeof(DateTime?), typeof(TimePicker), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public TimePicker()
        {
            InitializeComponent();

            OnLoad();
        }

        public string[] HoursStrings = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
        public string[] MinutesStrings =
        {
            "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", 
            "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
            "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32",
            "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43",
            "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54",
            "55", "56", "57", "58", "59"
        };

        public string[] AmPmStrings = {"AM", "PM"};

        public void OnLoad()
        {
            CbHours.ItemsSource = HoursStrings;
            CbMinutes.ItemsSource = MinutesStrings;
            CbAmPm.ItemsSource = AmPmStrings;

            var defHoursValue = (DateTime.Now.Hour % 12).ToString("00");
            var defMinutesValue = DateTime.Now.Minute.ToString("00");
            var defAmPmValue = DateTime.Now.ToShortTimeString().Contains("AM") ? "AM" : "PM";

            if (TimeValue != null)
            {
                Hours = (TimeValue.Value.Hour % 12).ToString("00");
                Minutes = TimeValue.Value.Minute.ToString("00");
                AmPm = TimeValue.Value.ToShortTimeString().Contains("AM") ? "AM" : "PM";
            }
            else
            {
                if (DisplayCurrentTime != true) return;

                Hours = defHoursValue;
                Minutes = defMinutesValue;
                AmPm = defAmPmValue;
            }
        }

        private void Cb_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AssignTimeValue();
        }

        private void AssignTimeValue()
        {
            if (Hours != null && Minutes != null && AmPm != null)
            {
                TimeValue = DateTime.Parse(Hours + ":" + Minutes + " " + AmPm);
                if (this.FindParentOfType<TimePickerBlock>() != null)
                {
                    //this.FindParentOfType<TimePickerBlock>().InitTimeValue = TimeValue;
                }
            }

        }

    }
}
