﻿namespace Scra.Controls.Modules
{
    public partial class SaveCancelModuleView
    {
        public SaveCancelModuleView()
        {
            InitializeComponent();
        }

        public SaveCancelModuleViewModel GetViewModel()
        {
            return (SaveCancelModuleViewModel) DataContext;
        }
    }
}
