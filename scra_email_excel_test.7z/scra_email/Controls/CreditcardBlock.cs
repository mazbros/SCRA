﻿using System.Windows;
using Scra.Model.Contracts;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public class CreditCardBlock : MaskBlock
    {
        public CreditCardBlock()
        {
            Setup(@"\d{4} \d{4} \d{4} \{4}", CreditCard.Empty().GetDisplay(), new[] { '-' });

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public CreditCard Value
        {
            get
            {
                var text = (string) GetValue(TextValueProperty);
                return CreditCard.Parse(text);
            }
            set
            {
                SetValue(ValueProperty, value);
                SetValue(TextValueProperty, value.GetDisplay());
            }
        }

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(CreditCard), typeof(CreditCardBlock), 
            new FrameworkPropertyMetadata(CreditCard.Empty(), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ValueChange));

        private static void ValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var creditCard = (CreditCard) e.NewValue;
            d.SetValue(TextValueProperty, creditCard.GetDisplay());
        }

        protected override void InputTextChanged(string newValue)
        {
            var creditCard = CreditCard.Parse(newValue);
            Value = creditCard;
        }
    }
}
