﻿using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.DataAccess.Configs;
using Scra.Model.Configs;
using Scra.Model.DomainEvents;
using Scra.Model.Logs;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;
using Scra.Tools.Logs;
using Scra.Views.Tasks;

namespace Scra.Configs
{
    public class DiScraModule
    {
        public static void Register()
        {
#if DEBUG
            AppConfig.IsDebug = true;
#endif
            DiModelModule.Register();
            DiDataAccessModule.Register();

            Di.Set<IMessageDialog, MessageDialog>();
            Di.Set<IViewNavigator, ViewNavigator>();
            Di.Set<TaskAssigneeControlModelFactory>();

            RegisterInstances();
        }

        private static void RegisterInstances()
        {
            Di.Set<ILogger>(CreateLogger());
            Di.Set<IUiThread>(new UiThread());

            Di.Set<AppCommandMiddleWare>();
            var store = new AppStore(new AppReducer());
            var dispatcher = store.Dispatcher;
            Di.Set<IDispatcher>(dispatcher);
            Di.Set<IAppStore>(store);

            Di.Set<AppNavigator>(new AppNavigator(Di.Get<IViewNavigator>(), dispatcher, Di.Get<IUiThread>()));
            Di.Set<IDomainEventDispatcher>(Di.Get<IDomainEventDispatcher>());
        }

        private static ILogger CreateLogger()
        {
            var logger = new Logger();
            logger.AddAppender(new FileLogAppender());
            return logger;
        }
    }
}
