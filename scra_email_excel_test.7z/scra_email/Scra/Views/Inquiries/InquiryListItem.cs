﻿using System;
using System.Windows;
using Scra.Model.Inquiries;

namespace Scra.Views.Inquiries
{
    public class InquiryListItem
    {
        public int Id { get; private set; }
        public DateTime RequestDate { get; private set; }
        public string Agent { get; private set; }
        public string ContactMethod { get; private set; }
        public string PersonInquiring { get; private set; }
        public string Servicemember { get; private set; }
        public string Relationship { get; private set; }
        public string InquiryType { get; private set; }
        public string InquiryDescription { get; private set; }
        public DateTime AcknowledgeDate { get; private set; }
        public DateTime ResponseDate { get; private set; }
        public bool IsVisible { get; set; }
        public bool IsComplete { get; private set; }
        
        public static InquiryListItem Create(InquirySnapshot inquiry)
        {
            return new InquiryListItem
            {
                Id = inquiry.Id,
                RequestDate = inquiry.InquiryDate,/*Formatter.Date(inquiry.InquiryDate),*/
                Agent = inquiry.Agent.DisplayName,
                ContactMethod = inquiry.ContactMethod.Name,
                PersonInquiring = inquiry.PersonInquiring.Name.FullName,
                Servicemember = inquiry.Servicemember.Name.FullName,
                Relationship = inquiry.DependentType.Name,
                InquiryType = inquiry.InquiryType.Name,
                InquiryDescription = inquiry.Description,
                AcknowledgeDate = inquiry.AcknowledgeDate,/*Formatter.Date(inquiry.AcknowledgeDate),*/
                ResponseDate = inquiry.ResponseDate,/*Formatter.Date(inquiry.ResponseDate),*/
                IsVisible = inquiry.IsCompleted,
                IsComplete = inquiry.IsCompleted
            };
        }
    }
}