﻿using System;
using System.Threading.Tasks;
using Scra.Controls.MessageDialog;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Views.Files;

namespace Scra.Views.PersonDashboard
{
    //TODO: refactor. NoteList and DocumentList should be splitted.
    public partial class PersonDocumentListWidget
    {
        private readonly IMessageDialog _messageDialog;
        private const string FILE_ENTITY = "Person";

        public PersonDocumentListWidget()
        {
            InitializeComponent();
            _messageDialog = Di.Get<IMessageDialog>();
        }

        public async Task Load(Person person)
        {
            try
            {
                var control = new PersonalNoteWidget();
                ListPanel.Children.Add(control);
                var viewModel = (PersonalNoteWidgetModel) control.DataContext;
                await viewModel.Load(person, person.Name.FullName);

                foreach (var link in person.DependentLinks)
                {
                    control = new PersonalNoteWidget();
                    ListPanel.Children.Add(control);
                    viewModel = (PersonalNoteWidgetModel) control.DataContext;

                    var dependent = await link.GetDependent();
                    await viewModel.Load(dependent, dependent.Name.FullName + " — " + link.Type.Name);
                }
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during loading person notes.");
            }
        }

        public async Task Load(Person person, string fileCategory, string attachFiles)
        {
            var control = new FileAttachmentsControl();
            ListPanel.Children.Add(control);
            var viewModel = (FileAttachmentsControlModel)control.DataContext;
            await viewModel.Load(person.Id.Value, FILE_ENTITY, person.Name.FullName);

            foreach (var link in person.DependentLinks)
            {
                control = new FileAttachmentsControl();
                ListPanel.Children.Add(control);
                viewModel = (FileAttachmentsControlModel)control.DataContext;

                var dependent = await link.GetDependent();
                await viewModel.Load(dependent.Id.Value, "Person", dependent.Name.FullName + " — " + link.Type.Name);
            }
        }
    }
}
