﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Communication;
using Scra.Model.Letters;

namespace Scra.Views.PersonDashboard
{
    public class CommunicationsListItem
    {
        public static CommunicationsListItem Create(ProductCommunication communication, Action<ProductCommunication> showCommunication)
        {
            return new CommunicationsListItem
            {
                //Title = string.IsNullOrEmpty(communication.ResponseText) ? GetLetterName(communication.LetterId) : communication.ResponseText,
                Title = GetLetterName(communication.LetterId),
	            CommunicationDate = Formatter.Date(communication.CommunicationDate),                
                Id = communication.CommunicationId,
                DoubleClickCommand = new Command(() => showCommunication(communication)),
			};
        }

        private static string GetLetterName(int communicationLetterId)
        {
            return Task<string>.Factory.StartNew(() => GetLetterNameAsync(communicationLetterId).ConfigureAwait(false).GetAwaiter().GetResult()).Result;
        }

        private static async Task<string> GetLetterNameAsync(int communicationLetterId)
        {
            var letters = await LetterList.GetInstance();
            return letters.Get(communicationLetterId).LongDescription;
        }


        public string Title { get; set; }
	    public string CommunicationDate { get; set; }
        public int Id { get; set; }
        public ICommand DoubleClickCommand { get; set; }
    }
    
}