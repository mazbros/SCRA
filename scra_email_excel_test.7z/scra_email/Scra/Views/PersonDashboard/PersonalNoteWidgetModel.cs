﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Views.PersonDashboard
{
    public class PersonalNoteWidgetModel : BaseViewModel
    {
        private Person _person;
        private Visibility _isViewMode;
        private Visibility _isEditMode;
        private string _text;
        private bool _showLess;
        private readonly IUser _user;

        private readonly IPersonNoteRepository _repository;
        private readonly IMessageDialog _messageDialog;
        private string _showButtonContent;
        private Visibility _showMoreButtonVisible;
        private string _title;
        private const int MAX_ROWS_FOR_SHOW_LESS = 3;
        private const string SHOW_MORE_BUTTON_CONTENT = "SHOW MORE";
        private const string SHOW_LESS_BUTTON_CONTENT = "SHOW LESS";

        public PersonalNoteWidgetModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _repository = Di.Get<IPersonNoteRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
			PersonNoteList = new ObservableCollection<PersonNoteListItem>();
            AddPersonalNoteCommand = new Command(AddNote);
            SaveCommand = new Command(Save);
            CancelCommand = new Command(CancelAddNote);
            ShowMoreCommand = new Command(ShowMoreOrLessNote);

            _user = Di.Get<IUser>();

            _isViewMode = Visibility.Visible;
            _isEditMode = Visibility.Collapsed;
            _showLess = true;
            _showButtonContent = SHOW_MORE_BUTTON_CONTENT;
            _showMoreButtonVisible = Visibility.Hidden;
        }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand AddPersonalNoteCommand { get; set; }
        public ICommand ShowMoreCommand { get; set; }        
        public ObservableCollection<PersonNoteListItem> PersonNoteList { get; set; }

        public PersonNote PersonNote {get;set;}

        public string ShowButtonContent
        {
            get { return _showButtonContent; }
            set { SetProperty(ref _showButtonContent, value); }
        }

        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }

        public Visibility IsViewMode
        {
            get { return _isViewMode; }
            set { SetProperty(ref _isViewMode, value); }
        }
        public Visibility IsEditMode
        {
            get { return _isEditMode; }
            set { SetProperty(ref _isEditMode, value); }
        }

        public Visibility ShowMoreButtonVisibility
        {
            get { return _showMoreButtonVisible; }
            set { SetProperty(ref _showMoreButtonVisible, value); }
        }

        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value);}
        }

        public async Task Load(Person person, string title)
        {
            _person = person;
            Title = title;
            await ReLoad(person.Id);
        }

        private async Task ReLoad(PersonId personId)
        {
            var result = await _repository.Load(personId);
	        var isGuestUser = _user.Type.Equals(UserType.Guest);

			var vms = result.Select(x => PersonNoteListItem.Create(x, EditNote, DeleteNote, isGuestUser)).ToList();
            ShowMoreButtonVisibility = vms.Count > MAX_ROWS_FOR_SHOW_LESS ? Visibility.Visible : Visibility.Hidden;
            PersonNoteList.Update(_showLess ? vms.Take(MAX_ROWS_FOR_SHOW_LESS) : vms);
        }

        private void ClearTextBox()
        {
            Text = "";
        }

        private void CancelAddNote()
        {
            SwitchToViewMode();
            ClearTextBox();
        }

        private void AddNote()
        {
			SwitchToEditMode();
            ClearTextBox();
			if(PersonNote != null)
				PersonNote.Id = 0;
		}

        private void EditNote(PersonNote note)
        {
	        if (_user.Type.Equals(UserType.Guest))
		        return;

			SwitchToEditMode();
            PersonNote = note;
            FillView();
        }

        private async void DeleteNote(PersonNote note)
        {
            var r = _messageDialog.ConfirmationBinary("Are you sure to delete the note: \n" + note.Text + "?");
            if (r == MessageBoxResult.No)
            {
                return;
            }

            await _repository.Delete(note, _user);
            await ReLoad(_person.Id);
        }

        private void FillView()
        {
            if(PersonNote != null)
                Text = PersonNote.Text;
        }

        private void SwitchToEditMode()
        {
            IsViewMode = Visibility.Collapsed;
            IsEditMode = Visibility.Visible;
        }

        private async void SwitchToViewMode()
        {
            IsViewMode = Visibility.Visible;
            IsEditMode = Visibility.Collapsed;
            await ReLoad(_person.Id);
        }

        private async void Save()
        {
            try
            {
                var personNote = FillModel();
                ValidateModel(personNote);
                await _repository.Create(personNote, _user);
                SwitchToViewMode();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
        }

        private async void ShowMoreOrLessNote()
        {
            _showLess = !_showLess;

            ShowButtonContent = _showLess ? SHOW_MORE_BUTTON_CONTENT : SHOW_LESS_BUTTON_CONTENT;

            await ReLoad(_person.Id);
        }

        private void ValidateModel(PersonNote personNote)
        {
            if (personNote.Text.IsEmpty())
            {
                throw new UserException("Please enter a note.");
            }
        }

        private PersonNote FillModel()
        {
            if(PersonNote == null)
                return new PersonNote(Text, _person.Id);

            PersonNote.Text = Text;
            return PersonNote;
        }
    }
}
