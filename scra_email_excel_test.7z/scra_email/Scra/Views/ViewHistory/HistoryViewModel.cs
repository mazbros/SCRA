﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Contracts;
using Scra.Model.History;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;

namespace Scra.Views.ViewHistory
{
    public class HistoryViewModel : BaseViewModel
    {
        private readonly AppNavigator _navigator;
        private readonly IPersonRepository _personRepository;
        private readonly IUiThread _uiThread;
        private readonly IHistoryRepository _historyRepository;

        public string Title { get; set; }
        public IList<Person> PersonEditHistory { get; set; }
        public IList<ActiveDuty> ActiveDutyHistory { get; set; }
        public IList<Contract> ContractHistory { get; set; }
        public bool PersonEditHistoryAvailable { get; set; }

        public Person CurrentPerson { get; set; }
        public ICommand TitleClicked { get; set; }

        public ObservableCollection<ActiveDutyHistoryVm> ActiveDutyHistoryList { get; set; }
        public ObservableCollection<ContractHistoryVm> ContractHistoryList { get; set; }

        public HistoryViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            var appStore = Di.Get<IAppStore>();
            _personRepository = Di.Get<IPersonRepository>();
            _historyRepository = Di.Get<IHistoryRepository>();
            _uiThread = Di.Get<IUiThread>();

            TitleClicked = new Command(OnTitleClicked);

            appStore.SubscribeCommand(Act.LOAD_PERSON_HISTORY, LoadPersonHistory);
            OnViewLoaded = Load;
        }

        private void OnTitleClicked()
        {
            if(CurrentPerson != null)
                _navigator.PersonDashboard(CurrentPerson.Id);
        }

        private async void LoadPersonHistory(IAct obj)
        {
            var act = (PersonEditHistoryAct)obj;
            var personId = new PersonId(act.Id);
            var timestamp = act.Timestamp;

            await GetContractInformation(personId, timestamp);
            await GetPersonalInformation(personId, timestamp);
            await GetActiveDutyInformation(personId, timestamp);

            _uiThread.Execute(FillView);
        }

        private async Task GetPersonalInformation(PersonId personId, DateTime? timestamp)
        {
            CurrentPerson = await _personRepository.Get(personId);
            PersonEditHistory = await _personRepository.LoadEditHistoryByPerson(personId.Value, timestamp);
        }

        private async Task GetActiveDutyInformation(PersonId personId, DateTime? timestamp)
        {
            ActiveDutyHistory = await _historyRepository.GetActiveDutyHistory(personId.Value, timestamp);

            var idList = ActiveDutyHistory.Select(x => x.Id).Distinct().ToList();
            ActiveDutyHistoryList = new ObservableCollection<ActiveDutyHistoryVm>();
            foreach (var id in idList)
            {
                var activeDutyHistory = ActiveDutyHistory.Where(x => x.Id == id).ToList();
                if (activeDutyHistory.Count <= 0) continue;
                var modifiedDate = activeDutyHistory.FirstOrDefault();
                if (modifiedDate != null && (modifiedDate.ModifiedDate != null && modifiedDate.ModifiedDate > timestamp))
                    ActiveDutyHistoryList.Add(ActiveDutyHistoryVm.Create(activeDutyHistory));
            }
        }

        private async Task GetContractInformation(PersonId personId, DateTime? timestamp)
        {
            ContractHistory = await _historyRepository.GetContractHistory(personId.Value, timestamp);

            var idList = ContractHistory.Select(x => x.Id).Distinct().ToList();
            ContractHistoryList = new ObservableCollection<ContractHistoryVm>();
            foreach (var id in idList)
            {
                var contractHistory = ContractHistory.Where(x => x.Id == id).ToList();
                if (contractHistory.Count <= 0) continue;
                var modifiedDate = contractHistory.FirstOrDefault();
                if (modifiedDate != null && (modifiedDate.ModifiedDate != null && modifiedDate.ModifiedDate > timestamp))
                    ContractHistoryList.Add(ContractHistoryVm.Create(contractHistory));
            }
        }

        private void Load()
        {
            Reload();            
        }

        private void Reload()
        {
            _uiThread.Execute(FillView);
        }

        private void FillView()
        {
            PersonEditHistoryAvailable = PersonEditHistory != null && PersonEditHistory.Count > 0;
            var fullName = CurrentPerson != null ? "(" + CurrentPerson.Name.FullName + ")" : "";
            Title = "View Edit History " + fullName;        
            UpdateAll();
        }
    }

    public class ActiveDutyHistoryVm
    {

        public bool ActiveDutyHistoryAvailable { get; set; }
        public IList<ActiveDuty> ActiveDutyHistory { get; set; }
        public string Title { get; set; }

        public static ActiveDutyHistoryVm Create(IList<ActiveDuty> activeDutyHistory)
        {
            var activeDutyHistoryVm = new ActiveDutyHistoryVm();
            var currentActiveDuty = activeDutyHistory.FirstOrDefault();
            var activeDutyHistoryAvailable = activeDutyHistory.Count > 0;
            var endDate = activeDutyHistoryAvailable ? currentActiveDuty != null && currentActiveDuty.EndDate.HasValue ? Formatter.Date(currentActiveDuty.EndDate) : "present" : "";

            if (currentActiveDuty == null) return activeDutyHistoryVm;
            var title = activeDutyHistoryAvailable
                ? "Active Duty " + "(" + Formatter.Date(currentActiveDuty.StartDate) + " - " + endDate + ")"
                : "";

            activeDutyHistoryVm = new ActiveDutyHistoryVm
            {
                ActiveDutyHistory = activeDutyHistory,
                ActiveDutyHistoryAvailable = activeDutyHistoryAvailable,
                Title = title,
            };

            return activeDutyHistoryVm;
        }
    }

    public class ContractHistoryVm
    {
        public bool ContractHistoryAvailable { get; set; }
        public IList<Contract> ContractHistory { get; set; }
        public string Title { get; set; }

        public static ContractHistoryVm Create(IList<Contract> contractHistory)
        {
            var contractHistoryVm = new ContractHistoryVm();
            var currentContract = contractHistory.FirstOrDefault();
            var activeDutyHistoryAvailable = contractHistory.Count > 0;
            if (currentContract == null) return contractHistoryVm;
            var title = activeDutyHistoryAvailable
                ? "Contract Information (" + currentContract.Category.Name + (currentContract.ContractProductName.Length == 0 ? "" : " - ") +
                  currentContract.ContractProductName + ")"
                : "";

            contractHistoryVm = new ContractHistoryVm
            {
                ContractHistory = contractHistory,
                ContractHistoryAvailable = activeDutyHistoryAvailable,
                Title = title,
            };

            return contractHistoryVm;
            
        }
    }
}
