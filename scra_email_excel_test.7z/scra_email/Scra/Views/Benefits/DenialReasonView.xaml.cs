﻿using System.Windows.Controls;

namespace Scra.Views.Benefits
{
    /// <summary>
    /// Interaction logic for DenialReasonView.xaml
    /// </summary>
    public partial class DenialReasonView : UserControl
    {
        public DenialReasonView()
        {
            InitializeComponent();
        }
    }
}
