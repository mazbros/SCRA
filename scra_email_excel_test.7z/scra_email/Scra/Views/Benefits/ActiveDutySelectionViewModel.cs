﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tools;

namespace Scra.Views.Benefits
{
    public class ActiveDutySelectionViewModel: BaseViewModel
    {
        private readonly IPersonRepository _personRepository;
        private PersonId _personId;
        private AppNavigator _navigator;

        public string ServiceMemberName { get; set; }
        public bool HasActiveDuty { get; set; }
        public IList<ActiveDutyListItem> ActiveDutyList { get; set; }
        public string Title { get; set; }
        public ICommand TitleClicked { get; set; }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public bool EmbeddedMode { get; set; }

        public ActiveDutySelectionViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            _personRepository = Di.Get<IPersonRepository>();
            TitleClicked = new Command(GotoPersonDashboard);
            
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);

            OnViewLoaded = Load;
        }
        private void Cancel()
        {
            var na = (NavigatorArguments)Arguments;
            //na.NavigatorArgumentList[1] = null;
            CloseView();
        }

        private void Save()
        {
            var na = (NavigatorArguments)Arguments;

            na.NavigatorArgumentList.Add(ActiveDutyList.Where(x => x.IsSelected).Select(x=>x.ActiveDuty).OrderBy(x=>x.StartDate).ToList());
            CloseView();
        }

        private void GotoPersonDashboard()
        {
            _navigator.PersonDashboard(_personId);
        }

        public async Task Load(PersonId personId)
        {
            EmbeddedMode = true;
            _personId = personId;
            await Reload();
        }

        public async void Load()
        {
            EmbeddedMode = false;
            var na = (NavigatorArguments)Arguments;
            _personId = (PersonId)na.NavigatorArgumentList[0];

            await Reload();
        }

        private async Task Reload()
        {
            var person = await _personRepository.Get(_personId);
            var serviceMember = await person.GetServiceMember();

            FillView(serviceMember);
        }

        private void FillView(ServiceMember serviceMember)
        {
            HasActiveDuty = serviceMember.ActiveDuties.Count > 0;
            if (HasActiveDuty)
            {
                ServiceMemberName = "Servicemember (" + serviceMember.Name.FullName + ")";

                ActiveDutyList = new List<ActiveDutyListItem>();
                foreach (var activeDuty in serviceMember.ActiveDuties)
                {
                    ActiveDutyList.Add(ActiveDutyListItem.Create(activeDuty));
                }

               //SelectedActiveDuty = ActiveDutyList.FirstOrDefault();
            }
            UpdateAll();
        }
    }
}
