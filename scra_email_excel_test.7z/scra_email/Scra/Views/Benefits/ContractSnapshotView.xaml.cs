﻿using System.Windows;
using System.Windows.Input;

namespace Scra.Views.Benefits
{
    /// <summary>
    /// Interaction logic for ContractSnapshotView.xaml
    /// </summary>
    public partial class ContractSnapshotView
    {
        public ContractSnapshotView()
        {
            InitializeComponent();
        }

        public ContractSnapshotViewModel GetViewModel()
        {
            return (ContractSnapshotViewModel)DataContext;
        }

        private void BenefitListView_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectCommand.Execute(null);
        }
    }
}
