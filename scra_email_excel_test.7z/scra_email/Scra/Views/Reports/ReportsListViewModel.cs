﻿using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Reports;
using Scra.Model.Tools;
using Scra.Tools;
using Scra.Views.Shell;
using System;
//using System.Collections;
//using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
//using System.ComponentModel;
using System.IO;
//using System.Linq;
//using System.Reflection;
//using System.Text;
using System.Windows.Input;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using System.Runtime.InteropServices;
using System.Drawing;
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;

namespace Scra.Views.Reports
{
    public class ReportsListViewModel : BaseViewModel
    {
        private readonly IReportsRepository _repository;

        //private readonly IContractRepository _contractRepository;
        private readonly IMessageDialog _messageDialog;
        private readonly ShellViewModel _shellViewModel;

        //private List<WeeklyControlReportItem> _items;
        //private List<ViewLetterHistoryReportItem> _letterReportLines;
        //private List<ServicememberExpiredDeniedActiveReportItem> _servicememberExpiredDeniedActiveReportLines;
        //private List<ServicememberExpiredDeniedActiveReport2Item> _servicememberExpiredDeniedActiveReport2Lines;
        //private List<ServicememberMonthlyIncomingGnLetterSentReportItem> _servicememberMonthlyIncomingGnLetterSentReportLines;
        //private List<ServicememberActiveDutyReportItem> _servicememberActiveDutyReportLines;
        //private List<TaskStatusReportItem> _taskStatusReportItems;
        //private List<OpenActiveBenefitsReportItem> _openActiveBenefitsReportLines;
        //private List<CurrentlyReceivingBenefitsReportItem> _currentlyReceivingBenefitsReportLines;

        //private List<ThirtyDaysListReportItem> _reportLines;
        //private List<PromoRateEndReportItem> _promoRateEndReportLines;
        //private List<DmdcValidationReportItem> _dmdcValidationReportLines;
        //private List<InquiriesReportItem> _inquiriesReportLines;
        //private List<AffiliateReportItem> _affiliateReportLines;
        //private List<BenefitsReportItem> _openActiveBenefitsReportLines;
        //private List<BenefitsReportItem> _currentlyReceivingBenefitsReportLines;
        //private List<BenefitsReportItem> _newAccountsReportLines;
        //private List<BenefitsReportItem> _expiredAccountsReportLines;
        //private List<DeniedAccountsReportItem> _deniedAccountsReportLines;

        //private TaskType _selectedTaskType;

        //private Visibility _visibility;
        //private Visibility _visibility2;
        //private Visibility _visibility3;

        //private string _interval;
        //private string _interval2;

        private readonly AppNavigator _navigator;

        public ObservableCollection<ContractCategory> Categories { get; set; }
        private ContractCategory _contractCategory;
        private ContractCategoryList _contractCategories;

        public ReportsListViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _shellViewModel = Di.Get<ShellViewModel>();
            _repository = Di.Get<IReportsRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _navigator = Di.Get<AppNavigator>();

            OnViewLoaded = OnLoaded;

            //RunWeeklyControlReportCommand = new Command(RunWeeklyControlReport);
            //RunViewLetterHistoryReportCommand = new Command(RunViewLetterHistoryReport);
            //RunServicememberExpiredDeniedActiveReportCommand = new Command(RunServicememberExpiredDeniedActiveReport);
            //RunServicememberExpiredDeniedActiveReport2Command = new Command(RunServicememberExpiredDeniedActiveReport2);
            //RunServicememberMonthlyIncomingGnLetterSentReportCommand = new Command(RunServicememberMonthlyIncomingGnLetterSentReport);
            //RunServicememberActiveDutyReportCommand = new Command(RunServicememberActiveDutyReport);
            //RunWeeklyTaskStatusReportCommand = new Command(RunTaskStatusReport);

            RunThirtyDaysListReportCommand = new Command(RunThirtyDaysListReport);
            RunPromoRateEndReportCommand = new Command(RunPromoRateEndReport);
            RunDmdcValidationReportCommand = new Command(RunDmdcValidationReport);
            RunInquiriesReportCommand = new Command(RunInquiriesReport);
            RunAffiliateReportCommand = new Command(RunAffiliateReport);
            RunOpenActiveBenefitsReportCommand = new Command(RunOpenActiveBenefitsReport);
            RunCurrentlyReceivingBenefitsReportCommand = new Command(RunCurrentlyReceivingBenefitsReport);
            RunNewAccountsReportCommand = new Command(RunNewAccountsReport);
            RunExpiredAccountsReportCommand = new Command(RunExpiredAccountsReport);
            RunDeniedAccountsReportCommand = new Command(RunDeniedAccountsReport);

            // TaskTypes = new ObservableCollection<TaskType>(TaskType.TaskTypeList().ToList());

            //_contractRepository = Di.Get<IContractRepository>();
            Categories = new ObservableCollection<ContractCategory>();
        }

        //public ICommand RunWeeklyControlReportCommand { get; set; }
        //public ICommand RunViewLetterHistoryReportCommand { get; set; }
        //public ICommand RunServicememberExpiredDeniedActiveReportCommand { get; set; }
        //public ICommand RunServicememberExpiredDeniedActiveReport2Command { get; set; }
        //public ICommand RunServicememberMonthlyIncomingGnLetterSentReportCommand { get; set; }
        //public ICommand RunServicememberActiveDutyReportCommand { get; set; }
        //public ICommand RunWeeklyTaskStatusReportCommand { get; set; }

        public ICommand RunThirtyDaysListReportCommand { get; set; }
        public ICommand RunPromoRateEndReportCommand { get; set; }
        public ICommand RunDmdcValidationReportCommand { get; set; }
        public ICommand RunInquiriesReportCommand { get; set; }
        public ICommand RunAffiliateReportCommand { get; set; }
        public ICommand RunOpenActiveBenefitsReportCommand { get; set; }
        public ICommand RunCurrentlyReceivingBenefitsReportCommand { get; set; }
        public ICommand RunNewAccountsReportCommand { get; set; }
        public ICommand RunExpiredAccountsReportCommand { get; set; }
        public ICommand RunDeniedAccountsReportCommand { get; set; }

        //public Visibility IsDateVisible
        //{
        //    get { return _visibility; }
        //    set { SetProperty(ref _visibility, value); }
        //}

        //public Visibility IsDateVisible2
        //{
        //    get { return _visibility2; }
        //    set { SetProperty(ref _visibility2, value); }
        //}

        //public Visibility IsDateVisible3
        //{
        //    get { return _visibility3; }
        //    set { SetProperty(ref _visibility3, value); }
        //}

        //private List<WeeklyControlReportItem> Items
        //{
        //    get { return _items; }
        //    set { SetProperty(ref _items, value); }
        //}

        //private List<ThirtyDaysListReportItem> ThirtyDaysListReportLines
        //{
        //    get { return _reportLines; }
        //    set { SetProperty(ref _reportLines, value); }
        //}

        //private List<ViewLetterHistoryReportItem> ViewLetterHistoryReportLines
        //{
        //    get { return _letterReportLines; }
        //    set { SetProperty(ref _letterReportLines, value); }
        //}

        //private List<ServicememberExpiredDeniedActiveReportItem> ServicememberExpiredDeniedActiveReportLines
        //{
        //    get { return _servicememberExpiredDeniedActiveReportLines; }
        //    set { SetProperty(ref _servicememberExpiredDeniedActiveReportLines, value); }
        //}

        //private List<ServicememberExpiredDeniedActiveReport2Item> ServicememberExpiredDeniedActiveReport2Lines
        //{
        //    get { return _servicememberExpiredDeniedActiveReport2Lines; }
        //    set { SetProperty(ref _servicememberExpiredDeniedActiveReport2Lines, value); }
        //}

        //private List<PromoRateEndReportItem> PromoRateEndReportLines
        //{
        //    get { return _promoRateEndReportLines; }
        //    set { SetProperty(ref _promoRateEndReportLines, value); }
        //}

        //private List<ServicememberMonthlyIncomingGnLetterSentReportItem> ServicememberMonthlyIncomingGnLetterSentReportLines
        //{
        //    get { return _servicememberMonthlyIncomingGnLetterSentReportLines; }
        //    set { SetProperty(ref _servicememberMonthlyIncomingGnLetterSentReportLines, value); }
        //}

        //private List<ServicememberActiveDutyReportItem> ServicememberActiveDutyReportLines
        //{
        //    get { return _servicememberActiveDutyReportLines; }
        //    set { SetProperty(ref _servicememberActiveDutyReportLines, value); }
        //}

        //private List<DmdcValidationReportItem> DmdcValidationReportLines
        //{
        //    get { return _dmdcValidationReportLines; }
        //    set { SetProperty(ref _dmdcValidationReportLines, value); }
        //}

        //private List<InquiriesReportItem> InquiriesReportLines
        //{
        //    get { return _inquiriesReportLines; }
        //    set { SetProperty(ref _inquiriesReportLines, value); }
        //}

        //private List<AffiliateReportItem> AffiliateReportLines
        //{
        //    get { return _affiliateReportLines; }
        //    set { SetProperty(ref _affiliateReportLines, value); }
        //}

        //private List<OpenActiveBenefitsReportItem> OpenActiveBenefitsReportLines
        //{
        //    get { return _openActiveBenefitsReportLines; }
        //    set {  SetProperty(ref _openActiveBenefitsReportLines, value);}
        //}

        //private List<BenefitsReportItem> OpenActiveBenefitsReportLines
        //{
        //    get { return _openActiveBenefitsReportLines; }
        //    set { SetProperty(ref _openActiveBenefitsReportLines, value); }
        //}

        //private List<CurrentlyReceivingBenefitsReportItem> CurrentlyReceivingBenefitsReportLines
        //{
        //    get { return _currentlyReceivingBenefitsReportLines; }
        //    set { SetProperty(ref _currentlyReceivingBenefitsReportLines, value); }
        //}

        //private List<BenefitsReportItem> CurrentlyReceivingBenefitsReportLines
        //{
        //    get { return _currentlyReceivingBenefitsReportLines; }
        //    set { SetProperty(ref _currentlyReceivingBenefitsReportLines, value); }
        //}

        //private List<BenefitsReportItem> NewAccountsReportLines
        //{
        //    get { return _newAccountsReportLines; }
        //    set { SetProperty(ref _newAccountsReportLines, value); }
        //}

        //private List<BenefitsReportItem> ExpiredAccountsReportLines
        //{
        //    get { return _expiredAccountsReportLines; }
        //    set { SetProperty(ref _expiredAccountsReportLines, value); }
        //}

        //private List<DeniedAccountsReportItem> DeniedAccountsReportLines
        //{
        //    get { return _deniedAccountsReportLines; }
        //    set { SetProperty(ref _deniedAccountsReportLines, value); }
        //}

        //public ObservableCollection<TaskType> TaskTypes { get; set; }

        //private List<TaskStatusReportItem> TaskStatusReportLines
        //{
        //    get { return _taskStatusReportItems; }
        //    set { SetProperty(ref _taskStatusReportItems, value); }
        //}

        //public TaskType SelectedTaskType
        //{
        //    get { return _selectedTaskType; }
        //    set { SetProperty(ref _selectedTaskType, value); }
        //}

        //public string Interval
        //{
        //    get { return _interval; }
        //    set
        //    {
        //        SetProperty(ref _interval, value);
        //        //_visibility = value == "Weekly" || value == "Monthly" ? Visibility.Visible : Visibility.Collapsed;
        //        //ReportDate2 = value == "Weekly" || value == "Monthly" ? ReportDate2 : null;
        //        UpdateAll();
        //    }
        //}

        //public string Interval2
        //{
        //    get { return _interval2; }
        //    set
        //    {
        //        SetProperty(ref _interval2, value);
        //        //_visibility2 = value == "Year" || value == "Month" ? Visibility.Visible : Visibility.Collapsed;
        //        ReportDate3 = value == "Year" || value == "Month" ? ReportDate3 : null;
        //        UpdateAll();
        //    }
        //}

        //public string Interval3
        //{
        //    get { return _interval3; }
        //    set
        //    {
        //        SetProperty(ref _interval3, value);
        //        _visibility3 = value == "Year" || value == "Month" ? Visibility.Visible : Visibility.Collapsed;
        //        ReportDate4 = value == "Year" || value == "Month" ? ReportDate4 : null;
        //        UpdateAll();
        //    }
        //}

        //public DateTime? ReportDate { get; set; }

        public DateTime? ReportDate2 { get; set; }
        public DateTime? ReportDate3 { get; set; }

        //public DateTime? ReportDate4 { get; set; }
        //public DateTime? ReportDate5 { get; set; }

        private DateTime? RunDate { get; set; }
        private DateTime? RunDate2 { get; set; }
        private string ProductCategory { get; set; }

        private void OnLoaded()
        {
            _navigator.CloseLeftPanel();

            //_selectedTaskType = TaskType.ALL;
            //_interval = "Weekly";
            //_interval2 = "Month";

            //_visibility = Visibility.Visible;
            //_visibility2 = Visibility.Visible;
            //_visibility3 = Visibility.Visible;

            _contractCategories = ContractCategoryList.Create(ContractCategoryList.ITEMS);

            Categories.Update(_contractCategories.All());
            Categories.Insert(1, new ContractCategory("all", "All"));
            Categories.Insert(5, new ContractCategory("consumer_loan_home_equity", "Consumer Loan + Home Equity"));

            UpdateAll();
        }

        public ContractCategory Category
        {
            get { return _contractCategory; }
            set { SetProperty(ref _contractCategory, value); }
        }

        //private async void RunWeeklyControlReport()
        //{
        //    RunDate = ReportDate;
        //    if (RunDate != null)
        //    {
        //        _shellViewModel.IsUiBusy = true;

        //        var items = await _repository.Load(RunDate);
        //        Items = items.AsEnumerable().ToList();
        //        if (Items.Count > 0)
        //        {
        //            var exportData = BuildReportString(Items);

        //            _shellViewModel.IsUiBusy = false;

        //            ExportToFile(exportData, "Weekly_Control_Report");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = false;
        //            _messageDialog.Warning("There is nothing to report. Please try the other date.");
        //        }
        //    }
        //    else
        //    {
        //        _messageDialog.Warning("Please select date");
        //    }
        //}

        //private async void RunThirtyDaysListReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "30DaysList";
        //    var items = await _repository.Load(Activator.CreateInstance<ThirtyDaysListReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ThirtyDaysListReportItem>();

        //    ThirtyDaysListReportLines = list.AsEnumerable().ToList();

        //    if (ThirtyDaysListReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ThirtyDaysListReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        private async void RunThirtyDaysListReport()
        {
            RunDate = null;
            RunDate2 = null;
            ProductCategory = "";
            const string REPORT_NAME = "30DaysList";

            _shellViewModel.IsUiBusy = true;

            var data = await _repository.LoadDt(REPORT_NAME);

            if (data.Rows.Count > 0)
            {
                _shellViewModel.IsUiBusy = false;

                ExportToExcel(data, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        //private async void RunViewLetterHistoryReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "ViewLetterHistory";
        //    var items = await _repository.Load(Activator.CreateInstance<ViewLetterHistoryReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ViewLetterHistoryReportItem>();

        //    ViewLetterHistoryReportLines = list.AsEnumerable().ToList();

        //    if (ViewLetterHistoryReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ViewLetterHistoryReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        //private async void RunServicememberExpiredDeniedActiveReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Servicemember_Expired_Denied_Active";
        //    var items = await _repository.Load(Activator.CreateInstance<ServicememberExpiredDeniedActiveReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ServicememberExpiredDeniedActiveReportItem>();

        //    ServicememberExpiredDeniedActiveReportLines = list.AsEnumerable().ToList();

        //    if (ServicememberExpiredDeniedActiveReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ServicememberExpiredDeniedActiveReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;
        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        //private async void RunServicememberExpiredDeniedActiveReport2()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Servicemember_Expired_Denied_Active_2";
        //    var items = await _repository.Load(Activator.CreateInstance<ServicememberExpiredDeniedActiveReport2Item>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ServicememberExpiredDeniedActiveReport2Item>();

        //    ServicememberExpiredDeniedActiveReport2Lines = list.AsEnumerable().ToList();

        //    if (ServicememberExpiredDeniedActiveReport2Lines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ServicememberExpiredDeniedActiveReport2Lines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;
        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        //private async void RunPromoRateEndReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Servicemember_Promo_Rate_End";
        //    var items = await _repository.Load(Activator.CreateInstance<PromoRateEndReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<PromoRateEndReportItem>();

        //    PromoRateEndReportLines = list.AsEnumerable().ToList();

        //    if (PromoRateEndReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(PromoRateEndReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        private async void RunPromoRateEndReport()
        {
            RunDate = null;
            RunDate2 = null;
            ProductCategory = "";
            const string REPORT_NAME = "Promo_Rate_End";

            _shellViewModel.IsUiBusy = true;

            var data = await _repository.LoadDt(REPORT_NAME);

            if (data.Rows.Count > 0)
            {
                _shellViewModel.IsUiBusy = false;

                ExportToExcel(data, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        //private async void RunServicememberMonthlyIncomingGnLetterSentReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Servicemember_Monthly_Incoming_GN_Letter_Sent";
        //    var items = await _repository.Load(Activator.CreateInstance<ServicememberMonthlyIncomingGnLetterSentReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ServicememberMonthlyIncomingGnLetterSentReportItem>();

        //    ServicememberMonthlyIncomingGnLetterSentReportLines = list.AsEnumerable().ToList();

        //    if (ServicememberMonthlyIncomingGnLetterSentReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ServicememberMonthlyIncomingGnLetterSentReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        //private async void RunServicememberActiveDutyReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Servicemember_Active_Duty";
        //    var items = await _repository.Load(Activator.CreateInstance<ServicememberActiveDutyReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<ServicememberActiveDutyReportItem>();

        //    ServicememberActiveDutyReportLines = list.AsEnumerable().ToList();

        //    if (ServicememberActiveDutyReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(ServicememberActiveDutyReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;
        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        //private async void RunTaskStatusReport()
        //{
        //    RunDate = ReportDate2;

        //    if (RunDate != null || Interval == "All")
        //    {
        //        _shellViewModel.IsUiBusy = true;

        //        const string REPORT_NAME = "Task_Status";
        //        var items = await _repository.Load(Interval, ReportDate2, SelectedTaskType.Code);
        //        var objList = (IList)items;
        //        var list = objList.Cast<TaskStatusReportItem>();

        //        TaskStatusReportLines = list.AsEnumerable().ToList();

        //        if (TaskStatusReportLines.Count > 0)
        //        {
        //            var exportData = BuildReportString(TaskStatusReportLines);

        //            _shellViewModel.IsUiBusy = false;

        //            var strMonth = Interval == "Monthly" ? "_" + string.Format("{0:MMMyyyy}", RunDate) : string.Empty;

        //            ExportToFile(exportData, Interval + "_" + REPORT_NAME + strMonth);
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = false;

        //            _messageDialog.Warning("There is nothing to report. Please try other date.");
        //        }
        //    }
        //    else
        //    {
        //        if (Interval == "Weekly" || Interval == "Monthly")
        //        {
        //            _messageDialog.Warning("Please select date");
        //        }
        //    }
        //}

        //private async void RunDmdcValidationReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "DMDC_Validation";
        //    var items = await _repository.Load(Activator.CreateInstance<DmdcValidationReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<DmdcValidationReportItem>();

        //    DmdcValidationReportLines = list.AsEnumerable().ToList();

        //    if (DmdcValidationReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(DmdcValidationReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        private async void RunDmdcValidationReport()
        {
            RunDate = null;
            RunDate2 = null;
            ProductCategory = "";
            const string REPORT_NAME = "DMDC_Validation";

            _shellViewModel.IsUiBusy = true;

            var data = await _repository.LoadDt(REPORT_NAME);

            if (data.Rows.Count > 0)
            {
                _shellViewModel.IsUiBusy = false;

                ExportToExcel(data, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        //private async void RunInquiriesReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Inquiries";
        //    var items = await _repository.Load(Activator.CreateInstance<InquiriesReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<InquiriesReportItem>();

        //    InquiriesReportLines = list.AsEnumerable().ToList();

        //    if (InquiriesReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(InquiriesReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        private async void RunInquiriesReport()
        {
            RunDate = null;
            RunDate2 = null;
            ProductCategory = "";
            const string REPORT_NAME = "Inquiries";

            _shellViewModel.IsUiBusy = true;

            var data = await _repository.LoadDt(REPORT_NAME);

            if (data.Rows.Count > 0)
            {
                _shellViewModel.IsUiBusy = false;

                ExportToExcel(data, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        //private async void RunAffiliateReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Affiliate";
        //    var items = await _repository.Load(Activator.CreateInstance<AffiliateReportItem>(), REPORT_NAME);
        //    var objList = (IList)items;
        //    var list = objList.Cast<AffiliateReportItem>();

        //    AffiliateReportLines = list.AsEnumerable().ToList();

        //    if (AffiliateReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(AffiliateReportLines);

        //        _shellViewModel.IsUiBusy = false;

        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;

        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }
        //}

        private async void RunAffiliateReport()
        {
            RunDate = null;
            RunDate2 = null;
            ProductCategory = "";
            const string REPORT_NAME = "Affiliate";
            
            _shellViewModel.IsUiBusy = true;
            
            var data = await _repository.LoadDt(REPORT_NAME);

            if (data.Rows.Count > 0)
            {
                _shellViewModel.IsUiBusy = false;

                ExportToExcel(data, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        //private async void RunBenefitPopulationReport()
        //{
        //    _shellViewModel.IsUiBusy = true;

        //    const string REPORT_NAME = "Benefit_Population";
        //    var items = await _repository.Load(Activator.CreateInstance<OpenActiveBenefitsReportItem>(), REPORT_NAME);
        //    var objList = (IList) items;
        //    var list = objList.Cast<OpenActiveBenefitsReportItem>();
        //    OpenActiveBenefitsReportLines = list.AsEnumerable().ToList();

        //    if (OpenActiveBenefitsReportLines.Count > 0)
        //    {
        //        var exportData = BuildReportString(OpenActiveBenefitsReportLines);
        //        _shellViewModel.IsUiBusy = false;
        //        ExportToFile(exportData, REPORT_NAME);
        //    }
        //    else
        //    {
        //        _shellViewModel.IsUiBusy = false;
        //        _messageDialog.Warning("There is nothing to report. Please try again later.");
        //    }

        //}


        private async void RunOpenActiveBenefitsReport()
        {
            RunDate = ReportDate2;
            RunDate2 = ReportDate3;
            ProductCategory = "";
            const string REPORT_NAME = "Open_Active_Benefits";

            if (RunDate != null && RunDate2 != null)
            {
                if (RunDate > RunDate2)
                {
                    _messageDialog.Warning("Start date cannot be greater than end date");
                }
                else
                {
                    _shellViewModel.IsUiBusy = true;

                    var data = await _repository.LoadOpenActiveDt(RunDate, RunDate2);

                    if (data.Rows.Count > 0)
                    {
                        _shellViewModel.IsUiBusy = false;

                        ExportToExcel(data, REPORT_NAME);
                    }
                    else
                    {
                        _shellViewModel.IsUiBusy = false;
                        _messageDialog.Warning("There is nothing to report. Please try again later.");
                    }
                }
            }
            else
            {
                var message = "";
                if (RunDate == null)
                {
                    message += "Please select start date\n";
                }

                if (RunDate2 == null)
                {
                    message += "Please select end date\n";
                }

                _messageDialog.Warning(message);
            }
        }

        //private async void RunOpenActiveBenefitsReport()
        //{
        //    RunDate = ReportDate2;
        //    RunDate2 = ReportDate3;

        //    if (RunDate != null && RunDate2 != null)
        //    {
        //        if (RunDate > RunDate2)
        //        {
        //            _messageDialog.Warning("Start date cannot be greater than end date");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = true;

        //            const string REPORT_NAME = "Open_Active_Benefits";
        //            var items = await _repository.LoadOpenActive(ReportDate2, ReportDate3);
        //            var objList = (IList) items;
        //            var list = objList.Cast<BenefitsReportItem>();
        //            OpenActiveBenefitsReportLines = list.AsEnumerable().ToList();

        //            if (OpenActiveBenefitsReportLines.Count > 0)
        //            {
        //                var exportData = BuildReportString(OpenActiveBenefitsReportLines);
        //                _shellViewModel.IsUiBusy = false;

        //                var strDate = string.Format("{0:MMddyyyy}", RunDate).ToUpper() + "-" + string.Format("{0:MMddyyyy}", RunDate2);
        //                ExportToFile(exportData, strDate + "_" + REPORT_NAME);
        //            }
        //            else
        //            {
        //                _shellViewModel.IsUiBusy = false;
        //                _messageDialog.Warning("There is nothing to report. Please try again later.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var message = "";
        //        if (RunDate == null)
        //        {
        //            message += "Please select start date\n";
        //        }
        //        if (RunDate2 == null)
        //        {
        //            message += "Please select end date";
        //        }

        //        _messageDialog.Warning(message);
        //    }
        //}

        private async void RunCurrentlyReceivingBenefitsReport()
        {
            RunDate = ReportDate2;
            RunDate2 = ReportDate3;
            ProductCategory = Category.Name;
            const string REPORT_NAME = "Currently_Receiving_Benefits";

            if (RunDate != null && RunDate2 != null && Category.Name != null)
            {
                if (RunDate > RunDate2)
                {
                    _messageDialog.Warning("Start date cannot be greater than end date");
                }
                else
                {
                    _shellViewModel.IsUiBusy = true;

                    
                    var data = await _repository.LoadCurrentlyReceivingDt(ReportDate2, ReportDate3, Category.Name);
                    
                    if (data.Rows.Count > 0)
                    {
                        _shellViewModel.IsUiBusy = false;

                        ExportToExcel(data, REPORT_NAME);
                    }
                    else
                    {
                        _shellViewModel.IsUiBusy = false;
                        _messageDialog.Warning("There is nothing to report. Please try again later.");
                    }
                }
            }
            else
            {
                var message = "";
                if (RunDate == null)
                {
                    message += "Please select start date\n";
                }
                if (RunDate2 == null)
                {
                    message += "Please select end date\n";
                }
                if (Category.Name == null || Category.Name != null && Category.Name.Length == 0)
                {
                    message += "Please select product category";
                }
                _messageDialog.Warning(message);
            }
        }

        //private async void RunCurrentlyReceivingBenefitsReport()
        //{
        //    RunDate = ReportDate2;
        //    RunDate2 = ReportDate3;

        //    if (RunDate != null && RunDate2 != null && Category.Name != null)
        //    {
        //        if (RunDate > RunDate2)
        //        {
        //            _messageDialog.Warning("Start date cannot be greater than end date");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = true;

        //            const string REPORT_NAME = "Currently_Receiving_Benefits";
        //            var items = await _repository.LoadCurrentlyReceiving(ReportDate2, ReportDate3, Category.Name);
        //            var objList = (IList)items;
        //            //var list = objList.Cast<CurrentlyReceivingBenefitsReportItem>();
        //            var list = objList.Cast<BenefitsReportItem>();
        //            //CurrentlyReceivingBenefitsReportLines = list.AsEnumerable().ToList();
        //            CurrentlyReceivingBenefitsReportLines = list.AsEnumerable().ToList();

        //            //if (CurrentlyReceivingBenefitsReportLines.Count > 0)
        //            if (CurrentlyReceivingBenefitsReportLines.Count > 0)
        //            {
        //                //var exportData = BuildReportString(CurrentlyReceivingBenefitsReportLines);
        //                var exportData = BuildReportString(CurrentlyReceivingBenefitsReportLines);
        //                _shellViewModel.IsUiBusy = false;

        //                var strDate = string.Format("{0:MMddyyyy}", RunDate).ToUpper() + "-" + string.Format("{0:MMddyyyy}", RunDate2);
        //                ExportToFile(exportData, strDate + "_" + REPORT_NAME);
        //            }
        //            else
        //            {
        //                _shellViewModel.IsUiBusy = false;
        //                _messageDialog.Warning("There is nothing to report. Please try again later.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var message = "";
        //        if (RunDate == null)
        //        {
        //            message += "Please select start date\n";
        //        }
        //        if (RunDate2 == null)
        //        {
        //            message += "Please select end date\n";
        //        }
        //        if (Category.Name == null || Category.Name != null && Category.Name.Length == 0)
        //        {
        //            message += "Please select product category";
        //        }
        //        _messageDialog.Warning(message);
        //    }
        //}

        private async void RunNewAccountsReport()
        {
            RunDate = ReportDate2;
            RunDate2 = ReportDate3;
            ProductCategory = "";
            const string REPORT_NAME = "New_Accounts";

            if (RunDate != null && RunDate2 != null)
            {
                if (RunDate > RunDate2)
                {
                    _messageDialog.Warning("Start date cannot be greater than end date");
                }
                else
                {
                    _shellViewModel.IsUiBusy = true;

                    var data = await _repository.LoadNewAccountsDt(RunDate, RunDate2);

                    if (data.Rows.Count > 0)
                    {
                        _shellViewModel.IsUiBusy = false;

                        ExportToExcel(data, REPORT_NAME);
                    }
                    else
                    {
                        _shellViewModel.IsUiBusy = false;
                        _messageDialog.Warning("There is nothing to report. Please try again later.");
                    }
                }
            }
            else
            {
                var message = "";
                if (RunDate == null)
                {
                    message += "Please select start date\n";
                }
                if (RunDate2 == null)
                {
                    message += "Please select end date\n";
                }
                _messageDialog.Warning(message);
            }
        }

        //private async void RunNewAccountsReport()
        //{
        //    RunDate = ReportDate2;
        //    RunDate2 = ReportDate3;

        //    if (RunDate != null && RunDate2 != null)
        //    {
        //        if (RunDate > RunDate2)
        //        {
        //            _messageDialog.Warning("Start date cannot be greater than end date");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = true;

        //            const string REPORT_NAME = "New_Accounts";
        //            var items = await _repository.LoadNewAccounts(ReportDate2, ReportDate3);
        //            var objList = (IList)items;
        //            var list = objList.Cast<BenefitsReportItem>();
        //            NewAccountsReportLines = list.AsEnumerable().ToList();

        //            if (NewAccountsReportLines.Count > 0)
        //            {
        //                var exportData = BuildReportString(NewAccountsReportLines);
        //                _shellViewModel.IsUiBusy = false;

        //                var strDate = string.Format("{0:MMddyyyy}", RunDate).ToUpper() + "-" + string.Format("{0:MMddyyyy}", RunDate2);
        //                ExportToFile(exportData, strDate + "_" + REPORT_NAME);
        //            }
        //            else
        //            {
        //                _shellViewModel.IsUiBusy = false;
        //                _messageDialog.Warning("There is nothing to report. Please try again later.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var message = "";
        //        if (RunDate == null)
        //        {
        //            message += "Please select start date\n";
        //        }
        //        if (RunDate2 == null)
        //        {
        //            message += "Please select end date";
        //        }

        //        _messageDialog.Warning(message);
        //    }
        //}

        private async void RunExpiredAccountsReport()
        {
            RunDate = ReportDate2;
            RunDate2 = ReportDate3;
            ProductCategory = "";
            const string REPORT_NAME = "Expired_Accounts";

            if (RunDate != null && RunDate2 != null)
            {
                if (RunDate > RunDate2)
                {
                    _messageDialog.Warning("Start date cannot be greater than end date");
                }
                else
                {
                    _shellViewModel.IsUiBusy = true;

                    var data = await _repository.LoadExpiredAccountsDt(RunDate, RunDate2);

                    if (data.Rows.Count > 0)
                    {
                        _shellViewModel.IsUiBusy = false;

                        ExportToExcel(data, REPORT_NAME);
                    }
                    else
                    {
                        _shellViewModel.IsUiBusy = false;
                        _messageDialog.Warning("There is nothing to report. Please try again later.");
                    }
                }
            }
            else
            {
                var message = "";
                if (RunDate == null)
                {
                    message += "Please select start date\n";
                }
                if (RunDate2 == null)
                {
                    message += "Please select end date\n";
                }
                _messageDialog.Warning(message);
            }
        }

        //private async void RunExpiredAccountsReport()
        //{
        //    RunDate = ReportDate2;
        //    RunDate2 = ReportDate3;

        //    if (RunDate != null && RunDate2 != null)
        //    {
        //        if (RunDate > RunDate2)
        //        {
        //            _messageDialog.Warning("Start date cannot be greater than end date");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = true;

        //            const string REPORT_NAME = "Expired_Accounts";
        //            var items = await _repository.LoadExpiredAccounts(ReportDate2, ReportDate3);
        //            var objList = (IList)items;
        //            var list = objList.Cast<BenefitsReportItem>();
        //            ExpiredAccountsReportLines = list.AsEnumerable().ToList();

        //            if (ExpiredAccountsReportLines.Count > 0)
        //            {
        //                var exportData = BuildReportString(ExpiredAccountsReportLines);
        //                _shellViewModel.IsUiBusy = false;

        //                var strDate = string.Format("{0:MMddyyyy}", RunDate).ToUpper() + "-" + string.Format("{0:MMddyyyy}", RunDate2);
        //                ExportToFile(exportData, strDate + "_" + REPORT_NAME);
        //            }
        //            else
        //            {
        //                _shellViewModel.IsUiBusy = false;
        //                _messageDialog.Warning("There is nothing to report. Please try again later.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var message = "";
        //        if (RunDate == null)
        //        {
        //            message += "Please select start date\n";
        //        }
        //        if (RunDate2 == null)
        //        {
        //            message += "Please select end date";
        //        }

        //        _messageDialog.Warning(message);
        //    }
        //}

        //private async void RunDeniedAccountsReport()
        //{
        //    RunDate = ReportDate2;
        //    RunDate2 = ReportDate3;

        //    if (RunDate != null && RunDate2 != null)
        //    {
        //        if (RunDate > RunDate2)
        //        {
        //            _messageDialog.Warning("Start date cannot be greater than end date");
        //        }
        //        else
        //        {
        //            _shellViewModel.IsUiBusy = true;

        //            const string REPORT_NAME = "Denied_Accounts";
        //            var items = await _repository.LoadDeniedAccounts(ReportDate2, ReportDate3);
        //            var objList = (IList)items;
        //            var list = objList.Cast<DeniedAccountsReportItem>();
        //            DeniedAccountsReportLines = list.AsEnumerable().ToList();

        //            if (DeniedAccountsReportLines.Count > 0)
        //            {
        //                var exportData = BuildReportString(DeniedAccountsReportLines);
        //                _shellViewModel.IsUiBusy = false;

        //                var strDate = string.Format("{0:MMddyyyy}", RunDate).ToUpper() + "-" + string.Format("{0:MMddyyyy}", RunDate2);
        //                ExportToFile(exportData, strDate + "_" + REPORT_NAME);
        //            }
        //            else
        //            {
        //                _shellViewModel.IsUiBusy = false;
        //                _messageDialog.Warning("There is nothing to report. Please try again later.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        var message = "";
        //        if (RunDate == null)
        //        {
        //            message += "Please select start date\n";
        //        }
        //        if (RunDate2 == null)
        //        {
        //            message += "Please select end date";
        //        }

        //        _messageDialog.Warning(message);
        //    }
        //}

        private async void RunDeniedAccountsReport()
        {
            RunDate = ReportDate2;
            RunDate2 = ReportDate3;
            ProductCategory = "";
            const string REPORT_NAME = "Denied_Accounts";

            if (RunDate != null && RunDate2 != null)
            {
                if (RunDate > RunDate2)
                {
                    _messageDialog.Warning("Start date cannot be greater than end date");
                }
                else
                {
                    _shellViewModel.IsUiBusy = true;

                    var data = await _repository.LoadDeniedAccountsDt(RunDate, RunDate2);

                    if (data.Rows.Count > 0)
                    {
                        _shellViewModel.IsUiBusy = false;

                        ExportToExcel(data, REPORT_NAME);
                    }
                    else
                    {
                        _shellViewModel.IsUiBusy = false;
                        _messageDialog.Warning("There is nothing to report. Please try again later.");
                    }
                }
            }
            else
            {
                var message = "";
                if (RunDate == null)
                {
                    message += "Please select start date\n";
                }
                if (RunDate2 == null)
                {
                    message += "Please select end date\n";
                }
                _messageDialog.Warning(message);
            }
        }

        private void ExportToExcel(DataTable data, string REPORT_NAME)
        {
            var StrDateRange = (RunDate != null ? string.Format("{0:MMddyyyy}", RunDate) + "-" : "") +
                               (RunDate2 != null ? string.Format("{0:MMddyyyy}", RunDate2) : "");
            var StrDate = string.Format("{0:MMddyyyy}", DateTime.Today);
            var FileName = (StrDateRange.Length > 0 ? StrDateRange + "_" : "") + REPORT_NAME +
                           "_" + (ProductCategory.Length > 0 ? ProductCategory.Replace(" ", "_") + "_" : "") + StrDate;
            var TempFolder = DirectoryUtility.GetTempDirectory();
            var FilePath = Path.Combine(TempFolder, FileName + ".xlsx");

            try
            {
                var excel = new Application();

                var wb = excel.Workbooks.Add();
                var ws = (Worksheet) wb.ActiveSheet;

                for (var Idx = 0; Idx < data.Columns.Count; Idx++)
                {
                    ws.Range["A1"].Offset[0, Idx].Value = data.Columns[Idx].ColumnName;
                }

                for (var Idx = 0; Idx < data.Rows.Count; Idx++)
                {
                    ws.Range["A2"].Offset[Idx].Resize[1, data.Columns.Count].Value = data.Rows[Idx].ItemArray;
                }

                var Header = ws.Range["A1"].Offset[0].Resize[1, data.Columns.Count].Columns;
                Header.Cells.Interior.Color = Color.Red;
                Header.Cells.Font.Color = Color.White;
                Header.Cells.Font.Bold = true;

                var SourceRange = ws.UsedRange;
                FormatAsTable(SourceRange, "Table1", "TableStyleMedium17");
                SourceRange.Columns.AutoFit();

                // SOLUTION FOR LONG VERTICAL COMMENTS EXPANDING THE HEIGHT OF THE ROW
                for (var Idx = 1; Idx < data.Rows.Count; Idx++)
                {
                    if (ws.Range["A2"].Offset[Idx].Resize[1, data.Columns.Count].Height > 15)
                    {
                        ws.Range["A2"].Offset[Idx].Resize[1, data.Columns.Count].EntireRow.RowHeight = 15;
                    }
                }

                ws.Name = FileName.Length > 31 ? FileName.Substring(0, 31) : FileName;

                excel.DisplayAlerts = false;
                
                ws.Range["A1"].Select();

                //ws.Activate();
                ws.Application.ActiveWindow.SplitRow = 1;
                ws.Application.ActiveWindow.FreezePanes = true;

                try
                {
                    wb.SaveAs(FilePath, XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                        false,
                        false,
                        XlSaveAsAccessMode.xlNoChange, XlSaveConflictResolution.xlLocalSessionChanges, Type.Missing, Type.Missing);
                }
                catch (COMException ex)
                {
                    if (ex.Message.StartsWith("Cannot access '" + FileName + ".xlsx'."))
                        _messageDialog.Warning("The file you are trying to save is already open.\n Please close it and try again.");
                    _shellViewModel.IsUiBusy = false;
                    return;
                }

                //Cleanup
                GC.Collect();
                GC.WaitForPendingFinalizers();
                wb.Close(true,FilePath,Type.Missing);
                excel.Quit();
                Marshal.FinalReleaseComObject(SourceRange);
                Marshal.FinalReleaseComObject(Header);
                Marshal.FinalReleaseComObject(ws);
                Marshal.FinalReleaseComObject(wb);
                Marshal.FinalReleaseComObject(excel);

                if (FileHelper.IsFileLocked(FilePath))
                {
                    var message = string.Format("File {0} is locked. Please, close the file and repeat export.", FileName + ".xlsx");
                    _messageDialog.Warning(message);
                }
                else
                {
                    FileHelper.Open(FilePath);
                }
            }
            catch (COMException ex)
            {
                _messageDialog.Warning("Error accessing Excel: " + ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Warning("Error: " + ex);
            }

            //Kill EXCEL COM processes
            var PROC = Process.GetProcessesByName("EXCEL");
            foreach (var PK in PROC)
            {
                //User process always have window name, COM process do not
                if (PK.MainWindowTitle.Length == 0)
                {
                    PK.Kill();
                }
            }

            _shellViewModel.IsUiBusy = false;
        }

        //private void ExportToFile(string exportData, string fileName)
        //{
        //    var date = RunDate != null && fileName.StartsWith("Weekly") ? (DateTime)RunDate : DateTime.Today;

        //    var firstDayOfWeek = DateExtension.FirstDayOfWeek(date).ToString("MMdd");
        //    var lastDayOfWeek = DateExtension.LastDayOfWeek(date).ToString("MMddyyyy");
        //    var interval = firstDayOfWeek + "-" + lastDayOfWeek;

        //    var today = date.ToString("MMddyyyy");

        //    var FileName = fileName + "_" + (fileName.StartsWith("Weekly") ? interval : today) + ".csv";
        //    var TempFolder = DirectoryUtility.GetTempDirectory();
        //    var filePath = Path.Combine(TempFolder, FileName);

        //    if (FileHelper.IsFileLocked(filePath))
        //    {
        //        var message = string.Format("File {0} is locked. Please, close the file and repeat export.", filePath);
        //        _messageDialog.Warning(message);
        //    }
        //    else
        //    {
        //        File.WriteAllText(filePath, exportData);
        //        FileHelper.Open(filePath);
        //    }
        //}

        //private static string BuildReportString(IEnumerable obj)
        //{
        //    var builder = new StringBuilder();
        //    var type = obj.GetType().GetTypeInfo().GenericTypeArguments[0];
        //    var header = type.GetProperties().Aggregate(string.Empty,
        //        (current, prop) => current + (prop.GetCustomAttribute<DisplayNameAttribute>().DisplayName + ","));
        //    builder.AppendLine(header.Substring(0, header.Length - 1));

        //    foreach (var item in obj)
        //    {
        //        var row = item.GetType().GetProperties().Aggregate("\"", (current, prop) => current + (prop.GetValue(item, null) + "\",\""));
        //        builder.AppendLine(row.Substring(0, row.Length - 2));
        //    }

        //    return builder.ToString();
        //}

        public void FormatAsTable(Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
                    SourceRange, Type.Missing, XlYesNoGuess.xlYes, Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
        }
            }

}