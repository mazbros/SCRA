﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Users;

namespace Scra.Views.Tasks
{
    public class TaskAssigneeAdminControlModel : BaseControlModel
    {
        private bool _isTextMode;
        private string _assigneeName;
        private readonly int _taskId;
        private readonly Func<int, IUser, Task> _updateAction;
        private IList<User> _users;
        private User _selectedUser;

        public TaskAssigneeAdminControlModel(int taskId, IUser assignee, bool isTextMode, Func<int, IUser, Task> updateAction, UserList userList)
        {
            _taskId = taskId;
            _updateAction = updateAction;
            IsTextMode = isTextMode;
            if (assignee != null)
            {
                AssigneeName = assignee.DisplayName;
            }

            AssignCommand = new Command(Assign);
            FillUsers(userList, assignee);
        }

        private void FillUsers(UserList userList, IUser assignee)
        {
            var users = userList.AllNotReadOnly().ToList();
            users.Insert(0, User.Empty);
            Users = users.ToList();

            if (assignee != null)
            {
                SelectedUser = users.FirstOrDefault(x => x.Id == assignee.Id);
            }
        }

        public bool IsTextMode
        {
            get { return _isTextMode; }
            set { SetProperty(ref _isTextMode, value); }
        }

        public string AssigneeName
        {
            get { return _assigneeName; }
            set { SetProperty(ref _assigneeName, value); }
        }

        public IList<User> Users
        {
            get { return _users; }
            set { SetProperty(ref _users, value); }
        }

        public User SelectedUser
        {
            get { return _selectedUser; }
            set { SetProperty(ref _selectedUser, value); }
        }

        public ICommand AssignCommand { get; private set; }

        private async void Assign()
        {            
            await _updateAction(_taskId, SelectedUser);
        }
    }
}