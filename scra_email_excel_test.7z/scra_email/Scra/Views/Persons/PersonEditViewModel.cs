﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Controls.Modules;
using Scra.Model.ContactMethods;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;
using Scra.Views.Shell;

namespace Scra.Views.Persons
{
    public class PersonEditViewModel : BaseViewModel
    {
        private readonly IPersonRepository _repository;
        private readonly IContractRepository _contractRepository;
        private readonly IMessageDialog _messageDialog;
        private ShellViewModel _shellViewModel;

        private PersonId _personId;
        private readonly AppNavigator _navigator;
        private ContactMethod _contactMethod;
        private ContactMethodList _contactMethods;
        private string _fNumber;
        private readonly IDispatcher _dispatcher;
        private readonly IUser _user;

        public PersonEditViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            SubTaskIdentifier = SubTaskType.PersonDetails;

            _repository = Di.Get<IPersonRepository>();
            _contractRepository = Di.Get<IContractRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _navigator = Di.Get<AppNavigator>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();
            _user = Di.Get<IUser>();
            
            ContactMethods = new ObservableCollection<ContactMethod>();
            OnViewLoaded = Load;

            ImportCommand = new Command(Import);

			IsFNumberValidated = false;
        }

	    private void UpdateFNumber()
	    {
		    FNumberFormattedText = FNumber.Format(FNumberText);
	    }

	    public SubTaskType SubTaskIdentifier { get; private set; }

        private void Cancel()
        {
            _navigator.Back();
        }

        public ObservableCollection<ContactMethod> ContactMethods { get; set; }
        public SaveCancelModuleViewModel SaveCancel { get; set; }

        public string FName { get; set; }
        public string MName { get; set; }
        public string LName { get; set; }
        public Ssn Ssn { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public AddressState State { get; set; }
        public ZipCode ZipCode { get; set; }
        public PhoneNumber Phone { get; set; }
        public string Email { get; set; }
        public DateTime? Dob { get; set; }

        public ContactMethod ContactMethod
        {
            get { return _contactMethod; }
            set { SetProperty(ref _contactMethod, value); }
        }

        public string FNumberText
        {
            get { return _fNumber; }
	        set
	        {
		        SetProperty(ref _fNumber, value);
		        UpdateFNumber();			
	        }
        }
	    public string FNumberFormattedText { get; set; }
		
		public bool IsFNumberReadonly { get; set; }
        public bool IsReadonlyMode { get; set; }
        public bool IsSsnReadonly { get; set; }
        private bool IsFNumberValidated { get; set; }
        public ICommand ImportCommand { get; set; }
        public bool IsImportVisible { get; set; }
        public Person CurrentPersonModel { get; set; }
        public Person StoredPersonModel { get; set; }
        //public IList<Contract> Contracts { get; set; }
	    
	    private async void Save()
        {
            _shellViewModel.IsUiBusy = true;
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
            try
            {
                FillModel();
                if (CurrentPersonModel.Changed(StoredPersonModel))
                {
                    if (FNumberFormattedText.IsNotEmpty())
                        await ValidateFNumber(FNumber.Format(FNumberFormattedText));

                    await _repository.Save(CurrentPersonModel, true);

                }

                //if (Contracts == null)
                //{
                //    await Reload();
                //    return;
                //}

                //foreach (var contract in Contracts)
                //{
                //    await _contractRepository.Save(Contract.CopyFromRemote(_personId, contract));
                //}

                await Reload();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }

            _shellViewModel.IsUiBusy = false;
        }

        private async void Import()
        {
            _shellViewModel.IsUiBusy = true;

            try
            {
                CurrentPersonModel = await GetModel();
                FillModel();
                await ValidateFNumber(FNumberFormattedText);              
                //Contracts = await _contractRepository.RemoteFetch(FNumberFormattedText);
                await MergeModels();                
                FillView(CurrentPersonModel);
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during Accessing Database.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }

            _shellViewModel.IsUiBusy = false;
        }

        private async Task MergeModels()
        {
            var importedPerson = await RemoteGetPerson();
            var personConflict = PersonConflictVm.Create(importedPerson, CurrentPersonModel);

            _navigator.PersonConflict(personConflict);
            if (personConflict.Canceled)
            {                
                return;
            }

            PersonConflictVm.Merge(personConflict, CurrentPersonModel);
            _personId = CurrentPersonModel.Id;
        }

        private async Task<Person> RemoteGetPerson()
        {
            var importedPerson = await _repository.RemoteGet(Ssn, FNumber.Parse(FNumberFormattedText));
            if (importedPerson == null)
            {                
                throw new UserException("Customer wasn't found. ");
            }

            return importedPerson;
        }

	    private async Task ValidateFNumber(string f)
	    {
			//if (FNumberText.IsEmpty() | !FNumber.CheckFormat(f))
			if (f.IsEmpty())
			{
			    throw new UserException("Please enter a valid FNumber");
		    }
		    var fNumber = FNumber.Parse(f);

		    var isFNumberExist = await _contractRepository.CheckDuplicate(fNumber, CurrentPersonModel.Id.Value);

		    if (isFNumberExist == -1)
		    {
			    var msg = "The FNumber " + fNumber + " has been used! Please enter a different FNumber";
			    throw new UserException(msg);
		    }

		    IsFNumberValidated = true;
	    }

		private async void Load()
        {
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
            _shellViewModel.IsUiBusy = true;

            var args = (IdArgs)Arguments;
            _personId = new PersonId(args.Id);

            await Reload();
            
            _shellViewModel.IsUiBusy = false;
        }

        private async Task Reload()
        {
            SaveCancel.Load(Save, Cancel);
            IsReadonlyMode = _user.Type.Equals(UserType.Guest);

            _contactMethods = await ContactMethodList.GetInstance();
            var model = await GetModel();

            IsFNumberReadonly = !model.FNumber.IsEmpty() | IsReadonlyMode;

            FillView(model);
        }

        private async Task<Person> GetModel()
        {
            if (_personId.IsEmpty())
            {
                return await PersonFactory.Create();
            }
            CurrentPersonModel = await _repository.Get(_personId);            
            StoredPersonModel = await _repository.Get(_personId);
            return CurrentPersonModel;
        }

        private void FillView(Person model)
        {
            ContactMethods.Update(_contactMethods.All());

            FName = model.Name.First;
            MName = model.Name.Middle;
            LName = model.Name.Last;
            Ssn = model.Ssn;
            Address1 = model.Address.Address1;
            Address2 = model.Address.Address2;
            City = model.Address.City;
            State = AddressState.Parse(model.Address.State);
            ZipCode = model.Address.ZipCode;
            Phone = model.Contacts.Phone;
            Email = model.Contacts.Email;
            Dob = model.Dob;
            ContactMethod = model.ContactMethod;
            IsImportVisible = !IsReadonlyMode;
            FNumberText = model.FNumber.ToString();

            UpdateAll();
        }

        private void FillModel()
        {
            CurrentPersonModel.Name.First = FName;
            CurrentPersonModel.Name.Middle = MName;
            CurrentPersonModel.Name.Last = LName;
            CurrentPersonModel.Ssn = Ssn;
            CurrentPersonModel.Address = Address.Create(Address1, Address2, City, State, ZipCode);
            CurrentPersonModel.Contacts.Phone = Phone;
            CurrentPersonModel.Contacts.Email = Email;
            CurrentPersonModel.Dob = Dob;
            CurrentPersonModel.ContactMethod = ContactMethod;
            //CurrentPersonModel.ChangeFNumber(FNumber.Parse(FNumberText));
            CurrentPersonModel.ChangeFNumber(FNumber.Parse(FNumberFormattedText));
        }
    }
}
