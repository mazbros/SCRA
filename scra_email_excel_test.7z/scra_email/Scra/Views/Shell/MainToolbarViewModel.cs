﻿using Scra.AppCore;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Views.Shell
{
    public class MainToolbarViewModel : BaseViewModel
    {
        private readonly AppNavigator _navigator;

        public MainToolbarViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            
            Back = new ToolbarTextButtonProps { Command = new Command(GoBack) };
            Requests = new ToolbarTextButtonProps {Command = new Command(OpenInquiry)};
            PersonList = new ToolbarTextButtonProps { Command = new Command(OnPersonList) };
	        Benefits = new ToolbarTextButtonProps { Command = new Command(OnBenefitList) };
            History = new ToolbarTextButtonProps { Command = new Command(OnHistoryList) };
	        Intake = new ToolbarTextButtonProps { Command = new Command(OnIntake) };
            Tasks = new ToolbarTextButtonProps { Command = new Command(OnNewTask) };
            Dashboard = new ToolbarTextButtonProps { Command = new Command(OnDashboard) };
            Reports = new ToolbarTextButtonProps { Command = new Command(OnOpenReports) };

            var user = Di.Get<IUser>();
            IsReportAvailable = !user.Type.Equals(UserType.Guest);
        }

	    public ToolbarTextButtonProps Back { get; set; }
        public ToolbarTextButtonProps Requests { get; set; }
        public ToolbarTextButtonProps PersonList { get; set; }
        public ToolbarTextButtonProps Benefits { get; set; }
        public ToolbarTextButtonProps History { get; set; }
	    public ToolbarTextButtonProps Intake { get; set; }
        public ToolbarTextButtonProps Tasks { get; set; }
        public ToolbarTextButtonProps Dashboard { get; set; }
        public ToolbarTextButtonProps Reports { get; set; }

        public bool IsReportAvailable { get; set; }

	    private void GoBack()
        {
            _navigator.Back();
        }

        private void OpenInquiry()
        {
            Requests.IsSelected = true;
            PersonList.IsSelected = false;
            Tasks.IsSelected = false;
            History.IsSelected = false;
            Reports.IsSelected = false;

            _navigator.InquiryList();
        }

        private void OpenIntake()
        {
            _navigator.PersonAdd();
        }

        private void OnIntake()
        {
            _navigator.NewInquiry();
        }

        private void OnPersonList()
        {
            PersonList.IsSelected = true;
            Requests.IsSelected = false;
            Tasks.IsSelected = false;
            History.IsSelected = false;
            Reports.IsSelected = false;

            _navigator.PersonList();
        }

	    private void OnBenefitList()
	    {
		    PersonList.IsSelected = false;
		    Requests.IsSelected = false;
		    Tasks.IsSelected = false;
		    Benefits.IsSelected = true;
		    History.IsSelected = false;
		    Reports.IsSelected = false;

		    _navigator.Benefits();
		}

		private void OnHistoryList()
        {
            History.IsSelected = true;
            Tasks.IsSelected = false;
            PersonList.IsSelected = false;
            Requests.IsSelected = false;
            Reports.IsSelected = false;

            _navigator.PersonHistory();
        }
        private void OnNewTask()
        {
            Tasks.IsSelected = true;
            PersonList.IsSelected = false;
            Requests.IsSelected = false;
            History.IsSelected = false;
            Reports.IsSelected = false;

            _navigator.TaskList();
        }
        
        private void OnOpenReports()
        {
            Reports.IsSelected = true;
            Tasks.IsSelected = false;
            PersonList.IsSelected = false;
            Requests.IsSelected = false;
            History.IsSelected = false;

            _navigator.ReportsList();
        }

        private void OnDashboard()
        {
            _navigator.Dashboard();
        }
    }
}
