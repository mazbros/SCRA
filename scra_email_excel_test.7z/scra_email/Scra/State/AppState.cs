﻿namespace Scra.State
{
    public struct AppState : IState
    {
        public int StateId { get; set; }        
    }
}