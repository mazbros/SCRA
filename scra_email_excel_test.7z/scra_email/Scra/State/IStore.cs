﻿namespace Scra.State
{
    public interface IStore<TState> : IActConsumer where TState : IState
    {
        IDispatcher Dispatcher { get; }

        TState GetState();

        void Subscribe(IStoreMiddleware<TState> middleware);
    }
}