﻿using System.Windows;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public partial class MultiLineEditBlock
    {
        public MultiLineEditBlock()
        {
            InitializeComponent();

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyProperty); }
            set { SetValue(IsReadOnlyProperty, value); }
        }
        public static readonly DependencyProperty IsReadOnlyProperty = DependencyProperty.Register(
            "IsReadOnly", typeof(bool), typeof(MultiLineEditBlock), new PropertyMetadata(false));

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(MultiLineEditBlock), new PropertyMetadata(""));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
            }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(MultiLineEditBlock), new PropertyMetadata("*"));

        public string Value
        {
            get { return (string)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(string), typeof(MultiLineEditBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }
}
