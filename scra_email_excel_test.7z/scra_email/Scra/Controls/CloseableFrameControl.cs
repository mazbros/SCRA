using System.Windows;
using System.Windows.Controls;

namespace Scra.Controls
{
    public class CloseableFrameControl : ContentControl
    {
        public CloseableFrameControl()
        {
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            //Image closeIcon = (Image)Template.FindName("CloseIcon", this);
            //closeIcon.MouseUp += new MouseButtonEventHandler(OnCloseIconClick);

            //ContentPresenter content = (ContentPresenter)Template.FindName("ContentPresenter", this);
            //content.DataContextChanged += ContentOnDataContextChanged;
        }

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        public static readonly DependencyProperty TitleProperty = DependencyProperty.Register(
            "Title",
            typeof(string),
            typeof(CloseableFrameControl),
            new PropertyMetadata(default(string))
        );

        public Visibility ContentVisibility
        {
            get { return (Visibility)GetValue(ContentVisibilityProperty); }
            set { SetValue(ContentVisibilityProperty, value); }
        }

        public static readonly DependencyProperty ContentVisibilityProperty = DependencyProperty.Register(
            "ContentVisibility",
            typeof(Visibility),
            typeof(CloseableFrameControl),
            new PropertyMetadata(Visibility.Visible)
        );

        public Visibility FrameVisibility
        {
            get { return (Visibility)GetValue(FrameVisibilityProperty); }
            set { SetValue(FrameVisibilityProperty, value); }
        }

        public static readonly DependencyProperty FrameVisibilityProperty = DependencyProperty.Register(
            "FrameVisibility",
            typeof(Visibility),
            typeof(CloseableFrameControl),
            new PropertyMetadata(Visibility.Visible)
        );

        //public void OnCloseIconClick(object sender, RoutedEventArgs e)
        //{
        //    FrameVisibility = Visibility.Collapsed;
        //}

        //private void ContentOnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        //{
        //    FrameVisibility = Visibility.Visible;
        //}
    }
}