﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;

namespace Scra.Controls
{
    public partial class MaskBlock
    {
        public MaskBlock()
        {
            InitializeComponent();
        }

        protected virtual void Setup(string mask, string defaultText, char[] skipSymbols)
        {
            MaskEditor.Attach(InputTextControl, mask, defaultText, skipSymbols);
        }


        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyProperty); }
            set { SetValue(IsReadOnlyProperty, value); }
        }
        public static readonly DependencyProperty IsReadOnlyProperty = DependencyProperty.Register(
            "IsReadOnly", typeof(bool), typeof(MaskBlock), new PropertyMetadata(false));

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(MaskBlock), new PropertyMetadata(""));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(MaskBlock), new PropertyMetadata("*"));

        public string EditMaxLength
        {
            get { return (string)GetValue(EditMaxLengthProperty); }
            set { SetValue(EditMaxLengthProperty, value); }
        }
        public static readonly DependencyProperty EditMaxLengthProperty = DependencyProperty.Register(
            "EditMaxLength", typeof(string), typeof(MaskBlock), new PropertyMetadata("255"));

        public ICommand EnterCommand
        {
            get { return (ICommand)GetValue(EnterCommandProperty); }
            set { SetValue(EnterCommandProperty, value); }
        }
        public static readonly DependencyProperty EnterCommandProperty = DependencyProperty.Register(
            "EnterCommand", typeof(ICommand), typeof(MaskBlock), new FrameworkPropertyMetadata(new Command(() => { })));

        public string TextValue
        {
            get { return (string)GetValue(TextValueProperty); }
            set { SetValue(TextValueProperty, value); }
        }
        public static readonly DependencyProperty TextValueProperty = DependencyProperty.Register(
            "TextValue", typeof(string), typeof(MaskBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, PropertyChangedCallback));

        private static void PropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var block = d as MaskBlock;
            if (block != null)
            {
                block.InputTextChanged((string) e.NewValue);
            }
        }

        protected virtual void InputTextChanged(string newValue)
        {
        }
    }
}