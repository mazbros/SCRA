﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;

namespace Scra.Controls
{
    public partial class ComparisonBlock
    {
        public ComparisonBlock()
        {
            InitializeComponent();
        }

        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyProperty); }
            set { SetValue(IsReadOnlyProperty, value); }
        }
        public static readonly DependencyProperty IsReadOnlyProperty = DependencyProperty.Register(
            "IsReadOnly", typeof(bool), typeof(ComparisonBlock), new PropertyMetadata(false));

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(ComparisonBlock), new PropertyMetadata(""));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(ComparisonBlock), new PropertyMetadata("*"));

        public string SelectedValue
        {
            get { return (string)GetValue(ValueProperty1); }
            set { SetValue(ValueProperty1, value); }
        }
        public static readonly DependencyProperty ValueProperty1 = DependencyProperty.Register(
            "SelectedValue", typeof(string), typeof(ComparisonBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string CurrentValue
        {
            get { return (string)GetValue(ValueProperty2); }
            set { SetValue(ValueProperty2, value); }
        }
        public static readonly DependencyProperty ValueProperty2 = DependencyProperty.Register(
            "CurrentValue", typeof(string), typeof(ComparisonBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string ImportedValue
        {
            get { return (string)GetValue(ValueProperty3); }
            set { SetValue(ValueProperty3, value); }
        }
        public static readonly DependencyProperty ValueProperty3 = DependencyProperty.Register(
            "ImportedValue", typeof(string), typeof(ComparisonBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public ICommand EnterCommand
        {
            get { return (ICommand)GetValue(EnterCommandProperty); }
            set { SetValue(EnterCommandProperty, value); }
        }
        public static readonly DependencyProperty EnterCommandProperty = DependencyProperty.Register(
            "EnterCommand", typeof(ICommand), typeof(ComparisonBlock), new FrameworkPropertyMetadata(new Command(() => { })));

        private void ButtonBase_OnClick_CopyCurrent(object sender, RoutedEventArgs e)
        {
            SelectedValue = CurrentValue;
        }

        private void ButtonBase_OnClick_CopyImported(object sender, RoutedEventArgs e)
        {
            SelectedValue = ImportedValue;
        }
    }
}
