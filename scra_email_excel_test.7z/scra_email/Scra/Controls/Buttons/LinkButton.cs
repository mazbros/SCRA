﻿using System.Windows.Controls;

namespace Scra.Controls.Buttons
{
    public class LinkButton : Button
    {
    }
}
