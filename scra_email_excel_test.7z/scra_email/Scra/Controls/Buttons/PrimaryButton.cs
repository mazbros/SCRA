﻿using System.Windows;
using System.Windows.Controls;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls.Buttons
{
    public class PrimaryButton : Button
    {
        public PrimaryButton()
        {
            var user = Di.Get<IUser>();
            Visibility = user.Type.Equals(UserType.Guest) ? Visibility.Collapsed : Visibility.Visible;
        }
    }
}
