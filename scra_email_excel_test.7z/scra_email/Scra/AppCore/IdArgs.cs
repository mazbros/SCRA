﻿using Scra.Model.Persons;

namespace Scra.AppCore
{
    public class IdArgs
    {
        public IdArgs(int id)
        {
            Id = id;
        }

        public IdArgs(IRefId entity)
        {
            Id = entity.Value;
        }

        public int Id { get; private set; }
    }
}
