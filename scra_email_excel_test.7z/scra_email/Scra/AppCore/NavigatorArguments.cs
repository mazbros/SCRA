﻿using System.Collections.Generic;

namespace Scra.AppCore
{
    public class NavigatorArguments
    {
        public NavigatorArguments()
        {
            NavigatorArgumentList = new List<object>();
        }
        public IList<object> NavigatorArgumentList { get; set; }
    }
}
