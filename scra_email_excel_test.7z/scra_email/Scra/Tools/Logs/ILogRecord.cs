﻿using System;

namespace Scra.Tools.Logs
{
    public interface ILogRecord
    {
        LogSeverity Severity { get; }
        Exception Exception { get; }
        string Message { get; }
    }
}