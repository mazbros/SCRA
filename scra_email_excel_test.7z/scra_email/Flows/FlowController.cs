﻿using System.Collections.Generic;

namespace Scra.Flows
{
    public static class FlowController
    {
        private static readonly List<FlowProcess> _startProcesses;

        static FlowController()
        {
            var processBenefitsForCustomer = new FlowProcess
            {
                Name = "Process customer", Tasks = new List<IFlowTask>
                {
                    new FlowTask {Name = "Check customer eligibility"},
                    new FlowTask {Name = "Check products eligibility"},
                }
            };

            _startProcesses = new List<FlowProcess>
            {
                new FlowProcess{Name = "Customer was identified as a servicemember after weekly scrub", Tasks = new List<IFlowTask>
                {
                    new FlowTask{Name = "Fill servicemember personal data into app"},
                    processBenefitsForCustomer
                }},
                new FlowProcess{Name = "NewInquiry from new servicemember"},
            };
        }

        public static IList<FlowProcess> GetFlowProcesses()
        {
            return _startProcesses;
        }
    }

    public interface IFlowTask
    {
    }

    public class FlowTask : IFlowTask
    {
        public string Name { get; set; }
    }

    public class FlowProcess : IFlowTask
    {
        public string Name { get; set; }

        public IList<IFlowTask> Tasks { get; set; }
    }
}
