﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.PersonDashboard
{
    public class ContractsWidgetModel : BaseViewModel
    {
        private readonly IContractRepository _repository;
        private readonly AppNavigator _navigator;
        private PersonId _personId;
        private readonly IMessageDialog _messageDialog;

        public ContractsWidgetModel()
        {
            _repository = Di.Get<IContractRepository>();
            _navigator = Di.Get<AppNavigator>();
            _messageDialog = Di.Get<IMessageDialog>();
            ContractsGroups = new ObservableCollection<ContractsGroupVm>();
            EditCommand = new Command(Edit);
        }

        public ObservableCollection<ContractsGroupVm> ContractsGroups { get; private set; }
        public ICommand EditCommand { get; set; }

        private void Edit()
        {
            _navigator.Benefits(_personId);
        }

        public async Task Load(Person person)
        {
            try
            {
                _personId = person.Id;
                var contracts = await _repository.Load(person.Id);
                ContractsGroups.Update(ToVm(contracts, person.Id));
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during loading person's contracts.");
            }
        }

        private IList<ContractsGroupVm> ToVm(IList<ContractSnapshot> contracts, PersonId personId)
        {
            return contracts
                .GroupBy(x => x.PersonId)
                .Select(x => ContractsGroupVm.Create(x, personId))
                .OrderBy(x => !x.IsMain)
                .ThenBy(x => x.PersonName)
                .ToList();
        }
    }
}
