﻿using Scra.Controls;
using Scra.Model.BranchOfServices;
using Scra.Model.ServiceMembers;

namespace Scra.Views.PersonDashboard
{
    public class ActiveDutyListItem
    {
        public static ActiveDutyListItem Create(ActiveDuty model, BranchOfServiceList branchOfServiceList)
        {
            var name = Formatter.Date(model.StartDate) + " - " + Formatter.Date(model.EndDate);
            var branch = model.BranchOfService.Name;
            return new ActiveDutyListItem {Name = name, Branch = branch, AdId = model.Id};
        }

        public int AdId { get; set; }

        public string Name { get; set; }
        public string Branch { get; set; }
    }
}