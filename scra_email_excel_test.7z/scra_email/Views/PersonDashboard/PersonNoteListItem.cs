﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Persons;

namespace Scra.Views.PersonDashboard
{
    public class PersonNoteListItem
    {
        public string ModifiedByName { get; set; }
        public string ModifiedTime { get; set; }
        public PersonNote Note { get; set; }
        public ICommand EditNoteCommand { get; set; }
        public ICommand DeleteNoteCommand { get; set; }
        public bool IsNoteEditable { get; set; }

		private PersonNoteListItem(PersonNote note, Action<PersonNote> editNoteCommand, Action<PersonNote> deleteNoteCommand)
        {

            Note = note;
            ModifiedTime = Formatter.Date(note.ModifiedTime);
            ModifiedByName = note.ModifiedByName;
            EditNoteCommand = new Command(() => editNoteCommand(Note));
            DeleteNoteCommand = new Command(() => deleteNoteCommand(Note));
        }

	    public static PersonNoteListItem Create(PersonNote note, Action<PersonNote> editNoteCommand, Action<PersonNote> deleteNoteCommand, bool isGuestUser)
	    {
		    return new PersonNoteListItem(note, editNoteCommand, deleteNoteCommand)
		    {
				IsNoteEditable = !isGuestUser,
			};
	    }

		public static PersonNoteListItem Create(PersonNote note, Action<PersonNote> editNoteCommand, Action<PersonNote> deleteNoteCommand)
        {
            return new PersonNoteListItem(note, editNoteCommand, deleteNoteCommand);
        }
    }
}