﻿namespace Scra.Views.PersonDashboard
{
    public partial class PersonDashboardView
    {
        public PersonDashboardView()
        {
            InitializeComponent();

            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.MilitaryWidget = MilitaryWidget.GetViewModel();
            vm.DependentsWidget = DependentsWidget.GetViewModel();
            vm.TaskWidget = TaskWidget.GetViewModel();
            vm.ContractsWidget = ContractsWidget.GetViewModel();
            vm.PersonFileList = PersonFileListWidget;
            vm.PersonNoteList = PersonNoteListWidget;
            vm.CommunicationList = CommunicationWidget.GetViewModel();
        }

        public PersonDashboardViewModel GetViewModel()
        {
            return (PersonDashboardViewModel)DataContext;
        }
    }
}
