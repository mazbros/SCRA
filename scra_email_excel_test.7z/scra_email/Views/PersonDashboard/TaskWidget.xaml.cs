﻿using System.Windows.Input;

namespace Scra.Views.PersonDashboard
{
    public partial class TaskWidget
    {
        public TaskWidget()
        {
            InitializeComponent();
        }

        public TaskWidgetModel GetViewModel()
        {
            return (TaskWidgetModel)DataContext;
        }

        private void OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectCommand.Execute(null);
        }
    }
}
