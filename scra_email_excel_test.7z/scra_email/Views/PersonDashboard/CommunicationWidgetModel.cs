﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Model.Communication;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.PersonDashboard
{
    public class CommunicationWidgetModel : BaseViewModel
    {
        private readonly AppNavigator _navigator;
        private readonly ICommunicationRepository _communicationRepository;

        public CommunicationWidgetModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _communicationRepository = Di.Get<ICommunicationRepository>();
            _navigator = Di.Get<AppNavigator>();
            Communications = new ObservableCollection<CommunicationsListItem>();
        }

        public CommunicationsListItem CommunicationsItem { get; set; }

        private void ShowCommunication(ProductCommunication communication)
        {
            _navigator.Task(communication.TaskId);
            _navigator.ProductCommunication(communication);
        }

        public ObservableCollection<CommunicationsListItem> Communications { get; set; }

        public async Task Load(Person person)
        {
            var communications = await _communicationRepository.GetByPerson(person.Id.Value);

            var vms = new List<CommunicationsListItem>();

            foreach (var communication in communications)
            {
                vms.Add(CommunicationsListItem.Create(communication, ShowCommunication));
            }

            Communications.Update(vms);
        }

        
    }
}