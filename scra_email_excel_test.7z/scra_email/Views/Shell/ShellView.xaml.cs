﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Scra.AppCore;
using Scra.Model.Tools;

namespace Scra.Views.Shell
{
    public partial class ShellView : IShell
    {
        public ShellView()
        {
            InitializeComponent();
            Left = 0;
            Top = 0;
            WindowState = WindowState.Maximized;
            var navigator = Di.Get<AppNavigator>();
            navigator.SetupShell(this);

            //var image = new BitmapImage(new Uri("pack://application:,,,/Scra;component/Images/loading.png", UriKind.RelativeOrAbsolute));
            //MyGif.Source = image.UriSource;
        }

        public void ShowChild(UserControl control)
        {
            ChildView.Content = control;
        }

        //private void MyGif_MediaEnded(object sender, RoutedEventArgs e)
        //{
        //    MyGif.Position = new TimeSpan(0, 0, 1);
        //    MyGif.Play();
        //}

        private void Control_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            LeftWidth.Width = GridLength.Auto;
            //GridSplitter.Background = new SolidColorBrush(Colors.Gray);  
            
            var image = new BitmapImage(new Uri("pack://application:,,,/Scra;component/Images/grey_left_right.png", UriKind.RelativeOrAbsolute));
            var brush = new ImageBrush {ImageSource = image, Stretch = Stretch.Fill, TileMode = TileMode.FlipXY, Opacity = 0.9};
            GridSplitter.Background = brush;
        }

        private void GridSplitter_OnDragCompleted(object sender, DragCompletedEventArgs e)
        {
            if (LeftWidth.Width != GridLength.Auto)
            {
                //GridSplitter.Background = new SolidColorBrush(Colors.Red);            
                var image = new BitmapImage(new Uri("pack://application:,,,/Scra;component/Images/red_left_right.png", UriKind.RelativeOrAbsolute));
                var brush = new ImageBrush {ImageSource = image, Stretch = Stretch.Fill, TileMode = TileMode.FlipXY, Opacity = 0.95};
                GridSplitter.Background = brush;
            }
        }
    }
}
