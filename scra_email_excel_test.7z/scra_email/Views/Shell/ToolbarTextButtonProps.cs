﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;

namespace Scra.Views.Shell
{
    public class ToolbarTextButtonProps : BaseViewModel
    {
        private Visibility _visibility;
        private bool _isEnabled;
        private bool _isSelected;

        public ToolbarTextButtonProps()
        {
            Visibility = Visibility.Visible;
            IsEnabled = true;
        }

        public Visibility Visibility
        {
            get { return _visibility; }
            set { SetProperty(ref _visibility, value); }
        }

        public bool IsEnabled
        {
            get { return _isEnabled; }
            set { SetProperty(ref _isEnabled, value); }
        }

        public bool IsSelected
        {
            get { return _isSelected; }
            set { SetProperty(ref _isSelected, value); }
        }

        public ICommand Command { get; set; }
    }
}