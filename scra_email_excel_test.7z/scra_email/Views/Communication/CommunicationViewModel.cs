using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.Communication
{
    public class CommunicationViewModel : BaseViewModel
    {
        //private readonly ICommunicationRepository _repository;
        private readonly IPersonRepository _personRepository;

        private PersonId _personId;
        private string _name;
        private string _address;
        //private readonly AppNavigator _navigator;

        public CommunicationViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            //_navigator = Di.Get<AppNavigator>();
            //_repository = Di.Get<ICommunicationRepository>();
            _personRepository = Di.Get<IPersonRepository>();
            OnViewLoaded = OnLoaded;
        }

        private async void OnLoaded()
        {
            _personId = new PersonId(0);
            await Reload();
        }

        private async Task Reload()
        {
            await GetPerson();
        }

        private Task<Person> GetPerson()
        {
            return _personRepository.Get(_personId);
        }

        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }

        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
    }
}