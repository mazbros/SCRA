﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.History;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;

namespace Scra.Views.LeftPanel
{
    public class PersonHistoryListViewModel : BaseViewModel
    {
        private readonly IDispatcher _dispatcher;
        private readonly IHistoryRepository _historyRepository;
        private readonly IUiThread _uiThread;
        private DateTime? _historyDate;
        private readonly AppNavigator _navigator;
        private bool _isModifiedRecordsAvailable;
        private ModifiedRecordVm _selectedPerson;

        public DateTime? HistoryDate
        {
            get { return _historyDate; }
            set
            {
                SetProperty(ref _historyDate, value);
                HistoryDateSelected();
            }
        }

        private async void HistoryDateSelected()
        {
            await Reload();
        }

        public ObservableCollection<ModifiedRecordVm> ModifiedRecords { get; set; }
        public PersonHistoryListViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            _dispatcher = Di.Get<IDispatcher>();
            _historyRepository = Di.Get<IHistoryRepository>();
            _uiThread = Di.Get<IUiThread>();

            HistoryDate = DateTime.Today;
        }

        public string Title { get; set; }

        public bool IsModifiedRecordsAvailable
        {
            get { return _isModifiedRecordsAvailable; }
            set { SetProperty(ref _isModifiedRecordsAvailable,  value); }
        }

        public async Task Load()
        {
            _navigator.ShowHistory();
            await Reload();
        }

        private async Task Reload()
        {
            _isModifiedRecordsAvailable = false;
            var personSnapshots = await _historyRepository.LoadModifiedRecords(HistoryDate);
            var personList = personSnapshots.OrderByDescending(x => x.Timestamp).ToList();
            _uiThread.Execute(()=> FillView(personList));

            if (personList.Count > 0)
            {
                var id = personList.FirstOrDefault();
                if (id != null)
                {
                    await _dispatcher.DispatchAsync(new PersonEditHistoryAct(id.Id.Value, HistoryDate));
                }

                IsModifiedRecordsAvailable = true;
            }
        }

        public ModifiedRecordVm SelectedPerson
        {
            get { return _selectedPerson; }
            set { SetProperty(ref _selectedPerson,value); }
        }

        private void FillView(IList<PersonSnapshot> personList)
        {
            ModifiedRecords = new ObservableCollection<ModifiedRecordVm>();
            
            foreach (var person in personList)
            {
                var p = ModifiedRecordVm.Create(person.Id.Value, person.Name.FullName, person.Timestamp, OnNameClicked);
                ModifiedRecords.Add(p);
            }
            
            Title = "Modified Records After " + Formatter.DateTime(HistoryDate);

            SelectedPerson = ModifiedRecords.Count > 0 ? ModifiedRecords.FirstOrDefault() : null;

            UpdateAll();
        }

        private async void OnNameClicked(int id)
        {
            SelectedPerson = ModifiedRecords.FirstOrDefault(x => x.Id == id);
            _navigator.ShowHistory();
            await _dispatcher.DispatchAsync(new PersonEditHistoryAct(id, HistoryDate));
        }
    }
}
