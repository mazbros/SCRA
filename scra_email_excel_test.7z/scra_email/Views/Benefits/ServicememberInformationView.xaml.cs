﻿using System.Windows;
using System.Windows.Input;

namespace Scra.Views.Benefits
{
    public partial class ServicememberInformationView
    {
        public ServicememberInformationView()
        {
            InitializeComponent();  
        }

        public ServicememberInformationViewModel GetViewModel()
        {
            return (ServicememberInformationViewModel)DataContext;
        }

	    private void Selector_OnSelected(object sender, RoutedEventArgs e)
	    {
		    var vm = GetViewModel();
		    vm.SelectedCommand.Execute(null);
		}
    }
}
