﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Views.Benefits
{
    public class BenefitInterval : BaseControlModel
	{
        private readonly AppNavigator _navigator;
	    private BenefitActionVm _selectedBenefitAction;
	    public int BenefitIntervalId { get; set; }
        public int ContractId { get; private set; }
        public int InquiryId { get; set; }
        public int InquiryTaskId { get; private set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public DateTime? BenefitAppliedDate { get; set; }
        public DateTime? ExpectedRemovalDate { get; set; }
        public DateTime? BenefitRemoveDate { get; set; }
        public DateTime? ExtendDate { get; set; }

		public BenefitStatus BenefitStatus { get; set; }
        public string BenefitStatusText { get; set; }
        public IList<BenefitEvent> BenefitEvents { get; private set; }
        public IList<BenefitActionVm> BenefitActionList { get; private set; }
        public IList<int> AdIdList { get; private set; }

		public int AdIntervalCount { get; private set; }
        public string AdIntervalText { get; private set; }
        public string AdIntervalList { get; private set; }
        public string DenialReason { get; set; }

        public int PersonId { get; set; }

        public ICommand ViewTaskCommand { get; set; }
        public ICommand ViewDetailCommand { get; set; }
        public ICommand ViewRequestCommand { get; set; }
		public ICommand OnTextBoxLeftClicked { get; set; }
		public ICommand OnTextBoxRightClicked { get; set; }

		public BenefitActionVm SelectedBenefitAction
	    {
			get { return _selectedBenefitAction; }
		    set
		    {
			    SetProperty(ref _selectedBenefitAction, value);
				OnBenefitActionSelected(BenefitIntervalId);
		    }
		}

		public Action<int> OnBenefitActionSelected { get; set; }
		

		private BenefitInterval(IList<BenefitEvent> benefitEvents)
        {
            _navigator = Di.Get<AppNavigator>();

			BenefitEvents = benefitEvents.OrderByDescending(x=>x.ActionDate).ToList();
            BenefitActionList = CreateBenefitActionList();

            ViewRequestCommand = new Command(() => ViewRequest());
            ViewTaskCommand = new Command(() => ViewTask());
            ViewDetailCommand = new Command(() => ViewDetail());

	        OnTextBoxLeftClicked = new Command(()=> OnBenefitActionSelected(BenefitIntervalId));
	        OnTextBoxRightClicked = new Command(()=> OnBenefitActionSelected(BenefitIntervalId));

	        AdIdList = benefitEvents.Where(x => x.ActiveDutyId != 0).Select(x => x.ActiveDutyId).Distinct().ToList();

            InquiryId = GetInquiryId();
            InquiryTaskId = GetInquiryTaskId();
            ContractId = GetContractId();
            BenefitIntervalId = GetBenefitIntervalId();
            PersonId = GetPersonId();

            BenefitAppliedDate = GetBenefitAppliedDate();
            BenefitEffectiveDate = GetBenefitEffectiveDate();
            ExpectedRemovalDate = GetExpectedRemovalDate();
            BenefitRemoveDate = GetBenefitRemoveDate();
            ExtendDate = GetExtendDate();
	        BenefitStatus = GetBenefitStatus();
            BenefitStatusText = BenefitStatus.Display;

            DenialReason = GetDenialReason();
            AdIntervalList = GetAdIntervalList();
        }

		private IList<BenefitActionVm> CreateBenefitActionList()
        {
            var taskIdList = BenefitEvents.Select(x => x.TaskId).Distinct().ToList();

            var benefitEventVmList = new List<BenefitActionVm>();

            foreach (var taskId in taskIdList)
            {
                var benefitEvents = BenefitEvents.Where(x => x.TaskId == taskId).ToList();
                benefitEventVmList.Add(BenefitActionVm.Create(benefitEvents));
            }

            return benefitEventVmList;
        }

        private void ViewRequest()
        {
            _navigator.Task(SelectedBenefitAction.InquiryTaskId);
        }

        private void ViewTask()
        {
            _navigator.Task(SelectedBenefitAction.TaskId);
        }

        private void ViewDetail()
        {
			var selectBenefitEvent = BenefitEvents == null ? null : BenefitEvents.FirstOrDefault(x => x.BenefitId == SelectedBenefitAction.BenefitId);

			NavigateBenefitDetail.Navigate(selectBenefitEvent);
        }

        public static BenefitInterval Create(IList<BenefitEvent> benefitEvents)
        {
            return new BenefitInterval(benefitEvents);
        }

        private string GetDenialReason()
        {
            if (!BenefitEvents.Any(x => x.BenefitStatus == BenefitStatus.Denying || x.BenefitStatus == BenefitStatus.Denied))
                return String.Empty;

            var denialReason = BenefitEvents.FirstOrDefault(x => x.BenefitStatus == BenefitStatus.Denying || x.BenefitStatus == BenefitStatus.Denied).DenialReason;
            return denialReason;
        }

        private int GetPersonId()
        {
            var personId = BenefitEvents.FirstOrDefault();
            return personId == null ? 0 : personId.PersonId;
        }

        private string GetAdIntervalList()
        {
            var benefitEvents = BenefitEvents.Where(x => x.TaskStatus != TascStatus.Misdirected && x.ActiveDutyId != 0)
                .Select(x => new { x.ActiveDutyStartDate, x.ActiveDutyEndDate })
                .Distinct()
                .ToList();
            var adList = string.Empty;
            foreach (var benefitEvent in benefitEvents)
            {
                var adsd = benefitEvent.ActiveDutyStartDate;
                var aded = benefitEvent.ActiveDutyEndDate;
                adList += string.Format("{0:MM/dd/yyyy}", adsd) + " - " + string.Format("{0:MM/dd/yyyy}", aded) + "\n";
            }

            if (benefitEvents.Count > 10)
            {
                AdIntervalCount = benefitEvents.Count;
                AdIntervalText = AdIntervalCount.ToString();
            }
            else
            {
                AdIntervalText = adList.TrimEnd('\n');
                AdIntervalList = adList.TrimEnd('\n');
            }

            return adList.TrimEnd('\n');
        }

        private int GetBenefitIntervalId()
        {
            var benefitIntervalId = BenefitEvents.FirstOrDefault();
            return benefitIntervalId == null ? 0 : benefitIntervalId.BenefitIntervalId;
        }

        private int GetInquiryId()
        {
            var inquiryId = BenefitEvents.FirstOrDefault(x => x.InquiryId !=0);
            return inquiryId == null ? 0 : inquiryId.InquiryId;
        }

        private int GetContractId()
        {
            var contractId = BenefitEvents.FirstOrDefault();
            return contractId == null ? 0 : contractId.ContractId;
        }

        private int GetInquiryTaskId()
        {
            var inquiryTaskId = BenefitEvents.FirstOrDefault();
            return inquiryTaskId == null ? 0 : inquiryTaskId.InquiryTaskId;
        }

        private DateTime? GetBenefitAppliedDate()
        {
            var addAction = BenefitEvents.LastOrDefault(x => x.TaskType == TaskType.ADD_BENEFIT && x.TaskStatus != TascStatus.Misdirected && x.BenefitDetailId != 0);
            return addAction == null ? null : addAction.BenefitAppliedDate;
        }

        private DateTime? GetBenefitEffectiveDate()
        {
            var addAction = BenefitEvents.LastOrDefault(x => x.TaskType == TaskType.ADD_BENEFIT && x.TaskStatus != TascStatus.Misdirected && x.BenefitDetailId != 0);
            return addAction == null ? null : addAction.BenefitEffectiveDate;
        }

        private DateTime? GetExpectedRemovalDate()
        {
            var addAction = BenefitEvents.LastOrDefault(x => (x.TaskType == TaskType.ADD_BENEFIT || x.TaskType == TaskType.EXTEND_BENEFIT ) && x.TaskStatus != TascStatus.Misdirected && x.BenefitDetailId != 0);
            return addAction == null ? null : addAction.ExpectedRemovalDate;
        }

        private DateTime? GetBenefitRemoveDate()
        {
            var removeAction = BenefitEvents.FirstOrDefault(x => x.TaskType == TaskType.REMOVE_BENEFIT && x.TaskStatus != TascStatus.Misdirected);
            if(removeAction != null && removeAction.BenefitDetailId == 0)
                removeAction = BenefitEvents.LastOrDefault(x => x.TaskType == TaskType.ADD_BENEFIT && x.TaskStatus != TascStatus.Misdirected);

            return removeAction == null ? null : removeAction.BenefitRemovedDate;
        }

		private DateTime? GetExtendDate()
		{
			var extendAction = BenefitEvents.FirstOrDefault(x => x.TaskType == TaskType.EXTEND_BENEFIT && x.TaskStatus != TascStatus.Misdirected);
			if (extendAction != null && extendAction.BenefitDetailId == 0)
				extendAction = BenefitEvents.LastOrDefault(x => x.TaskType == TaskType.ADD_BENEFIT && x.TaskStatus != TascStatus.Misdirected);

			return extendAction == null ? null : extendAction.ExtendDate;
		}

		private BenefitStatus GetBenefitStatus()
        {
			var majorActionTaskIdList = BenefitEvents.Where(x => x.TaskStatus != TascStatus.Misdirected
										 && (x.TaskType == TaskType.ADD_BENEFIT 
										     || x.TaskType == TaskType.REMOVE_BENEFIT
										     || x.TaskType == TaskType.EXTEND_BENEFIT
										     || x.TaskType == TaskType.DENY_BENEFIT))
								.Select(x => x.TaskId)
								.Distinct()
								.ToList();

	        if (majorActionTaskIdList.Count == 0)
				return BenefitStatus.Empty;

			var lastMajorAction = BenefitEvents.FirstOrDefault(x => x.TaskId == majorActionTaskIdList.First());

	        if (lastMajorAction == null)
		        return BenefitStatus.Empty;

			//if (lastMajorAction.TaskType == TaskType.EXTEND_BENEFIT)
			//{
			//	return lastMajorAction.TaskStatus == TascStatus.QaCompleted ? BenefitStatus.Applied : BenefitStatus.Applying;
			//}

			return lastMajorAction.BenefitStatus;
		}

		public void ValidateActionStatus(TaskType actionType)
		{
			if (actionType == TaskType.REMOVE_BENEFIT)
			{
				if (BenefitStatus == BenefitStatus.Denying || BenefitStatus == BenefitStatus.Denied)
					throw new UserException("Cannot remove benefit that has been denied.");

				if (BenefitStatus == BenefitStatus.Removing || BenefitStatus == BenefitStatus.Removed)
					throw new UserException("Cannot remove benefit that has been removed.");

				if (BenefitStatus == BenefitStatus.Applying || BenefitStatus == BenefitStatus.Extending)
					throw new UserException("Cannot remove benefit at this point." + "\nThe add or extend benefit workflow has to be QA Completed first.");
			}

			if (actionType == TaskType.EXTEND_BENEFIT)
			{
				if (BenefitStatus == BenefitStatus.Applying 
				    || BenefitStatus == BenefitStatus.Applied 
				    || BenefitStatus == BenefitStatus.Extending 
				    || BenefitStatus == BenefitStatus.Extended
				    || BenefitStatus == BenefitStatus.Denying
				    || BenefitStatus == BenefitStatus.Denied)
					throw new UserException("Extend benefit is used for removed benefit only.");

				if (BenefitStatus == BenefitStatus.Removing)
					throw new UserException("Cannot extend benefit at this point.\n" + "The remove benefit workflow has to be QA Completed first.");
			}

			if (actionType == TaskType.CONTINUE_BENEFIT)
			{
				if (BenefitStatus == BenefitStatus.Removing || BenefitStatus == BenefitStatus.Removed)
				{
					throw new UserException("Cannot continue benefit for removed benefit");
				}
			}

			if (actionType == TaskType.REMEDIATION_REIMBURSEMENT || actionType == TaskType.ADD_PROMOTIONAL_RATE || actionType == TaskType.REMOVE_PROMOTIONAL_RATE)
			{
				if (BenefitStatus == BenefitStatus.Denying || BenefitStatus == BenefitStatus.Denied)
				{
					throw new UserException("Cannot edit denied benefit");
				}
			}
		}
	}
}