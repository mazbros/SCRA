﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Logs;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
	public class ContractComparisonViewModel : BaseViewModel
	{
		private readonly IContractRepository _contractRepository;
		private readonly ILogger _logger;		
		private readonly AppNavigator _navigator;
		private readonly ShellViewModel _shellViewModel;
		private readonly IMessageDialog _messageDialog;

		private Person Person { get; set; }
		public ObservableCollection<ContractComparisonVm> ContractComparisonListVm { get; set; }
		public IList<Contract> SelectedContractList { get; set; }

		public ICommand SaveCommand { get; set; }
		public ICommand CancelCommand { get; set; }
		public ICommand TitleDoubleClickCommand { get; set; }

		public ContractComparisonViewModel()
		{
			_navigator = Di.Get<AppNavigator>();
			_shellViewModel = Di.Get<ShellViewModel>();
			_contractRepository = Di.Get<IContractRepository>();
			_messageDialog = Di.Get<IMessageDialog>();
			_logger = Di.Get<ILogger>();

			SaveCommand = new Command(Save);
			CancelCommand = new Command(Cancel);
			TitleDoubleClickCommand = new Command(async () => await Reload());

			OnViewLoaded = Load;
		}

		private async void Save()
		{
			try
			{
				_shellViewModel.IsUiBusy = true;

				foreach (var contract in SelectedContractList)
				{
					await _contractRepository.Save(Contract.CopyFromRemote(Person.Id, contract));
				}
			}
			catch (Exception e)
			{
				_navigator.Back();
				_logger.Warning(e.Message);
				_messageDialog.Warning("Unable to save contracts");
			}
			finally
			{
				_shellViewModel.IsUiBusy = false;
				_navigator.Back();
			}
		}

		private void Cancel()
		{
			_navigator.Back();
		}

		public async void Load()
		{
			try
			{
				_shellViewModel.IsUiBusy = true;

				Person = (Person) Arguments;
				await Reload();
			}
			catch (UserException e)
			{
				_messageDialog.Warning(e.Message);
			}
			catch (Exception e)
			{
				_navigator.Back();
				_logger.Warning(e.Message);
				_messageDialog.Warning("Unable to load contracts");
			}
			finally
			{
				_shellViewModel.IsUiBusy = false;
			}
		}

		private async Task Reload()
		{
			var contractsRaw = await _contractRepository.RemoteFetch(Person.FNumber.Code);
			var contractNoList = contractsRaw.Select(x => x.ContractNo).Distinct().ToList();

			ContractComparisonListVm = new ObservableCollection<ContractComparisonVm>();
			SelectedContractList = new List<Contract>();

			foreach (var contractNo in contractNoList)
			{
				var pulledContractList = contractsRaw.Where(x => x.ContractNo == contractNo).ToList();
				var vm = ContractComparisonVm.Create(Person.Id, pulledContractList, SelectedContractList);
				
				ContractComparisonListVm.Add(vm);
			}

			UpdateAll();
		}
	}

	public class ContractComparisonVm : BaseViewModel
	{
		private Contract _selectedContract;
		private bool _isContractSelected;
		public int PersonId { get; set; }
		public string ProductName { get; set; }

		public IList<Contract> SelectedContractList { get; set; }
		public IList<Contract> ContractListPulled { get; set; }

		public string ContractNo { get; set; }
		public Contract PreviousSelectedContract { get; set; } 
		public Contract SelectedContract
		{
			get { return _selectedContract; }
			set
			{
				SetProperty(ref _selectedContract, value);
				OnAccountSelectionChanged();
			}
		}

		public bool IsContractSelected
		{
			get { return _isContractSelected;}
			set
			{
				SetProperty(ref _isContractSelected, value);
				OnContractSelectionChanged();
			}
		}

		private void OnContractSelectionChanged()
		{
			if (!IsContractSelected)
			{
				SelectedContractList.RemoveAt(SelectedContractList.IndexOf(SelectedContract));
			}
			else
			{
				if(SelectedContract == null)
					return;

				SelectedContractList.Add(SelectedContract);
			}
		}

		private void OnAccountSelectionChanged()
		{
			if (!IsContractSelected || SelectedContract == null)
				return;

			if (PreviousSelectedContract != null)
			{
				SelectedContractList.RemoveAt(SelectedContractList.IndexOf(PreviousSelectedContract));
			}

			SelectedContractList.Add(SelectedContract);
			PreviousSelectedContract = SelectedContract;
		}

		public static ContractComparisonVm Create(PersonId personId, IList<Contract> pulledContracts, IList<Contract> selectedContracts)
		{
			var productName = pulledContracts.FirstOrDefault() == null ? "" : pulledContracts.FirstOrDefault().Category.Name;
			var subProductName = pulledContracts.FirstOrDefault() == null ? "" :  " - " + pulledContracts.FirstOrDefault().ContractProductName;
			var contractNo = pulledContracts.FirstOrDefault() == null ? "" : pulledContracts.FirstOrDefault().ContractNo;

			var vm = new ContractComparisonVm
			{
				ProductName = productName + subProductName,
				PersonId = personId.Value,
				ContractNo = contractNo,

				IsContractSelected = true,

				SelectedContractList = selectedContracts,
				ContractListPulled =  pulledContracts,
			};

			return vm;
		}
	}
}