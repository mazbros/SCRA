﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Contracts;
using Scra.Model.Tools;

namespace Scra.Views.Benefits
{
    public class BenefitActionVm
    {
        public int BenefitIntervalId { get; set; }
        public int BenefitId { get; set; }
	    public int InquiryTaskId { get; set; }
        public int TaskId { get; set; }
        public string CR { get; set; }

        public string InquiryDate { get; set; }
        public string ActionDate { get; set; }
        public string TaskType { get; set; }
        public string TaskStatus { get; set; }
        public string SCRA_Code { get; set; }
        public string AdIntervalListString { get; set; }

		public ICommand OnLeftClick { get; set; }
		public ICommand OnRightClick { get; set; }

		public static BenefitActionVm Create(IList<BenefitEvent> benefitEvents)
        {
            var count = benefitEvents.Count;
            var cr = string.Concat(Enumerable.Repeat("\n", count - 1));
	        

			var benefitEventVm = new BenefitActionVm
            {
                CR = cr,

	            BenefitIntervalId = benefitEvents.Select(x => x.BenefitIntervalId).First(),
				BenefitId = benefitEvents.Select(x => x.BenefitId).First(),
                TaskId = benefitEvents.Select(x => x.TaskId).First(),
                InquiryTaskId = benefitEvents.Select(x => x.InquiryTaskId).First(),

                InquiryDate = benefitEvents.Select(x => string.Format("{0:MM/dd/yyyy}", x.InquiryDate)).First() + cr,
                ActionDate = benefitEvents.Select(x => string.Format("{0:MM/dd/yyyy}", x.ActionDate)).First() + cr,
                TaskType = benefitEvents.Select(x => x.TaskType.Name).First() + cr,
                TaskStatus = benefitEvents.Select(x => x.TaskStatus.Name).First() + cr,
                AdIntervalListString = benefitEvents.Select(x=>x.GetAdIntervalText()).Aggregate((i,j) => i + "\n" + j),

                SCRA_Code = benefitEvents.Select(x => x.SCRA_Code).First(),

			};

            return benefitEventVm;
        }
    }
}