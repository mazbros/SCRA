﻿namespace Scra.Views.Benefits
{
    public partial class ConsumerLoanDetailsView
    {
        public ConsumerLoanDetailsView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ContractSnapshot = ContractSnapshotView.GetViewModel();
        }

        public ConsumerLoanDetailsViewModel GetViewModel()
        {
            return (ConsumerLoanDetailsViewModel)DataContext;
        }
    }
}
