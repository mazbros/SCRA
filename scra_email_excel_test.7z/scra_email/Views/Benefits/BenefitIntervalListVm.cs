﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Formatter = Scra.Controls.Formatter;

namespace Scra.Views.Benefits
{
    public class BenefitIntervalListVm : BaseControlModel
    {
        private BenefitEvent _selectedBenefitEvent;
        private BenefitInterval _selectedBenefitInterval;
        private IList<BenefitEvent> _benefitEventList;

        public BenefitIntervalListVm()
        {
            LeftDoubleClicked = new Command(SelectBenefitEvent);
        }

        private BenefitIntervalListVm(IList<BenefitInterval> benefitIntervalList,
                                    PersonId personId,
                                    Action<BenefitEvent> itemSelected, 
                                    Action<BenefitInterval, TaskType> newBenefit,
                                    Action<BenefitInterval, TaskType> addBenefit,
                                    Action<BenefitInterval, TaskType> editBenefit,
                                    Action<BenefitInterval, TaskType> contactCustomer,
                                    Action<BenefitInterval, TaskType> continueBenefit,
                                    Action<BenefitInterval, TaskType> extendBenefit,
                                    Action<BenefitInterval, TaskType> removeBenefit,
                                    Action<BenefitInterval, TaskType> denyBenefit,
                                    Action<BenefitEvent> editContract)
        {
            PersonId = personId;

	        BenefitIntervalList = benefitIntervalList;

	        foreach (var benefitInterval in BenefitIntervalList)
			{
		        benefitInterval.OnBenefitActionSelected = OnBenefitActionSelectedHandler;
				foreach (var benefitActionVm in benefitInterval.BenefitActionList)
				{
					benefitActionVm.OnLeftClick = new Command(() => OnBenefitActionSelectedHandler(benefitActionVm.BenefitIntervalId));
					benefitActionVm.OnRightClick = new Command(() => OnBenefitActionSelectedHandler(benefitActionVm.BenefitIntervalId));
				}
			}

            var user = Di.Get<IUser>();
            var readOnlyMode = user.Type.Equals(UserType.Guest);
	        
			IsBenefitEditable = !readOnlyMode;
            if(!readOnlyMode)
                ContractCommand = new Command(() => editContract(LatestBenefitEvent));

            LeftDoubleClickedAction = itemSelected;

            NewBenefitCommand = new Command(()=>newBenefit(SelectedBenefitInterval, TaskType.ADD_BENEFIT));
            CommunicationCommand = new Command(() => contactCustomer(SelectedBenefitInterval, TaskType.CONTACT_CUSTOMER));

			AddPromotionalRate = new Command(()=>editBenefit(SelectedBenefitInterval, TaskType.ADD_PROMOTIONAL_RATE));
	        RemovePromotionalRate = new Command(()=>editBenefit(SelectedBenefitInterval, TaskType.REMOVE_PROMOTIONAL_RATE));
			RemediationCommand = new Command(()=>editBenefit(SelectedBenefitInterval, TaskType.REMEDIATION_REIMBURSEMENT));
            ContinueBenefitCommand = new Command(() => continueBenefit(SelectedBenefitInterval, TaskType.CONTINUE_BENEFIT));
            RemoveBenefitCommand = new Command(()=>removeBenefit(SelectedBenefitInterval, TaskType.REMOVE_BENEFIT));
            ExtendBenefitCommand = new Command(() => extendBenefit(SelectedBenefitInterval, TaskType.EXTEND_BENEFIT));
            DenyBenefitCommand = new Command(() => denyBenefit(SelectedBenefitInterval, TaskType.DENY_BENEFIT));

        }

	    public static BenefitIntervalListVm Create(PersonId personId, 
                                                Tasc requestTask, 
                                                List<BenefitEvent> events, 
                                                Action<BenefitEvent> itemSelected,
                                                Action<BenefitInterval, TaskType> newBenefit,
                                                Action<BenefitInterval, TaskType> addBenefit, 
                                                Action<BenefitInterval, TaskType> editBenefit,
                                                Action<BenefitInterval, TaskType> contactCustomer, 
                                                Action<BenefitInterval, TaskType> continueBenefit, 
                                                Action<BenefitInterval, TaskType> extendBenefit, 
                                                Action<BenefitInterval, TaskType> removeBenefit, 
                                                Action<BenefitInterval, TaskType> denyBenefit,
                                                Action<BenefitEvent> editContract)
        {            
            var firstEvent = events.FirstOrDefault();


            var productName = firstEvent != null ? ContractCategory.Parse(firstEvent.SCRA_Code).Name + (firstEvent.SubProductName.Length == 0 ? "" : " - ") + firstEvent.SubProductName : "";
	        productName = productName.TrimEnd(' ').TrimEnd('-').TrimEnd(' ');

			var benefitIntervalList = new List<BenefitInterval>();

            var benefitIntervalId = events.Where(x => x.BenefitIntervalId != 0).Select(x => x.BenefitIntervalId).Distinct().ToList();

			foreach (var globalBenefitId in benefitIntervalId)
            {
                var benefitInterval = BenefitInterval.Create(events.Where(x => x.BenefitIntervalId == globalBenefitId).ToList());
                benefitIntervalList.Add(benefitInterval);
            }

            var inquiryIds = events.Where(x => x.BenefitIntervalId == 0).Select(x => x.InquiryId).Distinct().ToList();
            foreach (var inquiryId in inquiryIds)
            {
                var benefitInterval = BenefitInterval.Create(events.Where(x => x.InquiryId == inquiryId && x.BenefitIntervalId == 0).ToList());
                benefitIntervalList.Add(benefitInterval);
            }

            var contractListItem = new BenefitIntervalListVm(benefitIntervalList, personId, itemSelected, newBenefit, addBenefit, editBenefit, contactCustomer, continueBenefit, extendBenefit, removeBenefit, denyBenefit, editContract)
            {
				
				RequestTask = requestTask,
                LatestBenefitEvent = firstEvent,
                ProductName = productName,
                HasProduct = true,
                ContractNo = firstEvent != null ? firstEvent.ContractNo : "",
                AccountNum = firstEvent != null ? firstEvent.AccountNumber : "",
                OpenDate = firstEvent != null ? Formatter.Date(firstEvent.OpenDate) : null,
                CloseDate = firstEvent != null ? Formatter.Date(firstEvent.CloseDate) : null,                   
                ContractId = firstEvent != null ? firstEvent.ContractId : 0,
                CustomerName = firstEvent != null ? firstEvent.CustomerName : "",
            };
            
            return contractListItem;
        }

	    public void OnBenefitActionSelectedHandler( int benefitIntervalId)
	    {
		    SelectedBenefitInterval = BenefitIntervalList.FirstOrDefault(x => x.BenefitIntervalId == benefitIntervalId);
	    }

		public static BenefitIntervalListVm Create(Benefit benefit, Action showTask)
        {
            var contractListItem = new BenefitIntervalListVm()
            {
                HasProduct = false,
                NoContractLabel = "Request denied due to no product",
                Status = benefit.Status.Name,
                IsBenefitEditable = false,
                NoContractClicked = new Command(showTask),
                
            };

            return contractListItem;
        }

        public BenefitInterval SelectedBenefitInterval
        {
            get { return _selectedBenefitInterval;  }
            set
            {
                SetProperty(ref _selectedBenefitInterval, value);
                //SelectBenefitInterval();
            }
        }

        private void SelectBenefitInterval()
        {
            BenefitEventList = SelectedBenefitInterval.BenefitEvents;
        }

        private void SelectBenefitEvent()
        {
            LeftDoubleClickedAction(SelectedBenefitEvent);
        }


        public IList<BenefitEvent> BenefitEventList
        {
            get { return _benefitEventList; }
            set
            {
                SetProperty(ref _benefitEventList, value);
            }

        }
        public IList<BenefitInterval> BenefitIntervalList { get; set; }

        public BenefitEvent SelectedBenefitEvent
        {
            get { return _selectedBenefitEvent;}
            set
            {
                SetProperty(ref _selectedBenefitEvent, value);
                SelectBenefitEvent();
            }
        }

        public BenefitEvent LatestBenefitEvent { get; set; }
        public Tasc RequestTask { get; set; }
        public ICommand LeftDoubleClicked { get; set; }
        public Action<BenefitEvent> LeftDoubleClickedAction { get; set; }
        public int ContractId { get; set; }
        public string NoContractLabel { get; set; }
        public ICommand NoContractClicked { get; set; }

        public string Status { get; set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }
        public string ContractNo { get; set; }
        public string AccountNum { get; set; }
        public string ProductName { get; set; }
        public string CustomerName { get; set; }
        public PersonId PersonId { get; set; }
        public bool IsBenefitEditable { get; set; }
        public ICommand ContractCommand { get; set; }
        public bool HasProduct { get; set; }

        public ICommand NewBenefitCommand { get; set; }
        public ICommand CommunicationCommand { get; set; }
	    public ICommand AddPromotionalRate { get; set; }
	    public ICommand RemovePromotionalRate { get; set; }
		public ICommand RemediationCommand { get; set; }

        public ICommand ContinueBenefitCommand { get; set; }
        public ICommand ExtendBenefitCommand { get; set; }
        public ICommand RemoveBenefitCommand { get; set; }
        public ICommand DenyBenefitCommand { get; set; }

	    public bool IsContextMenuAvailable { get; set; }
    }
}