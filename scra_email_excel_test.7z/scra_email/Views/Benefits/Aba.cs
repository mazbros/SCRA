using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Views.Benefits
{
    public struct Aba : IEquatable<Aba>
    {
        private readonly string _code;
        private readonly string _name;

        public string Code
        {
            get { return _code; }
        }
        public string Name
        {
            get { return _name; }
        }

        public static readonly Aba Empty = new Aba("empty","");
        public static readonly Aba One = new Aba("011075150", "011075150");
        public static readonly Aba Two = new Aba("231372691", "231372691");

        public static readonly Dictionary<string, Aba> AbaMap =
            new[] {Empty, One, Two}.ToDictionary(x => x.Code, x => x);

        public Aba(string code, string name)
        {
            _name = name;
            _code = code;
        }

        public static Aba Parse(string code)
        {
            if (code == null)
            {
                return Empty;
            }

            Aba aba;
            if (AbaMap.TryGetValue(code, out aba))
            {
                return aba;
            }

            return new Aba(code, code);
        }

        public override int GetHashCode()
        {
            return Code != null ? Code.GetHashCode() : 0;
        }

        
        public override bool Equals(object obj)
        {
            if (!(obj is Aba))
            {
                return false;
            }
            return Equals((Aba)obj);
        }

        public bool Equals(Aba other)
        {
            return Code == other.Code;
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(Aba obj1, Aba obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(Aba obj1, Aba obj2)
        {
            return !(obj1 == obj2);
        }
    }
}