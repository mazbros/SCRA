using System.Collections.Generic;
using Scra.Model.Extensions;

namespace Scra.Views.Benefits
{
    public class AbaList 
    {

        private IReadOnlyCollection<Aba> _items;

        private AbaList()
        {

        }

        public static AbaList Create()
        {
            IList<Aba> ITEMS = new List<Aba>
            {
                Aba.Empty,
                Aba.One,
                Aba.Two
            };

            return new AbaList
            {
                _items = ITEMS.AsReadOnly()
            };
        }

        public IReadOnlyCollection<Aba> All()
        {
            return _items;
        }

        
    }
}