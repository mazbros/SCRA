﻿namespace Scra.Views.Benefits
{
    public partial class ProductCommunicationView
    {
        public ProductCommunicationView()
        {
            InitializeComponent();
			SetupViewModel();
		}

		private void SetupViewModel()
		{
			var vm = GetViewModel();
			//vm.ServicememberInformation = ServiceMemberInfoView.GetViewModel();
			vm.Attachments = AttachmentsControl.GetViewModel();
			vm.SaveCancel = SaveCancelModule.GetViewModel();
		}

		private ProductCommunicationViewModel GetViewModel()
		{
			return (ProductCommunicationViewModel)DataContext;
		}
	}
}
