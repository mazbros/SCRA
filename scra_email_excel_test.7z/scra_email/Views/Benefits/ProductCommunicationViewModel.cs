﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Controls.Modules;
using Scra.Model.Communication;
using Scra.Model.ContactMethods;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.Exceptions;
using Scra.Model.Letters;
using Scra.Model.Logs;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Tools;

using Scra.State;
using Scra.Views.Files;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class ProductCommunicationViewModel : BaseViewModel
    {
        private Benefit _benefit;
        private int _benefitId;
        //private readonly AppNavigator _navigator;
        private readonly IBenefitRepository _benefitRepository;
        private readonly ICommunicationRepository _communicationRepository;
        private readonly IMessageDialog _messageDialog;
        private ContactMethodList _contactMethods;
        private LetterList _letters;
        private const string FILE_ENTITY = "Benefits";
        private ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;
	    private readonly ILogger _logger;

		public ProductCommunicationViewModel()
        {
            SubTaskIdentifier = SubTaskType.ProductCommunication;

            _communicationRepository = Di.Get<ICommunicationRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            ResponseMethods = new ObservableCollection<ContactMethod>();
            Letters = new ObservableCollection<Letter>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();
	        _logger = Di.Get<ILogger>();
			//_navigator = Di.Get<AppNavigator>();
			GenerateLetterCommand = new Command(GenerateLetter);

            OnViewLoaded = Load;

        }

        private void Cancel()
        {
            Load();
        }

        public ObservableCollection<ContactMethod> ResponseMethods { get; set; }
        public ObservableCollection<Letter> Letters { get; set; }

        public DateTime? ResponseDate { get; set; }
        public ContactMethod ResponseMethod { get; set; }
        public Letter SelectedLetter { get; set; }
        public string ResponseText { get; set; }

        public ProductCommunication Communication { get; set; }
        //public ServicememberInformationViewModel ServicememberInformation { get; set; }
        public FileAttachmentsControlModel Attachments { get; set; }
        public SaveCancelModuleViewModel SaveCancel { get; set; }
        public SubTaskType SubTaskIdentifier { get; set; }
        public ICommand GenerateLetterCommand { get; set; }

        private async void GenerateLetter()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;

                var letter = await SelectedLetter.GenerateLetter(Communication);

                var path = Path.Combine(DirectoryUtility.GetTempDirectory(), letter.Name + ".mht");

                try
                {
                    Encoding wind1252 = Encoding.GetEncoding(1252);
                    var result = wind1252.GetBytes(letter.Template.Content);

                    File.WriteAllBytes(path, result);

                    //var word = new Application {Visible = false};
                    //var wordDoc = word.Documents.Open(path, ReadOnly: false);

                    //var docPath = Path.Combine(DirectoryUtility.GetTempDirectory(), letter.Name + ".docx");
                    //wordDoc.SaveAs2(docPath, WdSaveFormat.wdFormatXMLDocument);

                    //wordDoc.Close();
                    //word.Quit();

                    OpenMicrosoftWord(path);
                    ResponseDate = DateTime.Now;
                    UpdateAll();
                }
                catch
                {
                    throw new UserException("Cannot overwrite the current file, please close and try again!");
                }                                  
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, ex.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        public void OpenMicrosoftWord(string filePath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "WINWORD.EXE";
            startInfo.Arguments = filePath;
            Process.Start(startInfo);
        }

        private async void Load()
        {
            _shellViewModel.IsUiBusy = true;            
            _contactMethods = await ContactMethodList.GetInstance();
            _letters = await LetterList.GetInstance();

            Communication = (ProductCommunication)Arguments;
            
            _benefitId = Communication.BenefitId;
            if (_benefitId != 0)
            {
                _benefit = await _benefitRepository.LoadById(_benefitId);
                Communication.TaskId = _benefit.TaskId;
            }

            //await ServicememberInformation.Load(Communication.PersonId);
            await Attachments.Load(Communication.PersonId.Value, FILE_ENTITY);
            SaveCancel.Load(Save, Cancel);

            Reload();
        }

        private async void Reload()
        {           
            FillView();
            _shellViewModel.IsUiBusy = false;
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
        }

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
	            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskType.RequestReceived));
	            Thread.Sleep(100);
				await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));

	            FillModel();
                await _communicationRepository.Update(Communication);
            }
            catch (BreakException e)
            {
	            _logger.Warning(e.Message);
            }
			catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {	            
				_shellViewModel.IsUiBusy = false;
            }
        }

        private void FillModel()
        {
	        var model = GetModelFromUi();
	        if (Communication.HasChanged(model))
	        {
	            Communication.ResponseMethodId = ResponseMethod.Id;
	            Communication.CommunicationDate = ResponseDate;
	            Communication.ResponseText = ResponseText;
	            Communication.LetterId = SelectedLetter.Id;
				return;
	        }

			throw new BreakException("no change");

		}

	    private ProductCommunication GetModelFromUi()
	    {
			return new ProductCommunication
			{
				ResponseMethodId = ResponseMethod.Id,
				CommunicationDate = ResponseDate,
				ResponseText = ResponseText,
				LetterId = SelectedLetter.Id,
			};
	    }

        private void FillView()
        {
            Letters.Update(_letters.All());
            SelectedLetter = _letters.Get(Communication.LetterId);

            ResponseMethods.Update(_contactMethods.All());
            ResponseMethod = _contactMethods.Get(Communication.ResponseMethodId);

            ResponseText = Communication.ResponseText;
            
            ResponseDate = Communication.CommunicationDate;

            UpdateAll();
        }
    }
}
