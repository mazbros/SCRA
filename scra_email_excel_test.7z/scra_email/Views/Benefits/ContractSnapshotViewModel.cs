﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;

namespace Scra.Views.Benefits
{
    public class ContractSnapshotViewModel : BaseViewModel
    {
        private AppNavigator _navigator;
        private readonly IPersonRepository _personRepository;
        private readonly IBenefitRepository _benefitRepository;
        private IAppStore _store;
        private IUiThread _uiThread;
        private ContractId _contractId;
        private PersonId _personId;
        private int _benefitId;

        public string ServiceMemberName { get; set; }
        public string Title { get; set; }
        public ICommand TitleClicked { get; set; }
        public ICommand SelectCommand { get; set; }
        public IList<BenefitEvent> BenefitEventList { get; set; }
        public Person Person { get; set; }
        public BenefitEvent Contract { get; private set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }
        public string ContractNo { get; set; }
        public string AccountNum { get; set; }
        public string ProductName { get; set; }

        public string Message { get; set; }
        public bool HasMessage { get; set; }



        public BenefitEvent SelectedBenefitEvent { get; set; }

        public ContractSnapshotViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            _personRepository = Di.Get<IPersonRepository>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _store = Di.Get<IAppStore>();
            _uiThread = Di.Get<IUiThread>();

            _store.SubscribeCommand(Act.TASK_STATUS_CHANGED, ReloadAct);

            TitleClicked = new Command(OnTitleClicked);
            SelectCommand = new Command(SelectBenefitEvent);
        }

        private void ReloadAct(IAct obj)
        {
            _uiThread.Execute(async() => await Reload());
        }

        private async void SelectBenefitEvent()
        {
            if (SelectedBenefitEvent == null
                || SelectedBenefitEvent.BenefitId == 0
                || SelectedBenefitEvent.TaskType == TaskType.DENY_BENEFIT
                || SelectedBenefitEvent.TaskType == TaskType.CONTACT_CUSTOMER)
            {
                await Task.Run(() => DisplayMessage(SelectedBenefitEvent));
                await Reload();
                return;
            }
            NavigateBenefitDetail.Navigate(SelectedBenefitEvent);
        }

        private void DisplayMessage( BenefitEvent benefitEvent)
        {
            HasMessage = true;
            Message = benefitEvent.TaskType.Name + " " + "does not have benefit detail.";
            UpdateAll();

            Thread.Sleep(3000);

            HasMessage = false;
            Message = "";
            UpdateAll();
        }

        private void OnTitleClicked()
        {
            _navigator.Benefits(Person.Id);
        }

        public async Task Load(ContractId contractId, PersonId personId, int benefitId)
        {
            _contractId = contractId;
            _personId = personId;
            _benefitId = benefitId;

            await Reload();
        }

        private async Task Reload()
        {
            BenefitEventList = await _benefitRepository.LoadEvent(_benefitId);
            Person = await _personRepository.Get(_personId);
            Contract = BenefitEventList.FirstOrDefault();

            SelectedBenefitEvent = BenefitEventList.FirstOrDefault(x => x.BenefitId == _benefitId);
            FillView();
        }

        private void FillView()
        {
            
            ServiceMemberName = "Servicemember (" + Person.Name.FullName + ")";

            ProductName = ContractCategory.Parse(Contract.SCRA_Code).Name + " - " + Contract.SubProductName;
            ContractNo = Contract.ContractNo;
            AccountNum = Contract.AccountNumber;
            OpenDate = Formatter.Date(Contract.OpenDate);
            CloseDate = Formatter.Date(Contract.CloseDate);
            UpdateAll();
        }
    }
}
