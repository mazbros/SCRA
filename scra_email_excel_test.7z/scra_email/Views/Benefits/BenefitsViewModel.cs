﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Inquiries;
using Scra.Model.Logs;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class BenefitsViewModel : BaseViewModel
    {
        private readonly IPersonRepository _personRepository;
        private readonly IContractRepository _contractRepository;
        private readonly ILogger _logger;
        private int _personId;
        private readonly AppNavigator _navigator;
        private List<BenefitIntervalListVm> _contractVms;
        private readonly ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;
        private readonly IMessageDialog _messageDialog;
        private readonly IBenefitRepository _benefitRepository;
        private IAppStore _store;
        private IUiThread _uiThread;
        private Tasc _task;

        private const string ERROR_MESSAGE =
            "Can not perform any action. Please make sure the benefit interval is selected properly.";

        public ICommand AddContractCommand { get; set; }
        public ICommand UpdateProductCommand { get; set; }
		public ICommand DenyRequestCommand { get; set; }
        public SubTaskType SubTaskIdentifier { get; set; }
        public ObservableCollection<BenefitIntervalListVm> BenefitEventList { get; set; }
        public ObservableCollection<BenefitIntervalListVm> DependentBenefitEventList { get; set; }
        public string Title { get; set; }
        public ServicememberInformationViewModel ServicememberInformation { get; set; }
        public bool DenyRequestVisible { get; set; }
        public Person Person { get; private set; }
        public IList<Benefit> BenefitList { get; set; }
	    public IList<BenefitEvent> BenefitEvents { get; set; }
		public ActiveDuty SelectedActiveDuty { get; set; }
        public IList<ActiveDuty> SelectedActiveDutyList { get; set; }
        public BenefitEvent SelectedBenefitEvent { get; set; }
        public bool IsActionVisible { get; set; }
		public IList<Contract> Contracts { get; set; }

	    public Visibility IsServicememberVisible { get; set; }
	    public Visibility AreButtonsVisible { get; set; }


	    public BenefitsViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            BenefitEventList = new ObservableCollection<BenefitIntervalListVm>();
            DependentBenefitEventList = new ObservableCollection<BenefitIntervalListVm>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _contractRepository = Di.Get<IContractRepository>();
            _personRepository = Di.Get<IPersonRepository>();
            _store = Di.Get<IAppStore>();
            _dispatcher = Di.Get<IDispatcher>();
            _messageDialog = Di.Get<IMessageDialog>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _logger = Di.Get<ILogger>();
            _uiThread = Di.Get<IUiThread>();

            SubTaskIdentifier = SubTaskType.ProductInformation;
            _store.SubscribeCommand(Act.TASK_STATUS_CHANGED, ReloadAct);

            AddContractCommand = new Command(AddContract);
	        UpdateProductCommand = new Command(UpdateProduct);
			DenyRequestCommand = new Command(DenyRequest);

			OnViewLoaded = Load;
        }

	    private void ReloadAct(IAct obj)
        {
            _uiThread.Execute(async () => await Reload());
        }

        private void Select(BenefitEvent benefitEvent)
        {
            SelectedBenefitEvent = benefitEvent;
        }

        public void Select()
        {
            if(SelectedBenefitEvent == null)
                return;

            NavigateBenefitDetail.Navigate(SelectedBenefitEvent);
            _navigator.Task(SelectedBenefitEvent.TaskId);
        }

        private async void AddContract()
        {
            var contract = Contract.Create(new PersonId(_personId));            
            _navigator.AddContract(contract);
            await Reload();
        }

	    private void UpdateProduct()
	    {
		    try
		    {
			    _shellViewModel.IsUiBusy = true;

			    if (Person.FNumber.IsEmpty())
			    {
				    throw new UserException("FNumber is missing!");
			    }

				_navigator.ContractComparison(Person);
			}
		    catch (BreakException e)
		    {
			    _logger.Warning(e.Message);
		    }
		    catch (UserException e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(e.Message);
		    }
		    catch (Exception e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(e.Message);
		    }
		    finally
		    {
			    _shellViewModel.IsUiBusy = false;
		    }			
		}	    

	    private async void EditContract(BenefitEvent benefitEvent)
        {
            var contract = await _contractRepository.Get(new ContractId(benefitEvent.ContractId));
            _navigator.AddContract(contract);
        }

        private async void Load()
        {
	        try
	        {
		        _shellViewModel.IsUiBusy = true;
		        if (Arguments == null)
		        {
			        await ReloadAll();
			        _shellViewModel.IsUiBusy = false;
			        return;
		        }

		        var type = Arguments.GetType();
		        if (type == typeof(Tasc))
		        {
			        _task = (Tasc)Arguments;
			        _personId = _task.PersonId.Value;
		        }
		        else if (type == typeof(IdArgs))
		        {
			        var args = (IdArgs)Arguments;
			        _personId = args.Id;
		        }

		        await Reload();
		        _shellViewModel.IsUiBusy = false;
			}
			catch (BreakException e)
	        {
		        _logger.Warning(e.Message);
	        }
	        catch (UserException e)
	        {
		        _logger.Warning(e.Message);
		        _messageDialog.Warning(e.Message);
	        }
	        catch (Exception e)
	        {
		        _logger.Warning(e.Message);
		        _messageDialog.Warning("Unable to load benefit page.");
		        _navigator.Back();
			}
	        finally
	        {
		        _shellViewModel.IsUiBusy = false;				
	        }

			
        }

	    private async Task ReloadAll()
	    {			
			BenefitEvents = await _benefitRepository.LoadAllEvents();
			var contractIds = BenefitEvents.OrderByDescending(x => x.OpenDate).Select(x => x.ContractId).Distinct().ToList();

		    _contractVms = new List<BenefitIntervalListVm>();

			foreach (var id in contractIds)
		    {
			    var events = BenefitEvents.Where(c => c.ContractId == id).ToList();
			    var personId = events.Select(x => x.PersonId).First();

			    var vm = BenefitIntervalListVm.Create(new PersonId(personId), _task, events, Select, NewBenefit, AddBenefit, EditBenefit, ContactCustomer, ContinueBenefit, ExtendBenefit, RemoveBenefit, DenyBenefit, EditContract);
			    _contractVms.Add(vm);
		    }

		    FillView(_contractVms);
		}

	    private async Task Reload()
        {
			await ServicememberInformation.Load(new PersonId(_personId));
            Person = await _personRepository.Get(new PersonId(_personId));
            BenefitList = await _benefitRepository.LoadByPerson(_personId);
            var contractList = await _contractRepository.Load(new PersonId(_personId));
            BenefitEvents = await _benefitRepository.LoadEvent(new PersonId(_personId));
            var contractIds = BenefitEvents.OrderByDescending(x=>x.OpenDate).Select(x => x.ContractId).Distinct().ToList();
            DenyRequestVisible = contractList.Count == 0;

            _contractVms = new List<BenefitIntervalListVm>();

            if (contractList.Count == 0)
            {
                foreach (var benefit in BenefitList)
                {
                    var contract = await _contractRepository.Get(benefit.ContractId);
                    if (contract == null)
                    {
                        var v = BenefitIntervalListVm.Create(benefit, () => _navigator.Task(benefit.TaskId));
                        _contractVms.Add(v);
                    }
                }
            }

            foreach (var id in contractIds)
            {
                var events = BenefitEvents.Where(c => c.ContractId == id).ToList();
                var vm = BenefitIntervalListVm.Create(Person.Id, _task, events, Select, NewBenefit ,AddBenefit, EditBenefit, ContactCustomer, ContinueBenefit, ExtendBenefit, RemoveBenefit, DenyBenefit, EditContract);
                _contractVms.Add(vm);               
            }

            FillView(_contractVms);
			await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));            
        }

	    private void AddBenefit(BenefitInterval benefitInterval, TaskType taskType)
        {
            CheckBenefitStatus(benefitInterval, taskType);
            NewBenefit(benefitInterval, taskType);
        }

        private async void NewBenefit(BenefitInterval benefitInterval, TaskType taskType)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;

                GetSelectedActiveDutyList();

                var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).ToList();
                var taskId = 0;
                var benefitIntervalId = 0;

	            CheckActiveDuty(benefitInterval);

                var inquiryId = await GetSelectedInquiryId();
				foreach (var activeDutyId in activeDutyIdList)
                {
                    var newBenefit = Benefit.Create(benefitInterval.ContractId, activeDutyId, _personId, BenefitStatus.Applying, taskId, benefitIntervalId, inquiryId);
                    taskId = await newBenefit.AddBenefit();
                    benefitIntervalId = newBenefit.BenefitIntervalId;
                }

                _navigator.Task(taskId);
                await Reload();
            }
            catch(BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(ERROR_MESSAGE);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

	    private async void ContactCustomer(BenefitInterval benefitInterval, TaskType taskType)
	    {
		    try
		    {
			    _shellViewModel.IsUiBusy = true;

			    CheckBenefitStatus(benefitInterval, taskType);
			    var inquiryId = benefitInterval.InquiryId == 0 ? await GetSelectedInquiryId() : benefitInterval.InquiryId;

			    var newBenefit = Benefit.Create(benefitInterval.ContractId, ActiveDuty.EmptyActiveDutyId, _personId, BenefitStatus.Empty, 0, benefitInterval.BenefitIntervalId, inquiryId);
			    await newBenefit.ContactCustomer();
			    _navigator.Task(newBenefit.TaskId);
			    await Reload();
		    }
		    catch (BreakException e)
		    {
			    _logger.Warning(e.Message);
		    }
		    catch (UserException e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(e.Message);
		    }
		    catch (Exception e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(ERROR_MESSAGE);
		    }
		    finally
		    {
			    _shellViewModel.IsUiBusy = false;
		    }
	    }

	    private async void EditBenefit(BenefitInterval benefitInterval, TaskType taskType)
	    {
		    try
		    {
			    _shellViewModel.IsUiBusy = true;

			    CheckBenefitStatus(benefitInterval, taskType);
			    GetSelectedActiveDutyList();

			    var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).Distinct().ToList();
			    var taskId = 0;
			    var benefitIntervalId = benefitInterval.BenefitIntervalId;

				if (activeDutyIdList.Except(benefitInterval.AdIdList).Any())
					throw new UserException("Selected active duty period is not in the benefit interval. ");

			    var inquiryId = await GetSelectedInquiryId();
				foreach (var activeDutyId in activeDutyIdList)
			    {
				    var newBenefit = Benefit.Create(benefitInterval.ContractId, activeDutyId, _personId, BenefitStatus.Empty, taskId, benefitIntervalId, inquiryId);
				    taskId = await newBenefit.EditBenefit(taskType);

				    benefitIntervalId = newBenefit.BenefitIntervalId;
			    }

			    _navigator.Task(taskId);
			    await Reload();
		    }
		    catch (BreakException e)
		    {
			    _logger.Warning(e.Message);
		    }
		    catch (UserException e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(e.Message);
		    }
		    catch (Exception e)
		    {
			    _logger.Warning(e.Message);
			    _messageDialog.Warning(ERROR_MESSAGE);
		    }
		    finally
		    {
			    _shellViewModel.IsUiBusy = false;
		    }
	    }

		private async void ContinueBenefit(BenefitInterval benefitInterval, TaskType taskType)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;

                CheckBenefitStatus(benefitInterval, taskType);
                GetSelectedActiveDutyList();

                var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).ToList();
                var taskId = 0;
                var benefitIntervalId = benefitInterval.BenefitIntervalId;

	            CheckActiveDuty(benefitInterval);

                var inquiryId = await GetSelectedInquiryId();
				foreach (var activeDutyId in activeDutyIdList)
                {
                    var newBenefit = Benefit.Create(benefitInterval.ContractId, activeDutyId, _personId, BenefitStatus.Empty, taskId, benefitIntervalId, inquiryId);
                    taskId = await newBenefit.ContinueBenefit();
                    benefitIntervalId = newBenefit.BenefitIntervalId;
                }

                _navigator.Task(taskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(ERROR_MESSAGE);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void RemoveBenefit(BenefitInterval benefitInterval, TaskType taskType)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;

                CheckBenefitStatus(benefitInterval, taskType);

                var newBenefit = Benefit.Create(benefitInterval.ContractId, ActiveDuty.EmptyActiveDutyId, _personId, BenefitStatus.Removing, 0, benefitInterval.BenefitIntervalId, benefitInterval.InquiryId);
                await newBenefit.RemoveBenefit();

                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(ERROR_MESSAGE);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

		private async void ExtendBenefit(BenefitInterval benefitInterval, TaskType taskType)
		{
			try
			{
				_shellViewModel.IsUiBusy = true;

				CheckBenefitStatus(benefitInterval, taskType);
				GetSelectedActiveDutyList();

				var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).ToList();
				var taskId = 0;
				var benefitIntervalId = benefitInterval.BenefitIntervalId;

				//CheckActiveDuty(benefitInterval);
				var usedAdIdList = BenefitEvents.Where(x => x.BenefitIntervalId != 0 &&
														  x.BenefitIntervalId != benefitInterval.BenefitIntervalId &&
														  x.ActiveDutyId != 0 &&
														  x.ContractId == benefitInterval.BenefitEvents.Select(y => y.ContractId).First()).Select(x => x.ActiveDutyId).Distinct().ToList();

				foreach (var adId in activeDutyIdList)
				{
					if (usedAdIdList.Contains(adId))
						throw new UserException("Selected active duty period is already in another benefit interval. ");
				}

				var inquiryId = await GetSelectedInquiryId();
				foreach (var activeDutyId in activeDutyIdList)
				{
					var newBenefit = Benefit.Create(benefitInterval.ContractId, activeDutyId, _personId, BenefitStatus.Extending, taskId, benefitIntervalId, inquiryId);
					taskId = await newBenefit.ExtendBenefit();
					benefitIntervalId = newBenefit.BenefitIntervalId;
				}

				_navigator.Task(taskId);
				await Reload();
			}
			catch (BreakException e)
			{
				_logger.Warning(e.Message);
			}
			catch (UserException e)
			{
				_logger.Warning(e.Message);
				_messageDialog.Warning(e.Message);
			}
			catch (Exception e)
			{
				_logger.Warning(e.Message);
				_messageDialog.Warning(ERROR_MESSAGE);
			}
			finally
			{
				_shellViewModel.IsUiBusy = false;
			}
		}

		private async void DenyBenefit(BenefitInterval benefitInterval, TaskType taskType)
		{
			try
			{
				_shellViewModel.IsUiBusy = true;
				CheckBenefitStatus(benefitInterval, taskType);
				GetSelectedActiveDutyList();

				var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).ToList();
				var taskId = 0;
				var benefitIntervalId = 0;
				var denialReason = String.Empty;

				CheckActiveDuty1(benefitInterval);

				var inquiryId = await GetSelectedInquiryId();
				foreach (var activeDutyId in activeDutyIdList)
				{
					var newBenefit = Benefit.Create(benefitInterval.ContractId, activeDutyId, _personId, BenefitStatus.Denying, taskId, benefitIntervalId, inquiryId);

					if (denialReason == String.Empty)
					{
						_navigator.EnterDenialReason(newBenefit);
						denialReason = newBenefit.DenialReason;
						if (newBenefit.DenialReason == null)
							throw new UserException("Denial Reason is required");
					}
					else
					{
						newBenefit.DenialReason = denialReason;
					}

					taskId = await newBenefit.DenyBenefit();
					benefitIntervalId = newBenefit.BenefitIntervalId;
				}

				_navigator.Task(taskId);
				await Reload();
			}
			catch (BreakException e)
			{
				_logger.Warning(e.Message);
			}
			catch (UserException e)
			{
				_logger.Warning(e.Message);
				_messageDialog.Warning(e.Message);
			}
			catch (Exception e)
			{
				_logger.Warning(e.Message);
				_messageDialog.Warning(ERROR_MESSAGE);
			}
			finally
			{
				_shellViewModel.IsUiBusy = false;
			}
		}

		private async void DenyRequest()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var activeDuty = await Person.GetLastActiveDuty();
                var newBenefit = Benefit.CreateBenefitWithNoProduct(Person.Id, activeDuty, "No Product", 0);
                
                var tascFactory = Di.Get<ITascFactory>();
                var task = await tascFactory.DenyBenefit(newBenefit.PersonId, _task.InquiryId);

                newBenefit.TaskId = task.Id;
                await _benefitRepository.Save(newBenefit);

                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(ERROR_MESSAGE);
            }
            finally
            {                
                _shellViewModel.IsUiBusy = false;
            }            
        }

        private async Task<int> GetSelectedInquiryId()
        {
            var inquiryRepository = Di.Get<IInquiryRepository>();
            var benefitRequestList = await inquiryRepository.LoadByPerson(Person.Id);

            var inquiryIdCount = benefitRequestList.Count();

            if (inquiryIdCount == 0)
            {
                throw new UserException("Benefit request is needed for benefit decisions");
            }

            if (inquiryIdCount == 1)
            {
                var inquiryId = benefitRequestList.FirstOrDefault() == null ? 0 : benefitRequestList.FirstOrDefault().Id;
                return inquiryId;
            }

            var na = new NavigatorArguments();
            na.NavigatorArgumentList.Add(new PersonId(_personId));
            _navigator.InquirySelection(na);
            if ((int)na.NavigatorArgumentList[1] == 0)
                throw new BreakException("User canceled");

            return (int)na.NavigatorArgumentList[1];
        }

        private void GetSelectedActiveDutyList()
        {
            if (ServicememberInformation.HasActiveDuty && ServicememberInformation.ActiveDutyList.Count > 1)
            {
                var na = new NavigatorArguments();

                na.NavigatorArgumentList.Add(new PersonId(_personId));
                _navigator.ActiveDutySelection(na);

                if (na.NavigatorArgumentList.Count == 1)
                    throw new BreakException("User canceled");
                SelectedActiveDutyList = (IList<ActiveDuty>) na.NavigatorArgumentList[1];
            }
            else if (ServicememberInformation.HasActiveDuty)
            {
                SelectedActiveDutyList = new List<ActiveDuty>
                {
                    ServicememberInformation.SelectedActiveDuty.ActiveDuty
                };

            }
            else
            {
                SelectedActiveDutyList = new List<ActiveDuty>
                {
                    ActiveDuty.NoActiveDuty()
                };
            }
        }

	    private void CheckActiveDuty(BenefitInterval benefitInterval)
        {
            if (!ServicememberInformation.HasActiveDuty)
            {
                var msg = "Not eligible for benefit! There is no active duty";
                throw new UserException(msg);
            }

	        var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).Distinct().ToList();
			var usedAdIdList = BenefitEvents.Where(x => x.BenefitIntervalId != 0 &&
														x.ActiveDutyId != 0 &&
														x.ContractId == benefitInterval.BenefitEvents.Select(y => y.ContractId).First()).Select(x => x.ActiveDutyId).Distinct().ToList();
			foreach (var adId in activeDutyIdList)
			{
				if (usedAdIdList.Contains(adId))
					throw new UserException("Selected active duty period is already in this or another benefit interval. ");
			}
		}

	    private void CheckActiveDuty1(BenefitInterval benefitInterval)
	    {
		    var activeDutyIdList = SelectedActiveDutyList.Select(x => x.Id).Distinct().ToList();
		    var usedAdIdList = BenefitEvents.Where(x => x.BenefitIntervalId != 0 &&
		                                                x.ActiveDutyId != 0 &&
		                                                x.ContractId == benefitInterval.BenefitEvents.Select(y => y.ContractId).First()).Select(x => x.ActiveDutyId).Distinct().ToList();
		    foreach (var adId in activeDutyIdList)
		    {
			    if (usedAdIdList.Contains(adId))
				    throw new UserException("Selected active duty period is already in this or another benefit interval. ");
		    }
	    }


		private void CheckBenefitStatus(BenefitInterval benefitInterval, TaskType actionType)
        {
			benefitInterval.ValidateActionStatus(actionType);
        }

        private async Task MisdirecteCurrentTask(int taskId)
        {
            var taskRepository = Di.Get<ITaskRepository>();
            await taskRepository.DumpTask(taskId);
            _navigator.Task(taskId);
        }
		  
        private void FillView(IList<BenefitIntervalListVm> contracts)
        {
            BenefitEventList.Update(contracts);
            
            UpdateAll();
        }
    }

    public class NavigateBenefitDetail
    {
        public static void Navigate(BenefitEvent benefitEvent)
        {
            var navigator = Di.Get<AppNavigator>();
	        var _message = Di.Get<IMessageDialog>();

			if (benefitEvent == null
                || benefitEvent.BenefitId == 0
                || benefitEvent.TaskType == TaskType.DENY_BENEFIT
                || benefitEvent.TaskType == TaskType.CONTACT_CUSTOMER)
            {
				var msg = "Benefit detail is not available for this action. ";
	            _message.Warning(msg);
	            return;
            }
            
            navigator.Task(benefitEvent.TaskId);

            var type = ContractCategory.Parse(benefitEvent.SCRA_Code);
            if (type == ContractCategory.Commercial)
            {
                navigator.CommercialLoan(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.ConsumerLoan)
            {
                navigator.ConsumerLoan(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.CreditCard)
            {
                navigator.CreditCardDetails(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.Mortgage)
            {
                navigator.MortgageDetails(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.HomeEquity)
            {
                navigator.HomeEquity(benefitEvent.BenefitId);
            }
        }
    }
}
