using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
//using System.IO;
using System.Linq;
//using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Inquiries;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Inquiries
{
    public class InquiryListViewModel : BaseViewModel
    {
        private readonly IInquiryRepository _repository;
        private readonly AppNavigator _navigator;
        private InquiryListItem _selectedItem;
        private IList<InquiryListItem> _inquiryItems;
        private readonly IMessageDialog _messageDialog;
        private string _searchText;
        //private string _direction;
        private readonly ShellViewModel _shellViewModel;
        //private readonly IUiThread _uiThread;
        //private IList<InquiryListItem> _pagedItems;
        //private int _pageIndex;
        //private int _pageSize;
        //private int _itemLow;
        //private int _itemHigh;
        private bool _isPreviousEnabled;
        private bool _isNextEnabled;
        private string _pagingStats;
        private int _page;

        public InquiryListViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            _repository = Di.Get<IInquiryRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _shellViewModel = Di.Get<ShellViewModel>();
            //_uiThread = Di.Get<IUiThread>();
            //_direction = "Ascending";

            OnViewLoaded = OnLoaded;

            SelectCommand = new Command(Select);
            AddNewCommand = new Command(AddNew);
            //ExportCommand = new Command(Export);
            SearchCommand = new Command(Search);
            ClearCommand = new Command(ClearSearch);

            PreviousCommand = new Command(Previous);
            NextCommand = new Command(Next);

            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);

            Pages = new ObservableCollection<int> {5, 10, 15, 20, 25};
        }

        private async void Next()
        {
            await ReloadList(NextCommand);
        }

        private async void Previous()
        {
            await ReloadList(PreviousCommand);
        }

        private void ClearSearch()
        {
            SearchText = string.Empty;
            //Page = 15;
            Search();
        }

        //public ICommand ExportCommand { get; set; }
        public ICommand AddNewCommand { get; set; }
        public ICommand SelectCommand { get; set; }
        public ICommand SearchCommand { get; set; }
        public ICommand ClearCommand { get; set; }

        public ICommand PreviousCommand { get; set; }
        public ICommand NextCommand { get; set; }
        public ObservableCollection<int> Pages { get; set; }

        public PersonId PersonId { get; set; }

        public int Page
        {
            get { return _page; } 
            set { SetProperty(ref _page, value); }
        }

        public string SearchText
        {
            get { return _searchText; }
            set { SetProperty(ref _searchText, value); }
        }
        public InquiryListItem SelectedItem
        {
            get { return _selectedItem; }
            set { SetProperty(ref _selectedItem, value); }
        }
        public IList<InquiryListItem> InquiryItems
        {
            get { return _inquiryItems; }
            set { SetProperty(ref _inquiryItems, value); }
        }

        //public IList<InquiryListItem> PagedItems
        //{
        //    get { return _pagedItems; }
        //    set { SetProperty(ref _pagedItems, value); }
        //}

        private void AddNew()
        {
            _navigator.Task(0);
            _navigator.NewInquiry();
        }

        private async void Select()
        {
            if (SelectedItem == null || IsSelectOnlyMode)
            {
                return;
            }
            var taskId = await _repository.GetTaskByInquiry(SelectedItem.Id);
            _navigator.Inquiry(SelectedItem.Id);
            _navigator.Task(taskId);
        }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public bool IsPreviousEnabled
        {
            get { return _isPreviousEnabled; }
            set { SetProperty(ref _isPreviousEnabled, value); }
        }

        public bool IsNextEnabled
        {
            get { return _isNextEnabled; }
            set { SetProperty(ref _isNextEnabled, value); }
        }

        public string PagingStats
        {
            get { return _pagingStats; }
            set { SetProperty(ref _pagingStats, value); }
        }

        public bool IsSelectOnlyMode { get; set; }
        public bool IsSaveCancelVisible { get; set; }
	    public bool IsInitiateVisible { get; set; }

        private async void OnLoaded()
        {            
            if (Arguments != null)
            {

                var na = (NavigatorArguments)Arguments;
                PersonId = (PersonId)na.NavigatorArgumentList[0];

	            IsSelectOnlyMode = true;
				IsSaveCancelVisible = true;
                IsInitiateVisible = false;

                var inquirySnapshots = await _repository.LoadByPerson(PersonId);
                //BenefitRequestList = inquirySnapshots.Select(InquiryListItem.Create).ToList();
                InquiryItems = inquirySnapshots.Select(InquiryListItem.Create).ToList();

	            UpdateAll();
                return;
            }

	        IsSelectOnlyMode = false;
			IsSaveCancelVisible = false;
			//_pageIndex = -1;
            await ReloadList(null);
            
            //UpdatePages();
            //Page = InquiryItems.Count;
            _navigator.CloseLeftPanel();
        }

        private void Cancel()
        {
            var na = (NavigatorArguments)Arguments;
            na.NavigatorArgumentList.Add(0);
            CloseView();
        }

        private void Save()
        {
            var na = (NavigatorArguments)Arguments;
            if (SelectedItem == null)
            {
                CloseView();
            }

            na.NavigatorArgumentList.Add(SelectedItem.Id);
            CloseView();
        }

        private async void Search()
        {
            await ReloadList(null);

	        UpdateAll();
			//UpdatePages();
			//Page = InquiryItems.Count;
		}

	    public async Task ReloadList(ICommand command)
	    {
		    try
		    {
			    _shellViewModel.IsUiBusy = true;

			    var models = await _repository.Load(SearchText);
			    InquiryItems = models.Select(InquiryListItem.Create).ToList();
		    }
			catch (UserException ex)
			{
				_messageDialog.Warning(ex);
			}
			catch (Exception ex)
			{
				_messageDialog.Error(ex, "Error during loading.");
			}
			finally
			{
				_shellViewModel.IsUiBusy = false;
				UpdateAll();
			}
		}


		//public async Task ReloadList(ICommand command)
		//{
		//    try
		//    {
		//        _shellViewModel.IsUiBusy = true;

		//        var models = await _repository.Load(SearchText);
		//        InquiryItems = models.Select(InquiryListItem.Create).ToList();


		//        _pageSize = InquiryItems.Count;//Page;

		//        if (command == null)
		//        {
		//            _pageIndex = 0;
		//        }

		//        if (command == NextCommand)
		//        {
		//            _pageIndex++;
		//        }

		//        if (command == PreviousCommand)
		//        {
		//            _pageIndex--;
		//        }

		//        _pagedItems = _inquiryItems.Count >= _pageSize ? _inquiryItems.Skip(_pageIndex * _pageSize).Take(_pageSize).ToList() : _inquiryItems;

		//        if (_pageIndex < 1)
		//        {
		//            _itemLow = 1;
		//            _itemHigh = _inquiryItems.Count <= _pageSize ? _inquiryItems.Count : _pageSize;
		//            _isPreviousEnabled = false;
		//            _isNextEnabled = _itemHigh != _inquiryItems.Count;
		//        }
		//        else
		//        {
		//            _itemLow = _pageIndex * (_inquiryItems.Count <= _pageSize ? 0 : _pageSize) + 1;

		//            _itemHigh = _inquiryItems.Count <= _pageSize ? _inquiryItems.Count :
		//                _itemLow + _pageSize - 1 >= _inquiryItems.Count ? _inquiryItems.Count : _itemLow + _pageSize - 1;

		//            _isPreviousEnabled = true;
		//            _isNextEnabled = _itemHigh != _inquiryItems.Count;
		//        }

		//        //_pagingStats = _itemLow + " - " + _itemHigh + " of " + InquiryItems.Count;
		//        _pagingStats = "" + InquiryItems.Count + (InquiryItems.Count.ToString().EndsWith("1") ? " record" :" records");
		//        PagingStats = _pagingStats;
		//        if (PreviousCommand != null) PreviousCommand.CanExecute(_isPreviousEnabled);
		//        if (NextCommand != null) NextCommand.CanExecute(_isNextEnabled);

		//        PagedItems = _pagedItems.ToList();

		//    }
		//    catch (UserException ex)
		//    {
		//        _messageDialog.Warning(ex);
		//    }
		//    catch (Exception ex)
		//    {
		//        _messageDialog.Error(ex, "Error during loading.");
		//    }
		//    finally
		//    {
		//        _shellViewModel.IsUiBusy = false;
		//        UpdateAll();
		//    }
		//}

		//private void UpdatePages()
		//{
		//	_uiThread.Execute(() =>
		//	{
		//		Pages.Clear();

		//		var i = 5;

		//		if (i < InquiryItems.Count)
		//		{
		//			Pages.Add(i);

		//			while (i <= InquiryItems.Count)
		//			{
		//				i = +i <= 25 ? i + 5 :
		//					i == 50 ? i + 50 :
		//					i == 100 ? i + 100 :
		//					i == 200 ? i + 300 :
		//					i >= 500 ? i + 500 :
		//					i + 10;

		//				if (i >= InquiryItems.Count) break;

		//				Pages.Add(i);
		//			}

		//			Pages.Add(InquiryItems.Count);
		//			//Page = Pages.Count >= 3 ? Pages[2] : Pages[0];
		//		}
		//		else
		//		{
		//			Pages.Add(InquiryItems.Count);
		//			//Page = InquiryItems.Count;
		//		}

		//		UpdateAll();
		//	});
		//}

		//public async Task SortListAsync(string selectedHeaderName)
		//      {
		//          _shellViewModel.IsUiBusy = true;

		//          _direction = _direction == "Descending" ? "Ascending" : "Descending";
		//          var sortedModel = await _repository.Sort(SearchText, selectedHeaderName, _direction);
		//          PagedItems = sortedModel.Select(InquiryListItem.Create).ToList();

		//          _pageSize = InquiryItems.Count;//Page;

		//          _pagedItems = _inquiryItems.Count >= _pageSize ? _inquiryItems.Skip(_pageIndex * _pageSize).Take(_pageSize).ToList() : _inquiryItems;

		//          _itemLow = _pageIndex * (_inquiryItems.Count <= _pageSize ? 0 : _pageSize) + 1;
		//          _itemHigh = _inquiryItems.Count <= _pageSize ? _inquiryItems.Count : _pageSize;

		//          _isPreviousEnabled = _itemLow == 1;
		//          _isNextEnabled = _itemHigh != _inquiryItems.Count;

		//          _pagingStats = _itemLow + " - " + _itemHigh + " of " + InquiryItems.Count;

		//          PagedItems = _pagedItems.ToList();

		//          UpdatePages();

		//          IsBusy = false;
		//          _shellViewModel.IsUiBusy = false;
		//      }

	}
}