﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Controls.MessageDialog;
using Scra.Model.ContactMethods;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Inquiries;
using Scra.Model.Letters;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;
using Scra.Views.Files;
using Scra.Views.Shell;

namespace Scra.Views.Inquiries
{
    public class EditInquiryViewModel : BaseViewModel
    {
        private readonly IInquiryRepository _inquiryRepository;
        private readonly IMessageDialog _messageDialog;
        private ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;

        private int _inquiryId;
        private string _agent;
        private string _personInquiring;
        private string _servicemember;        
        private string _comments;
        private string _responseText;
        private string _acknowledgeDate;        
        private const string FILE_ENTITY = "Requests";

        public EditInquiryViewModel()
        {
            if (InDesignMode())
            {
                return;
            }
            SubTaskIdentifier = SubTaskType.RequestReceived;

            _inquiryRepository = Di.Get<IInquiryRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();
            
            ResponseMethods = new ObservableCollection<ContactMethod>();
            OnViewLoaded = Load;
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
            GenerateLetterCommand = new Command(GenerateLetter);
        }

        public ICommand GenerateLetterCommand { get; set; }

        public ObservableCollection<ContactMethod> ResponseMethods { get; set; }
        public Command SaveCommand { get; set; }
        public Command CancelCommand { get; set; }
        public FileAttachmentsControlModel Attachments { get; set; }
        public DateTime? ScusaConfirmationDate { get; set; }
        public string InquiryDate { get; set; }
        public SubTaskType SubTaskIdentifier { get; private set; }

        public string Agent
        {
            get { return _agent; }
            set { SetProperty(ref _agent, value); }
        }
        public string PersonInquiring
        {
            get { return _personInquiring; }
            set { SetProperty(ref _personInquiring, value); }
        }
        public string Servicemember
        {
            get { return _servicemember; }
            set { SetProperty(ref _servicemember, value); }
        }

        public string ContactMethodLabel { get; set; }

        public string Description { get; set; }
        public string Comments
        {
            get { return _comments; }
            set { SetProperty(ref _comments, value); }
        }
        public string ResponseText
        {
            get { return _responseText; }
            set { SetProperty(ref _responseText, value); }
        }
        public string AcknowledgeDate
        {
            get { return _acknowledgeDate; }
            set { SetProperty(ref _acknowledgeDate, value); }
        }
        public DateTime? ResponseDate { get; set; }
        public DateTime? DmdcValidationDate { get; set; }
        public bool IsOnActiveDuty { get; set; }
        public DateTime? ScusaSentDate1 { get; set; }
        public DateTime? ScusaSentDate2 { get; set; }
        public ContactMethod ResponseMethod { get; set; }
        public bool ScusaVisible { get; set; }
        public bool IsCompleted { get; set; }
        public bool IsNotesVisible { get; set; }
        public bool IsSmOnAdVisible { get; set; }
        public bool IsDmdcValidationDateVisible { get; set; }
        public string InquiryType { get; set; }
        public Inquiry Inquiry { get; private set; }

        private async void GenerateLetter()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;


                var letters = await LetterList.GetInstance();
                var letter = letters.GetByCode(101);

                var newLetter = await letter.GenerateRequestReceived(Inquiry.PersonInquiringId);

                var path = Path.Combine(DirectoryUtility.GetTempDirectory(), letter.Name + ".mht");

                try
                {
                    Encoding wind1252 = Encoding.GetEncoding(1252);
                    var result = wind1252.GetBytes(letter.Template.Content);

                    File.WriteAllBytes(path, result);

                    //var word = new Application {Visible = false};
                    //var wordDoc = word.Documents.Open(path, ReadOnly: false);

                    //var docPath = Path.Combine(DirectoryUtility.GetTempDirectory(), letter.Name + ".docx");
                    //wordDoc.SaveAs2(docPath, WdSaveFormat.wdFormatXMLDocument);

                    //wordDoc.Close();
                    //word.Quit();

                    OpenMicrosoftWord(path);
                    UpdateAll();
                }
                catch
                {
                    throw new UserException("Cannot overwrite the current file, please close and try again!");
                }
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, ex.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        public void OpenMicrosoftWord(string filePath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "WINWORD.EXE";
            startInfo.Arguments = filePath;
            Process.Start(startInfo);
        }

        // ====================================

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var inquiry = await _inquiryRepository.Get(_inquiryId);
                Validate();
                FillModel(inquiry);
                await _inquiryRepository.Update(inquiry);                
                //await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
	            await Task.Run(() =>
	            {
		            Thread.Sleep(100);
		            _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskType.RequestReceived));
		            Thread.Sleep(100);
					_dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskType.Communication));
	            });
				await Reload();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private void Validate()
        {

        }

        private void FillModel(Inquiry inquiry)
        {
            inquiry.Description = Description;
            inquiry.Response.Text = ResponseText;
            inquiry.Comment = Comments;
            inquiry.Scusa.SentDate1 = ScusaSentDate1;
            inquiry.Scusa.SentDate2 = ScusaSentDate2;
            inquiry.Scusa.ConfirmationDate = ScusaConfirmationDate;
            inquiry.Response.Date = ResponseDate;
            inquiry.Response.Method = ResponseMethod;
            inquiry.IsCompleted = IsCompleted;
            inquiry.IsOnActiveDuty = IsOnActiveDuty;
            inquiry.DmdcValidationDate = DmdcValidationDate;
        }

        private void Cancel()
        {
            Load();
        }

        private async void Load()
        {
            try
            {
				await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
				_shellViewModel.IsUiBusy = true;
                var args = (IdArgs) Arguments;
                _inquiryId = args.Id;
                await Reload();
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error on opening.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async Task Reload()
        {
            Inquiry = await _inquiryRepository.Get(_inquiryId);
            var contactMethods = await ContactMethodList.GetInstance();

            await FillView(Inquiry, contactMethods);
            await Attachments.Load(Inquiry.ServicememberId.Value, FILE_ENTITY);
        }

        private async Task FillView(Inquiry inquiry, ContactMethodList contactMethods)
        {
            ResponseMethods.Update(contactMethods.All());
            var id = inquiry.Response.Method.Id;
            ResponseMethod = contactMethods.Get(id);

            IsOnActiveDuty = inquiry.IsOnActiveDuty;

            InquiryDate = Formatter.DateTime(inquiry.InquiryDate);
            Agent = inquiry.Agent.DisplayName;
            PersonInquiring = (await inquiry.GetPersonInquiring()).FullName;
            Servicemember = (await inquiry.GetServiceMember()).FullName;
            if (Servicemember.IsNotEmpty())
            {
                Servicemember = Servicemember;
            }
            ContactMethodLabel = inquiry.ContactMethod.Name;
            InquiryType = inquiry.InquiryType.Name;
            Description = inquiry.Description;
            ResponseText = inquiry.Response.Text;
            Comments = inquiry.Comment;

            ScusaVisible = inquiry.InquiryType == Model.InquiryTypes.InquiryType.AFFILIATE;
            ScusaSentDate1 = inquiry.Scusa.SentDate1;
            ScusaSentDate2 = inquiry.Scusa.SentDate2;
            ScusaConfirmationDate = inquiry.Scusa.ConfirmationDate;
            ResponseDate = inquiry.Response.Date;
            AcknowledgeDate = Formatter.Date(inquiry.AcknowledgeDate);
            IsCompleted = inquiry.IsCompleted;
            IsOnActiveDuty = inquiry.IsOnActiveDuty;
            DmdcValidationDate = inquiry.DmdcValidationDate;

            IsNotesVisible = inquiry.InquiryType != Model.InquiryTypes.InquiryType.BENEFIT_REQUEST;
            IsSmOnAdVisible = inquiry.InquiryType == Model.InquiryTypes.InquiryType.DMDC_CHECK;
            IsDmdcValidationDateVisible = inquiry.InquiryType == Model.InquiryTypes.InquiryType.DMDC_CHECK;

            UpdateAll();
        }

        
    }
}