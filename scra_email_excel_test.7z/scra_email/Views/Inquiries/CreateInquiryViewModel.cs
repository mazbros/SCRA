﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Controls.Modules;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Inquiries;
using Scra.Model.InquiryTypes;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;
using Scra.Views.Persons;
using Scra.Views.Shell;

namespace Scra.Views.Inquiries
{
    public class CreateInquiryViewModel : BaseViewModel
    {
        private readonly IInquiryRepository _inquiryRepository;
        private readonly IPersonRepository _personRepository;
        private readonly ITaskRepository _taskRepository;

        private readonly AppNavigator _navigator;
        private IUser _user;
        private ContactMethod _contactMethod;
        private DependentType _dependentType;
        private InquiryType _inquiryType;
                
        private readonly IMessageDialog _messageDialog;
        private readonly ITascFactory _taskFactory;
        private bool _isServicememberChecked;        
        private IdentificationMethod _identificationMethod;
        private Visibility _identificationMethodVisibility;
        
        private Inquiry _inquiry;        
        private PersonId _inquiringPersonId;
        private Person _inquiringPerson;
        private PersonId _servicememberId;
        private Person _servicemember;
        private ContactMethodList _contactMethods;
        private DependentLink _link;
        private int _taskId;
        private readonly IDispatcher _dispatcher;
        private ShellViewModel _shellViewModel;
        private DependentTypeList _relationships;
        private UserList _agents;
	    private bool _loadedFromPorfolio;

	    public CreateInquiryViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            SubTaskIdentifier = SubTaskType.LogRequest;

            _navigator = Di.Get<AppNavigator>();
            _inquiryRepository = Di.Get<IInquiryRepository>();
            _personRepository = Di.Get<IPersonRepository>();
            Di.Get<IServiceMemberRepository>();
            _user = Di.Get<IUser>();
            _messageDialog = Di.Get<IMessageDialog>();
            _taskFactory = Di.Get<ITascFactory>();
            _taskRepository = Di.Get<ITaskRepository>();
            _dispatcher = Di.Get<IDispatcher>();
            _shellViewModel = Di.Get<ShellViewModel>();

            ContactMethods = new ObservableCollection<ContactMethod>();
            DependentTypes = new ObservableCollection<DependentType>();
            InquiryTypes = new ObservableCollection<InquiryType>();
            Agents = new ObservableCollection<User>();
            Requesting = new InquiryPersonVm("Requesting person");
            Servicemember = new InquiryPersonVm("Servicemember");

            OnViewLoaded = Load;
        }

        public ObservableCollection<ContactMethod> ContactMethods { get; private set; }
        public ObservableCollection<DependentType> DependentTypes { get; private set; }
        public ObservableCollection<InquiryType> InquiryTypes { get; set; }
        public ObservableCollection<User> Agents { get; set; }
        public SaveCancelModuleViewModel SaveCancel { get; set; }

        public InquiryPersonVm Requesting { get; set; }
        public InquiryPersonVm Servicemember { get; set; }
        public SubTaskType SubTaskIdentifier { get; private set; }
        public ContactMethod ContactMethod
        {
            get { return _contactMethod; }
            set { SetProperty(ref _contactMethod, value); }
        }

        public DependentType SelectedDependentType
        {
            get { return _dependentType; }
            set { SetProperty(ref _dependentType, value); }
        }

        public InquiryType InquiryType
        {
            get { return _inquiryType; }
            set
            {
                SetProperty(ref _inquiryType, value);                

                if (value == InquiryType.DMDC_CHECK)
                {
                    IdentificationMethodVisibility = Visibility.Collapsed;

                    ServicememberIfDifferentLabel = "Potential Servicemember: ";
                    IsServicememberChecked = true;
                    ServicememberIfDifferentEnabled = false;

                    IsRequestingPhoneVisible = false;
                    IsRequestingSsnVisible = false;
                    IsServicememberPhoneVisible = false;
                    //IsServicememberSsnVisible = false;
                    IsRelationshipVisible = false;

                    var contactMethods = _contactMethods.All().ToList();
                    ContactMethods.Update(contactMethods);
                    if(_inquiry != null)
                        ContactMethod = _contactMethods.Get(_inquiry.ContactMethod.Id);
                }
                else
                {
                    IdentificationMethodVisibility = Visibility.Collapsed;
                    ServicememberIfDifferentLabel = "Servicemember (if different)";
                    ServicememberIfDifferentEnabled = true;

                    IsRequestingPhoneVisible = true;
                    IsRequestingSsnVisible = true;
                    IsServicememberPhoneVisible = true;
                    IsServicememberSsnVisible = true;
                    IsRelationshipVisible = true;

                    var contactMethods = _contactMethods.All().Where(x => x.Id != 6).ToList();
                    ContactMethods.Update(contactMethods);
                    if (_inquiry != null)
                        ContactMethod = _contactMethods.Get(_inquiry.ContactMethod.Id);
                }

                if (value == InquiryType.BENEFIT_REQUEST)
                {
                    IdentificationMethodVisibility = Visibility.Visible;
                }

                UpdateAll();
            }
        }

        public IUser Agent
        {
            get { return _user; }
            set { SetProperty(ref _user, value); }
        }

        public DateTime? InquiryDate { get; set; }
        public string Description { get; set; }
        public IList<IdentificationMethod> IdentificationMethods { get; set; }
        public IdentificationMethod IdentificationMethod
        {
            get { return _identificationMethod; }
            set { SetProperty(ref _identificationMethod, value); }
        }
        public Visibility IdentificationMethodVisibility
        {
            get { return _identificationMethodVisibility; }
            set { SetProperty(ref _identificationMethodVisibility, value); }
        }

        public bool IsServicememberChecked
        {
            get { return _isServicememberChecked; }
	        set
	        {
		        SetProperty(ref _isServicememberChecked, value);
		        OnServicememberCheckClicked(_isServicememberChecked);
	        }
        }

	    public string ServicememberIfDifferentLabel { get; set; }
        public bool ServicememberIfDifferentEnabled { get; set; }

        public bool IsRequestingPhoneVisible { get; set; }
        public bool IsRequestingSsnVisible { get; set; }
        public bool IsServicememberPhoneVisible { get; set; }
        public bool IsServicememberSsnVisible { get; set; }

        public bool IsRelationshipVisible { get; set; }

	    private async void OnServicememberCheckClicked(bool isServicememberChecked)
	    {
		    if (isServicememberChecked == true && _loadedFromPorfolio)
		    {
			    _inquiringPersonId = PersonId.Empty;
			    //_inquiringPerson = null;

				ClearRequestingPerson();
				await FillServicemember();
			}
		    if (isServicememberChecked == false && _loadedFromPorfolio)
		    {
			    _inquiringPersonId = _servicememberId;
			    _inquiringPerson = _servicemember;

			    FillRequestingPerson();
		    }
		}

	    private void Cancel()
        {
            _navigator.Back();
        }

        private Inquiry FillInquiryModel()
        {
            var selectedInquiryDate = InquiryDate ?? DateTime.MinValue;
            return new Inquiry(_inquiringPersonId, _servicememberId, ContactMethod, Agent, selectedInquiryDate, Description, InquiryType, SelectedDependentType, 
                IdentificationMethod);
        }

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                Validate();
                if (IsRequestTypeChanged())
                {
                    var msg =
                        "By changing request type, the current workflow will be locked and marked as Misdirected. " +
                        "A new workflow will be created with selected type. " +
                        "\nAre you sure about this action?";
                    var r = _messageDialog.ConfirmationBinary(msg);
                    if (r == MessageBoxResult.No)
                    {
                        _shellViewModel.IsUiBusy = false;
                        return;
                    }

                    SetCurrentTaskAsMisdirected();
                    await Task.Run(() =>
                    {
                        Thread.Sleep(500);
                        _navigator.Task(0);
                        _navigator.NewInquiry();

                    });

                    _shellViewModel.IsUiBusy = false;
                    return;
                }

                await SavePerson();
                await SaveInquiry();

                await _navigator.AwaitTask(_taskId);
                await Task.Run(() =>
                {
                    Thread.Sleep(100);
                    _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
                });
                _shellViewModel.IsUiBusy = false;
            }
            catch(BreakException)
            {
                
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private bool IsRequestTypeChanged()
        {
            if (_inquiry == null)
                return false;

            return InquiryType != _inquiry.InquiryType;
        }

        private void SetCurrentTaskAsMisdirected()
        {
            _taskRepository.DumpTask(_taskId);
            _navigator.Task(_taskId);
            _inquiry = null;
        }

        private void Validate()
        {
            ValidateInquiry();
            ValidatePeople();
        }

        private void ValidateInquiry()
        {
            if (InquiryDate == null)
            {
                throw new UserException("Please select Requests Date.");
            }

            if (ContactMethod.IsEmpty())
            {
                throw new UserException("Please select Communication Method.");
            }

            if (InquiryType.IsEmpty())
            {
                throw new UserException("Please select Request Type.");
            }

            if (IdentificationMethodVisibility == Visibility.Visible)
            {
                if (IdentificationMethod.IsEmpty())
                {
                    throw new UserException("Please select Method of Identification.");
                }
            }

            if (Description.IsEmpty())
            {
                throw new UserException("Please fill Requests Notes.");
            }
        }

        private void ValidatePeople()
        {
            Requesting.Validate();
            if (!IsServicememberChecked)
            {
                return;
            }
            Servicemember.Validate();
            if (SelectedDependentType == DependentType.Empty && _inquiryType != InquiryType.DMDC_CHECK)
            {
                throw new UserException("Please select relationship type.");
            }
        }

        private async Task SaveLink()
        {
            if (InquiryType == InquiryType.DMDC_CHECK)
            {
                return;
            }

            if (_link == null)
            {
                _link = DependentLinkFactory.Create(_servicememberId, _inquiringPersonId, SelectedDependentType); 
            }
            else
            {
                await GetDependentType();
                _link.Type = SelectedDependentType;
            }

            await _personRepository.Save(_link);
        }

        private async Task SavePerson()
        {            

            if (_inquiringPersonId.IsEmpty())
            {
                _inquiringPerson = await Requesting.ToModel();
                _inquiringPerson.Origin = InquiryType.Code;
                await CheckDuplicatedEntry(_inquiringPerson);
            }

            await _personRepository.Save(_inquiringPerson);            
            _inquiringPersonId = _inquiringPerson.Id;

            if (!IsServicememberChecked)
            {
                _servicememberId = _inquiringPersonId;
                return;
            }

            if (_servicememberId.IsEmpty())
            {
                _servicemember = await Servicemember.ToModel();
                _servicemember.Origin = InquiryType.Code;
                await CheckDuplicatedEntry(_servicemember);
            }

            await _personRepository.Save(_servicemember);
            _servicememberId = _servicemember.Id;

            if (_servicememberId != _inquiringPersonId && InquiryType != InquiryType.DMDC_CHECK)
                await SaveLink();

        }

        private async Task<Person> SavePersonWithImport(Person personModel)
        {           

            await _personRepository.Save(personModel);

            return personModel;
        }

        private async Task CheckDuplicatedEntry(Person personModel)
        {
            var peopleList = await _personRepository.LoadWithParameter(personModel);
            if (peopleList.Count > 0)
            {
                var msg = "The person with name " + personModel.Name.FullName + " is already in the system." + 
                          "\nTo create a new profile for " + personModel.Name.FullName + " click \"NEW\"." + 
                          "\nTo use existing profile, please select one from the list below.";

                var args = new SelectPersonArgs()
                {
                    PeopleList = peopleList,
                    Message = msg,
                };
                _navigator.SelectPerson(args);

                if (args.Decision == Decision.AddNew)
                    personModel.Id = new PersonId(0);

                if (args.Decision == Decision.SelectOne)
                    personModel.Id = args.SelectedPersonId;

                if (args.Decision == Decision.Cancel)
                    throw new BreakException("User canceled");                
            }            
        }

        private async Task<Inquiry> SaveInquiry()
        {
            var model = FillInquiryModel();

            if (_inquiry == null)
            {
                await _inquiryRepository.Create(model);
                _inquiry = model;
                var task =  await _taskFactory.CreateRequest(model);
                _taskId = task.Id;
            }
            else
            {
                model.Id = _inquiry.Id;
                _inquiry = model;
                await _inquiryRepository.Create(model);
                await _inquiryRepository.UpdateTitle(_inquiry);
            }

            return model;
        }

        private async void Load()
        {
            _shellViewModel.IsUiBusy = true;
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
           
            if (Arguments == null)
            {
	            _loadedFromPorfolio = false;
				await Reload();
                return;
            }

            var type = Arguments.GetType();
            if (type == typeof(IdArgs))
            {
	            _loadedFromPorfolio = false;
				var arg = (IdArgs)Arguments;
                _inquiry = await _inquiryRepository.Get(arg.Id);
                _taskId = await _inquiryRepository.GetTaskByInquiry(_inquiry.Id);

                _inquiringPerson = await _personRepository.Get(_inquiry.PersonInquiringId);
                _inquiringPersonId = new PersonId(_inquiringPerson.Id.Value);

                _servicemember = await _personRepository.Get(_inquiry.ServicememberId);

                if (_servicemember != null)
                {
                    _servicememberId = new PersonId(_servicemember.Id.Value);
                }

                await Reload();

                IsServicememberChecked = _inquiringPersonId != _servicememberId;
                ServicememberIfDifferentEnabled = IsServicememberChecked;

                FillView();

            }
            else if (type == typeof(PersonId))
            {
                var arg = (PersonId)Arguments;
	            _loadedFromPorfolio = true;
				_servicememberId = arg;
                _servicemember = await _personRepository.Get(_servicememberId);

	            _inquiringPersonId = _servicememberId;
	            _inquiringPerson = _servicemember;

                await Reload();
                FillRequestingPerson();
                //FillView();
            }
        }

        private async Task Reload()
        {
            _contactMethods = await ContactMethodList.GetInstance();
            _relationships = await DependentTypeList.GetInstance();
            _agents = await UserList.GetInstance();
            FillDropDowns(_contactMethods.All().ToList(), _relationships, _agents);
            SaveCancel.Load(Save, Cancel);
            _shellViewModel.IsUiBusy = false;
        }


        private void FillDropDowns(IList<ContactMethod> contactMethods, DependentTypeList relationships, UserList agents)
        {
            contactMethods = _inquiryType == InquiryType.DMDC_CHECK ? contactMethods.Where(x => x.Id != 5).ToList() : contactMethods.Where(x => x.Id != 6).ToList();
            
            ContactMethods.Update(contactMethods);            
            ContactMethod = ContactMethod.Empty;

            DependentTypes.Update(relationships.All());
            DependentTypes.Insert(0, DependentType.Empty);
            SelectedDependentType = DependentType.Empty;

            InquiryTypes.Update(InquiryType.InquiryTypeList);
            InquiryTypes.Insert(0, InquiryType.EMPTY);
            InquiryType = InquiryType.EMPTY;

            var current = Di.Get<IUser>();
            Agents.Update(agents.All());
            Agent = Agents.First(x => x.Id == current.Id);

            IdentificationMethods = IdentificationMethod.List.ToList();
            IdentificationMethods.Insert(0,IdentificationMethod.Empty);
            IdentificationMethod = IdentificationMethods.First();

            UpdateAll();
        }

        private void FillRequestingPerson()
        {
            Requesting.FName = _inquiringPerson.Name.First;
            Requesting.MName = _inquiringPerson.Name.Middle;
            Requesting.LName = _inquiringPerson.Name.Last;
            Requesting.Email = _inquiringPerson.Contacts.Email;
            Requesting.Phone = _inquiringPerson.Contacts.Phone;
            Requesting.Ssn = _inquiringPerson.Ssn;

            UpdateAll();
        }

	    private void ClearRequestingPerson()
	    {
			Requesting.FName = null;
		    Requesting.MName = null;
		    Requesting.LName = null;
		    Requesting.Email = null;
		    Requesting.Phone = PhoneNumber.Empty();
		    Requesting.Ssn = Ssn.Empty();

		    UpdateAll();
		}

		private async Task FillServicemember()
        {
            Servicemember.FName = _servicemember.Name.First;
            Servicemember.MName = _servicemember.Name.Middle;
            Servicemember.LName = _servicemember.Name.Last;
            Servicemember.Email = _servicemember.Contacts.Email;
            Servicemember.Phone = _servicemember.Contacts.Phone;
            Servicemember.Ssn = _servicemember.Ssn;

            SelectedDependentType = await GetDependentType();

            UpdateAll();
        }

        private void FillInquiry()
        {
            InquiryDate = _inquiry.InquiryDate;
            ContactMethod = _contactMethods.Get(_inquiry.ContactMethod.Id);

            InquiryType = _inquiry.InquiryType;
            IdentificationMethod = _inquiry.IdentificationMethod;
            Description = _inquiry.Description;
            UpdateAll();
        }


        private async void FillView()
        {
            FillRequestingPerson();

            if (_inquiry != null)
            {
                FillInquiry();
            }

            if (IsServicememberChecked)
            {
                await FillServicemember();
            }

            UpdateAll();
        }

        private async Task<DependentType> GetDependentType()
        {
	        if (_inquiringPerson == null)
	        {
				return DependentType.Empty;
			}

            foreach (var link in _inquiringPerson.DependentLinks)
            {
                var dependent = await link.GetDependent();
                if (_servicememberId == dependent.Id)
                {
                    _link = link;
                    return link.Type;
                }
            }
            return DependentType.Empty;
        }
    }
}