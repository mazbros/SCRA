﻿using System;
using Scra.Model.ContactMethods;
using Scra.Model.Persons;

namespace Scra.Views.Persons
{
    public class PersonConflictVm
    {
        public PersonConflictVm()
        {

        }

        private PersonConflictVm(string importedFName, string importedMName,
            string importedLName, PhoneNumber importedPhone, string importedEmail,
            Ssn importedSsn, Address importedAddress, DateTime? importedDob, 
            string currentFName, string currentMName, string currentLName,
            PhoneNumber currentPhone, string currentEmail, Ssn currentSsn,
            Address currentAddress, DateTime? currentDob,
            ContactMethod currentContactMethod)
        {
            ImportedFName = importedFName;
            ImportedMName = importedMName;
            ImportedLName = importedLName;
            ImportedPhone = importedPhone;
            ImportedPhoneText = importedPhone.GetDisplay();
            ImportedEmail = importedEmail;
            ImportedSsn = importedSsn;
            ImportedSsnText = importedSsn.GetDisplay();
            ImportedContactMethod = currentContactMethod;
            ImportedContactMethodText = currentContactMethod.Name;
            ImportedAddress = importedAddress;
            ImportedDob = importedDob;
            ImportedDobText = string.Format("{0:MM/dd/yyyy}", importedDob);
            ImportedZipCodeText = importedAddress.ZipCode.GetDisplay();

            CurrentFName = currentFName;
            CurrentMName = currentMName;
            CurrentLName = currentLName;
            CurrentPhone = currentPhone;
            CurrentPhoneText = currentPhone.GetDisplay();
            CurrentEmail = currentEmail;
            CurrentSsn = currentSsn;
            CurrentSsnText = currentSsn.GetDisplay();
            CurrentContactMethod = currentContactMethod;
            CurrentContactMethodText = currentContactMethod.Name;
            CurrentAddress = currentAddress;
            CurrentDob = currentDob;
            CurrentDobText = string.Format("{0:MM/dd/yyyy}", currentDob);
            CurrentZipCodeText = currentAddress.ZipCode.GetDisplay();

            if (ImportedFName == CurrentFName)
            {
                SelectedFName = CurrentFName;
            }
            if (ImportedMName == CurrentMName)
            {
                SelectedMName = CurrentMName;
            }
            if (ImportedLName == CurrentLName)
            {
                SelectedLName = CurrentLName;
            }
            if (ImportedPhone == CurrentPhone)
            {
                SelectedPhone = CurrentPhone;
                SelectedPhoneText = currentPhone.GetDisplay();
            }
            if (ImportedEmail == CurrentEmail)
            {
                SelectedEmail = CurrentEmail;
            }
            if (ImportedSsn == CurrentSsn)
            {
                SelectedSsn = CurrentSsn;
                SelectedSsnText = currentSsn.GetDisplay();
            }

            SelectedContactMethod = CurrentContactMethod;
            SelectedContactMethodText = CurrentContactMethod.Name;
            SelectedAddress = new Address();

            if (ImportedAddress.Address1 == CurrentAddress.Address1)
            {
                SelectedAddress.Address1 = CurrentAddress.Address1;
            }
            if (ImportedAddress.Address2 == CurrentAddress.Address2)
            {
                SelectedAddress.Address2 = CurrentAddress.Address2;
            }
            if (ImportedAddress.City == CurrentAddress.City)
            {
                SelectedAddress.City = CurrentAddress.City;
            }
            if (ImportedAddress.State == CurrentAddress.State)
            {
                SelectedAddress.State = CurrentAddress.State;
            }
            if (ImportedAddress.ZipCode == CurrentAddress.ZipCode)
            {
                SelectedAddress.ZipCode = CurrentAddress.ZipCode;
                SelectedZipCodeText = CurrentAddress.ZipCode.GetDisplay();
            }

            if (ImportedDob == CurrentDob)
            {
                SelectedDob = CurrentDob;
                SelectedDobText = CurrentDobText;
            }
        }

        public string ImportedFName { get; set; }
        public string ImportedMName { get; set; }
        public string ImportedLName { get; set; }
        public PhoneNumber ImportedPhone { get; set; }
        public string ImportedPhoneText { get; set; }
        public string ImportedEmail { get; set; }
        public Ssn ImportedSsn { get; set; }
        public string ImportedSsnText { get; set; }
        public ContactMethod ImportedContactMethod { get; set; }
        public string ImportedContactMethodText { get; set; }        
        public Address ImportedAddress { get; set; }
        public DateTime? ImportedDob { get; set; }
        public string ImportedDobText { get; set; }
        public string ImportedZipCodeText { get; set; }
        
        public string CurrentFName { get; set; }
        public string CurrentMName { get; set; }
        public string CurrentLName { get; set; }
        public PhoneNumber CurrentPhone { get; set; }
        public string CurrentPhoneText { get; set; }
        public string CurrentEmail { get; set; }
        public Ssn CurrentSsn { get; set; }
        public string CurrentSsnText { get; set; }
        public ContactMethod CurrentContactMethod { get; set; }
        public string CurrentContactMethodText { get; set; }
        public Address CurrentAddress { get; set; }
        public DateTime? CurrentDob { get; set; }
        public string CurrentDobText { get; set; }
        public string CurrentZipCodeText { get; set; }

        public string SelectedFName { get; set; }
        public string SelectedMName { get; set; }
        public string SelectedLName { get; set; }
        public PhoneNumber SelectedPhone { get; set; }
        public string SelectedPhoneText { get; set; }
        public string SelectedEmail { get; set; }
        public Ssn SelectedSsn { get; set; }
        public string SelectedSsnText { get; set; }
        public ContactMethod SelectedContactMethod { get; set; }
        public string SelectedContactMethodText { get; set; }
        public Address SelectedAddress { get; set; }
        public DateTime? SelectedDob { get; set; }
        public string SelectedDobText { get; set; }
        public string SelectedZipCodeText { get; set; }

        public bool Canceled { get; set; }

        public static PersonConflictVm Create(Person importedPerson, Person currentPerson)
        {
            return new PersonConflictVm(
                importedPerson.Name.First,
                importedPerson.Name.Middle,
                importedPerson.Name.Last,
                importedPerson.Contacts.Phone,
                importedPerson.Contacts.Email,
                importedPerson.Ssn,
                importedPerson.Address,
                importedPerson.Dob,
                currentPerson.Name.First,
                currentPerson.Name.Middle,
                currentPerson.Name.Last,
                currentPerson.Contacts.Phone,
                currentPerson.Contacts.Email,
                currentPerson.Ssn,
                currentPerson.Address,
                currentPerson.Dob,
                currentPerson.ContactMethod);
        }

        public static PersonConflictVm Create(string importedFName,
            string importedMName,
            string importedLName,
            PhoneNumber importedPhone,
            string importedEmail,
            Ssn importedSsn,
            ContactMethod importedContactMethod,
            Address importedAddress,
            DateTime? importedDob,
            string currentFName,
            string currentMName,
            string currentLName,
            PhoneNumber currentPhone,
            string currentEmail,
            Ssn currentSsn,
            ContactMethod currentContactMethod,
            Address currentAddress,
            DateTime? currentDob)
        {
            return new PersonConflictVm(
                importedFName,
                importedMName,
                importedLName,
                importedPhone,
                importedEmail,
                importedSsn,
                importedAddress,
                importedDob,
                currentFName,
                currentMName,
                currentLName,
                currentPhone,
                currentEmail,
                currentSsn,
                currentAddress,
                currentDob,
                currentContactMethod);
        }

        public void SetData()
        {
            Canceled = false;
            SelectedPhone = PhoneNumber.Parse(SelectedPhoneText);
            SelectedSsn = Ssn.Parse(SelectedSsnText);
            SelectedContactMethod = CurrentContactMethod;
            SelectedContactMethodText = CurrentContactMethodText;
            SelectedAddress.Address1 = SelectedAddress.Address1;
            SelectedAddress.Address2 = SelectedAddress.Address2;
            SelectedAddress.City = SelectedAddress.City;
            SelectedAddress.State = SelectedAddress.State;
            SelectedAddress.ZipCode = ZipCode.Parse(SelectedZipCodeText);
            SelectedDob = DateTime.Parse(SelectedDobText);
            SelectedDobText = string.Format("{0:MM/dd/yyyy}", SelectedDob);
            SelectedZipCodeText = SelectedAddress.ZipCode.GetDisplay();
        }

        public void ResetData()
        {
            Canceled = true;
        }


        public static void Merge(PersonConflictVm personConflict, Person selectedPerson)
        {
            selectedPerson.Name.First = personConflict.SelectedFName;
            selectedPerson.Name.Middle = personConflict.SelectedMName;
            selectedPerson.Name.Last= personConflict.SelectedLName;
            selectedPerson.Contacts.Phone = personConflict.SelectedPhone;
            selectedPerson.Contacts.Email = personConflict.SelectedEmail;
            selectedPerson.Ssn = personConflict.SelectedSsn;
            selectedPerson.ContactMethod = personConflict.CurrentContactMethod;
            selectedPerson.Address.Address1 = personConflict.SelectedAddress.Address1;
            selectedPerson.Address.Address2= personConflict.SelectedAddress.Address2;
            selectedPerson.Address.City = personConflict.SelectedAddress.City;
            selectedPerson.Address.State = personConflict.SelectedAddress.State;
            selectedPerson.Address.ZipCode = personConflict.SelectedAddress.ZipCode;
            selectedPerson.Dob = personConflict.SelectedDob;
        }
    }
}
