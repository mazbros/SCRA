﻿using Scra.Model.Persons;

namespace Scra.Views.Persons
{
    public class PersonListItem
    {
        public PersonId Id { get; set; }

        public string Name { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip { get; set; }

        public string Ssn { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public string FNumber { get; set; }

        public static PersonListItem Create(PersonSnapshot person)
        {
            return new PersonListItem
            {
                Id = person.Id,
                City = person.Address.City,
                State = person.Address.State,
                Zip = person.Address.ZipCode.GetDisplay(),
                Name = person.Name.LastFirstName,
                Ssn = person.Ssn.GetDisplay(),
                FNumber = person.FNumber.ToString()
            };
        }

        public static PersonListItem CreateSimple(Person person)
        {
            return new PersonListItem
            {
                Id = person.Id,
                Name = person.Name.LastFirstName,
                Ssn = person.Ssn.GetDisplay(),
                Phone = person.Contacts.Phone.GetDisplay(),
                Email = person.Contacts.Email,
            };
        }
    }
}