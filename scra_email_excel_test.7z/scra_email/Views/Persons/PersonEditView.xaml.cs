﻿namespace Scra.Views.Persons
{
    public partial class PersonEditView
    {
        public PersonEditView()
        {
            InitializeComponent();
            SetupViewModel();
        }
        private void SetupViewModel()
        {
            var vm = GetViewModel();

            vm.SaveCancel = SaveCancelModule.GetViewModel();
        }

        private PersonEditViewModel GetViewModel()
        {
            return (PersonEditViewModel)DataContext;
        }
    }
}
