﻿namespace Scra.Model.ServiceMembers
{
    public class VerifiedByItem
    {

        public int Id { get; private set; }
        public string Name { get; private set; }

        private VerifiedByItem()
        {

        }

        public static VerifiedByItem Empty = new VerifiedByItem() { Id = 0, Name = string.Empty };

        public static VerifiedByItem Create(int id, string name)
        {
            return new VerifiedByItem() {Id = id, Name = name};
        }

    }
}