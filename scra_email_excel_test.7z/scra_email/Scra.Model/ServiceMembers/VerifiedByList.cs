﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.ServiceMembers
{
    public class VerifiedByList
    {
        private IReadOnlyCollection<VerifiedByItem> _items;
        private IDictionary<int, VerifiedByItem> _idNameMap;

        private VerifiedByList()
        {
        }

        public static VerifiedByList Create(IList<VerifiedByItem> items)
        {
            return new VerifiedByList
            {
                _items = items.AsReadOnly(),
                _idNameMap = items.ToDictionary(x => x.Id, x => x)
            };
        }

        public IReadOnlyCollection<VerifiedByItem> All()
        {
            return _items;
        }

        public string GetName(int verifiedById)
        {
            return _idNameMap[verifiedById].Name;
        }

        private static VerifiedByList _instance;
        public static async Task<VerifiedByList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<IServiceMemberRepository>();
                _instance = await repo.GetVerifiedByList();
            }
            return _instance;
        }

        public VerifiedByItem Get(int verifiedById)
        {
            if (verifiedById != 0)
            {
                return _idNameMap[verifiedById];
            }

            return null;
        }

        
    }
}
