﻿using System;
using Scra.Model.BranchOfServices;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public class ActiveDuty
    {
        public static ActiveDuty Create(PersonId personId)
        {
            return new ActiveDuty {PersonId = personId };
        }

        public static ActiveDuty NoActiveDuty()
        {
            return new ActiveDuty { Id = 0 };
        }

        public static int EmptyActiveDutyId = 0;


        public static ActiveDuty Create(int id, int personId, int branchOfServiceId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate)
        {
            return new ActiveDuty
            {
                Id = id,
                PersonId = new PersonId(personId),
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate
            };
        }

        public static ActiveDuty Create(int id, DateTime? startDate, DateTime? endDate, DateTime? noticeDate,
            BranchOfService branchOfService, DateTime? timestamp, string modifiedBy)
        {
            return new ActiveDuty()
            {
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
                BranchOfService = branchOfService,
                ModifiedBy = modifiedBy,
                ModifiedDate = timestamp
            };
        }

        public static ActiveDuty Create(int id, PersonId personId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate,
            BranchOfService branchOfService, VerifiedByItem verifiedBy)
        {
            return new ActiveDuty
            {
                PersonId = personId,
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
                BranchOfService = branchOfService
            };
        }

        public static ActiveDuty Create(int id, PersonId personId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate, BranchOfService branchOfService, VerifiedByItem verifiedBy, DateTime? verifiedByDate)
        {
            return new ActiveDuty
            {
                PersonId = personId,
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
                BranchOfService = branchOfService,
                VerifiedBy = verifiedBy,
                VerifiedByDate = verifiedByDate
            };
        }

        public int Id { get; set; }
        public PersonId PersonId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? NoticeDate { get; set; }
        public BranchOfService BranchOfService { get; set; }
        public ServiceMember ServiceMember { get; set; }

        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }

        public VerifiedByItem VerifiedBy { get; set; }
        public DateTime? VerifiedByDate { get; set; }

        public static ActiveDuty Copy(ActiveDuty activeDuty)
        {
            return new ActiveDuty()
            {
                Id = activeDuty.Id,
                PersonId = activeDuty.PersonId,
                StartDate = activeDuty.StartDate,
                EndDate = activeDuty.EndDate,
                NoticeDate = activeDuty.NoticeDate,
                BranchOfService = activeDuty.BranchOfService,
                ServiceMember = activeDuty.ServiceMember,
                VerifiedBy = activeDuty.VerifiedBy,
                VerifiedByDate = activeDuty.VerifiedByDate

            };
        }

        public bool Changed(ActiveDuty storedActiveDuty)
        {
            if (storedActiveDuty == null)
                return true;

            var isVerifiedBySame = false;
            var isVerifiedByDateSame = false;


            var isIdSame = Id == storedActiveDuty.Id;
            var isPersonIdSame = PersonId == storedActiveDuty.PersonId;
            var isStartDateSame = StartDate == storedActiveDuty.StartDate;
            var isEndDateSame = EndDate == storedActiveDuty.EndDate;
            var isNoticeDateSame = NoticeDate == storedActiveDuty.NoticeDate;
            var isBranchOfServiceSame = BranchOfService.Name == storedActiveDuty.BranchOfService.Name;
            if (storedActiveDuty.VerifiedBy != null)
            {
                isVerifiedBySame = VerifiedBy.Name == storedActiveDuty.VerifiedBy.Name;
            }
            if (storedActiveDuty.VerifiedByDate != null)
            {
                isVerifiedByDateSame = VerifiedByDate == storedActiveDuty.VerifiedByDate;
            }
             
            if (isIdSame &&
                isPersonIdSame &&
                isStartDateSame &&
                isEndDateSame &&
                isNoticeDateSame &&
                isBranchOfServiceSame &&
                isVerifiedBySame &&
                isVerifiedByDateSame)
                return false;

            return true;


        }
    }
}