﻿using System;

namespace Scra.Model.Tasks
{
    public struct SubTaskStatus : IEquatable<SubTaskStatus>
    {
        private readonly string _code;
        private readonly string _name;

        public static readonly SubTaskStatus Empty = new SubTaskStatus("", "Undefined");
        public static readonly SubTaskStatus InProcess = new SubTaskStatus("in_process", "In Process");
        public static readonly SubTaskStatus Completed = new SubTaskStatus("completed", "Completed");
        public static readonly SubTaskStatus Rejected = new SubTaskStatus("rejected", "Rejected");
        public static readonly SubTaskStatus QaCompleted = new SubTaskStatus("qa_completed", "QA Completed");
        public static readonly SubTaskStatus Misdirected = new SubTaskStatus("misdirected", "Misdirected");

        public string Code
        {
            get { return _code; }
        }
        public string Name
        {
            get { return _name; }
        }

        private SubTaskStatus(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static SubTaskStatus Parse(string code)
        {
            if (code == Completed.Code)
            {
                return Completed;
            }
            if (code == InProcess.Code)
            {
                return InProcess;
            }
            if (code == Rejected.Code)
            {
                return Rejected;
            }
            if (code == QaCompleted.Code)
            {
                return QaCompleted;
            }
            if (code == Misdirected.Code)
            {
                return Misdirected;
            }

            return Empty;
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public bool Equals(SubTaskStatus other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is SubTaskStatus))
            {
                return false;
            }
            return Equals((SubTaskStatus)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(SubTaskStatus obj1, SubTaskStatus obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(SubTaskStatus obj1, SubTaskStatus obj2)
        {
            return !(obj1 == obj2);
        }
    }
}