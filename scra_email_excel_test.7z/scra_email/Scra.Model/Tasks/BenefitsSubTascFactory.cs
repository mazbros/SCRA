﻿using System.Collections.Generic;
using Scra.Model.Contracts;

namespace Scra.Model.Tasks
{
    public class BenefitsSubTascFactory
    {
        public static readonly BenefitAction AddBenefit = new BenefitAction("add_benefit");
        public static readonly BenefitAction EditBenefit = new BenefitAction("edit_benefit");
        public static readonly BenefitAction ContactCustomer = new BenefitAction("contact_customer");
        public static readonly BenefitAction ContinueBenefit = new BenefitAction("continue_benefit");
        public static readonly BenefitAction ExtendBenefit = new BenefitAction("extend_benefit");
        public static readonly BenefitAction RemoveBenefit = new BenefitAction("remove_benefit");
        public static readonly BenefitAction DenyBenefit = new BenefitAction("deny_benefit");


        public IList<SubTask> Create(Contract contract, BenefitAction action)
        {
            var category = contract.Type == null ? ContractCategory.Empty : contract.Type.Category;
            var subTaskType = SubTaskType.GetSubTaskTypeByContractType(category);
            
            if (action == AddBenefit)
            {
                return new List<SubTask>
                    {                      
                        SubTask.CreateNew("Account Maintenance", subTaskType),
                        SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Account Maintenance", subTaskType),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (action == RemoveBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Account Maintenance", subTaskType),
                    //SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    //SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == ContactCustomer)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == ContinueBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Account Maintenance", subTaskType),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == ExtendBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Account Maintenance", subTaskType),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == DenyBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            return new List<SubTask>
            {
                SubTask.CreateNew("Others")
            };
        }
    }

    public class BenefitAction
    {
        private readonly string _code;
        public string Code
        {
            get { return _code; }
        }

        public BenefitAction(string code)
        {            
            _code = code;
        }
    }
}