﻿using System.Collections.Generic;
using Scra.Model.Inquiries;
using Scra.Model.InquiryTypes;

namespace Scra.Model.Tasks
{
    public class InquirySubTascFactory
    {
        public IList<SubTask> Create(Inquiry inquiry)
        {
	        var type = inquiry.InquiryType;

			if (type == InquiryType.DMDC_CHECK)
            {
                return CreateDmdcCheck();
            }
            if (type == InquiryType.INQUIRY)
            {
                return CreateInquiry();
            }
            if (type == InquiryType.AFFILIATE)
            {
                return CreateAffiliate();
            }
            return CreateBenefitApplication(inquiry);
        }

        private IList<SubTask> CreateDmdcCheck()
        {
            return new List<SubTask>
            {
                SubTask.CreateNew(SubTaskType.LogRequest),
                SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
                SubTask.CreateNew("Research on DMDC", SubTaskType.Communication),
                SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
                SubTask.CreateNew("Save all records", SubTaskType.Communication),
                SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
            };
        }

        private IList<SubTask> CreateAffiliate()
        {
            return new List<SubTask>
            {
                SubTask.CreateNew(SubTaskType.LogRequest),
                SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
                SubTask.CreateNew("Forward to Affiliate", SubTaskType.Communication),
                SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
                SubTask.CreateNew("Save all records", SubTaskType.Communication),
                SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
            };
        }

        private IList<SubTask> CreateInquiry()
        {
            return new List<SubTask>
            {
                SubTask.CreateNew(SubTaskType.LogRequest),
                SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
                SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
                SubTask.CreateNew("Save all records", SubTaskType.Communication),
                SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
            };
        }

        private IList<SubTask> CreateBenefitApplication(Inquiry inquiry)
        {
	        if (inquiry.IdentificationMethod == IdentificationMethod.Customer)
	        {
		        return CreateCustomerBenefitRequest();
	        }

	        if (inquiry.IdentificationMethod == IdentificationMethod.LineOfBusiness)
	        {
		        return CreateLineOfBusinessBenefitRequest();
	        }

	        return CreateProactiveBenefitRequest();
        }

	    public IList<SubTask> CreateLineOfBusinessBenefitRequest()
	    {
		    return new List<SubTask>
		    {
			    SubTask.CreateNew(SubTaskType.LogRequest),
			    SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
			    SubTask.CreateNew("Request Received", SubTaskType.RequestReceived),
			    SubTask.CreateNew("Military Information", SubTaskType.MilitaryInformation),
			    SubTask.CreateNew("Product Eligibility", SubTaskType.ProductInformation),
			    SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
			    SubTask.CreateNew("Save all records", SubTaskType.Communication),
			    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
		    };
	    }

	    public IList<SubTask> CreateProactiveBenefitRequest()
	    {
		    return new List<SubTask>
		    {
			    SubTask.CreateNew(SubTaskType.LogRequest),
			    SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
			    SubTask.CreateNew("Military Information", SubTaskType.MilitaryInformation),
			    SubTask.CreateNew("Product Eligibility", SubTaskType.ProductInformation),
			    SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
			    SubTask.CreateNew("Save all records", SubTaskType.Communication),
			    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
		    };
	    }

		public IList<SubTask> CreateCustomerBenefitRequest()
        {
            return new List<SubTask>
            {
                SubTask.CreateNew(SubTaskType.LogRequest),
                SubTask.CreateNew("Enter Details", SubTaskType.PersonDetails),
                SubTask.CreateNew("Request Received", SubTaskType.RequestReceived),
                SubTask.CreateNew("Military Information", SubTaskType.MilitaryInformation),
                SubTask.CreateNew("Product Eligibility", SubTaskType.ProductInformation),
                SubTask.CreateNew("Respond to the Requester", SubTaskType.Communication),
                SubTask.CreateNew("Save all records", SubTaskType.Communication),
                SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
            };
        }
    }
}