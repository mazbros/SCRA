using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.Communication
{
    public interface ICommunicationRepository
    {
        Task<ProductCommunication> GetByTask(int id);
        Task<IList<ProductCommunication>> GetByPerson(int id);
        Task Update(ProductCommunication model);
    }
}