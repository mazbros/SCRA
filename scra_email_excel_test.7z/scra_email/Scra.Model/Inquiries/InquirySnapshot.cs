﻿using System;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.InquiryTypes;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.Model.Inquiries
{
    public class InquirySnapshot
    {
        public int Id { get; private set; }
        public PersonSnapshot PersonInquiring { get; private set; }
        public PersonSnapshot Servicemember { get; private set; }
        public ContactMethod ContactMethod { get; private set; }
        public IUser Agent { get; private set; }
        public DateTime InquiryDate { get; private set; }
        public InquiryType InquiryType { get; private set; }
        public DependentType DependentType { get; private set; }
        public string Description { get; private set; }
        public DateTime ResponseDate { get; private set; }
        public DateTime AcknowledgeDate { get; private set; }
        public bool IsCompleted { get; private set; }

        public InquirySnapshot(int id, PersonSnapshot personInquiring, PersonSnapshot servicemember, ContactMethod contactMethod,
            IUser agent, DateTime inquiryDate, InquiryType inquiryType, DependentType dependentType,
            string description, DateTime responseDate, DateTime acknowledgeDate, bool isCompleted)
        {
            Id = id;
            PersonInquiring = personInquiring;
            Servicemember = servicemember;
            ContactMethod = contactMethod;
            Agent = agent;
            InquiryDate = inquiryDate;
            InquiryType = inquiryType;
            DependentType = dependentType;
            Description = description;
            ResponseDate = responseDate;
            AcknowledgeDate = acknowledgeDate;
            IsCompleted = isCompleted;
        }
    }
}