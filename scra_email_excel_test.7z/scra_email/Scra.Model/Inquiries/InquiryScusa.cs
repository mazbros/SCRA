﻿using System;

namespace Scra.Model.Inquiries
{
    public class InquiryScusa
    {
        public DateTime? SentDate1 { get; set; }
        public DateTime? SentDate2 { get; set; }
        public DateTime? ConfirmationDate { get; set; }
    }
}