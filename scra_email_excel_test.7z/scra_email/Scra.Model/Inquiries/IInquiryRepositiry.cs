﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Persons;

namespace Scra.Model.Inquiries
{
    public interface IInquiryRepository
    {
        Task<Inquiry> Get(int inquiryId);
        Task Create(Inquiry model);
        Task Update(Inquiry inquiry);
        Task UpdateTitle(Inquiry inquiry);
        Task<IList<InquirySnapshot>> Load(string search);
        Task<IList<InquirySnapshot>> LoadByPerson(PersonId personId);
        Task<int> GetTaskByInquiry(int inquiryId);
        Task SetAcknowledge(int inquiryId, DateTime date);
        Task<IList<InquirySnapshot>> Sort(string searchText, string selectedHeaderName, string direction);
    }
}
