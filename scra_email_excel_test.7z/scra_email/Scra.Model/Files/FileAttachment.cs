﻿namespace Scra.Model.Files
{
    public class FileAttachment
    {
        public FileAttachment(string fileName, byte[] content)
        {
            FileName = fileName;
            Content = content;
        }
        
        public string FileName { get; set; }
        public byte[] Content { get; set; }
    }
}