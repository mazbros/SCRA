﻿namespace Scra.Model.Users
{
    public class User : IUser
    {
        public UserId Id { get; set; }
        public string UserName { get; private set; }
        public bool IsAdmin { get; private set; }
        public UserType Type { get; set; }
        public string DisplayName
        {
            get
            {
                return Name ?? UserName;
            }
        }
        public string Name { get; private set; }
        public bool IsActive { get; private set; }

        private User(UserId id, string userName, string name)
        {
            Id = id;
            UserName = userName;
            Name = name;
        }

        public static User Create(UserId id, string userName, string name)
        {
            return new User(id, userName, name);
        }

        public static readonly User Empty = new User(UserId.Empty, "", "");

        public User(UserId id, string userName, string name, bool isActive, UserType type)
        {
            Id = id;
            UserName = userName;
            IsActive = isActive;
            Name = name;
            Type = type;

            IsAdmin = Type.Equals(UserType.Admin);
        }

        public override string ToString()
        {
            return string.Format("{0}", UserName);
        }
    }
}
