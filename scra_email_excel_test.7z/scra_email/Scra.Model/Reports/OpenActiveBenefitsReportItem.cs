﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    //TODO: delete as orphan
    public class OpenActiveBenefitsReportItem
    {
        #region Properties
        [DisplayName("Contact Date")]
        public string ContactDate { get; set; }

        [DisplayName("Identification Method")]
        public string IdentificationMethod { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServicememberID { get; set; }

        [DisplayName("Servicemember FNumber")]
        public string ServicememberFNumber { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstName { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Branch")]
        public string Branch { get; set; }

        [DisplayName("Reserv")]
        public string Reserv { get; set; }

        [DisplayName("Active Duty Start Date")]
        public string ActiveDutyStartDate { get; set; }

        [DisplayName("Active Duty End Date")]
        public string ActiveDutyEndDate { get; set; }

        [DisplayName("Benefit Status")]
        public string BenefitStatus { get; set; }

        [DisplayName("Benefit Applied Date")]
        public string BenefitAppliedDate { get; set; }

        [DisplayName("Benefit Effective Date")]
        public string BenefitEffectiveDate { get; set; }

        [DisplayName("Expected Removal Date")]
        public string ExpectedRemovalDate { get; set; }

        [DisplayName("Benefit Removed Date")]
        public string BenefitRemovedDate { get; set; }

        [DisplayName("Extend Date")]
        public string ExtendDate { get; set; }

        [DisplayName("Customer ID")]
        public string CustomerID { get; set; }

        [DisplayName("Customer FNumber")]
        public string CustomerFNumber { get; set; }

        [DisplayName("Customer First Name")]
        public string CustomerFirstName { get; set; }

        [DisplayName("Customer Middle Initial")]
        public string CustomerMiddleInitial { get; set; }

        [DisplayName("Customer Last Name")]
        public string CustomerLastName { get; set; }

        [DisplayName("Contract #")]
        public string ContractNo { get; set; }

        [DisplayName("Account #")]
        public string AccountNo { get; set; }

        [DisplayName("Product Type")]
        public string ProductType { get; set; }

        [DisplayName("Product SubType")]
        public string ProductSubType { get; set; }

        [DisplayName("Product Open Date")]
        public string ProductOpenDate { get; set; }

        [DisplayName("Product Close Date")]
        public string ProductCloseDate { get; set; }
        #endregion

        public static OpenActiveBenefitsReportItem Create(DataRow dr)
        {
            var items = new OpenActiveBenefitsReportItem
            {
                ContactDate = string.Format("{0:MM/dd/yyyy}",dr["ContactDate"]),
                IdentificationMethod = dr["IdentificationMethod"].ToString(),
                ServicememberID = dr["SMID"].ToString(),
                ServicememberFNumber = dr["FNumber"].ToString(),
                ServicememberFirstName = dr["SMFirstName"].ToString(),
                ServicememberMiddleInitial = dr["SMMiddleInitial"].ToString(),
                ServicememberLastName = dr["SMLastName"].ToString(),
                Branch = dr["Branch"].ToString(),
                Reserv = dr["Reserv"].ToString(),
                ActiveDutyStartDate = string.Format("{0:MM/dd/yyyy}", dr["ADSD"]),
                ActiveDutyEndDate = dr["ADED"].ToString() == "PRESENT" ? dr["ADED"].ToString() : string.Format("{0:MM/dd/yyyy}", dr["ADED"]),
                BenefitStatus = dr["Status"].ToString(),
                BenefitAppliedDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitAppliedDate"]),
                BenefitEffectiveDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitEffectiveDate"]),
                ExpectedRemovalDate = string.Format("{0:MM/dd/yyyy}", dr["ExpectedRemovalDate"]),
                BenefitRemovedDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitRemovedDate"]),
                ExtendDate = string.Format("{0:MM/dd/yyyy}", dr["ExtendDate"]),
                CustomerID = dr["CustID"].ToString(),
                CustomerFNumber = dr["CustFnumber"].ToString(),
                CustomerFirstName = dr["CustFirstName"].ToString(),
                CustomerMiddleInitial = dr["CustMiddleInitial"].ToString(),
                CustomerLastName = dr["CustLastName"].ToString(),
                ContractNo = dr["ContractNo"].ToString(),
                AccountNo = dr["AccountNo"].ToString(),
                ProductType = dr["ProductType"].ToString(),
                ProductSubType = dr["ProductSubType"].ToString(),
                ProductOpenDate = string.Format("{0:MM/dd/yyyy}", dr["ProductOpenDate"]),
                ProductCloseDate = string.Format("{0:MM/dd/yyyy}", dr["ProductCloseDate"])
            };

            return items;
        }
    }
}