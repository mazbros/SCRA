﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class ServicememberActiveDutyReportItem
    {
        #region Properties
        [DisplayName("Date Of Contact")]
        public string DateOfContact { get; set; }

        [DisplayName("Method Of Notification")]
        public string OriginalContactMethod { get; set; }

        [DisplayName("Date DMDC Search Performed")]
        public string DateDmdcSearchPerformed { get; set; }

        [DisplayName("Verify By SCRA or Military Orders")]
        public string VerifyByScraOrMilOrders { get; set; }
        /*
        [DisplayName("Notification Date")]
        public string DateMilitaryOrdersReceived { get; set; }

        [DisplayName("Agent")]
        public string Agent { get; set; }

        [DisplayName("QC Agent")]
        public string QcAgent { get; set; }

        [DisplayName("Task Status")]
        public string TaskStatus { get; set; }

        [DisplayName("Benefit Approved/Denied/Pending")]
        public string BenefitApprovedDeniedPending { get; set; }

        [DisplayName("Status Code")]
        public string StatusCode { get; set; }

        [DisplayName("Not Eligible Reason")]
        public string NotEligibleReason { get; set; }

        [DisplayName("Denial Reason")]
        public string DenialReason { get; set; } */

        [DisplayName("Servicemember ID")]
        public string ServicememberId { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstname { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Servicemember FNumber")]
        public string ServicememberFNumber { get; set; }

        [DisplayName("Servicemember Origin")]
        public string ServicememberOrigin { get; set; }

        [DisplayName("Branch Of Service")]
        public string BranchOfService { get; set; }

        [DisplayName("AD Start Date")]
        public string AdStartDate { get; set; }

        [DisplayName("AD End Date")]
        public string AdEndDate { get; set; }

        [DisplayName("Notification Date")]
        public string NoticeDate { get; set; }

        [DisplayName("Reservist")]
        public string Reserv { get; set; }

        [DisplayName("Customer ID")]
        public string CustomerId { get; set; }

        [DisplayName("Customer Last Name")]
        public string CustomerLastName { get; set; }

        [DisplayName("Customer First Name")]
        public string CustomerFirstName { get; set; }

        [DisplayName("Customer Middle Initial")]
        public string CustomerMiddleInitial { get; set; }

        [DisplayName("Customer Origin")]
        public string CustomerOrigin { get; set; }

        [DisplayName("Customer FNumber")]
        public string CustomerFNumber { get; set; }
 
        [DisplayName("Product Type")]
        public string ProductType { get; set; }

        [DisplayName("Product SubType")]
        public string SubType { get; set; }

        [DisplayName("Account Number")]
        public string AccountNum { get; set; }

        [DisplayName("Product Start Date")]
        public string StartDate { get; set; }

        [DisplayName("Product End Date")]
        public string EndDate { get; set; }

        [DisplayName("Benefit Status")]
        public string BenefitStatus { get; set; }

        [DisplayName("Date Benefits Applied")]
        public string DateBenefitsApplied { get; set; }

        [DisplayName("Benefits Expected Removal Date")]
        public string ExpectedRemovalDate { get; set; }

        [DisplayName("Date Benefits Ended")]
        public string DateBenefitsEnded { get; set; }

        [DisplayName("Benefit Effective (as of) Date")]
        public string BenefitsEffectiveDate { get; set; }

        [DisplayName("Denial Reason")]
        public string DenialReason { get; set; }

        [DisplayName("Comments")]
        public string Comments { get; set; }

        #endregion
        public static ServicememberActiveDutyReportItem Create(DataRow dr)
        {
            var item = new ServicememberActiveDutyReportItem
            {
                DateOfContact = string.Format("{0:MM/dd/yyyy}", dr["DateOfContact"]),
                OriginalContactMethod = dr["OriginalContactMethod"].ToString(),
                DateDmdcSearchPerformed = dr["DateDmdcSearchPerformed"].ToString(),
                VerifyByScraOrMilOrders = dr["VerifyByScraOrMilOrders"].ToString(),

                ServicememberId = dr["ServicememberID"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                ServicememberFirstname = dr["ServicememberFirstname"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                ServicememberFNumber = dr["ServicememberFNumber"].ToString(),
                ServicememberOrigin = dr["ServicememberOrigin"].ToString(),
                
                BranchOfService = dr["BranchOfService"].ToString(),
                AdStartDate = string.Format("{0:MM/dd/yyyy}", dr["ADStartDate"]),
                AdEndDate = string.Format("{0:MM/dd/yyy}", dr["ADEndDate"]),
                NoticeDate = string.Format("{0:MM/dd/yyy}", dr["NoticeDate"]),
                Reserv = dr["Reserv"].ToString(),

                CustomerId = dr["CustomerID"].ToString(),
                CustomerLastName = dr["CustomerLastName"].ToString(),
                CustomerFirstName = dr["CustomerFirstName"].ToString(),
                CustomerMiddleInitial = dr["CustomerMiddleInitial"].ToString(),
                CustomerFNumber = dr["CustomerFNumber"].ToString(),
                CustomerOrigin = dr["CustomerOrigin"].ToString(),

                ProductType = dr["Product"].ToString(),
                SubType = dr["SubProduct"].ToString(),
                AccountNum = dr["AccountNum"].ToString().Length > 0
                    ?  dr["AccountNum"].ToString().Length == 16
                        ? dr["AccountNum"].ToString().Substring(0, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(4, 4) + " " +
                          dr["AccountNum"].ToString().Substring(7, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(12, 4)
                        : dr["AccountNum"].ToString().Length >= 19
                            ? dr["AccountNum"].ToString().Substring(0, 9) + " " + 
                              dr["AccountNum"].ToString().Substring(9, 10)
                            : " " + dr["AccountNum"] + " "
                    : string.Empty,
                StartDate = string.Format("{0:MM/dd/yyy}", dr["OpenDate"]),
                EndDate = string.Format("{0:MM/dd/yyy}", dr["CloseDate"]),
                
                BenefitStatus = dr["BenefitStatus"].ToString(),
                DateBenefitsApplied = string.Format("{0:MM/dd/yyy}", dr["BenefitAppliedDate"]),
                ExpectedRemovalDate = string.Format("{0:MM/dd/yyy}", dr["ExpectedRemovalDate"]),
                DateBenefitsEnded = string.Format("{0:MM/dd/yyy}", dr["BenefitRemovedDate"]),
                BenefitsEffectiveDate =  string.Format("{0:MM/dd/yyy}", dr["BenefitEffectiveDate"]),
                
                DenialReason = dr["DenialReason"].ToString(),

                Comments = dr["Comments"].ToString()

            };

            return item;
        }
    }
}