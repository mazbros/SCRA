﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Scra.Model.Reports
{
    public interface IReportsRepository
    {
        //Task<IEnumerable<WeeklyControlReportItem>> Load(DateTime? reportDate);
        //Task<IEnumerable<TaskStatusReportItem>> Load(string interval, DateTime? reportDate, string taskType);
        //Task<IEnumerable<OpenActiveBenefitsReportItem>> LoadOpenActive(DateTime? reportDate, DateTime? reportDate2);
        //Task<IEnumerable<CurrentlyReceivingBenefitsReportItem>> LoadCurrentlyReceiving(DateTime? reportDate, DateTime? reportDate2, string category);

        //Task<IEnumerable<BenefitsReportItem>> LoadOpenActive(DateTime? reportDate, DateTime? reportDate2);
        //Task<IEnumerable<BenefitsReportItem>> LoadCurrentlyReceiving(DateTime? reportDate, DateTime? reportDate2, string category);
        //Task<IEnumerable<BenefitsReportItem>> LoadNewAccounts(DateTime? reportDate, DateTime? reportDate2);
        //Task<IEnumerable<BenefitsReportItem>> LoadExpiredAccounts(DateTime? reportDate, DateTime? reportDate2);
        //Task<IEnumerable<DeniedAccountsReportItem>> LoadDeniedAccounts(DateTime? reportDate, DateTime? reportDate2);
        
        Task<IEnumerable<object>> Load(object obj, string reportName);

        Task<DataTable> LoadDt(string reportName);
        Task<DataTable> LoadDeniedAccountsDt(DateTime? reportDate, DateTime? reportDate2);
        Task<DataTable> LoadExpiredAccountsDt(DateTime? reportDate, DateTime? reportDate2);
        Task<DataTable> LoadNewAccountsDt(DateTime? reportDate, DateTime? reportDate2);
        Task<DataTable> LoadOpenActiveDt(DateTime? reportDate, DateTime? reportDate2);
        Task<DataTable> LoadCurrentlyReceivingDt(DateTime? reportDate, DateTime? reportDate2, string category);
    }
}