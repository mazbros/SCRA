﻿using System;
using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public struct Ssn : IEquatable<Ssn>
    {
        private const string EMPTY_VALUE = "000000000";

        public readonly string Value;

        public string GetDisplay()
        {
            var text = Value ?? EMPTY_VALUE;
            return text.Substring(0, 3) + "-" + text.Substring(3, 2) + "-" + text.Substring(5, 4);
        }

        private Ssn(string ssn)
        {
            Value = ssn;
        }

        public override string ToString()
        {
            return Value;
        }

        public static Ssn Empty()
        {
            return new Ssn(EMPTY_VALUE);
        }

        public static Ssn Parse(string ssn)
        {
            if (!IsValid(ssn))
            {
                return Empty();
            }

            ssn = ssn.Replace("-", "");
            return new Ssn(ssn);
        }

        private static bool IsValid(string ssn)
        {
            if (ssn.IsEmpty())
            {
                return false;
            }

            return ssn.Replace("-", "").Length == 9;
        }

        public override int GetHashCode()
        {
            return (Value != null ? Value.GetHashCode() : 0);
        }

        public bool Equals(Ssn other)
        {
            return Value == other.Value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Ssn))
            {
                return false;
            }
            return Equals((Ssn)obj);
        }

        public static bool operator ==(Ssn obj1, Ssn obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(Ssn obj1, Ssn obj2)
        {
            return !(obj1 == obj2);
        }
    }
}