﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Users;

namespace Scra.Model.Persons
{
    public interface IPersonNoteRepository
    {
        Task Create(PersonNote person, IUser user);
        Task Delete(PersonNote note, IUser user);
        Task <IList<PersonNote>> Load(PersonId personId);
    }
}