﻿using System;

namespace Scra.Model.Persons
{
    public struct PersonId : IEquatable<PersonId>, IRefId
    {
        private readonly int _value;

        public int Value
        {
            get { return _value; }
        }

        public static PersonId Empty
        {
            get
            {
                return new PersonId(0);
            }
        }

        public bool IsNotEmpty()
        {
            return Value > 0;
        }

        public bool IsEmpty()
        {
            return Value < 1;
        }

        public PersonId(int id)
        {
            _value = id;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        public bool Equals(PersonId other)
        {
            return _value == other._value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is PersonId))
            {
                return false;
            }
            return Equals((PersonId)obj);
        }

        public override string ToString()
        {
            return _value.ToString();
        }

        public static bool operator ==(PersonId obj1, PersonId obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(PersonId obj1, PersonId obj2)
        {
            return !(obj1 == obj2);
        }
    }
}