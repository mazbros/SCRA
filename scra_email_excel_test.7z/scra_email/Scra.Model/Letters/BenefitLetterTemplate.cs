﻿using System;

namespace Scra.Model.Letters
{
    public class BenefitLetterTemplate    
    {
        public int BenefitId { get; set; }
        public int ActiveDutyId { get; set; }
        public int ContractId { get; set; }
        public int BenefitDetailId { get; set; }
        public DateTime? ActiveDutyStartDate { get; set; }
        public DateTime? AceiveDutyEndDate { get; set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public DateTime? BenefitExpectedRemovalDate { get; set; }
        public DateTime? BenefitRemovedDate { get; set; }        
        public string SUB_PRODUCT_NAME { get; set; }
        public string AccountNumber { get; set; }
        public string SCRA_Code { get; set; }
        public DateTime? OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
    }
}