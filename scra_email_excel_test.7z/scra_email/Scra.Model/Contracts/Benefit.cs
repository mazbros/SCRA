﻿using System;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Model.Contracts
{
    public class Benefit
    {
        public int Id { get; set; }
        public BenefitStatus Status { get; private set; }
        public ContractId ContractId { get; private set; }
        public PersonId PersonId { get; private set; }
        public int ActiveDutyId { get; set; }
        public bool IsPromo { get; private set; }
        public DateTime? StartDate { get; private set; }
        public DateTime? EndDate { get; private set; }
        public string DenialReason { get; set; }
        public int TaskId { get; set; }

        public int InquiryId { get; set; }
        public int BenefitIntervalId { get; set; }

        public Benefit(int id, ContractId contractId, PersonId personId, int activeDutyId, bool isPromo,
            DateTime? startDate, DateTime? endDate, BenefitStatus status, string denialReason, int taskId, int benefitIntervalId, int inquiryId)
        {
            Id = id;
            ContractId = contractId;
            PersonId = personId;
            ActiveDutyId = activeDutyId;
            IsPromo = isPromo;
            StartDate = startDate;
            EndDate = endDate;
            Status = status;
            DenialReason = denialReason;
            TaskId = taskId;
            BenefitIntervalId = benefitIntervalId;
            InquiryId = inquiryId;
        }

        

        public static Benefit Create(int contractId, int activeDutyId, int personId, BenefitStatus benefitStatus, int taskId, int benefitIntervalId, int inquiryId)
        {
            return new Benefit(0, new ContractId(contractId), new PersonId(personId), activeDutyId, false, null, null, benefitStatus, null, taskId, benefitIntervalId, inquiryId);
        }

        public static Benefit Create(ContractId contractId, ActiveDuty activeDuty, PersonId personId, BenefitStatus benefitStatus)
        {
            var activeDutyId = activeDuty != null ? activeDuty.Id : 0;
            return new Benefit(0, contractId, personId, activeDutyId, false, null, null, benefitStatus, null, 0, 0, 0);
        }

        public static Benefit CreateBenefitWithNoProduct(PersonId personId, ActiveDuty activeDuty, string denialReason, int taskId)
        {
            var activeDutyId = activeDuty != null ? activeDuty.Id : 0;
            return new Benefit(0, ContractId.Empty, personId, activeDutyId, false, null, null, BenefitStatus.Denying, denialReason, taskId, 0, 0);
        }

        public async Task<int> AddBenefit()
        {
            if (TaskId == 0)
            {
                var taskFactory = Di.Get<ITascFactory>();
                var task = await taskFactory.AddBenefit(ContractId, InquiryId);
                await ChangeStatus(task.Id);
                return task.Id;
            }

            await ChangeStatus(TaskId);
            return TaskId;

        }

        public async Task<int> ContinueBenefit()
        {
            if (TaskId == 0)
            {
                var taskFactory = Di.Get<ITascFactory>();
                var task = await taskFactory.ContinueBenefit(ContractId, InquiryId);
                await ChangeStatus(task.Id);
                return task.Id;
            }

            await ChangeStatus(TaskId);
            return TaskId;
        }

        public async Task<int> ExtendBenefit()
        {
            if (TaskId == 0)
            {
                var taskFactory = Di.Get<ITascFactory>();
                var task = await taskFactory.ExtendBenefit(ContractId, InquiryId);
                await ChangeStatus(task.Id);
                return task.Id;
            }

            await ChangeStatus(TaskId);
            return TaskId;
        }

        public async Task<Tasc> RemoveBenefit()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.RemoveBenefit(ContractId, InquiryId);
            await ChangeStatus(task.Id);
            return task;
        }

        public async Task<int> EditBenefit(TaskType taskType)
        {
	        if (TaskId == 0)
	        {
				var taskFactory = Di.Get<ITascFactory>();
	            var task = await taskFactory.EditBenefit(ContractId, taskType, InquiryId);
	            await ChangeStatus(task.Id);
	            //await CopyBenefitDetail();
	            return task.Id;
	        }

	        await ChangeStatus(TaskId);
	        return TaskId;
		}

        public async Task<Tasc> ContactCustomer()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.ContactCustomer(ContractId, InquiryId);
            await ChangeStatus(task.Id);
            return task;
        }

        public async Task<int> DenyBenefit()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.DenyBenefit(ContractId, InquiryId);
            await ChangeStatus(task.Id);
            return task.Id;
        }

        //private async Task CopyBenefitDetail()
        //{
        //    var repo = Di.Get<IBenefitDetailRepository>();
        //    var benefitDetail = await repo.GetLastDetail(Id);

        //    if (benefitDetail == null)
        //        return;

        //    var newBenefitDetail = BenefitDetail.CopyPartial(benefitDetail);
        //    newBenefitDetail.BenefitId = Id;

        //    await repo.Save(newBenefitDetail);
        //}

        public async Task ChangeStatus(BenefitStatus status)
        {
            Status = status;
            var repo = Di.Get<IBenefitRepository>();
            await repo.Save(this);
        }

        public async Task ChangeMultipleStatus(BenefitStatus status)
        {
            Status = status;
            var repo = Di.Get<IBenefitRepository>();
            await repo.Save(this);
        }

        public async Task ChangeStatus(int id)
        {            
            var repo = Di.Get<IBenefitRepository>();
            TaskId = id;
            await repo.Save(this);
        }
    }
}
