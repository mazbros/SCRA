﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Persons;

namespace Scra.Model.Contracts
{
    public interface IContractRepository
    {
        Task<IList<Contract>> RemoteFetch(PersonId personId);
        Task<IList<Contract>> RemoteFetch(string fnumber);
        Task Save(Contract contract);
        Task<IList<ContractSnapshot>> Load(PersonId personId);
        Task<Contract> Get(ContractId id);
        Task<int> GetCurrent();
        Task SaveCurrent(int currentNumber);
        Task<int> CheckDuplicate(FNumber fNumber, int id);
    }
}
