﻿using System;
using System.Collections.Generic;
using Scra.Model.Persons;

namespace Scra.Model.Contracts
{
    public class Contract
    {
        public ContractId Id { get; set; }
        public string ContractNo { get; set; }
        public DateTime? OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public PersonId PersonId { get; set; }
        public ContractType Type { get; set; }
        public string LegacyNo { get; set; }
        public string CardNo { get; set; }
	    public int? Center { get; set; }
        public int? Product { get; set; }
        public bool IsDeleted { get; set; }
        public ContractCategory Category { get; set; }
        public string ContractProductName { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public Contract()
        {

        }

        public Contract(ContractId id, PersonId personId, ContractType type, string contractNo, string legacyNo, string cardNo, int? center, int? product, DateTime? openDate, DateTime? closeDate,ContractCategory category, string productName )
        {
            Id = id;
            PersonId = personId;
            Type = type;
            ContractNo = contractNo;
            OpenDate = openDate;
            CloseDate = closeDate;
            LegacyNo = legacyNo;
            CardNo = cardNo;
            Center = center;
            Product = product;
            Category = category;
            ContractProductName = productName;
        }

        public static Contract Create(PersonId personId)
        {
            return new Contract(ContractId.Empty, personId, null, null, null, null, null, null, null, null, ContractCategory.Empty, string.Empty);
        }

        public static Contract Create(ContractId id, PersonId personId, string contractNo, string accountNumber, string contractType, string productName, DateTime? openDate, DateTime? closeDate, bool isDeleted, DateTime? timestamp, string modifiedBy)
        {
            return new Contract()
            {
                Id = id,
                PersonId = personId,
                ContractNo = contractNo,
                AccountNumber = accountNumber,
                Category = ContractCategory.Parse(contractType),
                ContractProductName = productName,
                OpenDate = openDate,
                CloseDate = closeDate,
                IsDeleted = isDeleted,
                ModifiedDate = timestamp,
                ModifiedBy = modifiedBy,
            };
        }

        public string AccountNumber { get; set; }

        public static Contract CreateRemote(ContractType type, string contractNo, string legacyNo, string cardNo, int center, int product, DateTime openDate, DateTime? closeDate, ContractCategory category, string productName)
        {
            return new Contract(ContractId.Empty, PersonId.Empty, type, contractNo, legacyNo, cardNo, center, product, openDate, closeDate, category, productName);
        }

        public static Contract CopyFromRemote(PersonId personId, Contract contract)
        {
            return new Contract(ContractId.Empty, personId, contract.Type, contract.ContractNo, contract.LegacyNo, contract.CardNo, contract.Center, contract.Product, contract.OpenDate, contract.CloseDate, contract.Category, contract.ContractProductName);
        }
    }
}
