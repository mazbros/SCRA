﻿using System;
using Scra.Model.Tasks;

namespace Scra.Model.Contracts
{
    public class BenefitEvent   
    {
        public int BenefitId { get; set; }
        public int BenefitDetailId { get; set; }
        public int ActiveDutyId { get; set; }
        public int ContractId { get; set; }
        public int TaskId { get; set; }
        public int InquiryId { get; set; }
        public int InquiryTaskId { get; set; }
        public BenefitStatus BenefitStatus { get; set; }
        public DateTime? BenefitAppliedDate { get; set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public DateTime? ExpectedRemovalDate { get; set; }        
        public DateTime? BenefitRemovedDate { get; set; }
	    public DateTime? ExtendDate { get; set; }
        public string DenialReason { get; set; }
        public DateTime? ActionDate { get; set; }
        public DateTime? ActiveDutyStartDate { get; set; }
        public DateTime? ActiveDutyEndDate { get; set; }
        public string ActiveDutyPeriod { get; set; }
        public string SubProductName { get; set; }
        public string AccountNumber { get; set; }
        public string ContractNo { get; set; }
        public string SCRA_Code { get; set; }
        public DateTime? OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public TaskType TaskType { get; set; }
        public TascStatus TaskStatus { get; set; }
        public string ServicememberName { get; set; }
        public string CustomerName { get; set; }
        public int BenefitIntervalId { get; set; }
        public DateTime? InquiryDate { get; set; }
        public int PersonId { get; set; }

	    public string GetAdIntervalText()
        {
            var adsd = string.Format("{0:MM/dd/yyyy}", ActiveDutyStartDate);
            var aded = ActiveDutyEndDate == null ? "" : " - " + string.Format("{0:MM/dd/yyyy}", ActiveDutyEndDate);
            var adIntervalText = adsd + aded;

            return adIntervalText;
        }
    }
}