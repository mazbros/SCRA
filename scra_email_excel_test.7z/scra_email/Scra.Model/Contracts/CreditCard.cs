﻿using System;
using Scra.Model.Extensions;

namespace Scra.Model.Contracts
{
    public struct CreditCard : IEquatable<CreditCard>
    {
        private const string EMPTY_VALUE = "0000000000000000";

        public readonly string Value;

        public string GetDisplay()
        {
            var text = Value ?? EMPTY_VALUE;
            return text.Length > 0
                ? text.Substring(0, 4) + "-" + text.Substring(4, 4) + "-" + text.Substring(8, 4) + "-" + text.Substring(12, 4)
                : EMPTY_VALUE;
        }

        private CreditCard(string creditCard)
        {
            Value = creditCard;
        }

        public override string ToString()
        {
            return Value;
        }

        public static CreditCard Empty()
        {
            return new CreditCard(EMPTY_VALUE);
        }

        public static CreditCard Parse(string creditCard)
        {
            if (!IsValid(creditCard))
            {
                return Empty();
            }

            creditCard = creditCard.Replace(" ", "");
            return new CreditCard(creditCard);
        }

        private static bool IsValid(string creditCard)
        {
            if (creditCard.IsEmpty())
            {
                return false;
            }

            return creditCard.Replace(" ", "").Length == 16;
        }

        public override int GetHashCode()
        {
            return (Value != null ? Value.GetHashCode() : 0);
        }

        public bool Equals(CreditCard other)
        {
            return Value == other.Value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CreditCard))
            {
                return false;
            }
            return Equals((CreditCard)obj);
        }

        public static bool operator ==(CreditCard obj1, CreditCard obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(CreditCard obj1, CreditCard obj2)
        {
            return !(obj1 == obj2);
        }
    }
}