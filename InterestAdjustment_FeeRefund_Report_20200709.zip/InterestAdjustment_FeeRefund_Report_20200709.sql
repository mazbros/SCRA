SELECT DISTINCT			[BenefitIntervalID],
						[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[BenefitStatus] as [Benefit Status],
						[InterestRate] as [Interest Rate Before SCRA],
						[IsInterestAdjustmentCalculated] as [Is Interest Adjustment Calculated],
						[IsRateCapPerformed] as [Is Rate Cap Performed],
						[IsFeeWaived] as [Is Fee Waived],
						[FeeRefunded] as [Fee Refund Amount],
						[FeeRefundedDate] as [Fee Refund Date],
						[InterestRefunded] as [Interest Adjustment Amount],
						[InterestRefundedDate] as [Date Interest Adjustment Applied],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date]
						
				FROM (
				SELECT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,ISNULL(CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE NULL END END,'') as ADED 
					,ISNULL(adr.ADCount,0) as ADCount
					--,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE 'Reimbursement' END as [Status]
					--,t.[Status] as TaskStatus
					,bd2.BenefitStatus
					,ISNULL(CONVERT(VARCHAR(10),bd2.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd2.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd2.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd2.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd2.ExtendDate,121),'') as ExtendDate

					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate

					,CASE WHEN ISNULL(CONVERT(VARCHAR(10),bd.InterestRate),'0.0000') = '0.0000' THEN '' ELSE ISNULL(CONVERT(VARCHAR(10),CONVERT(NUMERIC(9,2),bd.InterestRate)),'') END as InterestRate
					,CASE WHEN bd.IsInterestAdjustmentCalculated = 1 THEN 'Yes' ELSE '' END as IsInterestAdjustmentCalculated
					,CASE WHEN bd.IsRateCapPerformed = 1 THEN 'Yes' ELSE '' END as IsRateCapPerformed
					,CASE WHEN bd.IsFeeWaived = 1 THEN 'Yes' ELSE '' END as IsFeeWaived
					,CASE WHEN ISNULL(CONVERT(VARCHAR(10),bd.[FeeRefunded]),'0.00') = '0.00' THEN '' ELSE ISNULL(CONVERT(VARCHAR(10),CONVERT(NUMERIC(9,2),bd.[FeeRefunded])),'') END as [FeeRefunded]
					,ISNULL(CONVERT(VARCHAR(10),bd.[FeeRefundedDate],121),'') as [FeeRefundedDate]
					,CASE WHEN ISNULL(CONVERT(VARCHAR(10),bd.[InterestRefunded]),'0.00') = '0.00' THEN '' ELSE ISNULL(CONVERT(VARCHAR(10),CONVERT(NUMERIC(9,2),bd.[InterestRefunded])),'') END as [InterestRefunded]
					,ISNULL(CONVERT(VARCHAR(10),bd.[InterestRefundedDate],121),'') as [InterestRefundedDate]
					--,bd.[Timestamp]

				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
												   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
													FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
														ON adr.BenefitIntervalId = b.BenefitIntervalId
														JOIN (
															SELECT bb.BenefitIntervalID,bb.ID,bb.[Status],bb.PersonId,bb.ContractID
																,bd1.CurrentRate as InterestRate
																,bd1.IsInterestAdjustmentCalculated as IsInterestAdjustmentCalculated
																,bd1.IsRateCapPerformed as IsRateCapPerformed
																,bd1.IsFeeWaived as IsFeeWaived
																,bd1.[FeeRefunded]
																,bd1.[FeeRefundedDate]
																,bd1.[InterestRefunded]
																,bd1.[InterestRefundedDate]
																,bd1.[Timestamp]
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID 
															WHERE (ISNULL(bd1.[FeeRefunded],0.0) <> 0.0 OR  bd1.[FeeRefundedDate] IS NOT NULL)
																OR (ISNULL(bd1.[InterestRefunded],0.0) <> 0.0 OR bd1.[InterestRefundedDate] IS NOT NULL)) bd 
																	ON b.benefitIntervalId = bd.BenefitIntervalId AND b.ContractID = bd.Contractid AND b.ID = bd.ID
															LEFT JOIN (SELECT bb.BenefitIntervalID
																		,MAX(bd2.BenefitAppliedDate) as BenefitAppliedDate
																		,MAX(bd2.BenefitEffectiveDate) as BenefitEffectiveDate
																		,MAX(bd2.BenefitRemovedDate) as BenefitRemovedDate
																		,MAX(bd2.ExpectedRemovalDate) as ExpectedRemovalDate 
																		,MAX(bd2.ExtendDate) as ExtendDate 
																		,MAX(bd2.[DmiSentDate]) as SentDate
																		,MAX(bd2.CurrentRate) as InterestRate
																		,[dbo].[fnBenefitStatus](bb.BenefitIntervalID) as BenefitStatus
																		FROM [BenefitDetail] bd2 JOIN Benefit bb ON bd2.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd2 
																		ON b.BenefitIntervalId = bd2.BenefitIntervalId
															JOIN [Customer] cust on cust.PersonID = c.PersonID
																JOIN [Customer] sm on   sm.PersonID = adr.PersonID
																	JOIN Person smn on smn.ID = adr.PersonID
		) th
		ORDER BY SMID DESC,BenefitIntervalId

/*
		SELECT * FROM Benefit B JOIN (SELECT bb.BenefitIntervalID,bb.ID,bb.[Status],bb.PersonId,bb.ContractID
														,bd1.CurrentRate as InterestRate
														,bd1.IsInterestAdjustmentCalculated as IsInterestAdjustmentCalculated
														,bd1.IsRateCapPerformed as IsRateCapPerformed
														,bd1.IsFeeWaived as IsFeeWaived
														,bd1.[FeeRefunded]
														,bd1.[FeeRefundedDate]
														,bd1.[InterestRefunded]
														,bd1.[InterestRefundedDate]
													FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID 
													WHERE (ISNULL(bd1.[FeeRefunded],0.0) <> 0.0 OR  bd1.[FeeRefundedDate] IS NOT NULL)
														OR (ISNULL(bd1.[InterestRefunded],0.0) <> 0.0 OR bd1.[InterestRefundedDate] IS NOT NULL)) bd ON b.benefitIntervalId = bd.BenefitIntervalId AND b.ContractID = bd.Contractid AND b.ID = bd.ID
														*/