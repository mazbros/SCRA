-- ===============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/11/2020&gt;
-- Description:	&lt;Get modified active duty by date&gt;
-- ===============================================
CREATE PROCEDURE [dbo].[spGetContractHistory]
	@PersonID INT,
	@Timestamp datetime
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  	INT,
			@ErrorSource    SYSNAME,
			@ErrorState 	INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

			    IF @Timestamp &lt; (SELECT MAX([Timestamp]) FROM [Contract] WHERE [PersonID] = @PersonId) BEGIN
			
					SELECT	C.[ID], C.[ContractNo], C.[OpenDate], C.[CloseDate], 
							C.[IsDeleted], C.[Timestamp], C.[PersonID], E.[Name] As ModifiedBy,
							CT.[SCRA_Code], dbo.fnProductSubName(C.ID) as [SUB_PRODUCT_NAME],
							CASE WHEN ISNULL(C.[LegacyNo], '') = '' THEN C.[CardNo] ELSE C.[LegacyNo] END as AccountNumber
					FROM(
						SELECT	[ID], [ContractNo], [OpenDate], [CloseDate], [IsDeleted], 
								[Timestamp], [ModifiedBy], [PersonID], [LegacyNo], 
								[ContractTypeId], [Center], [Product], [CardNo], 
								[ProductName] FROM [Contract] WHERE [PersonID] = @PersonId
						UNION
						SELECT TOP 1 [ID], [ContractNo], [OpenDate], [CloseDate], [IsDeleted], 
								[Timestamp], [ModifiedBy], [PersonID], [LegacyNo], 
								[ContractTypeId], [Center], [Product], [CardNo], 
								[ProductName] FROM [hist].[Contract] WHERE [PersonId] = @PersonId ORDER BY [Timestamp] DESC) C
					JOIN [ContractType] CT ON C.[ContractTypeId] = CT.ID
					LEFT JOIN [Employee] E ON E.[ID] = C.[ModifiedBy]
					where C.[IsDeleted] = 0
					ORDER BY [Timestamp] DESC
				
				END

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

