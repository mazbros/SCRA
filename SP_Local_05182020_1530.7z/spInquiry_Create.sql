CREATE PROCEDURE [dbo].[spInquiry_Create]
	
	@ID						INT OUT,
	@InquiryDate			DATETIME,
	@AgentId				INT,
	@ContactMethodId		INT,
	@PersonInquiringId		INT = NULL,
	@ServicememberId		INT = NULL,
	@DependentTypeId		INT = NULL,
	@InquiryType			VARCHAR(255),
	@IdentificationMethod	VARCHAR(255),
	@Description			VARCHAR(MAX),
	@IsOnActiveDuty			BIT = NULL,
	@ModifiedBy				INT

AS
BEGIN
	
	SET NOCOUNT ON;
	Declare 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION   
		
				IF @ID = 0 BEGIN SET @ID = NULL END;
				
				IF @DependentTypeId = 0 BEGIN SET @DependentTypeId = NULL END;
				
				IF @ID IS NULL BEGIN
				
					INSERT INTO [dbo].[Inquiry]
						   ([InquiryDate]
						   ,[AgentID]
						   ,[ContactMethodID]
						   ,[PersonInquiringId]
						   ,[ServicememberId]
						   ,[DependentTypeId]
						   ,[InquiryType]
						   ,[IdentificationMethod]
						   ,[Description]
						   ,[IsOnActiveDuty]
						   ,[ModifiedBy]
						   ,[Timestamp])
					 VALUES
						   (@InquiryDate
						   ,@AgentId
						   ,@ContactMethodId
						   ,@PersonInquiringId
						   ,@ServicememberId
						   ,@DependentTypeId
						   ,@InquiryType
						   ,@IdentificationMethod
						   ,@Description
						   ,@IsOnActiveDuty
						   ,@ModifiedBy
						   ,GETDATE())
				           
					  SET @ID = SCOPE_IDENTITY();
				
					  /* ====== MAKING SURE ANYONE WITH BENEFIT REQUEST OR AFFILIATE REQEST SEARCHABLE IN PORTFOLIO ===== */
					  /**/	IF @InquiryType = 'benefit_request'	OR @InquiryType = 'affiliate' BEGIN						/**/	
					  /**/		SET ROWCOUNT 1																			/**/	
					  /**/		UPDATE [dbo].[Person] SET [Origin] = @InquiryType										/**/		
					  /**/			WHERE ID = @ServicememberId	AND Origin IN ('inquiry','dmdc_check')					/**/
					  /**/		SET ROWCOUNT 0																			/**/	
					  /**/	END																							/**/	
					  /* ================================================================================================ */
				
				END ELSE BEGIN
				
					INSERT INTO [hist].[Inquiry]
			           ([InquiryID]
			           ,[InquiryDate]
			           ,[AgentID]
			           ,[ContactMethodID]
			           ,[DependentTypeId]
			           ,[InquiryType]
			           ,[Description]
			           ,[ModifiedBy]
			           ,[Timestamp]
			           ,[ScusaSentDate1]
			           ,[ScusaSentDate2]
			           ,[ResponseText]
			           ,[ResponseDate]
			           ,[ResponseMethodId]
			           ,[Comment]
			           ,[IsCompleted]
			           ,[AcknowledgeDate]
			           ,[PersonInquiringId]
			           ,[ServicememberId]
			           ,[ScusaConfirmationDate]
			           ,[IdentificationMethod]
			           ,[IsOnActiveDuty])
					 SELECT [ID]
					  ,[InquiryDate]
					  ,[AgentID]
					  ,[ContactMethodID]
					  ,[DependentTypeId]
					  ,[InquiryType]
					  ,[Description]
					  ,[ModifiedBy]
					  ,[Timestamp]
					  ,[ScusaSentDate1]
					  ,[ScusaSentDate2]
					  ,[ResponseText]
					  ,[ResponseDate]
					  ,[ResponseMethodId]
					  ,[Comment]
					  ,[IsCompleted]
					  ,[AcknowledgeDate]
					  ,[PersonInquiringId]
					  ,[ServicememberId]
					  ,[ScusaConfirmationDate]
					  ,[IdentificationMethod]
					  ,[IsOnActiveDuty]
					  FROM [dbo].[Inquiry]
						WHERE [ID] = @ID
				
					UPDATE [dbo].[Inquiry]
						SET [AgentID]				= @AgentId
						   ,[InquiryDate]			= @InquiryDate
						   ,[ContactMethodID]		= @ContactMethodId
						   ,[PersonInquiringId]		= @PersonInquiringId
						   ,[ServicememberId]		= @ServicememberId
						   ,[DependentTypeId]		= @DependentTypeId
						   ,[InquiryType]			= @InquiryType
						   ,[IdentificationMethod]	= @IdentificationMethod
						   ,[Description]			= @Description
						   ,[IsOnActiveDuty]		= @IsOnActiveDuty
						   ,[ModifiedBy]			= @ModifiedBy
						   ,[Timestamp]				= GETDATE()
						WHERE [ID] = @ID
					 		
				END
			COMMIT TRANSACTION
	    
	    END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END			

END

