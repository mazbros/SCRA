
-- =====================================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;01/07/2020&gt;
-- Modified:	&lt;01/16/2019&gt;
-- Description:	&lt;Denied Accounts Report with parameters&gt;
-- Version:		&lt;1.0&gt;
-- =====================================================
CREATE PROCEDURE [dbo].[spDeniedAccounts_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
			SELECT	ContactDate as [ContactDate],
						IdentificationMethod as [IdentificationMethod],
						SMID as [SMID],
						FNumber as [FNumber],
						SMFirstName as [SMFirstName],
						SMMiddleInitial as [SMMiddleInitial],
						SMLastName as [SMLastName],
						Branch as [Branch],
						Reserv as [Reserv],
						ADSD as [ADSD],
						ADED as [ADED],
						[Status] as [Status],
						DenialReason as [DenialReason],
						BenefitAppliedDate as [BenefitAppliedDate],
						BenefitEffectiveDate as [BenefitEffectiveDate],
						ExpectedRemovalDate as [ExpectedRemovalDate],
						BenefitRemovedDate as [BenefitRemovedDate],
						ExtendDate as [ExtendDate],
						CustID as [CustID],
						CustFNumber as [CustFNumber],
						CustFirstName as [CustFirstName],
						CustMiddleInitial as [CustMiddleInitial],
						CustLastName as [CustLastName],
						ContractNo as [ContractNo],
						AccountNo as [AccountNo],
						ProductType as [ProductType],
						ProductSubType as [ProductSubType],
						ProductOpenDate as [ProductOpenDate],
						ProductCloseDate as [ProductCloseDate]
			FROM
				(
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					--,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,ISNULL(sm.FNumber,'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					,ISNULL(adr.Branch,'') as Branch,ISNULL(adr.Reserv,'') as Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') &lt;&gt; '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') &lt;&gt; '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE '' END END as ADED 
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,ISNULL(b.DenialReason,'') as DenialReason
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,ISNULL(cust.FNumber,'') as CustFNumber,ISNULL(cp.FirstName,'') as CustFirstName
					,ISNULL(cp.MiddleInitial,'') as CustMiddleInitial,ISNULL(cp.LastName,'') as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON b.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											LEFT JOIN 
													(SELECT b.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b.ActiveDutyID) as ADCount, 
														   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
													FROM ActiveDuty ad JOIN Benefit b on b.ActiveDutyID = ad.ID WHERE b.BenefitIntervalId IS NOT NULL GROUP BY b.BenefitIntervalID,ad.PersonID) adr
													ON b.BenefitIntervalId = adr.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 RIGHT JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													LEFT JOIN [Customer] cust on c.PersonID = cust.PersonID
														LEFT JOIN [Person] cp ON cust.PersonID = cp.ID
															LEFT JOIN [Customer] sm on sm.PersonID = adr.PersonID
																LEFT JOIN [Person] smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') &lt;&gt; 'misdirected'
							AND b.[Status] IN ('denied','denying')
							AND (t.TaskType = 'deny_benefit')
							AND i.InquiryDate &gt;= @DateStart AND i.InquiryDate &lt;= @DateEnd
							AND ISNULL(c.IsDeleted,'') = 0
							--AND (ISNULL(bd.BenefitRemovedDate,'') &gt; @DateEnd OR bd.BenefitRemovedDate IS NULL)
							--AND i.InquiryDate &lt;= @DateEnd
				--ORDER BY b.PersonID
				) th
				ORDER BY SMID
			
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spDeniedAccounts_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31'
*/

