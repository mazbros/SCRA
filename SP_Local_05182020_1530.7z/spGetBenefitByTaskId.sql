-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/11/2020&gt;
-- Description:	&lt;Get benefit by task id&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spGetBenefitByTaskId]
	@TaskId INT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT	[ID], [BenefitIntervalId], [ContractID], 
						[Timestamp], [ModifiedBy], [PersonID],
						[ActiveDutyID], [IsPromo], [StartDate],
						[EndDate], [Status], [DenialReason],
						[TaskID]
				FROM [dbo].[Benefit]
				WHERE [TaskID] = @TaskId;
    
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
END



