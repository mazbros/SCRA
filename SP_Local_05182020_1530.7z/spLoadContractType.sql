-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;02/25/2020&gt;
-- Description:	&lt;Loading contract type info&gt;
-- =============================================
CREATE PROCEDURE dbo.[spLoadContractType] 
	@categoryCode varchar(55)
AS
BEGIN

	SET NOCOUNT ON;

	SELECT	[ID] AS ContractTypeId, [SCRA_Code], [SUB_PRODUCT_NAME]
		FROM	dbo.ContractType
	WHERE [SCRA_Code] = @categoryCode;

END
