
CREATE PROCEDURE [dbo].[spBenefit_Update]
	@Id				INT,
	@Status			VARCHAR(50),
	@DenialReason	VARCHAR(MAX),
	@StartDate		DATE = NULL,
	@EndDate		DATE = NULL,
	@TaskID			INT = NULL,
	@ModifiedBy		INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	INSERT INTO [hist].[Benefit]
           ([BenefitID]
           ,[ContractID]
           ,[Timestamp]
           ,[ModifiedBy]
           ,[PersonID]
           ,[ActiveDutyID]
           ,[IsPromo]
           ,[StartDate]
           ,[EndDate]
           ,[Status]
           ,[DenialReason]
           ,[TaskID])
		SELECT [ID]
		  ,[ContractID]
		  ,[Timestamp]
		  ,[ModifiedBy]
		  ,[PersonID]
		  ,[ActiveDutyID]
		  ,[IsPromo]
		  ,[StartDate]
		  ,[EndDate]
		  ,[Status]
		  ,[DenialReason]
		  ,[TaskID]
	  FROM [dbo].[Benefit]
		WHERE ID = @ID
		
	UPDATE [dbo].[Benefit]
	   SET [Timestamp] = GETDATE(),
		   [ModifiedBy] = @ModifiedBy,
		   [StartDate] = @StartDate,
		   [EndDate] = @EndDate,
		   [Status] = @Status,
		   [DenialReason] = @DenialReason,
		   [TaskID] = @TaskID
	 WHERE [ID] = @Id

END
