CREATE PROCEDURE [dbo].[spNote_Update] 

	@PersonID	INT,
	@Comment	NVARCHAR(MAX),
	@ModifiedBy	INT,
	@IsDeleted	BIT,
	@ID			INT OUT
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @ID = 0 BEGIN SET @ID = NULL END
				
				IF @ID IS NULL BEGIN
				
					INSERT INTO [dbo].[Note]
						([PersonID]
						,[Comment]
						,[Timestamp]
						,[ModifiedBy])
					VALUES
						(@PersonID
						,@Comment
						,GETDATE()
						,@ModifiedBy)
						
					SET @ID = SCOPE_IDENTITY()
					
				END ELSE BEGIN
				
					INSERT INTO [hist].[Note]
						([ID]
						,[PersonID]
						,[Comment]
						,[Timestamp]
						,[ModifiedBy]
						,[IsDeleted])
					SELECT [ID]
						,[PersonID]
						,[Comment]
						,[Timestamp]
						,[ModifiedBy]
						,[IsDeleted]
					FROM [dbo].[Note]
					WHERE [ID] = @ID
					
					UPDATE [dbo].[Note]
						SET [Comment] = @Comment,
							[Timestamp] = GETDATE(),
							[ModifiedBy] = @ModifiedBy,
							[IsDeleted] = @IsDeleted
						WHERE [ID] = @ID
						
				END			
				
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
			
END

