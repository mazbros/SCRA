CREATE PROCEDURE [dbo].[spTask_Update]
	@ID			INT,
	@ModifiedBy INT,
	@Status		VARCHAR(255) = NULL,
	@QaComplete	BIT = NULL,
	@AssigneeID INT = NULL,
	@QaAssigneeID INT = NULL
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  	INT,
        @ErrorSource    SYSNAME,
        @ErrorState 	INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION   
				  
				IF @AssigneeID = 0 BEGIN SET @AssigneeID = NULL END;
				IF @QaAssigneeID = 0 BEGIN SET @QaAssigneeID = NULL END;
				
				UPDATE [dbo].[Task]
					SET [Status] = COALESCE(@Status, [Status])
					   ,[QaComplete] = COALESCE(@QaComplete, QaComplete)
					   ,[AssigneeID] = COALESCE(@AssigneeID, [AssigneeID])
					   ,[QaAssigneeID] = COALESCE(@QaAssigneeID, [QaAssigneeID])
					   ,[Timestamp] = GETDATE()
					   ,[ModifiedBy] = @ModifiedBy
				 WHERE [ID] = @ID

			 COMMIT TRANSACTION
	    
	    END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END

END


