CREATE PROCEDURE [dbo].[spDMDC_Validation_EXL_Report]
	--@ReportDate date
AS
BEGIN

	SET NOCOUNT ON;
	
SELECT [Status],
	[PersonRequestingFirstName] as [Person Requesting First Name],
	[PersonRequestingLastName] as [Person Requesting Last Name],
	[ServicememberID] as [Potential Servicemember ID],	
	[ServicememberFirstName] as [Potential Servicemember First Name],
	[ServicememberMiddleInitial] as [Potential Servicemember Middle Initial],
	[ServicememberLastName] as [Potential Servicemember Last Name],
	[RequestDate] as	[Request Date],	
	[LogRequestDone] as [Log Request Done],
	[LogRequestCompletedBy] as [Log Request Completed By],
	[DMDCValidationDate] as [DMDC Validation Date],
	[ServicememberOnActiveDuty] as [Servicemember On Active Duty],
	[Completed] as [Completed],
	[ResponseDate] as [Response Date],
	[ResponseMethod] as [Response Method],
	[ResponseText] as [Response Text],
	[Description] as [Description],
	[Comment] as [Comment]
FROM (
	/* DMDC */
	SELECT DISTINCT i.ID,CAST(CONVERT(VARCHAR(10),[InquiryDate],121) as DATE) as 'RequestDate'
	  ,[InquiryType]
	  
	  ,COALESCE(/*(SELECT CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th )  &gt; 0 THEN 'in_process'
				ELSE CASE WHEN
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'completed'
				ELSE CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'qa_completed'
				ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
				END
			END
		END)*/t.[Status], CASE i.[IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE '' END) as [Status]
	  
	  ,ISNULL(i.PersonInquiringId,'') as [PersonRequestingId]
	  ,ISNULL((SELECT FirstName FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingFirstName]
	  ,ISNULL((SELECT LastName FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingLastName]
	  
	  ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
     
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [dbo].[Task] tt JOIN [dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]&lt;&gt; 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestDone'
      ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [dbo].[Task] tt JOIN [dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]&lt;&gt; 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestCompletedBy'
      	      
      ,ISNULL(REPLACE(REPLACE([Description],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Description]
      ,ISNULL(REPLACE(REPLACE([Comment],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Comment]
      ,ISNULL(REPLACE(REPLACE([ResponseText],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [ResponseText]
      
      --,ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Description],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Description]
      --,ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Comment],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Comment]
      --,ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([ResponseText],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [ResponseText]
      
      ,ISNULL(CONVERT(VARCHAR(10),[ResponseDate],121),'') as [ResponseDate]
      ,ISNULL(dbo.fnResponseMethodName([ResponseMethodId]),'') as [ResponseMethod]
      
      ,ISNULL(CONVERT(VARCHAR(10),[DMDCValidationDate],121),'') as [DMDCValidationDate]
      
      ,ISNULL(CASE WHEN ad.PersonID IS NOT NULL AND i.IsOnActiveDuty = 1 THEN 'Yes' ELSE '' END,'') as [ServicememberOnActiveDuty]
      
      ,CASE WHEN COALESCE(/*(SELECT CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th )  &gt; 0 THEN 'in_process'
				ELSE CASE WHEN
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'completed'
				ELSE CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'qa_completed'
				ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
				END
			END
		END)*/t.[Status], CASE i.[IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE '' END) IN ('completed','qa_completed','misdirected') THEN 'Yes' ELSE '' END as [Completed]
      
      /* CHANGE LATER, WHEN TASK ARE GENERATED */
      --,CASE WHEN (SELECT TOP 1 [Status] FROM dbo.SubTask WHERE TaskId = (SELECT ID FROM dbo.Task WHERE InquiryID = i.ID) GROUP BY [Title],[Status],[Timestamp] 
						--HAVING [Timestamp] = MAX([Timestamp]) AND [Title] &lt;&gt; 'Assign QA Agent' ORDER BY [Timestamp] DESC) IN ('completed','qa_completed','misdirected') THEN 'Yes' ELSE '' END as [Completed]
      
	FROM [dbo].[Inquiry] i
		LEFT JOIN [dbo].[Person] p ON i.ServicememberId = p.ID
		LEFT JOIN [dbo].[Task] t ON i.ID = t.InquiryID
		LEFT JOIN [dbo].[Customer] c ON p.Id = c.PersonID
		LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [dbo].[ActiveDuty] ad JOIN [dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
				GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
				(EndDate = (SELECT MAX(EndDate) FROM [dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
		LEFT JOIN [dbo].[Contract] con ON p.Id = con.PersonID
		LEFT JOIN [dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
		LEFT JOIN [dbo].[Employee] e ON i.[AgentID] = e.ID

	  WHERE [InquiryType] = 'dmdc_check' --and COALESCE(t.[Status], CASE i.[IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE '' END) = 'in_process'
	  ) th
	  ORDER BY CAST(CONVERT(VARCHAR(10),[RequestDate],121) as DATE) DESC


END


/*

--DECLARE @date date SET @date = dateadd(wk,-1,getdate())
--SELECT @date
EXEC [dbo].[spDMDC_Validation_EXL_Report]
	--@ReportDate = @date
	
*/
