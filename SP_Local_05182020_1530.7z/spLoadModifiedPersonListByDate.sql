-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/11/2020&gt;
-- Description:	&lt;Get modified person by date&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spGetModifiedPersonByDate]
	@Timestamp datetime
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT DISTINCT p.[ID], p.[FirstName], p.[MiddleInitial], p.[LastName], th.[Timestamp], th.[Category]
    FROM [dbo].[Person] p
        JOIN (SELECT [PersonID], [Timestamp], [Category] FROM (
                SELECT [ID] as PersonID, [Timestamp], 'PERS' as Category FROM [dbo].[Person] WHERE [Timestamp] &gt; @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'AD' as Category FROM [dbo].[ActiveDuty] WHERE [Timestamp] &gt; @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'CONTR' as Category FROM [dbo].[Contract] WHERE [Timestamp] &gt; @Timestamp
        ) u
    GROUP BY [PersonID], [Timestamp], [Category]
    HAVING [Timestamp] = (SELECT MAX([Timestamp]) 
                            FROM (
                                SELECT [ID] as PersonID, [Timestamp] FROM [dbo].[Person] p WHERE [Timestamp] &gt; @Timestamp AND p.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID], [Timestamp] FROM [dbo].[ActiveDuty] a WHERE [Timestamp] &gt; @Timestamp AND a.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID], [Timestamp] FROM [dbo].[Contract] c WHERE [Timestamp] &gt; @Timestamp AND c.[ID] = u.[PersonID]) uu )
    ) th 
        ON p.[ID] = th.[PersonID]
            WHERE p.[Origin] NOT IN ('dmdc_check','inquiry')
        ORDER BY [Timestamp] DESC
        
END
