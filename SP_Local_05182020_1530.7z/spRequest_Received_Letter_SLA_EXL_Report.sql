
-- ==================================================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;01/07/2020&gt;
-- Modified:	&lt;03/19/2020&gt;
-- Description:	&lt;Request Received Letter SLA Report, Excel Optimized&gt;
-- Version:		&lt;1.0&gt;
-- ==================================================================
CREATE PROCEDURE [dbo].[spRequest_Received_Letter_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT 
					[ContactDate] as [ContactDate],
					[IdentificationMethod] as [Identification Method],
					[OriginalMethodOfContact] as [Original Contact Method],
					[SMID] as [Servicemember ID],
					[FNumber] as [Servicemember FNumber],
					[SMFirstName] as [Servicemember First Name],
					[SMMiddleInitial] as [Servicemember Middle Initial],
					[SMLastName] as [Servicemember Last Name],
					[DueDate] as [Due Date],
					[CommunicationDate] as [Communication Date],
					[LetterId] as [Letter ID],
					[LetterCode] as [Letter Code],
					[LetterName] as [Letter Name],
					[LetterFullName] as [Letter Full Name],
					[Returned],
					[SLA Met],
					[Days Since Contact]
				--,DATENAME(weekday,ContactDate) as ContactDay,DATENAME(weekday,DueDate) as DueDay,DATENAME(weekday,CommunicationDate) as CommDate 
				FROM (
				SELECT DISTINCT ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,p.ID as SMID,ISNULL(COALESCE(cust.FNumber,sm.FNumber),'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					,dbo.fnGetNextBusinessDay(ISNULL(CONVERT(VARCHAR(10),DATEADD(day, 15, i.InquiryDate),121),'')) as DueDate
					,COALESCE(dbo.fnLetterNumberById(com.LetterId),'101') as LetterId
					,COALESCE(dbo.fnLetterCodeById(com.LetterId),'SCRA-101') as LetterCode
					,COALESCE(dbo.fnLetterNameById(com.LetterId),'RequestRcd') as LetterName
					,COALESCE(dbo.fnLetterFullNameById(com.LetterId),'SCRA-101 Request Received') as LetterFullName
					,'' as Returned
					--,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as Date1
					--,ISNULL(CONVERT(VARCHAR(10),i.ResponseDate,121),'') as Date2
					,ISNULL(CONVERT(VARCHAR(10),COALESCE(com.CommunicationDate,i.ResponseDate),121),'') as CommunicationDate
					,ISNULL(i.ResponseMethodID,'') as InquiryResponseMethod
					,CASE WHEN  COALESCE(com.CommunicationDate,i.ResponseDate) &lt;= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 15, i.InquiryDate),121),'')) THEN 'Yes' 
						   ELSE CASE WHEN COALESCE(com.CommunicationDate,i.ResponseDate) IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,isnull(COALESCE(com.CommunicationDate,i.ResponseDate),getdate())) as [Days Since Contact]
					 FROM [Inquiry] i 
							JOIN [Task] t ON i.ID = t.InquiryID
								JOIN [Person] p ON i.ServicememberId = p.ID
									LEFT JOIN [Contract] c ON (p.ID = c.PersonID)
										LEFT JOIN [Customer] cust on p.ID = cust.PersonID
											LEFT JOIN [ActiveDuty] ad ON p.ID = ad.PersonID
												LEFT JOIN [Communication] com ON p.ID = com.PersonID AND ISNULL(com.TaskID,'') = t.ID
													LEFT JOIN [Customer] sm on sm.PersonID = ad.PersonID
														LEFT JOIN [Person] smn on smn.ID = ad.PersonID
					WHERE 1=1
						
						AND (i.InquiryType = 'benefit_request'
						AND t.TaskType = 'request_benefits'
						AND ISNULL(i.IdentificationMethod,'') &lt;&gt; 'internal' 
						AND ((ISNULL(com.LetterId,'') = 2 OR com.LetterId IS NULL))
							OR (i.ResponseMethodId = 3 AND i.ResponseText LIKE '%request received%'))
						AND ISNULL(COALESCE(com.CommunicationDate,i.ResponseDate),'1900-01-01') BETWEEN @DateStart and @DateEnd
						AND ((dbo.fnLetterNumberById(com.LetterId) = 101 OR dbo.fnLetterNumberById(com.LetterId) IS NULL))
					) th 
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spExpiredAccounts_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31'
*/
