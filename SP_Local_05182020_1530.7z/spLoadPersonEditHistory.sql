-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/11/2020&gt;
-- Description:	&lt;Get person edit history&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spLoadPersonEditHistory] 
	@PersonId INT,
	@Timestamp datetime
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				IF @Timestamp &lt; (SELECT max([Timestamp]) FROM [Person] WHERE [ID] = @PersonId) BEGIN
			
					SELECT	P.[ID], P.[FirstName], P.[LastName], P.[MiddleInitial],
							P.[SSN], P.[DOB], P.[Address1], P.[Address2], P.[City],
							P.[State], P.[Zip], P.[Phone], P.[Email], C.[Name] as ContactMethod,
							P.[Timestamp], E.[Name] As ModifiedBy, CM.[FNumber]
					FROM
						(SELECT [ID], [FirstName], [LastName], [MiddleInitial],
								[SSN], [DOB], [Address1], [Address2], [City], 
								[State], [Zip], [Phone], [Email], [ContactMethodID], 
								[Timestamp], [ModifiedBy], [Origin]
							FROM [Person] WHERE ID = @PersonId
						UNION
						SELECT TOP 1 [ID], [FirstName], [LastName], [MiddleInitial],
									 [SSN], [DOB], [Address1], [Address2], [City], 
									 [State], [Zip], [Phone], [Email], [ContactMethodID], 
									 [Timestamp], [ModifiedBy], [Origin]
							FROM [hist].[Person] WHERE ID = @PersonId ORDER BY [Timestamp] DESC) P
						LEFT JOIN [ContactMethod] C ON C.[ID] = P.[ContactMethodID]
						LEFT JOIN [Employee] E ON E.[ID] = P.[ModifiedBy]
						LEFT JOIN [Customer] CM ON CM.[PersonID] = P.[ID]	
						ORDER BY [Timestamp] DESC;
						
				END
    
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END


