CREATE PROCEDURE [dbo].[spContract_Get]
	@ID INT
WITH RECOMPILE	
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				SELECT x.Id
					, x.Center
					, x.Product
					, x.ContractNo
					, x.LegacyNo
					, x.CardNo
					, x.OpenDate
					, x.CloseDate
					, x.PersonID
					, x.ContractTypeId
					, dbo.fnProductSubName(x.ID) as [SUB_PRODUCT_NAME]
					, t.SCRA_Code
					, x.[Charge_Off]
					, x.[Charge_Off_Note]
				FROM	dbo.[Contract] x
					INNER	JOIN dbo.ContractType t 
						ON	t.Id	= x.ContractTypeId
				WHERE x.ID = @ID
			
			 COMMIT TRANSACTION
	
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END


/*

EXEC [dbo].[spContract_Get] 723

*/

/*
UPDATE [SCRA_DB].[dbo].[Contract] 
	SET [SCRA_DB].[dbo].[Contract].[LegacyNo] = t4.[H1564_CTOLOCAL]
	FROM [SCRA_DB].[dbo].[Contract]  t1 
    JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t4 
		ON t1.Center = t4.H1564_IDCENT AND
			t1.Product = t4.H1564_IDPROD AND
			t1.ContractNo = t4.H1564_IDCONTRN
*/
