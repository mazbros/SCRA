
CREATE PROCEDURE [dbo].[spContract_RemoteFetch_2] 	
	@FNumber varchar(10)
WITH RECOMPILE	
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @TIPOPERS VARCHAR(1),@CODOPERS INT
		
	PRINT @FNUMBER;
	
	SET @TIPOPERS = LEFT(@FNUMBER,1)
	
	IF LEN(@FNUMBER) = 10 BEGIN
		SET @CODOPERS = CONVERT(INT, RIGHT(@FNUMBER,9))
	END ELSE BEGIN
		SET @CODOPERS = CAST(REPLACE(REPLACE(@FNUMBER,'F',''),'J','') as INT)
	END

	
	/* ============================================================== */
	;WITH Table_Result (
	   [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[CategoryName]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[ContractTypeId]
      )  AS (
	/* ============================================================== */	
	SELECT DISTINCT
       @FNUMBER as [FNumber]
      ,CAST(t3.[IDCENT] as INT) as [Center]
      ,CAST(t3.[IDPROD] as INT) as [Product]
      ,CAST(t3.[IDSTIPRO] as INT) as [Subproduct]
      ,CAST(t3.[ESTANREF] as INT) as [StandardRef]
      ,CAST(t3.[IDCONTRN] as INT) as [ContractNo]
      ,t5.[H1564_CTOLOCAL] as [LegacyNo]
      ,m.[H4253_XPAN] as [CardNo]
      ,[FECCONTR] as [OpenDate]
      ,(CASE WHEN [FECBAJA] = '9999-12-31' THEN NULL ELSE [FECBAJA] END) as [CloseDate]
      ,t4.[CATEGORY_NAME] as [CategoryName]
      ,t4.[SUB_PRODUCT_NAME]
      ,t4.[SCRA_Code]
      ,t4.[ID] as [ContractTypeId]
	FROM 
		[CUSTDASH].[OLD].[CAD_CONTR_M_S] t3
			JOIN [dbo].[ContractType] t4
				ON t3.IDPROD = t4.Product AND
					t3.IDSTIPRO = t4.Sub_Product AND
					t3.ESTANREF = t4.Standard_Ref 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t5
				ON t3.IDCONTRN = t5.H1564_IDCONTRN AND
					t3.IDCENT = t5.H1564_IDCENT AND
					t3.IDPROD = t5.H1564_IDPROD 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_MPDT009_M] m
				ON t3.[IDCENT] = m.[H4253_CENTALTA] AND
					t3.[IDPROD] = m.[H4253_CDGPRODU] AND
					t3.[IDCONTRN] = m.[H4253_IDCONTRN] AND [H4253_CDGPRODU] = '500' AND (m.H4253_CODBLQ = 0 OR m.H4253_TEXBLQ LIKE '%CLOS%')
		WHERE TIPOPERS = @TIPOPERS AND CODPERS = @CODOPERS
	AND t4.IsEligible = 1
		GROUP BY  t3.[IDCENT],t3.[IDPROD],t3.[IDSTIPRO],t3.[ESTANREF],t3.[IDCONTRN],t5.[H1564_CTOLOCAL]
				  ,m.[H4253_XPAN],[FECCONTR],t4.[CATEGORY_NAME],t4.[SUB_PRODUCT_NAME],t4.[SCRA_Code],t4.[ID]
				  ,t3.[FECBAJA]
	/* ================================================================== */
	) 
   
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[ContractTypeId] FROM (
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[ContractTypeId]
      ,ROW_NUMBER() OVER (PARTITION by [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate] order by [CloseDate] DESC) as [RN]
   FROM Table_Result) t1
   WHERE [RN] = 1
	/* ================================================================== */
 	

END

/*

EXEC  [dbo].[spContract_RemoteFetch] @PersonId = 422

*/
