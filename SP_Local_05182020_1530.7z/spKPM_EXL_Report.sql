-- =================================================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;12/26/2019&gt;
-- Modified:	&lt;01/16/2019&gt;
-- Description:	&lt;KPI Report with parameters&gt;
-- Version:		&lt;1.0&gt;
-- =================================================================
CREATE PROCEDURE [dbo].[spKPM_EXL_Report] 
	@DateStart date,
	@DateEnd date,
	@ProductCategory varchar(50)
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				DECLARE @SQL varchar(max),@SQL2 varchar(max)
				SET @SQL2 = ''	
				SET @SQL = '
				SELECT	ContactDate as [Contact Date],
						IdentificationMethod as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						SMID as [Servicemember ID],
						FNumber as [Servicemember FNumber],
						SMFirstName as [Servicemember First Name],
						SMMiddleInitial as [Servicemember Middle Initial],
						SMLastName as [Servicemember Last Name],
						Branch,
						Reserv,
						ADSD as [Active Duty Start Date],
						ADED as [Active Duty End Date],
						Status as [Benefit Status],
						BenefitAppliedDate as [Benefit Applied Date],
						BenefitEffectiveDate as [Benefit Effective Date],
						ExpectedRemovalDate as [Expected Removal Date],
						BenefitRemovedDate as [Benefit Removed Date],
						ExtendDate as [Extend Date],
						CustID as [Customer ID],
						CustFNumber as [Customer FNumber],
						CustFirstName as [Customer First Name],
						CustMiddleInitial as [Customer Middle Initial],
						CustLastName as [Customer Last Name],
						ContractNo as [Contract #],
						AccountNo as [Account #],
						ProductType as [Product Type],
						ProductSubType as [Product SubType],
						ProductOpenDate as [Product Open Date],
						ProductCloseDate as [Product Close Date]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'''') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'''') 
						WHEN ''internal'' THEN ''Proactive''
						WHEN ''line_business'' THEN ''Line of Business''
						WHEN ''customer'' THEN ''Customer Originated''
						WHEN ''third_party'' THEN ''Third Party Service Provider''
						WHEN '''' THEN ''''
						ELSE ''''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'''') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'''') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = ''9999-12-31'' AND ISNULL(adr.ADSD,'''') &lt;&gt; '''' THEN '''' ELSE CASE WHEN ISNULL(adr.ADSD,'''') &lt;&gt; '''' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE NULL END END as ADED 
					,ISNULL(adr.ADCount,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'''') != '''' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '''' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'''') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'''') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'''') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'''') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'''') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'''') = '''' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'''') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'''') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'''') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'''') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,''9999-12-31'')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														LEFT JOIN [Customer] sm on   sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
																	WHERE b.BenefitIntervalId
						IN		
						(
							SELECT ISNULL(b.BenefitIntervalId,0) as BenefitIntervalId
								FROM [Benefit] b 
									JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 ,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 ,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 ,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 ,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 ,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
								WHERE 1 = 1
									AND ISNULL(t.[Status],'''') &lt;&gt; ''misdirected''
									AND (t.TaskType = ''add_benefit'' OR t.TaskType = ''continue_benefit'') 
									--AND (ISNULL(bd0.BenefitAppliedDate,'''') &lt;= ''' + CONVERT(VARCHAR(10),@DateEnd,121) + ''' OR bd0.BenefitAppliedDate IS NULL)
									AND (ISNULL(bd0.BenefitAppliedDate,''9999-12-31'') &lt;= ''' + CONVERT(VARCHAR(10),@DateEnd,121) + ''' OR bd0.BenefitAppliedDate IS NULL)
						) '
						SET @SQL2 = @SQL2 + '
						AND b.BenefitIntervalId NOT IN 
						(	
							SELECT ISNULL(b.BenefitIntervalId,0)
								FROM [Benefit] b 
									JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 ,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 ,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 ,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 ,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 ,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
									WHERE 1 = 1
										AND ISNULL(t.[Status],'''') &lt;&gt; ''misdirected''
										AND t.TaskType = ''remove_benefit'' 
										AND (ISNULL(bd0.BenefitRemovedDate,''9999-12-31'') &gt; (ISNULL(bd0.ExtendDate,''1900-01-01'')))
										--AND (ISNULL(bd0.BenefitRemovedDate,'''') &lt; ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''' OR bd0.BenefitRemovedDate IS NULL)
										AND (ISNULL(bd0.BenefitRemovedDate,''1900-01-01'') &lt;= ''' + CONVERT(VARCHAR(10),@DateEnd,121) + ''' OR bd0.BenefitRemovedDate IS NULL)
										GROUP BY b.BenefitIntervalId
						)
						AND 
						(
						      (TaskType = ''add_benefit''		AND  ISNULL(bd.BenefitRemovedDate,''9999-12-31'') &gt;= ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''' AND bd.ExtendDate IS NULL)
						  OR  (TaskType = ''continue_benefit''	AND (ISNULL(bd.BenefitRemovedDate,''9999-12-31'') &gt;= ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''' or ISNULL(bd.BenefitRemovedDate,''9999-12-31'') &lt;  ISNULL(bd.ExtendDate,''1900-01-01'')) ) 
						  OR  (TaskType = ''extend_benefit''	AND (ISNULL(bd.BenefitRemovedDate,''9999-12-31'') &gt;= ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''' or ISNULL(bd.BenefitRemovedDate,''9999-12-31'') &lt;  ISNULL(bd.ExtendDate,''1900-01-01'') ))
						)
						AND ISNULL(t.[Status],'''') &lt;&gt; ''misdirected''
						AND ISNULL(b.[Status],'''') &lt;&gt; ''''
						AND c.IsDeleted = 0 
						AND (ISNULL(c.CloseDate,'''') &gt;= ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''' or c.CloseDate IS NULL)						
						
						AND NOT (ISNULL(b.[Status],'''') IN (''applying'',''extending'') AND bd.BenefitAppliedDate IS NULL AND ISNULL(i.InquiryDate,''9999-12-31'') &gt; ''' + CONVERT(VARCHAR(10),@DateStart,121) + ''') '	
						
						IF @ProductCategory = 'Consumer Loan + Home Equity' BEGIN 
							SET @SQL2 = @SQL2 + '						AND dbo.fnProductName(c.ContractTypeId) IN (''Consumer Loan'',''Home Equity'') '
						END ELSE BEGIN
							IF @ProductCategory &lt;&gt; 'All' BEGIN
								SET @SQL2 = @SQL2 + '						AND dbo.fnProductName(c.ContractTypeId) IN (''' + @ProductCategory + ''') '
							END ELSE BEGIN
								SET @SQL2 = @SQL2 + ''
							END
						END
				
				SET @SQL2 = @SQL2 + '
					) th
				ORDER BY SMID,ISNULL(CONVERT(VARCHAR(10),BenefitAppliedDate,121),'''')'
			
				PRINT LEN(@SQL)
				PRINT LEN(@SQL2)
				PRINT @SQL
				PRINT @SQL2
				EXEC (@SQL+@SQL2)
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='All'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Auto'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Commercial Loan'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Credit Card'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Consumer Loan'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Home Equity'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2020-01-01',@DateEnd='2020-01-01',@ProductCategory='Consumer Loan + Home Equity'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Mortgage'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Safe Deposit Box'
EXEC [dbo].[spKPM_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Other'
*/
