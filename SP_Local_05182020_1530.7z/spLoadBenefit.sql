-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/11/2020&gt;
-- Description:	&lt;Load benefit&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spLoadBenefit]
	@ContractID INT = NULL,
	@BenefitID	INT = NULL,
	@PersonID	INT = NULL
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @SQL varchar(max)
	SET @SQL = '
	SELECT	[ID], [BenefitIntervalId], [ContractID], 
			[PersonID], [ActiveDutyID], [IsPromo], 
			[StartDate], [EndDate], [Status], 
			[DenialReason], [TaskID]
	FROM [dbo].[Benefit]
	WHERE '
	IF @ContractID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[ContractID] = ' + CAST(@ContractID as varchar(16))
	END
	IF @BenefitID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[ID] = ' + CAST(@BenefitID as varchar(16))
	END
	IF @PersonID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[PersonID] = ' + CAST(@PersonID as varchar(16))
	END
	SET @SQL = @SQL + '
	ORDER	BY [StartDate], [ID];'
	
	EXEC (@SQL);
	
END
