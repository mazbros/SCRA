
CREATE PROCEDURE [dbo].[spLetter_Templates]
	@ID				INT = NULL,
	@Action			VARCHAR(255),
	@FileName		VARCHAR(MAX)  = null,
	@FileContent	VARBINARY(MAX) = null
AS
BEGIN
	
	SET NOCOUNT ON;
				
		if @Action = 'list' begin
			select * from Letter_DATA
		end
		
		else if @Action = 'upload' begin
			insert into dbo.Letter_DATA (TemplateFilename, Template)
				values (@FileName, @FileContent)
		end

		else if @Action = 'update' begin
			update dbo.Letter_DATA 
				set TemplateFilename = @FileName,
					Template = @FileContent
			where ID = @ID
		end

		else if @Action = 'download' begin
			select * from Letter_DATA
			where ID = @ID
		end

		else if @Action = 'delete' begin
			delete from dbo.Letter_DATA 
			where ID = @ID
		end
	
END

--exec dbo.spLetter_Templates @Action='list'

--exec dbo.spLetter_Templates @Action='download', @ID = 2