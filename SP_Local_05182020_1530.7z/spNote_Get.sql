CREATE PROCEDURE [dbo].[spNote_Get]
	@PersonID	INT
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  	INT,
			@ErrorSource    SYSNAME,
			@ErrorState 	INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT * FROM 
				(
					SELECT 
						n.id,
						n.PersonID,
						n.[Comment], 
						n.[Timestamp], 
						n.[ModifiedBy], 
						dbo.fnGetUserName(n.[ModifiedBy]) as 'ModifiedByName'			
					FROM [dbo].[Note] n 
					WHERE [PersonID] = @PersonID 
					AND n.[IsDeleted] = 0
						
				--UNION
					
				--	SELECT 
				--		i.[Description] as [Comment],
				--		i.[Timestamp],
				--		i.[ModifiedBy],
				--		(SELECT [Name] FROM [dbo].[Employee] 
				--			WHERE [ID] = i.[ModifiedBy]) as 'ModifiedByName' 
				--		FROM [dbo].[Inquiry] i
				--			WHERE i.[ServicememberId] = @PersonID 
				) u
				ORDER BY [Timestamp] DESC
			
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
			
END

/* 
--ALTER TABLE [dbo].[Note] ADD [IsDeleted] BIT NOT NULL DEFAULT (0) 
--ALTER TABLE [hist].[Note] ADD [IsDeleted] BIT NOT NULL DEFAULT (0) 
*/
