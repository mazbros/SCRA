
CREATE PROCEDURE [dbo].[spBenefit_Create]
	@ContractId		INT,
	@ActiveDutyId	INT,
	@PersonId		INT,
	@Status			VARCHAR(50),
	@IsPromo		BIT,
	@StartDate		DATE = NULL,
	@EndDate		DATE = NULL,
	@ModifiedBy		INT,
	@DenialReason	VARCHAR(MAX),
	@BenefitIntervalId int = null,
	@ID				INT OUT
AS
BEGIN
	
	SET NOCOUNT ON;
		if(@BenefitIntervalId is null or @BenefitIntervalId = 0) begin
			set @BenefitIntervalId = (select max(isnull (BenefitIntervalId, 0)) + 1 from Benefit)
		end

		INSERT INTO [dbo].[Benefit]
           ([ContractID]
           ,[Timestamp]
           ,[ModifiedBy]
           ,[PersonID]
           ,[ActiveDutyID]
           ,[IsPromo]
           ,[StartDate]
           ,[EndDate]
           ,[Status]
           ,[DenialReason]
		   ,[BenefitIntervalId])
     VALUES
           (@ContractID,
			GETDATE(),
            @ModifiedBy,
            @PersonID,
            @ActiveDutyID,
            @IsPromo,
			@StartDate,
			@EndDate,
			@Status,
			@DenialReason,
			@BenefitIntervalId)
			
	SELECT @ID = SCOPE_IDENTITY();		
	
	SELECT BenefitIntervalId from Benefit where ID = @ID

END
