
CREATE PROCEDURE [dbo].[sp_Delete_Person_Records]
	@PersonID INT
AS
BEGIN
	
	SET NOCOUNT ON;

    DELETE from [dbo].[ActiveDutyDetail] WHERE ActiveDutyID IN (select id from [dbo].[ActiveDuty] WHERE PersonID = @PersonID)
    DELETE from [dbo].[ActiveDuty] WHERE PersonID = @PersonID
	DELETE from [dbo].[BenefitDetail] WHERE BenefitId IN (SELECT ID from dbo.Benefit WHERE PersonID = @PersonID)
	DELETE from [dbo].[Benefit] WHERE PersonID = @PersonID
	DELETE from [dbo].[Communication] WHERE PersonID = @PersonID
	DELETE from [dbo].[SubTask] WHERE TaskID IN (SELECT ID from dbo.Task WHERE PersonID = @PersonID)
	DELETE from [dbo].[Task] WHERE PersonID = @PersonID
	DELETE from [dbo].[Contract] WHERE PersonID = @PersonID
	DELETE from [dbo].[Customer] WHERE PersonID = @PersonID
	DELETE from [dbo].[File] WHERE ID IN (SELECT FileID from [dbo].[DocumentLink] WHERE EntityId = @PersonID)
	DELETE from [dbo].[DocumentLink] WHERE EntityId = @PersonID
	DELETE from [dbo].[Inquiry] WHERE PersonInquiringId = @PersonID OR ServicememberId = @PersonID
	DELETE from [dbo].[Note] WHERE PersonID = @PersonID
	DELETE from [dbo].[PersonToPersonLink] WHERE FromID = @PersonID OR ToID = @PersonID
	DELETE from [dbo].[Person] WHERE ID = @PersonID
    
END

/* 

EXECUTE [dbo].[sp_Delete_Person_Records] 735
EXECUTE [dbo].[sp_Delete_Person_Records] 736
	
*/	