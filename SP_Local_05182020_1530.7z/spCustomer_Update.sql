CREATE PROCEDURE [dbo].[spCustomer_Update]

	@FNumber	VARCHAR(10),
	@PersonID	INT,
	@ModifiedBy		INT
WITH RECOMPILE
	AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  	INT,
        @ErrorSource    SYSNAME,
        @ErrorState 	INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION   

				IF NOT EXISTS(SELECT * FROM [dbo].[Customer] WHERE [PersonID] = @PersonID) BEGIN
					
					INSERT INTO [dbo].[Customer]
						([FNumber]
						,[PersonID]
						,[Timestamp]
						,[ModifiedBy])
						VALUES
						(@FNumber
						,@PersonID
						,GETDATE()
						,@ModifiedBy)
						
				END ELSE BEGIN
				
					INSERT INTO [hist].[Customer]
						([ID]
						,[FNumber]
						,[PersonID]
						,[ModifiedBy]
						,[Timestamp])
					SELECT [ID],[FNumber],[PersonID],[ModifiedBy],[Timestamp] 
						FROM [dbo].[Customer]
						WHERE [PersonID] = @PersonID
						
					UPDATE [dbo].[Customer]
						SET [FNumber] = @FNumber,
							[ModifiedBy] = @ModifiedBy,
							[Timestamp] = GETDATE()
						WHERE [PersonID] = @PersonID
				END
	
			COMMIT TRANSACTION
	
		END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END			

END
