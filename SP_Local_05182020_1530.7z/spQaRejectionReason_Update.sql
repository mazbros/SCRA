-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/06/2020&gt;
-- Description:	&lt;Save QA rejection reason&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spQaRejectionReason_Update]
	@SubTaskId			INT,
	@RejectionReason	VARCHAR(255)	
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
			
				IF (SELECT COUNT(*) FROM [dbo].[RejectionReason] WHERE SubTaskID = @SubTaskId) = 0 BEGIN
					
						INSERT INTO [dbo].[RejectionReason]
							(SubTaskID,
							Rejectionreason)
						VALUES
							(@SubTaskId,
							@RejectionReason)
							
				END ELSE BEGIN 
					
						UPDATE [dbo].[RejectionReason]
							SET [RejectionReason] = @RejectionReason
						WHERE [SubTaskId] = @SubTaskId
					
				END

			COMMIT TRANSACTION
	
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = Convert(NVARCHAR(2048),SUBSTRING(ERROR_MESSAGE(),1,2047));
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
    
END
