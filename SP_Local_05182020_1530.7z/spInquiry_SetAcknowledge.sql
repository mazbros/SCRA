
CREATE PROCEDURE dbo.spInquiry_SetAcknowledge
	@ID					INT,
	@AcknowledgeDate	DATETIME,
	@ModifiedBy			INT
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE dbo.[Inquiry] 
		SET [AcknowledgeDate] = @AcknowledgeDate, 
			[ModifiedBy] = @ModifiedBy, 
			[Timestamp] = GETDATE() 
	WHERE [ID] = @ID
	
END
