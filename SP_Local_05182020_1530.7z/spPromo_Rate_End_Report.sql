CREATE PROCEDURE [dbo].[spPromo_Rate_End_Report]
WITH RECOMPILE
AS
	SET NOCOUNT ON;
--	;with CTE AS (
--	SELECT DISTINCT sm.PersonID,s.DateOfContact,s.MethodOfNotification,s.DateDMDCSearchPerformed,s.VerifyBySCRAOrMilOrders
--				,s.ActiveAccountEligible,s.BenefitApprovedDeniedPending,s.StatusCode
--				,s.NotEligReason,s.DenialReason,s.[90DayLetterSentOn]
--	FROM [SCRA_DB_MIGRATE].[dbo].[Sample] s 
--	JOIN [dbo].[Servicemember] sm ON s.ServiceMemberID = sm.ServicememberID
--	) 
--	SELECT DISTINCT
--	 CAST(com.CommunicationDate	as DATE)	AS DateOfContact
--		,p.ID								AS ServiceMemberID
--		,p.LastName							AS ServicememberLastName
--		,p.FirstName						AS ServicememberFirstname
--		,p.MiddleInitial					AS ServicememberMiddleInitial
--		,cust.FNumber
--		,p.SSN								AS SocialSecurityNumber
--		,p.DOB								AS DateOfBirth
--		,bos.Branch							AS BranchOfService
--		,ad.StartDate						AS ADStartDate
--		,ad.EndDate							AS ADEndDate
--		,cte.BenefitApprovedDeniedPending	AS BenefitApprovedDeniedPending
--		,bd.BenefitAppliedDate				AS DateBenefitsApplied
--		,bd.BenefitRemovedDate				AS DateBenefitsEnded
--		--,ct.CATEGORY_ORIGIN
--		,CASE WHEN ct.SCRA_Code = 'auto' THEN 'Auto'
--			  WHEN ct.SCRA_Code = 'commercial' THEN 'Commercial Loan'
--			  WHEN ct.SCRA_Code = 'consumer_loan' THEN 'Consumer Loan'
--			  WHEN ct.SCRA_Code = 'credit_card' THEN 'Credit Card'
--			  WHEN ct.SCRA_Code = 'mortgage' THEN 'Mortgage'
--			  WHEN ct.SCRA_Code = 'safe_dep_box' THEN 'Safe Deposit Box'
--			  WHEN ISNULL(ct.SCRA_Code,'') = '' THEN ''
--			  ELSE 'Other' END
--											AS ProductType
--		,ct.SUB_PRODUCT_NAME				AS SubType
--		,COALESCE(
--			CASE 
--				WHEN ISNULL(cnt.LegacyNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.LegacyNo END,
--			CASE 
--				WHEN ISNULL(cnt.CardNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.CardNo END,
--			CASE 
--				WHEN ISNULL(cnt.ContractNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.ContractNo END)	AS AccountNum
--		,cnt.OpenDate						AS StartDate
--		,cnt.CloseDate						AS EndDate
--		,cte.ActiveAccountEligible			AS ActiveAccountEligible
--		,REPLACE(REPLACE(REPLACE(note.Comment,CHAR(13)+CHAR(10),'|'),CHAR(34),''''''),CHAR(9),' ') AS Comments
--		,REPLACE(REPLACE(REPLACE(note.Comment,CHAR(13)+CHAR(10),'|'),CHAR(34),''''''),CHAR(9),' ') AS AdditionalComments
--		,bd.PromotionEndDate				AS [Promo Rate End Date]
--	FROM dbo.Person p 
--		INNER JOIN dbo.Communication com 
--			ON com.PersonID=p.ID
--		INNER JOIN dbo.ContactMethod cm 
--			ON com.ContactMethodId=cm.ID
--		INNER JOIN dbo.Customer cust 
--			ON cust.PersonID=p.ID
--		LEFT JOIN dbo.Note note 
--			ON note.PersonID=p.ID
--		INNER JOIN dbo.Benefit b 
--			ON com.BenefitID=b.ID
--		LEFT JOIN dbo.BenefitDetail bd 
--			ON b.ID=bd.BenefitId
--		LEFT JOIN dbo.[Contract] cnt ON cnt.ID=b.ContractID
--		INNER JOIN dbo.ContractType ct ON cnt.ContractTypeId=ct.ID
--		LEFT JOIN dbo.ActiveDuty ad ON ad.PersonID=p.ID
--		INNER JOIN dbo.BranchOfService bos ON ad.BranchOfServiceID=bos.ID
--		LEFT JOIN dbo.Letter_DATA ld ON ld.ID=com.LetterId
		
--		LEFT JOIN CTE cte ON p.ID = cte.PersonID
		
--		OUTER APPLY (SELECT CASE WHEN inq.DMDCValidationDate IS NULL 
--						THEN inq.InquiryDate ELSE inq.DMDCValidationDate END AS DMDCValidationDate 
--							FROM dbo.Inquiry inq inner join dbo.Task task 
--								ON inq.ID = task.InquiryID 
--							WHERE inq.InquiryType='dmdc_check' and task.ID=com.TaskId) dmdc
--		WHERE ISNULL(bd.PromotionEndDate,'') &lt;&gt; ''

--ORDER BY CAST(com.CommunicationDate	as DATE) DESC	

--;with CTE AS (
--	SELECT DISTINCT sm.PersonID,s.DateOfContact,s.MethodOfNotification,s.DateDMDCSearchPerformed,s.VerifyBySCRAOrMilOrders
--				,s.ActiveAccountEligible,s.BenefitApprovedDeniedPending,s.StatusCode
--				,s.NotEligReason,s.DenialReason,s.[90DayLetterSentOn]
--	FROM [SCRA_DB].[dbo].[Migration_History] s 
--	JOIN [dbo].[Servicemember] sm ON s.ServiceMemberID = sm.ServicememberID
--	) 
--	SELECT DISTINCT
--		--CAST(com.CommunicationDate	as DATE)	AS DateOfContact
--		COALESCE(cast(cte.DateOfContact as date), 
--					CASE WHEN cast(p.[Timestamp] as date) = '2019-02-15' THEN NULL ELSE cast(p.[timestamp] as date) END,
--					com.CommunicationDate)	
--				  							AS DateOfContact
--		,p.ID								AS ServiceMemberID
--		,p.LastName							AS ServicememberLastName
--		,p.FirstName						AS ServicememberFirstname
--		,p.MiddleInitial					AS ServicememberMiddleInitial
--		,cust.FNumber
--		,p.SSN								AS SocialSecurityNumber
--		,p.DOB								AS DateOfBirth
--		,bos.Branch							AS BranchOfService
--		,ad.StartDate						AS ADStartDate
--		,ad.EndDate							AS ADEndDate
--		,cte.BenefitApprovedDeniedPending	AS BenefitApprovedDeniedPending
--		,bd.BenefitAppliedDate				AS DateBenefitsApplied
--		,bd.BenefitRemovedDate				AS DateBenefitsEnded
--		--,ct.CATEGORY_ORIGIN
--		--,CASE WHEN ct.SCRA_Code = 'auto' THEN 'Auto'
--		--	  WHEN ct.SCRA_Code = 'commercial' THEN 'Commercial Loan'
--		--	  WHEN ct.SCRA_Code = 'consumer_loan' THEN 'Consumer Loan'
--		--	  WHEN ct.SCRA_Code = 'credit_card' THEN 'Credit Card'
--		--	  WHEN ct.SCRA_Code = 'mortgage' THEN 'Mortgage'
--		--	  WHEN ct.SCRA_Code = 'safe_dep_box' THEN 'Safe Deposit Box'
--		--	  WHEN ISNULL(ct.SCRA_Code,'') = '' THEN ''
--		--	  ELSE 'Other' END
--		--									AS ProductType
--		,ct.Product_Type					AS ProductType
--		--,ct.SUB_PRODUCT_NAME				AS SubType
--		,CASE WHEN ISNULL(cnt.ProductName,'') = '' THEN ct.Product_SubType
--				ELSE cnt.ProductName END	AS SubType
--		,COALESCE(
--			CASE 
--				WHEN ISNULL(cnt.LegacyNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.LegacyNo END,
--			CASE 
--				WHEN ISNULL(cnt.CardNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.CardNo END,
--			CASE 
--				WHEN ISNULL(cnt.ContractNo,'') = '' 
--				THEN NULL 
--				ELSE cnt.ContractNo END)	AS AccountNum
--		,cnt.OpenDate						AS StartDate
--		,cnt.CloseDate						AS EndDate
--		,CASE WHEN cte.ActiveAccountEligible = 0 THEN 'No'
--			  WHEN cte.ActiveAccountEligible = 1 THEN 'Yes'
--			  ELSE NULL END					AS ActiveAccountEligible
--		,REPLACE(REPLACE(STUFF((SELECT ',' + note.Comment FROM dbo.Note note WHERE PersonID = p.ID ORDER BY note.[Timestamp] DESC FOR XML PATH('')),1,1,''),',',CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)),CHAR(34),CHAR(39)+CHAR(39)) 
--											AS Comments
--		,''									AS AdditionalComments
--		,bd.PromotionEndDate				AS [Promo Rate End Date]
--	FROM dbo.Person p 
--		outer apply(Select distinct FNumber from dbo.Customer where PersonID=p.ID and PersonID in (Select pp.ID As PersonId from Person pp 
--						where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID )))) cust
						
--		outer apply( Select distinct ID,CommunicationDate,LetterId,TaskId,PersonId,BenefitID from dbo.Communication where PersonID in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID )))) com
							
--		outer apply (Select distinct  ContactMethodID from dbo.Inquiry where COALESCE(ServicememberId,PersonInquiringId) in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID )))) r
--			LEFT JOIN dbo.ContactMethod cm 
--				ON r.ContactMethodId = cm.ID
				
--		outer apply (Select * from dbo.ActiveDuty a where a.PersonID in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID )))) ad
--			INNER JOIN dbo.BranchOfService bos 
--				ON bos.ID = ad.BranchOfServiceID
				
--		outer apply (select * from dbo.Benefit bb where bb.PersonID in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID ))
--									AND bb.ContractID IN (SELECT ID FROM dbo.[Contract] WHERE PersonID = p.ID and ID = bb.ContractID)
--									AND bb.ActiveDutyID IN (SELECT ID FROM ActiveDuty WHERE PersonID = p.ID AND ID = ad.ID) )) b
--			 LEFT JOIN dbo.BenefitDetail bd 
--				ON b.ID = bd.BenefitId
				
--		outer apply (select * from dbo.[Contract] c where b.ContractID = c.ID AND c.IsDeleted = 0 AND c.PersonID in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID ))
--							AND c.ID = b.ContractID)) cnt
--			LEFT JOIN dbo.ContractType ct 
--				ON cnt.ContractTypeId = ct.ID	
				
--		outer apply(select distinct Comment from dbo.Note where PersonID in (Select pp.ID As PersonId from Person pp 
--							where ( pp.ID = p.ID OR pp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = p.ID )))) note
		
--		LEFT JOIN CTE cte ON p.ID = cte.PersonID

--		WHERE ISNULL(bd.PromotionEndDate,'') &lt;&gt; ''
		
--ORDER BY COALESCE(cast(cte.DateOfContact as date), 
--			CASE WHEN cast(p.[Timestamp] as date) = '2019-02-15' THEN NULL ELSE cast(p.[timestamp] as date) END,
--					com.CommunicationDate)	 DESC	

;WITH CTE as (
SELECT DISTINCT b.ID,b.BenefitIntervalId,ContractID,PersonID,ActiveDutyID,PromotionEndDate,TaskID from Benefit b LEFT JOIN BenefitDetail bd ON b.ID = bd.BenefitId where bd.PromotionEndDate IS NOT NULL AND ActiveDutyID &lt;&gt; 0)

SELECT	DateOfContact as [DateOfContact],
		ServicememberID as [ServicememberID],	
		ServicememberFirstName as [ServicememberFirstName],
		ServicememberLastName as [ServicememberLastName],
		ServicememberMiddleInitial as [ServicememberMiddleInitial],
		FNumber,
		SocialSecurityNumber as [SocialSecurityNumber],
		DateOfBirth as [DateOfBirth],
		BranchOfService as [BranchOfService],
		ADStartDate as [ADStartDate],
		ADEndDate as [ADEndDate],
		Reserv as [Reserv],
		BenefitApprovedDeniedPending as [BenefitApprovedDeniedPending],
		[Status] as [Benefit Status],
		DateBenefitsApplied as [DateBenefitsApplied],
		BenefitEffectiveDate as [Benefits Effective Date],
		ExpectedRemovalDate as [Expected Removal Date],
		DateBenefitsEnded as [DateBenefitsEnded],
		ExtendDate as [Extend Date],
		ProductType as [ProductType],
		SubType	as [SubType],
		ContractNo as [Contract #],
		AccountNum as [AccountNum],
		StartDate as [StartDate],
		EndDate	 as [EndDate],
		ActiveAccountEligible as [ActiveAccountEligible],
		[Promo Rate End Date] as [Promo Rate End Date],
		Comments as [Comments],
		'' as [AdditionalComments]
FROM
(
SELECT DISTINCT 
	ISNULL(CONVERT(VARCHAR(10),COALESCE(mh.DateOfContact,i.InquiryDate),121),'')	as DateOfContact,
	p.ID																			as ServicememberID,
	p.FirstName																		as ServicememberFirstName,
	p.LastName																		as ServicememberLastName,
	p.MiddleInitial																	as ServicememberMiddleInitial,
	cust.FNumber																	as FNumber,
	CASE WHEN dbo.SSN_Format(p.SSN)	= '000-00-0000' THEN '' 
		ELSE dbo.SSN_Format(p.SSN) END												as SocialSecurityNumber,
	ISNULL(CONVERT(VARCHAR(10),p.DOB,121),'')										as DateOfBirth,
	dbo.fnServiceBranchByID(ad.BranchOfServiceID)									as BranchOfService,
	ISNULL(CONVERT(VARCHAR(10),ad.StartDate,121),'')								as ADStartDate,
	ISNULL(CASE WHEN CONVERT(varchar(10),ad.EndDate,121) = '9999-12-31' 
		AND ISNULL(ad.StartDate,'') &lt;&gt; '' THEN '' ELSE 
			CASE WHEN ISNULL(ad.StartDate,'') &lt;&gt; '' THEN 
				CONVERT(VARCHAR(10),ad.EndDate,121) ELSE '' END END,'')				as ADEndDate,
	dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)								as Reserv,
	CASE ISNULL((SELECT TOP 1 CASE WHEN ISNULL(b1.[Status],'') &lt;&gt; '' 
					THEN UPPER(SUBSTRING(b1.[Status],1,1))+
						SUBSTRING(b1.[Status],2,LEN(b1.[Status]) - 1) ELSE '' END
						FROM [Benefit] b1 
						WHERE b1.BenefitIntervalId = b.BenefitIntervalId AND 
						ISNULL(b1.[Status],'') &lt;&gt; '' 
						ORDER BY b1.[Timestamp] DESC),'')
					WHEN 'Denied' THEN 'Denied' 
					WHEN  '' THEN ''
					ELSE 'Approved' END												as BenefitApprovedDeniedPending,
	ISNULL((SELECT TOP 1 CASE WHEN ISNULL(b1.[Status],'') &lt;&gt; '' 
			THEN UPPER(SUBSTRING(b1.[Status],1,1))+
				SUBSTRING(b1.[Status],2,LEN(b1.[Status]) - 1) ELSE '' END 
						FROM [Benefit] b1 
						WHERE b1.BenefitIntervalId = b.BenefitIntervalId 
						AND ISNULL(b1.[Status],'') &lt;&gt; '' 
						ORDER BY b1.[Timestamp] DESC),'')							as [Status],
	ISNULL(CONVERT(varchar(10),bd.BenefitAppliedDate,121),'')						as DateBenefitsApplied,
	ISNULL(CONVERT(varchar(10),bd.BenefitEffectiveDate,121),'')						as BenefitEffectiveDate,
	ISNULL(CONVERT(varchar(10),bd.ExpectedRemovalDate,121),'')						as ExpectedRemovalDate,
	ISNULL(CONVERT(varchar(10),bd.BenefitRemovedDate,121),'')						as DateBenefitsEnded,
	ISNULL(CONVERT(varchar(10),bd.ExtendDate,121),'')								as ExtendDate,
	dbo.fnProductName(c.ContractTypeId)												as ProductType,
	dbo.fnProductSubName(cte.ContractID)											as SubType,
	dbo.PARTENON_Format(c.ContractNo)												as ContractNo,
	ISNULL(COALESCE(CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN NULL 
		ELSE dbo.LegacyNo_Format(c.LegacyNo) END,
			CASE WHEN ISNULL(c.CardNo,'') = '' THEN NULL 
				ELSE dbo.CardNo_Format(c.CardNo) END),'')							as AccountNum,
	ISNULL(CONVERT(varchar(10),c.OpenDate,121),'')									as StartDate,
	ISNULL(CONVERT(varchar(10),c.CloseDate,121),'')									as EndDate,
	'Yes'																			as ActiveAccountEligible,
	--[dbo].DecodeUTF8String(ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Comment],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'')) as [Comment]
	[dbo].DecodeUTF8String(ISNULL(REPLACE(REPLACE(STUFF((SELECT ',' + note.Comment FROM dbo.Note note 
		WHERE PersonID = p.ID ORDER BY note.[Timestamp] DESC 
			FOR XML PATH('')),1,1,''),',',
			CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)),CHAR(34),CHAR(39)+CHAR(39)),''))		as Comments,
	--''																				as AdditionalComments,
	cte.PromotionEndDate															as [Promo Rate End Date]
	FROM CTE cte 
		JOIN Person p ON cte.PersonID = p.ID 
			LEFT JOIN ActiveDuty ad ON cte.ActiveDutyID = ad.ID
				LEFT JOIN Task t ON cte.TaskID = t.ID
					LEFT JOIN Inquiry i on t.InquiryID = i.ID
						LEFT JOIN Customer cust ON cte.PersonID = cust.PersonID
							LEFT JOIN Benefit b ON cte.ID = b.ID
								LEFT JOIN (SELECT bb.BenefitIntervalID
											,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON cte.BenefitIntervalId = bd.BenefitIntervalId
									LEFT JOIN [Contract] c ON cte.ContractID = c.ID
										LEFT JOIN (SELECT DateOfContact,p.ID FROM Migration_History mh JOIN Servicemember sm ON mh.ServiceMemberID = sm.ServicememberID JOIN Person p On sm.PersonID = p.ID) mh ON cte.PersonID = mh.ID
	) th
	ORDER BY [Promo Rate End Date]

/*
EXEC [dbo].[spPromo_Rate_End_Report]
*/
