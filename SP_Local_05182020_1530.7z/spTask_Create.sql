CREATE PROCEDURE [dbo].[spTask_Create]
	@Title		VARCHAR(MAX), 
	@CreateDate	DATETIME, 
	@DueDate	DATETIME = NULL, 
	@TaskType	VARCHAR(255),
	@ModifiedBy INT,
	@PersonId	INT = NULL,
	@InquiryId	INT = NULL,
	@ContractId INT = NULL,
	@ID INT OUT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  	INT,
        @ErrorSource    SYSNAME,
        @ErrorState 	INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION   
	
				IF @ID = 0 BEGIN SET @ID = NULL END;
				IF @PersonId = 0 BEGIN SET @PersonId = NULL END;
				IF @InquiryId = 0 BEGIN SET @InquiryId = NULL END;
				IF @ContractId = 0 BEGIN SET @ContractId = NULL END;
				
				IF @ID IS NULL BEGIN
				
					INSERT INTO [dbo].[Task]
						   ([Title]
						   ,[CreateDate]
						   ,[DueDate]
						   ,[TaskType]
						   ,[Status]
						   ,[PersonID]
						   ,[InquiryID]
						   ,[ContractID]
						   ,[Timestamp]
						   ,[ModifiedBy])
					 VALUES
						   (@Title
						   ,@CreateDate
						   ,@DueDate
						   ,@TaskType
						   ,'in_process'
						   ,@PersonId
						   ,@InquiryId
						   ,@ContractId
						   ,GETDATE()
						   ,@ModifiedBy)
						   
					SET @ID = SCOPE_IDENTITY()
				
				END 

			COMMIT TRANSACTION
	    
	    END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END			

END
