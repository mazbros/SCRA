CREATE PROCEDURE [dbo].[spInquiry_Update]
	@ID					INT,
	@ScusaSentDate1				DATETIME = NULL,
	@ScusaSentDate2				DATETIME = NULL,
	@ScusaConfirmationDate		DATETIME = NULL,
	@ResponseText				VARCHAR(MAX),
	@ResponseDate				DATETIME = NULL,
	@Comment					VARCHAR(MAX) = NULL,
	@ResponseMethodID			INT = NULL,
	@IsCompleted				BIT,
	@IsOnActiveDuty				BIT = NULL,
	@DmdcValidationDate			DATE = NULL,
	@ModifiedBy					INT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION
	
				IF @ResponseMethodID = 0 BEGIN SET @ResponseMethodID = NULL END;
	
				INSERT INTO [hist].[Inquiry]
			           ([InquiryID]
			           ,[InquiryDate]
			           ,[AgentID]
			           ,[ContactMethodID]
			           ,[DependentTypeId]
			           ,[InquiryType]
			           ,[Description]
			           ,[ModifiedBy]
			           ,[Timestamp]
			           ,[ScusaSentDate1]
			           ,[ScusaSentDate2]
			           ,[ResponseText]
			           ,[ResponseDate]
			           ,[ResponseMethodId]
			           ,[Comment]
			           ,[IsCompleted]
			           ,[AcknowledgeDate]
			           ,[PersonInquiringId]
			           ,[ServicememberId]
			           ,[ScusaConfirmationDate]
			           ,[IdentificationMethod]
			           ,[IsOnActiveDuty]
			           ,[DMDCValidationDate])
					SELECT [ID]
						  ,[InquiryDate]
						  ,[AgentID]
						  ,[ContactMethodID]
						  ,[DependentTypeId]
						  ,[InquiryType]
						  ,[Description]
						  ,[ModifiedBy]
						  ,[Timestamp]
						  ,[ScusaSentDate1]
						  ,[ScusaSentDate2]
						  ,[ResponseText]
						  ,[ResponseDate]
						  ,[ResponseMethodId]
						  ,[Comment]
						  ,[IsCompleted]
						  ,[AcknowledgeDate]
						  ,[PersonInquiringId]
						  ,[ServicememberId]
						  ,[ScusaConfirmationDate]
						  ,[IdentificationMethod]
						  ,[IsOnActiveDuty]
						  ,[DMDCValidationDate]
					  FROM [dbo].[Inquiry]
						WHERE [ID] = @ID
					
					UPDATE [dbo].[Inquiry]
						SET  [ScusaSentDate1] = @ScusaSentDate1
							,[ScusaSentDate2] = @ScusaSentDate2
							,[ScusaConfirmationDate] = @ScusaConfirmationDate
							,[ResponseText] = @ResponseText
							,[ResponseDate] = @ResponseDate
							,[Comment] = @Comment
							,[ResponseMethodId] = @ResponseMethodID 
							,[IsCompleted] = @IsCompleted
							,[IsOnActiveDuty] = @IsOnActiveDuty
							,[DMDCValidationDate] = @DmdcValidationDate
							,[ModifiedBy] = @ModifiedBy
							,[Timestamp] = GETDATE()
			      
				WHERE [ID] = @ID
	
			COMMIT TRANSACTION
    
	    END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END			

END
