USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spWeeklyReport_Load]    Script Date: 04/17/2019 14:06:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[spWeeklyReport_Load]
	@ReportDate date
	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @Interval varchar(24)
	SET @Interval = CONVERT(varchar(10),(DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),0)),101) + ' - ' + CONVERT(varchar(10),(DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),6)),101)
	PRINT @Interval

/*	SELECT DISTINCT
	   p.[ID] as 'ServiceMemberID'
	  ,CASE p.[Origin]
			WHEN 'inquiry'			THEN 'Inquiries'
			WHEN 'benefit_request'	THEN 'Benefit intake and eligibility determination'
			WHEN 'dmdc_check'		THEN 'DMDC Validation'
			WHEN 'affiliate'		THEN 'Affiliate or Service By Other'
			ELSE ''
	   END as 'Origin'
	  /* Personal Info */
      ,p.[FirstName]
      ,p.[MiddleInitial]
      ,p.[LastName]
      ,CAST(p.[SSN] as varchar(9)) as 'SSN'
      ,CONVERT(varchar(10),CAST(p.[DOB] as DATE),101) as 'DOB'
      ,p.[Address1]
      ,p.[Address2]
      ,p.[City]
      ,p.[State]
      ,CASE WHEN LEN (p.[Zip]) = 9 THEN SUBSTRING(p.[Zip],1,5)+'-'+SUBSTRING(p.[Zip],5,4)
			WHEN LEN(p.[Zip]) = 5 THEN p.[Zip]
			ELSE p.[Zip]
	   END as 'Zip'
      ,p.[Phone]
      ,p.[Email]
      ,(SELECT Name FROM [ContactMethod] WHERE ID = p.[ContactMethodID]) as 'Contact Method'
      ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[Person] WHERE [ID] = p.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN p.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[Person] WHERE [ID] = p.[ID] ORDER BY [Timestamp]) END as 'Personal Info Created'
	  /* Customer */			
      ,p.[Timestamp] as 'Personal Info Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = p.[ModifiedBy] ) as 'Personal Info Agent'
      ,c.[FNumber] as 'Customer Number'
      ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[Customer] WHERE [ID] = c.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN c.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[Customer] WHERE [ID] = c.[ID] ORDER BY [Timestamp]) END as 'Customer Info Created'
      ,c.[Timestamp] as 'Customer Info Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = c.[ModifiedBy] ) as 'Customer Info Agent'
      /* Military Info (Active Duty) */
      ,(SELECT [Branch] FROM [dbo].[BranchOfService] WHERE [ID] = a.[BranchOfServiceID]) as 'Branch Of Service'
      ,CONVERT(varchar(10),CAST(a.StartDate as DATE),101) as 'ADSD'
      ,CONVERT(varchar(10),CAST(a.EndDate as DATE),101) as 'ADED'
      ,CONVERT(varchar(10),CAST(a.NoticeDate as DATE),101) as 'Notification Date'
      ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[ActiveDuty] WHERE [ID] = a.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN a.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[ActiveDuty] WHERE [ID] = a.[ID] ORDER BY [Timestamp]) END as 'Military Info Created'
      ,a.[Timestamp] as 'Military Info Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = a.[ModifiedBy] ) as 'Military Info Agent'
      /* Contract */
      ,con.ContractNo
      ,CONVERT(varchar(10),CAST(con.OpenDate as DATE),101) as 'Contract Open Date'
      ,CONVERT(varchar(10),CAST(con.CloseDate as DATE),101) as 'Contract Close Date'
      ,con.LegacyNo
      ,con.CardNo
      ,(SELECT 
			CASE [SCRA_Code] 
				WHEN 'consumer_loan' THEN 'Consumer Loan - ' 
				WHEN 'credit_card' THEN 'Credit Card - '
				WHEN 'commercial' THEN 'Commercial Loan - '
				WHEN 'mortgage' THEN ''
				WHEN 'auto' THEN 'AUTO - '
				WHEN 'safe_dep_box' THEN 'Safe Deposit Box - '
				ELSE ''
			END
			+ [CATEGORY_NAME] FROM [ContractType] WHERE [ID] = con.ContractTypeId) as 'Contract Type'
      ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[Contract] WHERE [ID] = con.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN con.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[Contract] WHERE [ID] = con.[ID] ORDER BY [Timestamp]) END as 'Contract Info Created'
      ,con.[Timestamp] as 'Contract Info Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = con.[ModifiedBy] ) as 'Contract Info Agent'
      /* Benefit */
      ,CONVERT(varchar(10),CAST(b.[StartDate] as DATE),101) as 'Benefit Start Date'
      ,CONVERT(varchar(10),CAST(b.[EndDate] as DATE),101) as 'Benefit End Date'
      ,b.[Status] as 'Benefit Status'
      ,b.[DenialReason] as 'Benefit Denial Reason'
       ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[Benefit] WHERE [ID] = b.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN b.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[Benefit] WHERE [ID] = con.[ID] ORDER BY [Timestamp]) END as 'Benefit Info Created'
      ,b.[Timestamp] as 'Benefit Info Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = b.[ModifiedBy] ) as 'Benefit Info Agent'
	  /* Benefit Detail */
	  ,bd.[CurrentRate]
	  ,bd.[Block41]
	  ,CAST(bd.[DmiSentDate] as DATE) as 'DMISentDate'
	  ,CAST(bd.[ConfirmationReceivedDate] as DATE) as 'ConfirmationReceivedDate'
      ,bd.[IsPromotionalOffer]
      ,CONVERT(varchar(10),CAST(bd.[PromotionEndDate] as DATE),101) as 'PromotionEndDate'
      ,bd.[IsRateCapPerformed]
      ,bd.[IsFeeWaived]
      ,bd.[FeeRefunded]
      ,CONVERT(varchar(10),CAST(bd.[FeeRefundedDate] as DATE),101) as 'FeeRefundedDate'
      ,bd.[IsStatementsPending]
      ,CONVERT(varchar(10),CAST(bd.[StatementDate] as DATE),101) as 'StatementDate'
      ,bd.[IsInterestAdjustmentCalculated]
      ,bd.[InterestRefunded]
      ,CONVERT(varchar(10),CAST(bd.[InterestRefundedDate] as DATE),101) as 'InterestRefundedDate'
      ,CONVERT(varchar(10),CAST(bd.[BenefitExpectedDate] as DATE),101) as 'BenefitExpectedDate'
      ,CONVERT(varchar(10),CAST(bd.[BenefitAppliedDate] as DATE),101) as 'BenefitAppliedDate'
      ,CONVERT(varchar(10),CAST(bd.[BenefitEffectiveDate] as DATE),101) as 'BenefitEffectiveDate'
      ,CONVERT(varchar(10),CAST(bd.[ExpectedRemovalDate] as DATE),101) as 'ExpectedRemovalDate'
      ,CONVERT(varchar(10),CAST(bd.[BenefitRemovedDate] as DATE),101) as 'BenefitRemovedDate'
      ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[BenefitDetail] WHERE [ID] = bd.[ID] ORDER BY [Timestamp]) IS NULL 
	  		THEN bd.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[BenefitDetail] WHERE [ID] = bd.[ID] ORDER BY [Timestamp]) END as 'Benefit Details Created'
      ,bd.[Timestamp] as 'Benefit Details Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = bd.[ModifiedBy] ) as 'Benefit Details Agent'
      /* Communication */
	  ,CONVERT(varchar(10),CAST(com.CommunicationDate as DATE),101) as 'Communication Date'
	  ,(SELECT Name FROM [ContactMethod] WHERE ID = com.[ContactMethodID]) as 'Communication Method'
	  ,replace(com.[ResponseText], char(13)+char(10),'|') as [ResponseText]
	  ,(SELECT [LetterLongDesc] FROM [dbo].[Letter_DATA] WHERE [ID] = com.LetterId) as 'Letter'
	  ,CASE WHEN (SELECT TOP 1 [Timestamp] FROM [hist].[Communication] WHERE [ID] = com.[ID] ORDER BY [Timestamp]) IS NULL 
			THEN com.[Timestamp] ELSE (SELECT TOP 1 [Timestamp] FROM [hist].[BenefitDetail] WHERE [ID] = bd.[ID] ORDER BY [Timestamp]) END as 'Communication Created'
      ,com.[Timestamp] as 'Communication Last Modified'
      ,(SELECT Name FROM [dbo].[Employee] WHERE [ID] = bd.[ModifiedBy] ) as 'Communication Agent'
      
  FROM [dbo].[Person] p 
		LEFT JOIN [dbo].[Customer] c ON p.[ID] = c.PersonID
		LEFT JOIN [dbo].[ActiveDuty] a ON p.[ID] = a.[PersonID]
		LEFT JOIN [dbo].[Contract] con ON p.[ID] = con.[PersonID] 
		LEFT JOIN [dbo].[Benefit] b ON p.[ID] = b.[PersonID] AND a.ID = b.ActiveDutyID AND con.[ID] = b.ContractID
		LEFT JOIN [dbo].[BenefitDetail] bd ON b.[ID] = bd.BenefitId
		LEFT JOIN [dbo].[Communication] com ON p.[ID] = com.[PersonID] OR (p.[ID] = com.[PersonID] AND b.[ID] = com.[BenefitID])

	WHERE p.[Timestamp] BETWEEN DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),0) AND DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),6)
*/	

;with CTE AS (
	SELECT DISTINCT sm.PersonID,s.DateOfContact,s.MethodOfNotification,s.DateDMDCSearchPerformed,s.VerifyBySCRAOrMilOrders
				,s.ActiveAccountEligible,s.BenefitApprovedDeniedPending,s.StatusCode,s.DateBenefitsApplied,s.DateBenefitsEnded,s.[Benefits Effective (as of) Date]
				,s.NotEligReason,s.DenialReason,s.[90DayLetterSentOn],s.BenefitsRecvd,s.Returned,s.AccountNum
	FROM [SCRA_DB_MIGRATE].[dbo].[Sample] s 
	JOIN [dbo].[Servicemember] sm ON s.ServiceMemberID = sm.ServicememberID
	) 
SELECT DISTINCT i.ID,CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) as [Date]
	  ,COALESCE(t.[Status],CASE [IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE NULL END,'qa_completed') as [Status]
      ,CASE  COALESCE(i.[InquiryType],p.[Origin])
			WHEN 'inquiry'			THEN 'Inquiries'
			WHEN 'benefit_request'	THEN 'Benefit intake and eligibility determination'
			WHEN 'dmdc_check'		THEN 'DMDC Validation'
			WHEN 'affiliate'		THEN 'Affiliate or Service By Other'
			ELSE ''
	   END as [RequestTypeOrOrigin]
      ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
      ,ISNULL(c.FNumber,'') as [FNumber]
      ,ad.ID as ADID
      ,ISNULL(ad.Branch,'') as [Branch]
      ,ISNULL(CAST(ad.IsReserve as varchar(1)),'') as [IsReserve]
      ,ISNULL(CONVERT(VARCHAR(10),ad.NoticeDate, 121),'') as NoticeDate
      ,ISNULL(CONVERT(VARCHAR(10),ad.StartDate, 121),'') as	ADStartDate	
      ,ISNULL(CONVERT(VARCHAR(10),ad.EndDate, 121),'') as ADEndDate
      ,ISNULL(con.ContractNo,'') as [ContractNo]
      ,CASE WHEN ISNULL(con.LegacyNo,'') = '' THEN ISNULL(con.CardNo,'') ELSE ISNULL(con.LegacyNo,'') END as [AccountNumber]
      ,ISNULL(COALESCE(con.ProductName,ct.SUB_PRODUCT_NAME),'') as [ProductType]
      ,ISNULL(CONVERT(VARCHAR(10),con.OpenDate, 121),'') as ProductOpenDate
      ,ISNULL(CONVERT(VARCHAR(10),con.CloseDate, 121),'') as ProductCloseDate
      ,ISNULL(COALESCE((SELECT TOP 1 CASE WHEN BenefitApprovedDeniedPending = 'Approved' THEN 'applied' ELSE NULL END FROM CTE cte2 WHERE PersonID = p.ID and cte2.AccountNum = CASE WHEN ISNULL(con.LegacyNo,'') = '' THEN ISNULL(con.CardNo,'') ELSE ISNULL(con.LegacyNo,'') END), b.[Status]),'') as [BenefitStatus]
      ,ISNULL(b.DenialReason,'') as [DenialReason]
      ,ISNULL(CONVERT(VARCHAR(10),COALESCE(b.StartDate,cast(cte.DateBenefitsApplied as date),bd.BenefitAppliedDate),121),'') as [BenefitStartDate]
      ,ISNULL(CONVERT(VARCHAR(10),CASE WHEN COALESCE(b.StartDate,cast(cte.DateBenefitsApplied as date)) < COALESCE(b.EndDate,cast(cte.DateBenefitsEnded as date),bd.BenefitRemovedDate)
			THEN COALESCE(b.EndDate,cast(cte.DateBenefitsEnded as date),bd.BenefitRemovedDate)
			ELSE NULL END,121),'') as [BenefitEndDate]
      ,ISNULL(CONVERT(VARCHAR(10),COALESCE(bd.BenefitEffectiveDate,cast(cte.[Benefits Effective (as of) Date] as date)),121),'') as [BenefitEffectiveDate]
      ,t.ID as TID
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'LogRequestDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE	
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'EnterDetailsDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'MilitaryInfoDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'ProductEligibilityDONE'
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'RespondToRequesterDONE'
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'SaveAllRecordsDONE'
	  ,CASE WHEN t.ID IS NULL THEN 'Carolyn Cafarelli' ELSE
		ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'CompletedBy'

      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestREJECTED'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'EnterDetailsREJECTED'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'MilitaryInfoREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'ProductEligibilityREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RespondToRequesterREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'SaveAllRecordsREJECTED'
	  ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RejectedBy'

      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaLogRequestDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaEnterDetailsDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaMilitaryInfoDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaProductEligibilityDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaRespondToRequesterDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaSaveAllRecordsDONE'
	  ,CASE WHEN t.ID IS NULL THEN 'Carolyn Cafarelli' ELSE
	  ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaCompletedBy'

	  ,CASE WHEN t.ID IS NULL THEN 'Yes' ELSE
			CASE WHEN (SELECT CASE WHEN 
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th )  > 0 THEN 'in_process'
					ELSE CASE WHEN
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th ) > 0 THEN 'completed'
					ELSE CASE WHEN 
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th ) > 0 THEN 'qa_completed'
					ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
					END
				END
			END) IN ('qa_completed','misdirected') THEN 'Yes' ELSE '' END 
		END as [Completed]
	  
  FROM [SCRA_DB].[dbo].[Person] p 
  LEFT JOIN [SCRA_DB].[dbo].[Inquiry] i  ON p.ID = i.ServicememberId
  LEFT JOIN [SCRA_DB].[dbo].[Task] t ON i.ID = t.InquiryID
  LEFT JOIN [SCRA_DB].[dbo].[Customer] c ON p.Id = c.PersonID
  LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [SCRA_DB].[dbo].[ActiveDuty] ad JOIN [SCRA_DB].[dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
  LEFT JOIN [SCRA_DB].[dbo].[Contract] con ON p.Id = con.PersonID and con.IsDeleted = 0
  LEFT JOIN [SCRA_DB].[dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
  LEFT JOIN [SCRA_DB].[dbo].[Benefit] b ON p.Id = b.PersonID AND con.ID = b.ContractID and ad.ID = b.ActiveDutyID
  LEFT JOIN [SCRA_DB].[dbo].[BenefitDetail] bd ON b.ID = bd.BenefitId
  LEFT JOIN CTE cte ON p.ID = cte.PersonID
  WHERE 1=1  
  AND COALESCE(i.[InquiryType],p.[Origin]) = 'benefit_request'
  AND p.ID > 103
  AND p.ID NOT IN (SELECT DISTINCT PersonInquiringId FROM [SCRA_DB].[dbo].[Inquiry] WHERE PersonInquiringId <> ServicememberId)
  
  AND (CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121)
	BETWEEN DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),0) AND DATEADD(ww,datediff(ww,0,dateadd(ww,0,@ReportDate)),6)
	OR COALESCE(t.[Status],CASE [IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE NULL END,'qa_completed') <> 'qa_completed')
	
ORDER BY CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) desc

END

/*
DECLARE @date date SET @date = GETDATE()
EXEC  [dbo].[spWeeklyReport_Load]
	@ReportDate = @date
*/


GO


