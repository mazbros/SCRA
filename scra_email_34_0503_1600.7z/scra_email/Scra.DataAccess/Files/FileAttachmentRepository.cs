﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Files;

namespace Scra.DataAccess.Files
{
    internal class FileAttachmentRepository : IFileAttachmentRepository
    {
        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        private const string LOAD_SQL = @"
            SELECT ID, FileName from dbo.[File]
            WHERE ID in (SELECT FileId FROM dbo.[DocumentLink] 
			            WHERE EntityId = {id})
            AND IsDeleted = 0;";


        private const string GET_SQL = @"
            SELECT FileName ,FileContent      
            FROM dbo.[File]
            WHERE ID = {id}";

        public FileAttachmentRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public async Task<IList<FileAttachmentSnapshot>> Load(int id, string entity)
        {
            var sql = LOAD_SQL.Replace("{id}", id.ToString());
            return await _sqlExecutor.Execute(sql, ToFileAttachmentSnapShot);
        }

        public async Task<FileAttachment> Get(int fileId)
        {
            var sql = GET_SQL.Replace("{id}", fileId.ToString());
            return await _sqlExecutor.ExecuteOne(sql, ToFileAttachment);
        }

        public async Task Delete(int fileId)
        {
            var parameters = new[]
            {
                SpParameter.Create(FileColumns.ID, fileId)
            };

            await _spExecutor.Execute("dbo.spFile_Delete", parameters);
        }

        private FileAttachment ToFileAttachment(IRowData row)
        {        
            var fileName = row.AsString(FileColumns.FILE_NAME);
            var fileContent = row.AsByteArray(FileColumns.FILE_CONTENT);
            return new FileAttachment(fileName, fileContent);
        }

        private FileAttachmentSnapshot ToFileAttachmentSnapShot(IRowData row)
        {
            var fileName = row.AsString(FileColumns.FILE_NAME);
            var fileId = row.AsInt(FileColumns.ID);
            return new FileAttachmentSnapshot(fileId, fileName);
        }

        public async Task UploadFile(int entityId, string entity, FileAttachment newFile)
        {
            var parameters = new[]
            {
                SpParameter.Create(FileColumns.ENTITY_ID, entityId),
                SpParameter.Create(FileColumns.ENTITY, entity),
                SpParameter.Create(FileColumns.FILE_NAME, newFile.FileName),
                SpParameter.Create(FileColumns.FILE_CONTENT, newFile.Content)

            };

            await _spExecutor.Execute("dbo.spFile_Save", parameters);
        }
    }
}