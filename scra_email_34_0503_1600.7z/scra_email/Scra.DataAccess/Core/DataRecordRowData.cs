﻿using System;
using System.Data;

namespace Scra.DataAccess.Core
{
    internal class DataRecordRowData : IRowData
    {
        private readonly IDataRecord _row;

        public DataRecordRowData(IDataRecord row)
        {
            _row = row;
        }

        public int AsInt(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return 0;
            }
            //return (int)ordinal;
            return Int32.Parse(ordinal.ToString());
        }

        public decimal AsDecimal(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return 0;
            }
            return (decimal)ordinal;
        }

        public string AsString(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return null;
            }
            //return (string)ordinal
            return ordinal.ToString();
        }

        public byte[] AsByteArray(string name)
        {            
            var data = (byte[])_row[name];
            return data;
        }

        public string AsString(int fieldIndex)
        {
            return (string)_row[fieldIndex];
        }

        public DateTime? AsDateTime(string name)
        {
            var ordinal = _row.GetOrdinal(name);
            if (_row.IsDBNull(ordinal))
            {
                return null;
            }
            return _row.GetDateTime(ordinal);
        }

        public DateTime AsDateTimeStrict(string name)
        {
            var ordinal = _row.GetOrdinal(name);
            if (_row.IsDBNull(ordinal))
            {
                return new DateTime();
            }
            return _row.GetDateTime(ordinal);
        }

        public bool AsBool(string name)
        {
            var ordinal = _row.GetOrdinal(name);
            if (_row.IsDBNull(ordinal))
            {
                return false;
            }
            return _row.GetBoolean(ordinal);
        }
    }
}