﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Scra.DataAccess.Configs;

namespace Scra.DataAccess.Core
{
    public  class SqlExecutor : ISqlExecutor
    {
        private readonly IDbConfig _config;

        public SqlExecutor(IDbConfig config)
        {
            _config = config;
        }

        public async Task<TResult> ExecuteOne<TResult>(string query, Func<IRowData, TResult> parser) where TResult: class
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();
                    var reader = await command.ExecuteReaderAsync();

                    if (await reader.ReadAsync())
                    {
                        var row = RowDataFactory.Create(reader);
                        return parser(row);
                    }
                    return null;
                }
            }
        }

        public async Task Execute(string query)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task ExecuteQuery(string query)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();
                    await command.ExecuteScalarAsync();
                }
            }
        }

        public async Task<IList<TResult>> Execute<TResult>(string query, Func<IRowData, TResult> parser)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();
                    var reader = await command.ExecuteReaderAsync();

                    var res = new List<TResult>();
                    while (await reader.ReadAsync())
                    {
                        var row = RowDataFactory.Create(reader);
                        var record = parser(row);
                        res.Add(record);
                    }
                    return res;
                }
            }
        }

        public async Task<DataSet> GetDataSet(string query)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();

                    var dataSet = new DataSet();
                    var dataAdapter = new SqlDataAdapter { SelectCommand = command };
                    dataAdapter.Fill(dataSet);

                    return dataSet;
                }
            }
        }

        public async Task<DataTable> GetTable(string query)
        {
            var dataSet = await GetDataSet(query);
            return dataSet.Tables[0];
        }

        public async Task<object> GetScalar(string query)
        {
            using (var connection = new SqlConnection(_config.ConnectionString))
            {
                using (var command = new SqlCommand(query, connection))
                {
                    command.CommandTimeout = 900;
                    await connection.OpenAsync();
                    return await command.ExecuteScalarAsync();
                }
            }
        }
    }
}