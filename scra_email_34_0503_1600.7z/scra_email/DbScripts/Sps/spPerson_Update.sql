USE [SCRA_DB]
GO

IF OBJECT_ID('dbo.spPerson_Update') IS NULL
    EXEC('CREATE PROCEDURE dbo.spPerson_Update AS SET NOCOUNT ON;')
GO

ALTER PROCEDURE [dbo].[spPerson_Update]
(
	@ID						INT OUTPUT,
	@FirstName				VARCHAR(255),
	@LastName				VARCHAR(255),
	@MiddleInitial				VARCHAR(255),
	@Ssn					VARCHAR(255),
	@DOB					DATE = NULL,
	
	@Address1				VARCHAR(255),
	@Address2				VARCHAR(255),
	@City					VARCHAR(255),
	@State					VARCHAR(255),	
	@Zip					VARCHAR(255),
	
	@Phone					VARCHAR(255),
	@Email					VARCHAR(255),
	@NotificationMethodID	INT,
	@EmployeeID				INT,
	
	@Search					VARCHAR(MAX)
)
AS
BEGIN
	SET NOCOUNT ON
	
	IF NOT EXISTS(SELECT [ID] FROM dbo.[Person] WHERE [ID] = @ID) BEGIN
	
		INSERT INTO [dbo].[Person]
			   ([FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[NotificationMethodID]
			   ,[EmployeeID]
			   ,[Timestamp]
			   ,[Search])
		 VALUES
			   (@FirstName
			   ,@LastName
			   ,@MiddleInitial
			   ,@Ssn
			   ,@DOB
			   ,@Address1
			   ,@Address2
			   ,@City
			   ,@State
			   ,@Zip
			   ,@Phone
			   ,@Email
			   ,@NotificationMethodID
			   ,@EmployeeID
			   ,GETDATE()
			   ,@Search)
			   
		SET @ID = SCOPE_IDENTITY()
	
	END ELSE BEGIN
		
		INSERT INTO [hist].[Person]
			   ([ID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[NotificationMethodID]
			   ,[EmployeeID]
			   ,[Timestamp])
		 SELECT [ID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[NotificationMethodID]
			   ,[EmployeeID]
			   ,[Timestamp]
			FROM [dbo].[Person]
			WHERE [ID] = @ID
		
		UPDATE [dbo].[Person]
			SET [FirstName] = @FirstName
			   ,[LastName] = @LastName
			   ,[MiddleInitial] = @MiddleInitial
			   ,[SSN] = @Ssn
			   ,[DOB] = @DOB
			   ,[Address1] = @Address1
			   ,[Address2] = @Address2
			   ,[City] = @City
			   ,[State] = @State
			   ,[Zip] = @Zip
			   ,[Phone] = @Phone
			   ,[Email] = @Email
			   ,[NotificationMethodID] = @NotificationMethodID
			   ,[EmployeeID] = @EmployeeID
			   ,[Timestamp] = GETDATE()
			   ,[Search] = @Search
			WHERE [ID] = @ID

	END
GO