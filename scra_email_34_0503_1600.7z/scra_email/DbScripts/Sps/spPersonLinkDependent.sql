USE [SCRA_DB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spPersonLinkDependent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spPersonLinkDependent]
GO


CREATE PROCEDURE [dbo].[spPersonLinkDependent] 
AS
BEGIN SET NOCOUNT ON; END
GO

ALTER PROCEDURE [dbo].[spPersonLinkDependent] 
	
	@ID int OUTPUT,
	@DependentTypeId int,
	@FromID int,
	@ToID int,
	@StartDate date,
	@EndDate date
	
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @ID IS NULL BEGIN
		
		INSERT INTO [dbo].[PersonToPersonLink]
			([DependentTypeID]
			,[FromID]
			,[ToID]
			,[StartDate]
			,[EndDate]
			,[Timestamp])
			VALUES
			(@DependentTypeId
			,@FromID
			,@ToID
			,@StartDate
			,@EndDate
			,GETDATE())
			
		SET @ID = SCOPE_IDENTITY()
		
	END ELSE BEGIN
	
		INSERT INTO [hist].[PersonToPersonLink]
			([ID]
			,[DependentTypeID]
			,[FromID]
			,[ToID]
			,[Startdate]
			,[EndDate]
			,[Timestamp])
			SELECT [ID]
				,[DependentTypeID]
				,[FromID]
				,[ToID]
				,[StartDate]
				,[EndDate]
				,[Timestamp]
			FROM [dbo].[PersonToPersonLink]
			WHERE [ID] = @ID
			
		UPDATE [dbo].[PersonToPersonLink]
			SET
				[DependentTypeId] = @DependentTypeId,
				[FromID] = @FromID,
				[ToID] = @ToID,
				[StartDate] = @StartDate,
				[EndDate] = @EndDate,
				[Timestamp] = GETDATE()
			WHERE [ID] = @ID
	
	END
	
END


GO



