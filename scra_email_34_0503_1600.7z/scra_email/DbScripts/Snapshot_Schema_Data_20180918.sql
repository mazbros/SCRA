USE [SCRA_DB]
GO
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Employee_Acive]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [DF_Employee_Acive]
END
/****** Object:  ForeignKey [FK_ActiveDuty_BranchOfService]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_BranchOfService]
GO
/****** Object:  ForeignKey [FK_ActiveDuty_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_Employee]
GO
/****** Object:  ForeignKey [FK_ActiveDuty_ServiceMember]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_ServiceMember]
GO
/****** Object:  ForeignKey [FK_Benefit_Contract]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Contract]
GO
/****** Object:  ForeignKey [FK_Benefit_Customer]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Customer]
GO
/****** Object:  ForeignKey [FK_Benefit_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Employee]
GO
/****** Object:  ForeignKey [FK_Communication_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Communication] DROP CONSTRAINT [FK_Communication_Employee]
GO
/****** Object:  ForeignKey [FK_Communication_Person]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Communication] DROP CONSTRAINT [FK_Communication_Person]
GO
/****** Object:  ForeignKey [FK_Contract_Customer]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Customer]
GO
/****** Object:  ForeignKey [FK_Contract_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Employee]
GO
/****** Object:  ForeignKey [FK_Customer_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Employee]
GO
/****** Object:  ForeignKey [FK_Customer_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Person]
GO
/****** Object:  ForeignKey [FK_FK_DMDCSearchHistory_ServiceMember]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[DMDCSearchHistory] DROP CONSTRAINT [FK_DMDCSearchHistory_ServiceMember]
GO
/****** Object:  ForeignKey [FK_EconomicConcept_Contract]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[EconomicConcept] DROP CONSTRAINT [FK_EconomicConcept_Contract]
GO
/****** Object:  ForeignKey [FK_Letter_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Letter] DROP CONSTRAINT [FK_Letter_Person]
GO
/****** Object:  ForeignKey [FK_Note_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_Employee]
GO
/****** Object:  ForeignKey [FK_Note_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_Person]
GO
/****** Object:  ForeignKey [FK_Person_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Person] DROP CONSTRAINT [FK_Person_Employee]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_DependentType]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_DependentType]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Employee]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Person_FromID]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Person_FromID]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Person_ToID]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Person_ToID]
GO
/****** Object:  ForeignKey [FK_Request_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Request] DROP CONSTRAINT [FK_Request_Employee]
GO
/****** Object:  ForeignKey [FK_Request_Person]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Request] DROP CONSTRAINT [FK_Request_Person]
GO
/****** Object:  ForeignKey [FK_ServiceMember_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_ServiceMember_Employee]
GO
/****** Object:  ForeignKey [FK_ServiceMember_Person]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_ServiceMember_Person]
GO
/****** Object:  ForeignKey [FK_Document_ServiceMember]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMemberDocument] DROP CONSTRAINT [FK_Document_ServiceMember]
GO
/****** Object:  ForeignKey [FK_ServiceMemberDocument_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMemberDocument] DROP CONSTRAINT [FK_ServiceMemberDocument_Employee]
GO
/****** Object:  Table [dbo].[Benefit]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Contract]
GO
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Customer]
GO
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Employee]
GO
DROP TABLE [dbo].[Benefit]
GO
/****** Object:  Table [dbo].[EconomicConcept]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[EconomicConcept] DROP CONSTRAINT [FK_EconomicConcept_Contract]
GO
DROP TABLE [dbo].[EconomicConcept]
GO
DROP PROCEDURE [dbo].[spEmployee_GetOrCreate]
GO
/****** Object:  StoredProcedure [dbo].[spActiveDuty_Update]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spActiveDuty_Update]
GO
/****** Object:  StoredProcedure [dbo].[spServiceMember_Get]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spServiceMember_Get]
GO
/****** Object:  StoredProcedure [dbo].[spPersonLinkDependent]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spPersonLinkDependent]
GO
/****** Object:  StoredProcedure [dbo].[spPerson_Get]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spPerson_Get]
GO
/****** Object:  Table [dbo].[DMDCSearchHistory]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[DMDCSearchHistory] DROP CONSTRAINT [FK_DMDCSearchHistory_ServiceMember]
GO
DROP TABLE [dbo].[DMDCSearchHistory]
GO
/****** Object:  Table [dbo].[ServiceMemberDocument]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMemberDocument] DROP CONSTRAINT [FK_Document_ServiceMember]
GO
ALTER TABLE [dbo].[ServiceMemberDocument] DROP CONSTRAINT [FK_ServiceMemberDocument_Employee]
GO
DROP TABLE [dbo].[ServiceMemberDocument]
GO
/****** Object:  Table [dbo].[ActiveDuty]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_BranchOfService]
GO
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_Employee]
GO
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_ActiveDuty_ServiceMember]
GO
DROP TABLE [dbo].[ActiveDuty]
GO
/****** Object:  Table [dbo].[Contract]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Customer]
GO
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Employee]
GO
DROP TABLE [dbo].[Contract]
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Employee]
GO
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_Customer_Person]
GO
DROP TABLE [dbo].[Customer]
GO
/****** Object:  Table [dbo].[Letter]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Letter] DROP CONSTRAINT [FK_Letter_Person]
GO
DROP TABLE [dbo].[Letter]
GO
/****** Object:  Table [dbo].[Note]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_Employee]
GO
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_Note_Person]
GO
DROP TABLE [dbo].[Note]
GO
/****** Object:  Table [dbo].[Communication]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Communication] DROP CONSTRAINT [FK_Communication_Employee]
GO
ALTER TABLE [dbo].[Communication] DROP CONSTRAINT [FK_Communication_Person]
GO
DROP TABLE [dbo].[Communication]
GO
/****** Object:  Table [dbo].[PersonToPersonLink]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_DependentType]
GO
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Employee]
GO
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Person_FromID]
GO
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_PersonToPersonLink_Person_ToID]
GO
DROP TABLE [dbo].[PersonToPersonLink]
GO
/****** Object:  StoredProcedure [dbo].[spPerson_List]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spPerson_List]
GO
/****** Object:  StoredProcedure [dbo].[spPerson_Update]    Script Date: 09/18/2018 16:33:31 ******/
DROP PROCEDURE [dbo].[spPerson_Update]
GO
/****** Object:  Table [dbo].[Request]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Request] DROP CONSTRAINT [FK_Request_Employee]
GO
ALTER TABLE [dbo].[Request] DROP CONSTRAINT [FK_Request_Person]
GO
DROP TABLE [dbo].[Request]
GO
/****** Object:  Table [dbo].[ServiceMember]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_ServiceMember_Employee]
GO
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_ServiceMember_Person]
GO
DROP TABLE [dbo].[ServiceMember]
GO
/****** Object:  Table [dbo].[Person]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Person] DROP CONSTRAINT [FK_Person_Employee]
GO
DROP TABLE [dbo].[Person]
GO
/****** Object:  Table [hist].[Person]    Script Date: 09/18/2018 16:33:29 ******/
DROP TABLE [hist].[Person]
GO
/****** Object:  Table [dbo].[DependentType]    Script Date: 09/18/2018 16:33:28 ******/
DROP TABLE [dbo].[DependentType]
GO
/****** Object:  Table [hist].[ActiveDuty]    Script Date: 09/18/2018 16:33:29 ******/
DROP TABLE [hist].[ActiveDuty]
GO
/****** Object:  Table [dbo].[BenefitStatus]    Script Date: 09/18/2018 16:33:27 ******/
DROP TABLE [dbo].[BenefitStatus]
GO
/****** Object:  Table [dbo].[BranchOfService]    Script Date: 09/18/2018 16:33:27 ******/
DROP TABLE [dbo].[BranchOfService]
GO
/****** Object:  Table [hist].[ServiceMember]    Script Date: 09/18/2018 16:33:30 ******/
DROP TABLE [hist].[ServiceMember]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 09/18/2018 16:33:28 ******/
DROP TABLE [dbo].[Employee]
GO
/****** Object:  Table [hist].[PersonToPersonLink]    Script Date: 09/18/2018 16:33:29 ******/
DROP TABLE [hist].[PersonToPersonLink]
GO
/****** Object:  Table [dbo].[ContactMethod]    Script Date: 09/18/2018 16:33:27 ******/
DROP TABLE [dbo].[ContactMethod]
GO
/****** Object:  Schema [hist]    Script Date: 09/18/2018 16:33:31 ******/
DROP SCHEMA [hist]
GO
/****** Object:  Schema [hist]    Script Date: 09/18/2018 16:33:31 ******/
CREATE SCHEMA [hist] AUTHORIZATION [dbo]
GO
/****** Object:  Table [dbo].[ContactMethod]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[ContactMethod](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL,
 CONSTRAINT [PK_ContactMethod] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[ContactMethod] ON
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (1, N'Phone', 1)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (2, N'Email', 2)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (3, N'Letter', 3)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (4, N'Internal', 4)
SET IDENTITY_INSERT [dbo].[ContactMethod] OFF
/****** Object:  Table [hist].[PersonToPersonLink]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [hist].[PersonToPersonLink](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID] [int] NULL,
	[DependentTypeID] [int] NULL,
	[FromID] [int] NULL,
	[ToID] [int] NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_PersoToPersonLinkHistory] PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [hist].[PersonToPersonLink] ON
INSERT [hist].[PersonToPersonLink] ([HistoryID], [ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (1, 1, 2, 21, 6, CAST(0xB63E0B00 AS Date), NULL, CAST(0x0000A95A01055A08 AS DateTime), NULL)
INSERT [hist].[PersonToPersonLink] ([HistoryID], [ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (2, 2, 2, 5, 3, CAST(0x883E0B00 AS Date), NULL, CAST(0x0000A95A0105821C AS DateTime), NULL)
INSERT [hist].[PersonToPersonLink] ([HistoryID], [ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (3, 9, 4, 5, 8, NULL, NULL, CAST(0x0000A95B00F89981 AS DateTime), NULL)
INSERT [hist].[PersonToPersonLink] ([HistoryID], [ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (4, 7, 4, 21, 8, NULL, NULL, CAST(0x0000A95A011F89D9 AS DateTime), NULL)
INSERT [hist].[PersonToPersonLink] ([HistoryID], [ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (5, 1, 2, 21, 6, CAST(0xB63E0B00 AS Date), CAST(0xC43E0B00 AS Date), CAST(0x0000A95F00A583A5 AS DateTime), NULL)
SET IDENTITY_INSERT [hist].[PersonToPersonLink] OFF
/****** Object:  Table [dbo].[Employee]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Employee](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [varchar](255) NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[Employee] ADD  CONSTRAINT [DF_Employee_Acive]  DEFAULT ((0)) FOR [Active]
/****** Object:  Table [hist].[ServiceMember]    Script Date: 09/18/2018 16:33:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [hist].[ServiceMember](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID] [int] NOT NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_HistoryServiceMember] PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [hist].[ServiceMember] ON
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (2, 5, 21, CAST(0x0000A9540105151B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (3, 5, 21, CAST(0x0000A954010547BE AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (4, 5, 21, CAST(0x0000A95401058697 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (5, 5, 21, CAST(0x0000A9540105FE52 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (6, 5, 21, CAST(0x0000A95401069C3C AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (7, 5, 21, CAST(0x0000A9540106D41A AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (8, 5, 21, CAST(0x0000A9540106FA2F AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (9, 5, 21, CAST(0x0000A9540107A60B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (10, 5, 21, CAST(0x0000A9540107F347 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (11, 5, 21, CAST(0x0000A954010857C4 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (12, 5, 21, CAST(0x0000A95401086415 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (13, 5, 21, CAST(0x0000A9540109199B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (14, 5, 21, CAST(0x0000A95401092B0B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (15, 5, 21, CAST(0x0000A95401097F0C AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (16, 5, 21, CAST(0x0000A954010AF1CE AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (17, 5, 21, CAST(0x0000A954010B335B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (18, 5, 21, CAST(0x0000A954010B5DE6 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (19, 5, 21, CAST(0x0000A954010B92A0 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (20, 5, 21, CAST(0x0000A954010BB400 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (21, 5, 21, CAST(0x0000A954010BFFE8 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (22, 5, 21, CAST(0x0000A954010C05E9 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (23, 5, 21, CAST(0x0000A954010C1052 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (24, 5, 21, CAST(0x0000A954010C1641 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (25, 5, 21, CAST(0x0000A954010C256B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (26, 5, 21, CAST(0x0000A954010C6278 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (27, 5, 21, CAST(0x0000A954010CC51B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (28, 5, 21, CAST(0x0000A954010D243E AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (29, 5, 21, CAST(0x0000A954010D9B6D AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (30, 5, 21, CAST(0x0000A954010DACDE AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (31, 5, 21, CAST(0x0000A954010DBEBE AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (32, 5, 21, CAST(0x0000A954010DD224 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (33, 5, 21, CAST(0x0000A954010DD9F3 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (34, 6, 23, CAST(0x0000A954010F7CC7 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (35, 5, 21, CAST(0x0000A954010DFFC1 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (36, 5, 21, CAST(0x0000A9540111519C AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (37, 5, 21, CAST(0x0000A95700B97A19 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (38, 5, 21, CAST(0x0000A95700BE2F90 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (39, 5, 21, CAST(0x0000A95700F79AE4 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (40, 5, 21, CAST(0x0000A95700F7B2E2 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (41, 5, 21, CAST(0x0000A95700F7EA26 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (42, 5, 21, CAST(0x0000A9570101032A AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (43, 7, 5, CAST(0x0000A95700EDCFBD AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (44, 7, 5, CAST(0x0000A95701061847 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (45, 5, 21, CAST(0x0000A95701010E86 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (46, 5, 21, CAST(0x0000A957010E7874 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (47, 5, 21, CAST(0x0000A957010E8091 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (48, 5, 21, CAST(0x0000A957010E8B43 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (49, 5, 21, CAST(0x0000A95701118823 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (50, 5, 21, CAST(0x0000A9570111984A AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (51, 5, 21, CAST(0x0000A9570111DEC9 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (52, 5, 21, CAST(0x0000A9570111E59A AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (53, 5, 21, CAST(0x0000A9570111ED13 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (54, 5, 21, CAST(0x0000A9570111F348 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (55, 5, 21, CAST(0x0000A9570111F96B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (56, 7, 5, CAST(0x0000A95701062219 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (57, 7, 5, CAST(0x0000A95701129F98 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (58, 7, 5, CAST(0x0000A95800D445B1 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (59, 7, 5, CAST(0x0000A95800D44C0E AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (60, 7, 5, CAST(0x0000A95800D44F9B AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (61, 7, 5, CAST(0x0000A95800D4521A AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (62, 7, 5, CAST(0x0000A95800D454A2 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (63, 7, 5, CAST(0x0000A95800D45753 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (64, 7, 5, CAST(0x0000A95800D45DA2 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (65, 5, 21, CAST(0x0000A95701120142 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (66, 5, 21, CAST(0x0000A95B00BEAB13 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (67, 5, 21, CAST(0x0000A95B00C14606 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (68, 5, 21, CAST(0x0000A95B00F8E80D AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (69, 10, 19, CAST(0x0000A958010695F1 AS DateTime), NULL)
INSERT [hist].[ServiceMember] ([HistoryID], [ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (70, 7, 5, CAST(0x0000A95800D46D18 AS DateTime), NULL)
SET IDENTITY_INSERT [hist].[ServiceMember] OFF
/****** Object:  Table [dbo].[BranchOfService]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[BranchOfService](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Branch] [varchar](50) NOT NULL,
 CONSTRAINT [PK_BranchOfService] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[BranchOfService] ON
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (1, N'Air Force')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (2, N'Air Force National Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (3, N'Air Force Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (4, N'Army')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (5, N'Army National Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (6, N'Army Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (7, N'Coast Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (8, N'Coast Guard Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (9, N'Marine Corps')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (10, N'Marine Corps Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (11, N'Navy')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (12, N'Navy Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (13, N'NOAA')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (14, N'Public Health Service')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (15, N'Army Cadet')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (16, N'Air National Guard')
SET IDENTITY_INSERT [dbo].[BranchOfService] OFF
/****** Object:  Table [dbo].[BenefitStatus]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BenefitStatus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Status] [varchar](255) NOT NULL,
 CONSTRAINT [PK_BenefitStatus] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[BenefitStatus] ON
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (1, N'Approved')
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (2, N'Denied')
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (3, N'Pending')
SET IDENTITY_INSERT [dbo].[BenefitStatus] OFF
/****** Object:  Table [hist].[ActiveDuty]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [hist].[ActiveDuty](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID] [int] NOT NULL,
	[ServiceMemberID] [int] NOT NULL,
	[BranchOfServiceID] [int] NOT NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[ExpectedEndDate] [date] NULL,
	[NoticeDate] [date] NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_ActiveDutyHistory] PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [hist].[ActiveDuty] ON
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (1, 6, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010B335B AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (2, 6, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010B5DE7 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (3, 6, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010B92A0 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (4, 7, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010BB400 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (5, 18, 5, 7, CAST(0xBC3E0B00 AS Date), NULL, NULL, CAST(0xC53E0B00 AS Date), CAST(0x0000A95700B97A19 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (6, 19, 5, 16, NULL, CAST(0xBB3E0B00 AS Date), CAST(0xC63E0B00 AS Date), NULL, CAST(0x0000A95700BE2F90 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (7, 6, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010C05EA AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (8, 11, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010D243E AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (9, 15, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010DD9F4 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (10, 17, 5, 4, NULL, NULL, NULL, NULL, CAST(0x0000A9540111519C AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (11, 5, 5, 4, NULL, NULL, NULL, NULL, CAST(0x0000A9540104C443 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (12, 12, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010D9B6E AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (13, 13, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010DACDE AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (14, 9, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010C1642 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (15, 10, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010CC51B AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (16, 7, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010C1052 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (17, 8, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010BFFE8 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (18, 6, 5, 14, NULL, NULL, NULL, NULL, CAST(0x0000A95700F7EA26 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (19, 14, 5, 15, NULL, NULL, NULL, NULL, CAST(0x0000A954010DBEBE AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (20, 22, 7, 1, CAST(0xB23E0B00 AS Date), CAST(0xB33E0B00 AS Date), NULL, NULL, CAST(0x0000A95701062219 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (21, 6, 5, 14, CAST(0xBE3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111F96B AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (22, 8, 5, 15, CAST(0xAA3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111F348 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (23, 8, 5, 15, CAST(0xAA3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95B00F8E80E AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (24, 34, 10, 16, CAST(0xBF3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A958010695F1 AS DateTime), NULL)
INSERT [hist].[ActiveDuty] ([HistoryID], [ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (25, 22, 7, 1, CAST(0x68370B00 AS Date), CAST(0x893E0B00 AS Date), NULL, NULL, CAST(0x0000A95701129F98 AS DateTime), NULL)
SET IDENTITY_INSERT [hist].[ActiveDuty] OFF
/****** Object:  Table [dbo].[DependentType]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DependentType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Type] [varchar](50) NULL,
 CONSTRAINT [PK_DependentType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[DependentType] ON
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (1, N'Service Member')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (2, N'Spouse')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (3, N'Dependent')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (4, N'Other')
SET IDENTITY_INSERT [dbo].[DependentType] OFF
/****** Object:  Table [hist].[Person]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [hist].[Person](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID] [int] NOT NULL,
	[FirstName] [varchar](255) NULL,
	[LastName] [varchar](255) NULL,
	[MiddleInitial] [varchar](255) NULL,
	[SSN] [varchar](255) NULL,
	[DOB] [date] NULL,
	[Address1] [varchar](255) NULL,
	[Address2] [varchar](255) NULL,
	[City] [varchar](255) NULL,
	[State] [varchar](255) NULL,
	[Zip] [varchar](255) NULL,
	[Phone] [varchar](255) NULL,
	[Email] [varchar](255) NULL,
	[ContactMethodID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_PersonHistory] PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [hist].[Person] ON
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (1, 17, N'q4', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946011A6E4A AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (2, 17, N'q4', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946011A6F89 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (3, 17, N'q4', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946011A92E5 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (4, 5, N'fasdfsdf', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946010CE72C AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (5, 5, N'Jonh', N'Kennedy', N'F', N'', NULL, N'', N'', N'', N'NJ', N'', N'', N'', 1, CAST(0x0000A949010AA353 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (6, 5, N'Jonh', N'Kennedy', N'F', N'', NULL, N'', N'', N'', N'NJ', N'', N'', N'', 1, CAST(0x0000A949010AB2EC AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (7, 19, N'Joe', N'Blow', N'V', N'', NULL, N'123 Some Str', N'', N'Elsewhere', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A94A01204323 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (8, 20, N'jk', N'hkj', N'hk', N'2', NULL, N'h', N'kjh', N'kh', N'khk', N'hkj', N'4', N'3', 1, CAST(0x0000A95100FBFD8E AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (9, 5, N'Jonh', N'Kennedy', N'F', N'', NULL, N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A94901213BBF AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (10, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700ED9C0C AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (11, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700EDF78D AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (12, 5, N'Jonh', N'Kennedy', N'F', N'123-45-6789', NULL, N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700EF3CFF AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (13, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700F032B3 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (14, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700F13D3D AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (15, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700F21F83 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (16, 5, N'Jonh', N'Kennedy', N'F', N'', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95700FFD2FA AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (17, 5, N'Jonh', N'Kennedy', N'F', N'123456789', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A9570105E6C7 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (18, 19, N'Joe', N'Brown', N'V', N'', NULL, N'123 Some Str', N'', N'Elsewhere', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A95100F0FF0F AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (19, 21, N'Ernest', N'Barns', N'', N'', CAST(0xBD3E0B00 AS Date), N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95100FC7A31 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (20, 6, N'sfd', N'sdsd', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94601125D99 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (21, 18, N'fdsfsdf', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94A00B27671 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (22, 8, N'asdasd', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460113679E AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (23, 7, N'dfdsdf', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460112ACD4 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (24, 20, N'jk', N'hkj', N'hk', N'', NULL, N'h', N'kjh', N'kh', N'khk', N'hkj', N'', N'', 1, CAST(0x0000A95100FC1DD0 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (25, 23, N'gdfgdfg', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A954010F494D AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (26, 2, N'q1', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94600F021A3 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (27, 10, N'q1', N'a1', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94601187AA1 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (28, 12, N'q2', N'w2', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94601197D68 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (29, 16, N'q3', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460119F53B AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (30, 15, N'q3', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460119F221 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (31, 14, N'q3', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460119F009 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (32, 13, N'q3', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460119ED4C AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (33, 17, N'q4', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94900CD3858 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (34, 4, N'qwq', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946010C44EF AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (35, 1, N'', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A94600E912E8 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (36, 3, N'qwq', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946010C30DB AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (37, 9, N'sadfasdf', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A9460113DECA AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (38, 22, N'sdfsdf', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A954010F36AA AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (39, 11, N'sdfsdfd', N'', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A946011928E8 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (40, 20, N'Justin', N'Wood', N'hk', N'', NULL, N'h', N'kjh', N'kh', N'khk', N'hkj', N'', N'', 1, CAST(0x0000A95800CEA7BA AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (41, 5, N'Jonh', N'Kennedy', N'F', N'123-45-6789', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A9570105F7D5 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (42, 14, N'Clarence', N'Kelly', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF40C4 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (43, 2, N'Brian', N'Cox', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CEDE00 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (44, 2, N'Brian', N'Cox', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95900B3A435 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (45, 5, N'Jonh', N'Kennedy', N'F', N'123-45-6789', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95800D404D4 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (46, 5, N'Jonh', N'Kennedy', N'F', N'123-45-6789', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95900F2354B AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (47, 4, N'Christine ', N'Baker', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF6DE6 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (48, 14, N'Clarence', N'Kelly', N'', N'324234', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95801073C76 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (49, 21, N'Ernest', N'Barns', N'', N'', CAST(0xBD3E0B00 AS Date), N'', N'', N'Parsippany', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A957012E8477 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (50, 1, N'Nancy', N'Lewis', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF810E AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (51, 3, N'Michelle', N'White', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF94FA AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (52, 19, N'Joe', N'Brown', N'V', N'012-34-5678', CAST(0x0FF80A00 AS Date), N'123 Some Str', N'', N'Elsewhere', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A95701155768 AS DateTime), NULL)
INSERT [hist].[Person] ([HistoryID], [ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [ModifiedBy]) VALUES (53, 20, N'Justin', N'Wood', N'hk', N'', NULL, N'h', N'kjh', N'kh', N'MA', N'hkj', N'', N'', 1, CAST(0x0000A95800D2CFDC AS DateTime), NULL)
SET IDENTITY_INSERT [hist].[Person] OFF
/****** Object:  Table [dbo].[Person]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Person](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](255) NULL,
	[LastName] [varchar](255) NULL,
	[MiddleInitial] [varchar](255) NULL,
	[SSN] [varchar](255) NULL,
	[DOB] [date] NULL,
	[Address1] [varchar](255) NULL,
	[Address2] [varchar](255) NULL,
	[City] [varchar](255) NULL,
	[State] [varchar](255) NULL,
	[Zip] [varchar](255) NULL,
	[Phone] [varchar](255) NULL,
	[Email] [varchar](255) NULL,
	[ContactMethodID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[Search] [varchar](max) NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [FK_Person_Employee] ON [dbo].[Person] 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Person] ON
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (1, N'Nancy', N'Lewis', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95900F72D87 AS DateTime), N'Nancy Lewis||', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (2, N'Brian', N'Cox', N'', N'', NULL, N'127 North Rd', N'220', N'Cranford', N'NJ', N'07895', N'', N'', 1, CAST(0x0000A95900B6F1F8 AS DateTime), N'Brian Cox|127 North Rd, 220, Cranford, NJ, 07895|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (3, N'Michelle', N'White', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95900F74FEE AS DateTime), N'Michelle White||', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (4, N'Christine ', N'Baker', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95900F2F493 AS DateTime), N'Christine  Baker||', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (5, N'John', N'Kennedy', N'F', N'123-45-6789', CAST(0x570B0B00 AS Date), N'209 Comly Rd', N'H11', N'Lincoln Park', N'NJ', N'07035', N'', N'', 1, CAST(0x0000A95900F29E6C AS DateTime), N'John F Kennedy|209 Comly Rd, H11, Lincoln Park, NJ, 07035|9/12/1982', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (6, N'Johnny', N'Henderson', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CE5C59 AS DateTime), N'Johnny Henderson|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (7, N'Sharon', N'Butler', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CE9762 AS DateTime), N'Sharon Butler|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (8, N'Margaret', N'Griffin', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CE8696 AS DateTime), N'Margaret Griffin|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (9, N'Karen ', N'Miller', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CFAE4A AS DateTime), N'Karen  Miller|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (10, N'Paula', N'Morris', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CEFAE7 AS DateTime), N'Paula Morris|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (11, N'Jose ', N'Rivera', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CFCD59 AS DateTime), N'Jose  Rivera|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (12, N'Joe', N'Hill', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF0ED3 AS DateTime), N'Joe Hill|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (13, N'Patrick', N'Russell', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF4F76 AS DateTime), N'Patrick Russell|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (14, N'Clarence', N'Kelly', N'', N'324234', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95900F2FE85 AS DateTime), N'Clarence Kelly||', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (15, N'Mark', N'Roberts', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF2E26 AS DateTime), N'Mark Roberts|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (16, N'George', N'Powell', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF1F24 AS DateTime), N'George Powell|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (17, N'Frances ', N'Howard', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CF5F0B AS DateTime), N'Frances  Howard|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (18, N'Phyllis', N'King', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CE723B AS DateTime), N'Phyllis King|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (19, N'Joe', N'Brown', N'V', N'012-34-5678', CAST(0x0FF80A00 AS Date), N'123 Some Str', N'', N'Elsewhere', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A95900F77FAE AS DateTime), N'Joe V Brown|123 Some Str, , Elsewhere, NJ, 07054|3/8/1969', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (20, N'Justin', N'Wood', N'hk', N'', NULL, N'h', N'kjh', N'kh', N'MA', N'hkj', N'', N'', 1, CAST(0x0000A95900F7B75E AS DateTime), N'Justin hk Wood|h, kjh, kh, MA, hkj|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (21, N'Ernest', N'Barns', N'', N'', CAST(0xBD3E0B00 AS Date), N'', N'', N'Parsippany', N'NJ', N'07054', N'', N'', 1, CAST(0x0000A95900F30873 AS DateTime), N'Ernest Barns|Parsippany, NJ, 07054|9/21/2018', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (22, N'Jack ', N'Young', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CFBD40 AS DateTime), N'Jack  Young|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (23, N'Lawrence', N'Adams', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95800CEBA8F AS DateTime), N'Lawrence Adams|', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (24, N'7', N'8', N'', N'', NULL, N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95F00CE6E60 AS DateTime), N'7 8|||', NULL)
INSERT [dbo].[Person] ([ID], [FirstName], [LastName], [MiddleInitial], [SSN], [DOB], [Address1], [Address2], [City], [State], [Zip], [Phone], [Email], [ContactMethodID], [Timestamp], [Search], [ModifiedBy]) VALUES (25, N'Igor', N'Ofenbakh', N'', N'', CAST(0x78000B00 AS Date), N'', N'', N'', N'', N'', N'', N'', 1, CAST(0x0000A95F00CEA594 AS DateTime), N'Igor Ofenbakh||1/29/75|01/29/1975', NULL)
SET IDENTITY_INSERT [dbo].[Person] OFF
/****** Object:  Table [dbo].[ServiceMember]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServiceMember](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_ServiceMember] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[ServiceMember] ON
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (5, 21, CAST(0x0000A95B00FF8CAA AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (6, 23, CAST(0x0000A954010F8DA2 AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (7, 5, CAST(0x0000A95F00DA1340 AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (8, 18, CAST(0x0000A95800C1DE9A AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (9, 14, CAST(0x0000A95800E4734F AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (10, 19, CAST(0x0000A95F00D2C92B AS DateTime), NULL)
INSERT [dbo].[ServiceMember] ([ID], [PersonID], [Timestamp], [ModifiedBy]) VALUES (11, 22, CAST(0x0000A958010703DB AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[ServiceMember] OFF
/****** Object:  Table [dbo].[Request]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Request](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Request] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[spPerson_Update]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spPerson_Update]
(
	@ID						INT OUTPUT,
	@FirstName				VARCHAR(255),
	@LastName				VARCHAR(255),
	@MiddleInitial			VARCHAR(255),
	@Ssn					VARCHAR(255),
	@DOB					DATE = NULL,
	
	@Address1				VARCHAR(255),
	@Address2				VARCHAR(255),
	@City					VARCHAR(255),
	@State					VARCHAR(255),	
	@Zip					VARCHAR(255),
	
	@Phone					VARCHAR(255),
	@Email					VARCHAR(255),
	@ContactMethodID		INT,
	@ModifiedBy				INT,
	
	@Search					VARCHAR(MAX)
)
AS
BEGIN
	SET NOCOUNT ON
	
	IF NOT EXISTS(SELECT [ID] FROM dbo.[Person] WHERE [ID] = @ID) BEGIN
	
		INSERT INTO [dbo].[Person]
			   ([FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[ContactMethodID]
			   ,[Timestamp]
			   ,[Search]
			   ,[ModifiedBy])
		 VALUES
			   (@FirstName
			   ,@LastName
			   ,@MiddleInitial
			   ,@Ssn
			   ,@DOB
			   ,@Address1
			   ,@Address2
			   ,@City
			   ,@State
			   ,@Zip
			   ,@Phone
			   ,@Email
			   ,@ContactMethodID
			   ,GETDATE()
			   ,@Search
			   ,@ModifiedBy)
			   
		SET @ID = SCOPE_IDENTITY()
	
	END ELSE BEGIN
		
		INSERT INTO [hist].[Person]
			   ([ID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[ContactMethodID]
			   ,[Timestamp]
			   ,[ModifiedBy])
		 SELECT [ID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleInitial]
			   ,[SSN]
			   ,[DOB]
			   ,[Address1]
			   ,[Address2]
			   ,[City]
			   ,[State]
			   ,[Zip]
			   ,[Phone]
			   ,[Email]
			   ,[ContactMethodID]
			   ,[Timestamp]
			   ,[ModifiedBy]
			FROM [dbo].[Person]
			WHERE [ID] = @ID
		
		UPDATE [dbo].[Person]
			SET [FirstName] = @FirstName
			   ,[LastName] = @LastName
			   ,[MiddleInitial] = @MiddleInitial
			   ,[SSN] = @Ssn
			   ,[DOB] = @DOB
			   ,[Address1] = @Address1
			   ,[Address2] = @Address2
			   ,[City] = @City
			   ,[State] = @State
			   ,[Zip] = @Zip
			   ,[Phone] = @Phone
			   ,[Email] = @Email
			   ,[ContactMethodID] = @ContactMethodID
			   ,[Timestamp] = GETDATE()
			   ,[Search] = @Search
			   ,[ModifiedBy] = @ModifiedBy
			WHERE [ID] = @ID

	END
	
	--SELECT @ID
	
END
GO
/****** Object:  StoredProcedure [dbo].[spPerson_List]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spPerson_List]
	@Search VARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	IF @Search IS NULL BEGIN
		SET @Search = ISNULL(@Search,'')
	END ELSE BEGIN
		SET @Search = @Search
	END

	SELECT TOP 50 [ID]
      ,[FirstName]
      ,[LastName]
      ,[MiddleInitial]
      ,[SSN]
      ,[DOB]
      ,[Address1]
      ,[Address2]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Phone]
      ,[Email]
      ,[ContactMethodID]
      ,[Timestamp]
      ,[ModifiedBy]
  FROM [dbo].[Person]
  WHERE /*[FirstName] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[LastName] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[SSN] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[DOB] LIKE '%'+RTRIM(LTRIM(@Search))+'%'*/
		[Search] LIKE '%'+RTRIM(LTRIM(@Search))+'%'
  ORDER BY [LastName], [FirstName]	
    
END
GO
/****** Object:  StoredProcedure [dbo].[spEmployee_GetOrCreate]    Script Date: 09/18/2018 17:30:45 ******/
CREATE PROCEDURE [dbo].[spEmployee_GetOrCreate] 
	@UserName varchar(50)
AS
BEGIN
	SET NOCOUNT ON;

	IF NOT EXISTS(SELECT * FROM [dbo].[Employee] WHERE [UserName] = @UserName) BEGIN
		
		INSERT INTO [dbo].[Employee] ([UserName]) VALUES (@UserName)
		
	END
	
	SELECT [ID],[UserName],[Active] FROM [dbo].[Employee] WHERE [UserName] = @UserName

END

GO
/****** Object:  Table [dbo].[PersonToPersonLink]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PersonToPersonLink](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DependentTypeID] [int] NOT NULL,
	[FromID] [int] NOT NULL,
	[ToID] [int] NOT NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[Timestamp] [datetime] NOT NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_ServiceMemberToCustomerLink] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UC_PersonToPersonLink] UNIQUE NONCLUSTERED 
(
	[FromID] ASC,
	[ToID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[PersonToPersonLink] ON
INSERT [dbo].[PersonToPersonLink] ([ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (1, 3, 21, 6, CAST(0x582D0B00 AS Date), CAST(0xC43E0B00 AS Date), CAST(0x0000A95F00B31076 AS DateTime), NULL)
INSERT [dbo].[PersonToPersonLink] ([ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (2, 4, 5, 3, CAST(0xDA240B00 AS Date), NULL, CAST(0x0000A95F00B15EFA AS DateTime), NULL)
INSERT [dbo].[PersonToPersonLink] ([ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (7, 2, 21, 8, CAST(0x3F230B00 AS Date), NULL, CAST(0x0000A95F00B2E766 AS DateTime), NULL)
INSERT [dbo].[PersonToPersonLink] ([ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (8, 4, 14, 2, NULL, NULL, CAST(0x0000A95A012202CB AS DateTime), NULL)
INSERT [dbo].[PersonToPersonLink] ([ID], [DependentTypeID], [FromID], [ToID], [StartDate], [EndDate], [Timestamp], [ModifiedBy]) VALUES (9, 2, 5, 8, CAST(0x28320B00 AS Date), NULL, CAST(0x0000A95F00B18CAA AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[PersonToPersonLink] OFF
/****** Object:  Table [dbo].[Communication]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Communication](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Communication] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Note]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Note](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PersonID] [int] NOT NULL,
	[Comment] [nvarchar](max) NOT NULL,
	[Timestamp] [datetime] NOT NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Note] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Letter]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Letter](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Template] [varchar](255) NOT NULL,
	[PersonID] [int] NOT NULL,
 CONSTRAINT [PK_Letter] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Customer](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FNumber] [varchar](10) NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Contract]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Contract](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Contract] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ActiveDuty]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ActiveDuty](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ServiceMemberID] [int] NOT NULL,
	[BranchOfServiceID] [int] NOT NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	[ExpectedEndDate] [date] NULL,
	[NoticeDate] [date] NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_ActiveDuty] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[ActiveDuty] ON
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (5, 5, 4, CAST(0xC13E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A957010E8091 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (6, 5, 10, CAST(0xBE3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95B00BEAB16 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (7, 5, 15, CAST(0xBE3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111ED13 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (8, 5, 15, CAST(0xAA3E0B00 AS Date), CAST(0xC63E0B00 AS Date), NULL, NULL, CAST(0x0000A95B00FF8CAA AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (9, 5, 15, CAST(0xBF3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111DEC9 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (10, 5, 15, CAST(0xB83E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111E59B AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (11, 5, 15, CAST(0xB63E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570101032A AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (12, 5, 15, CAST(0xAD3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95701118823 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (13, 5, 14, CAST(0xB63E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A9570111984B AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (14, 5, 15, CAST(0xBB3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95701120142 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (15, 5, 15, CAST(0xC23E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95701010E86 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (16, 6, 6, NULL, NULL, NULL, NULL, CAST(0x0000A954010F7CC7 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (17, 5, 4, CAST(0xB83E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A957010E7874 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (18, 5, 7, CAST(0xBC3E0B00 AS Date), CAST(0xC43E0B00 AS Date), NULL, CAST(0xC53E0B00 AS Date), CAST(0x0000A95700F79AE5 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (19, 5, 16, CAST(0xB43E0B00 AS Date), CAST(0xBB3E0B00 AS Date), CAST(0xC63E0B00 AS Date), NULL, CAST(0x0000A95700F7B2E3 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (20, 7, 7, CAST(0x8A3E0B00 AS Date), CAST(0x64410B00 AS Date), NULL, NULL, CAST(0x0000A95700EDCFBD AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (22, 7, 1, CAST(0x68370B00 AS Date), CAST(0x8A3E0B00 AS Date), NULL, NULL, CAST(0x0000A95F00DA1340 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (24, 8, 5, CAST(0xB53E0B00 AS Date), CAST(0xC53E0B00 AS Date), NULL, NULL, CAST(0x0000A95800C1DE9B AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (32, 7, 11, CAST(0x3A310B00 AS Date), CAST(0x4A370B00 AS Date), NULL, NULL, CAST(0x0000A95800D46D18 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (33, 9, 4, CAST(0xB63E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95800E47350 AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (34, 10, 16, CAST(0xBF3E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95F00D2C92F AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (35, 11, 4, CAST(0xB73E0B00 AS Date), NULL, NULL, CAST(0xB83E0B00 AS Date), CAST(0x0000A958010703DB AS DateTime), NULL)
INSERT [dbo].[ActiveDuty] ([ID], [ServiceMemberID], [BranchOfServiceID], [StartDate], [EndDate], [ExpectedEndDate], [NoticeDate], [Timestamp], [ModifiedBy]) VALUES (36, 5, 5, CAST(0xB73E0B00 AS Date), NULL, NULL, NULL, CAST(0x0000A95B00C14607 AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[ActiveDuty] OFF
/****** Object:  Table [dbo].[ServiceMemberDocument]    Script Date: 09/18/2018 16:33:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServiceMemberDocument](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ServiceMemberID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_ServiceMemberDocument] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DMDCSearchHistory]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DMDCSearchHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ServiceMemberID] [int] NOT NULL,
	[SearchDate] [date] NOT NULL,
 CONSTRAINT [PK_DMDCSearchHistory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[spPerson_Get]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spPerson_Get]
	@ID int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT [ID]
      ,[FirstName]
      ,[LastName]
      ,[MiddleInitial]
      ,[SSN]
      ,[DOB]--CAST(convert(varchar(10),[DOB],101) as datetime) AS 'DOB'
      ,[Address1]
      ,[Address2]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Phone]
      ,[Email]
      ,[ContactMethodID]
      ,[Timestamp]
  FROM [dbo].[Person]
  WHERE [ID] = @ID
  
  SELECT 
		 [ID]
		 ,CASE WHEN [FromID] = @ID THEN [ToID]
			  WHEN [ToID] = @ID THEN [FromID]
			  ELSE @ID
		 END as [PersonID]
		 ,[DependentTypeID]
		 ,[StartDate]
		 ,[EndDate]
	FROM [dbo].[PersonToPersonLink]
	  WHERE [FromID] = @ID OR [ToID] = @ID
    
END
GO
/****** Object:  StoredProcedure [dbo].[spPersonLinkDependent]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spPersonLinkDependent] 
	
	@ID int OUTPUT,
	@DependentTypeId int,
	@FromID int,
	@ToID int,
	@StartDate date = NULL,
	@EndDate date = NULL,
	@ModifiedBy INT
	
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @ID = 0
		SET @ID = NULL;
	
	IF @ID IS NULL BEGIN
		
		INSERT INTO [dbo].[PersonToPersonLink]
			([DependentTypeID]
			,[FromID]
			,[ToID]
			,[StartDate]
			,[EndDate]
			,[Timestamp]
			,[ModifiedBy])
			VALUES
			(@DependentTypeId
			,@FromID
			,@ToID
			,@StartDate
			,@EndDate
			,GETDATE()
			,@ModifiedBy)
			
		SET @ID = SCOPE_IDENTITY()
		
		
		
	END ELSE BEGIN
	
		INSERT INTO [hist].[PersonToPersonLink]
			([ID]
			,[DependentTypeID]
			,[FromID]
			,[ToID]
			,[Startdate]
			,[EndDate]
			,[Timestamp]
			,[ModifiedBy])
			SELECT [ID]
				,[DependentTypeID]
				,[FromID]
				,[ToID]
				,[StartDate]
				,[EndDate]
				,[Timestamp]
				,[ModifiedBy]
			FROM [dbo].[PersonToPersonLink]
			WHERE [ID] = @ID
			
		UPDATE [dbo].[PersonToPersonLink]
			SET
				[DependentTypeId] = @DependentTypeId,
				[FromID] = @FromID,
				[ToID] = @ToID,
				[StartDate] = @StartDate,
				[EndDate] = @EndDate,
				[Timestamp] = GETDATE(),
				[ModifiedBy] = @ModifiedBy
			WHERE [ID] = @ID
	
	END
	
END
GO
/****** Object:  StoredProcedure [dbo].[spServiceMember_Get]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spServiceMember_Get]
	@PersonID INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	SELECT FirstName,MiddleInitial,LastName FROM dbo.Person WHERE ID = @PersonID
	
	SELECT ID,StartDate,EndDate,ExpectedEndDate,NoticeDate,BranchOfServiceID FROM dbo.ActiveDuty 
		WHERE ServiceMemberID = (SELECT ID FROM dbo.ServiceMember WHERE PersonID = @PersonID)
		ORDER BY StartDate DESC
    
END
GO
/****** Object:  StoredProcedure [dbo].[spActiveDuty_Update]    Script Date: 09/18/2018 16:33:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spActiveDuty_Update]
(	
	@BranchOfServiceID		INT,
	@PersonID				INT,
	@StartDate				DATE = NULL,
	@EndDate				DATE = NULL,
	@ExpectedEndDate		DATE = NULL,
	@NoticeDate				DATE = NULL,
	@ActiveDutyID			INT OUTPUT,
	@ModifiedBy				INT
)
AS
BEGIN
	SET NOCOUNT ON

	IF @ActiveDutyID = 0
		SET @ActiveDutyID = NULL
	
	DECLARE @ID INT
	SET @ID = (SELECT [ID] FROM [dbo].[ServiceMember] WHERE [PersonID] = @PersonID)
	
	PRINT @ID
	
	IF @ID IS NULL BEGIN
	
		INSERT INTO [dbo].[ServiceMember]
           ( [PersonID]
            ,[Timestamp]
            ,[ModifiedBy])
		VALUES
           ( @PersonID
            ,GETDATE()
            ,@ModifiedBy)
		
		SET @ID = SCOPE_IDENTITY()
			   
		INSERT INTO [dbo].[ActiveDuty]
			(
				 [ServiceMemberID]
				,[BranchOfServiceID]
				,[StartDate]
				,[EndDate]
				,[ExpectedEndDate]
				,[NoticeDate]
				,[Timestamp]
				,[ModifiedBy])
			VALUES
				(@ID
				,@BranchOfServiceID
				,@StartDate
				,@EndDate
				,@ExpectedEndDate
				,@NoticeDate
				,GETDATE()
				,@ModifiedBy)
				
		
			SET @ActiveDutyID = SCOPE_IDENTITY()
			
	END ELSE BEGIN
		
		INSERT INTO [hist].[ServiceMember]
           ( [ID]
			,[PersonID]
            ,[Timestamp]
            ,[ModifiedBy])
		SELECT [ID]
			  ,[PersonID]
			  ,[Timestamp]
			  ,[ModifiedBy]
		  FROM [dbo].[ServiceMember]
		WHERE [PersonID] = @PersonID
		
		UPDATE [dbo].[ServiceMember]
			SET [PersonID] = @PersonID
			   ,[Timestamp] = GETDATE()
			   ,[ModifiedBy] = @ModifiedBy
	 		WHERE [ID] = @ID

		IF @ActiveDutyID IS NOT NULL BEGIN
			 		
		   INSERT INTO [hist].[ActiveDuty]
			   ([ID]
			   ,[ServiceMemberID]
			   ,[BranchOfServiceID]
			   ,[StartDate]
			   ,[EndDate]
			   ,[ExpectedEndDate]
			   ,[NoticeDate]
			   ,[Timestamp]
			   ,[ModifiedBy])
				SELECT [ID]
				  ,[ServiceMemberID]
				  ,[BranchOfServiceID]
				  ,[StartDate]
				  ,[EndDate]
				  ,[ExpectedEndDate]
				  ,[NoticeDate]
				  ,[Timestamp]
				  ,[ModifiedBy]
			  FROM [dbo].[ActiveDuty]
			WHERE [ID] = @ActiveDutyID
			
			UPDATE [dbo].[ActiveDuty]
			   SET [ServiceMemberID] = @ID
				  ,[BranchOfServiceID] = @BranchOfServiceID
				  ,[StartDate] = @StartDate
				  ,[EndDate] = @EndDate
				  ,[ExpectedEndDate] = @ExpectedEndDate
				  ,[NoticeDate] = @NoticeDate
				  ,[Timestamp] = GETDATE()
				  ,[ModifiedBy] = @ModifiedBy
			WHERE [ID] = @ActiveDutyID
			
		END ELSE BEGIN	
			
			INSERT INTO [dbo].[ActiveDuty]
				(
					 [ServiceMemberID]
					,[BranchOfServiceID]
					,[StartDate]
					,[EndDate]
					,[ExpectedEndDate]
					,[NoticeDate]
					,[Timestamp]
					,[ModifiedBy])
				VALUES
					(@ID
					,@BranchOfServiceID
					,@StartDate
					,@EndDate
					,@ExpectedEndDate
					,@NoticeDate
					,GETDATE()
					,@ModifiedBy)
					
				SET @ActiveDutyID = SCOPE_IDENTITY()
				
		END
	END

END
GO
/****** Object:  Table [dbo].[EconomicConcept]    Script Date: 09/18/2018 16:33:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EconomicConcept](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ContractID] [int] NOT NULL,
 CONSTRAINT [PK_EconomicConcept] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Benefit]    Script Date: 09/18/2018 16:33:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Benefit](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[ContractID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
 CONSTRAINT [PK_Benefit] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_ActiveDuty_BranchOfService]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty]  WITH CHECK ADD  CONSTRAINT [FK_ActiveDuty_BranchOfService] FOREIGN KEY([BranchOfServiceID])
REFERENCES [dbo].[BranchOfService] ([ID])
GO
ALTER TABLE [dbo].[ActiveDuty] CHECK CONSTRAINT [FK_ActiveDuty_BranchOfService]
GO
/****** Object:  ForeignKey [FK_ActiveDuty_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty]  WITH CHECK ADD  CONSTRAINT [FK_ActiveDuty_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[ActiveDuty] CHECK CONSTRAINT [FK_ActiveDuty_Employee]
GO
/****** Object:  ForeignKey [FK_ActiveDuty_ServiceMember]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[ActiveDuty]  WITH CHECK ADD  CONSTRAINT [FK_ActiveDuty_ServiceMember] FOREIGN KEY([ServiceMemberID])
REFERENCES [dbo].[ServiceMember] ([ID])
GO
ALTER TABLE [dbo].[ActiveDuty] CHECK CONSTRAINT [FK_ActiveDuty_ServiceMember]
GO
/****** Object:  ForeignKey [FK_Benefit_Contract]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit]  WITH CHECK ADD  CONSTRAINT [FK_Benefit_Contract] FOREIGN KEY([ContractID])
REFERENCES [dbo].[Contract] ([ID])
GO
ALTER TABLE [dbo].[Benefit] CHECK CONSTRAINT [FK_Benefit_Contract]
GO
/****** Object:  ForeignKey [FK_Benefit_Customer]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit]  WITH CHECK ADD  CONSTRAINT [FK_Benefit_Customer] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customer] ([ID])
GO
ALTER TABLE [dbo].[Benefit] CHECK CONSTRAINT [FK_Benefit_Customer]
GO
/****** Object:  ForeignKey [FK_Benefit_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Benefit]  WITH CHECK ADD  CONSTRAINT [FK_Benefit_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Benefit] CHECK CONSTRAINT [FK_Benefit_Employee]
GO
/****** Object:  ForeignKey [FK_Communication_Employee]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Communication]  WITH CHECK ADD  CONSTRAINT [FK_Communication_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Communication] CHECK CONSTRAINT [FK_Communication_Employee]
GO
/****** Object:  ForeignKey [FK_Communication_Person]    Script Date: 09/18/2018 16:33:27 ******/
ALTER TABLE [dbo].[Communication]  WITH CHECK ADD  CONSTRAINT [FK_Communication_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Communication] CHECK CONSTRAINT [FK_Communication_Person]
GO
/****** Object:  ForeignKey [FK_Contract_Customer]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Contract]  WITH CHECK ADD  CONSTRAINT [FK_Contract_Customer] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customer] ([ID])
GO
ALTER TABLE [dbo].[Contract] CHECK CONSTRAINT [FK_Contract_Customer]
GO
/****** Object:  ForeignKey [FK_Contract_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Contract]  WITH CHECK ADD  CONSTRAINT [FK_Contract_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Contract] CHECK CONSTRAINT [FK_Contract_Employee]
GO
/****** Object:  ForeignKey [FK_Customer_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_Employee]
GO
/****** Object:  ForeignKey [FK_Customer_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_Person]
GO
/****** Object:  ForeignKey [FK_DMDCSearchHistory_ServiceMember]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[DMDCSearchHistory]  WITH CHECK ADD  CONSTRAINT [FK_DMDCSearchHistory_ServiceMember] FOREIGN KEY([ServiceMemberID])
REFERENCES [dbo].[ServiceMember] ([ID])
GO
ALTER TABLE [dbo].[DMDCSearchHistory] CHECK CONSTRAINT [FK_DMDCSearchHistory_ServiceMember]
GO
/****** Object:  ForeignKey [FK_EconomicConcept_Contract]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[EconomicConcept]  WITH CHECK ADD  CONSTRAINT [FK_EconomicConcept_Contract] FOREIGN KEY([ContractID])
REFERENCES [dbo].[Contract] ([ID])
GO
ALTER TABLE [dbo].[EconomicConcept] CHECK CONSTRAINT [FK_EconomicConcept_Contract]
GO
/****** Object:  ForeignKey [FK_Letter_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Letter]  WITH CHECK ADD  CONSTRAINT [FK_Letter_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Letter] CHECK CONSTRAINT [FK_Letter_Person]
GO
/****** Object:  ForeignKey [FK_Note_Employee]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Note]  WITH CHECK ADD  CONSTRAINT [FK_Note_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Note] CHECK CONSTRAINT [FK_Note_Employee]
GO
/****** Object:  ForeignKey [FK_Note_Person]    Script Date: 09/18/2018 16:33:28 ******/
ALTER TABLE [dbo].[Note]  WITH CHECK ADD  CONSTRAINT [FK_Note_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Note] CHECK CONSTRAINT [FK_Note_Person]
GO
/****** Object:  ForeignKey [FK_Person_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Person]  WITH CHECK ADD  CONSTRAINT [FK_Person_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Person] CHECK CONSTRAINT [FK_Person_Employee]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_DependentType]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_PersonToPersonLink_DependentType] FOREIGN KEY([DependentTypeID])
REFERENCES [dbo].[DependentType] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_PersonToPersonLink_DependentType]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_PersonToPersonLink_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_PersonToPersonLink_Employee]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Person_FromID]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_PersonToPersonLink_Person_FromID] FOREIGN KEY([FromID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_PersonToPersonLink_Person_FromID]
GO
/****** Object:  ForeignKey [FK_PersonToPersonLink_Person_ToID]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_PersonToPersonLink_Person_ToID] FOREIGN KEY([ToID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_PersonToPersonLink_Person_ToID]
GO
/****** Object:  ForeignKey [FK_Request_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Request]  WITH CHECK ADD  CONSTRAINT [FK_Request_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Request] CHECK CONSTRAINT [FK_Request_Employee]
GO
/****** Object:  ForeignKey [FK_Request_Person]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[Request]  WITH CHECK ADD  CONSTRAINT [FK_Request_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Request] CHECK CONSTRAINT [FK_Request_Person]
GO
/****** Object:  ForeignKey [FK_ServiceMember_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMember]  WITH CHECK ADD  CONSTRAINT [FK_ServiceMember_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[ServiceMember] CHECK CONSTRAINT [FK_ServiceMember_Employee]
GO
/****** Object:  ForeignKey [FK_ServiceMember_Person]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMember]  WITH CHECK ADD  CONSTRAINT [FK_ServiceMember_Person] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[ServiceMember] CHECK CONSTRAINT [FK_ServiceMember_Person]
GO
/****** Object:  ForeignKey [FK_Document_ServiceMember]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMemberDocument]  WITH CHECK ADD  CONSTRAINT [FK_Document_ServiceMember] FOREIGN KEY([ServiceMemberID])
REFERENCES [dbo].[ServiceMember] ([ID])
GO
ALTER TABLE [dbo].[ServiceMemberDocument] CHECK CONSTRAINT [FK_Document_ServiceMember]
GO
/****** Object:  ForeignKey [FK_ServiceMemberDocument_Employee]    Script Date: 09/18/2018 16:33:29 ******/
ALTER TABLE [dbo].[ServiceMemberDocument]  WITH CHECK ADD  CONSTRAINT [FK_ServiceMemberDocument_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[ServiceMemberDocument] CHECK CONSTRAINT [FK_ServiceMemberDocument_Employee]
GO
