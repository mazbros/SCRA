USE [SCRA_DB]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Contract_Customer]') AND parent_object_id = OBJECT_ID(N'[dbo].[Contract]'))
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Customer]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Contract_Employee]') AND parent_object_id = OBJECT_ID(N'[dbo].[Contract]'))
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_Contract_Employee]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Benefit_Contract]') AND parent_object_id = OBJECT_ID(N'[dbo].[Benefit]'))
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_Benefit_Contract]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_EconomicConcept_Contract]') AND parent_object_id = OBJECT_ID(N'[dbo].[EconomicConcept]'))
ALTER TABLE [dbo].[EconomicConcept] DROP CONSTRAINT [FK_EconomicConcept_Contract]
GO

/****** Object:  Table [dbo].[Contract]    Script Date: 09/20/2018 16:59:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Contract]') AND type in (N'U'))
DROP TABLE [dbo].[Contract]
GO

USE [SCRA_DB]
GO

/****** Object:  Table [dbo].[Contract]    Script Date: 09/20/2018 16:59:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Contract](
	[ID]			INT IDENTITY(1,1) NOT NULL,
	[CustomerID]	INT NOT NULL,
	[Center]		INT NULL,
	[Product]		INT NULL,
	[StandardRef]	INT NULL,
	[Subproduct]	INT NULL,
	[ContractNo]	INT NULL,
	[OpenDate]		DATE NULL,
	[CloseDate]		DATE NULL,
	[IsDeleted]		BIT DEFAULT 0,
	[Timestamp]		DATETIME NULL,
	[ModifiedBy]	INT NULL,
 CONSTRAINT [PK_Contract] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Contract]  WITH CHECK ADD  CONSTRAINT [FK_Contract_Customer] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customer] ([ID])
GO

ALTER TABLE [dbo].[Contract] CHECK CONSTRAINT [FK_Contract_Customer]
GO

ALTER TABLE [dbo].[Contract]  WITH CHECK ADD  CONSTRAINT [FK_Contract_Employee] FOREIGN KEY([ModifiedBy])
REFERENCES [dbo].[Employee] ([ID])
GO

ALTER TABLE [dbo].[Contract] CHECK CONSTRAINT [FK_Contract_Employee]
GO

ALTER TABLE [dbo].[Benefit]  WITH CHECK ADD  CONSTRAINT [FK_Benefit_Contract] FOREIGN KEY([ContractID])
REFERENCES [dbo].[Contract] ([ID])
GO

ALTER TABLE [dbo].[Benefit] CHECK CONSTRAINT [FK_Benefit_Contract]
GO

ALTER TABLE [dbo].[EconomicConcept]  WITH CHECK ADD  CONSTRAINT [FK_EconomicConcept_Contract] FOREIGN KEY([ContractID])
REFERENCES [dbo].[Contract] ([ID])
GO

ALTER TABLE [dbo].[EconomicConcept] CHECK CONSTRAINT [FK_EconomicConcept_Contract]
GO





