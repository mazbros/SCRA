﻿using System;
using Scra.Model.Persons;

namespace Scra.Tests.Tools
{
    public class NameGenerator
    {
        private readonly Random _rand;

        private readonly string[] _firstNames = {
            "Barbara", "Charles", "David", "Elizabeth", "Irene", "James", "Jennifer", "Jeremy", "Jessica", "John",
            "Joseph", "Linda", "Margaret", "Mary", "Michael",
            "Patricia", "Richard", "Robert", "Sarah", "Stephanie", "Susan", "Timothy", "Thomas", "William"
        };

        private readonly string[] _lastNames = {
            "Anderson", "Brown", "Davis", "Garcia", "Hernandez", "Johnson", "Jones", "Martin", "Martinez", "Miller",
            "Moore", "Rodriguez", "Russell", "Ross", "Smith", "Taylor",
            "Thomas", "Thompson", "Williams", "Wilson"
        };

        private readonly string[] _middleInitials = { "A", "B", "C", "D", "", "", "" };

        public NameGenerator()
        {
            _rand = new Random(DateTime.Now.Millisecond);
        }

        public PersonName Next()
        {
            return PersonName.Create(Get(_firstNames), Get(_middleInitials), Get(_lastNames));
        }

        private string Get(string[] data)
        {
            var index= _rand.Next(data.Length);
            return data[index];
        }
    }
}