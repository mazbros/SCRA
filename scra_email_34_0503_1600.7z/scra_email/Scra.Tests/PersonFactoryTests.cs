﻿using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Tests.Tools;

namespace Scra.Tests
{
    public class PersonFactoryTests
    {
        [Test]
        public async Task Factory_create_should_return_new_person()
        {
            await Tester.Init();

            var name = new NameGenerator().Next();
            var person = await PersonFactory.CreateAsync(name, Address.Empty(), null, Ssn.Empty(), PersonContacts.Empty(), FNumber.Empty(), string.Empty);
            Assert.NotNull(person);

            var repository = Di.Get<IPersonRepository>();
            await repository.Save(person);
        }
    }
}