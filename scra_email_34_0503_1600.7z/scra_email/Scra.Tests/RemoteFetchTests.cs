﻿using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Tests.Tools;

namespace Scra.Tests
{
    
    public class RemoteFetchTests
    {
        private IContractRepository _contractRepository;
        private IPersonRepository _personRepository;

        [Test]
        public async Task PersonRepository_RemoteFetch_should_return_new_Person()
        {
            await Tester.Init();


            _personRepository = Di.Get<IPersonRepository>();

            //var ssn = Ssn.Parse("100-00-0005");
            var ssn = Ssn.Empty();
            var fNumber = FNumber.Parse("f000000006");
            var importedPerson = await _personRepository.RemoteGet(ssn, fNumber);

        }

        [Test]
        public async Task ContractRepository_RemoteFetch_should_return_new_Contract()
        {
            await Tester.Init();


            _contractRepository = Di.Get<IContractRepository>();
            var contracts = await _contractRepository.RemoteFetch(new PersonId(299));


        }
    }
}
