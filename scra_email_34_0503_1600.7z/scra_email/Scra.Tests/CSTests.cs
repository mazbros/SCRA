﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Scra.Tests
{
    public class CSTests
    {
        [Test]
        public void Array_Test()
        {
            var list = new List<int>(new int[] { 100, 100, 50, 40, 40, 20, 10 });

            var list1 = list.Distinct().ToList();

            Assert.AreEqual( list1.Count, 5);

        }

        [Test]
        public void Directory_Test()
        {
            var dir = AppDomain.CurrentDomain.BaseDirectory;
            Console.WriteLine(dir);
        }
    }
}