﻿using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Model.Communication;
using Scra.Model.Tools;
using Scra.Tests.Tools;

namespace Scra.Tests
{
    public class ProductCommunicationTest
    {
        private ICommunicationRepository _communicationRepository;

        [Test]
        public async Task Get_Communication_should_return_ProductCommunication()
        {
            await Tester.Init();

            _communicationRepository = Di.Get<ICommunicationRepository>();

            var c = await _communicationRepository.GetByBenefit(146);

            Assert.AreEqual(c.BenefitId, 146);
        }

    }
}