﻿using System;
using System.Diagnostics;
using NUnit.Framework;
using PdfFileWriter;
using System.Drawing;

namespace Scra.Tests
{
    public class PdfWriterTests
    {
        private PdfDocument _document;
        private PdfContents _contents;
        private PdfPage _page;
        private string _fileName = "test.pdf";
        private PdfFont _arialNormal;

        [Test]
        public void PdfWriterTests_Create_Document()
        {
            //SetCurentEnvironmentDirectory();

            _document = new PdfDocument(PaperType.Letter, false, UnitOfMeasure.Inch, _fileName);

            DefineFontResources();

            _page = new PdfPage(_document);
            _contents = new PdfContents(_page);

            DrawImage();
            DrawTextBox();

            _document.CreateFile();
            // start default PDF reader and display the file
            Process Proc = new Process();
            Proc.StartInfo = new ProcessStartInfo(_fileName);
            Proc.Start();

        }

        private void DrawImage()
        {
            // define local image resources
            // resolution 96 pixels per inch, image quality 50%
            PdfImageControl ImageControl = new PdfImageControl();
            ImageControl.Resolution = 96.0;
            ImageControl.ImageQuality = 50;
            PdfImage Image1 = new PdfImage(_document, "C:\\Users\\Owner\\Documents\\wizdata_software\\scra\\Scra\\Images\\Santander_logo.png", ImageControl);

            // save graphics state

            _contents.SaveGraphicsState();

            // translate coordinate origin to the center of the picture
            _contents.Translate(1, 9.5);

            // adjust image size and preserve aspect ratio
            PdfRectangle NewSize = Image1.ImageSizePosition(1.75, 1.5, ContentAlignment.MiddleCenter);

            // clipping path
            _contents.DrawOval(NewSize.Left, NewSize.Bottom, NewSize.Width, NewSize.Height, PaintOp.ClipPathEor);

            // draw image
            _contents.DrawImage(Image1, NewSize.Left, NewSize.Bottom, NewSize.Width, NewSize.Height);

            // restore graphics state
            _contents.RestoreGraphicsState();
            return;
        }

        //private void SetCurentEnvironmentDirectory()
        //{
        //    // current directory
        //    string CurDir = Environment.CurrentDirectory;
        //    string WorkDir = CurDir.Replace("bin\\Debug", "Work");
        //    if (WorkDir != CurDir && Directory.Exists(WorkDir))
        //        Environment.CurrentDirectory = WorkDir;
        //}

        private void DefineFontResources()
        {
            // Define font resources
            // Arguments: PdfDocument class, font family name, font style, embed flag
            // Font style (must be: Regular, Bold, Italic or Bold | Italic) All other styles are invalid.
            // Embed font. If true, the font file will be embedded in the PDF file.
            // If false, the font will not be embedded
            string FontName1 = "Arial";            

            _arialNormal = PdfFont.CreatePdfFont(_document, FontName1, FontStyle.Regular, true);

        }

        private void DrawTextBox()
        {
            // save graphics state
            //_contents.SaveGraphicsState();

            // translate origin to PosX=1.1" and PosY=1.1" this is the bottom left corner of the text box example
            _contents.Translate(1.0, 5);

            // Define constants
            // Box width 3.25"
            // Box height is 3.65"
            // Normal font size is 9.0 points.
            const Double Width = 6.5;
            const Double Height = 3.6;
            const Double FontSize = 12.0;

            // Parse text box object width 3.25"
            // First line indent of 0.25"
            TextBox Box = new TextBox(Width, 0.25);

            // add text to the text box
            var msg =
                "This area is an example of displaying text that is too long to fit within a fixed width " +
                "area. The text is displayed justified to right edge. You define a text box with the required " +
                "width and first line indent. You add text to this box. The box will divide the text into " +
                "lines. Each line is made of segments of text. For each segment, you define font, font " +
                "size, drawing style and color. After loading all the text, the program will draw the formatted text.\n";
            Box.AddText(_arialNormal, FontSize,msg);
            

            // Draw the text box
            // Text left edge is at zero (note: origin was translated to 1.1") 
            // The top text base line is at Height less first line ascent.
            // Text drawing is limited to vertical coordinate of zero.
            // First line to be drawn is line zero.
            // After each line add extra 0.015".
            // After each paragraph add extra 0.05"
            // Stretch all lines to make smooth right edge at box width of 3.15"
            // After all lines are drawn, PosY will be set to the next text line after the box's last paragraph
            Double PosY = Height;
            _contents.DrawText(0.0, ref PosY, 0.0, 0, 0.015, 0.05, TextBoxJustify.FitToWidth, Box);

            // Parse text box object width 3.25"
            // No first line indent
            Box = new TextBox(Width);

            // Add text as before.
            // No extra line spacing.
            // No right edge adjustment
            Box.AddText(_arialNormal, FontSize,
                "In the examples above this area the text box was set for first line indent of " +
                "0.25 inches. This paragraph has zero first line indent and no right justify.");
            _contents.DrawText(0.0, ref PosY, 0.0, 0, 0.01, 0.05, TextBoxJustify.Left, Box);

            // Parse text box object width 2.75
            // First line hanging indent of 0.5"
            Box = new TextBox(Width - 0.5, -0.5);

            // Add text
            Box.AddText(_arialNormal, FontSize,
                "This paragraph is set to first line hanging indent of 0.5 inches. " +
                "The left margin of this paragraph is 0.5 inches.");

            // Draw the text
            // left edge at 0.5"
            _contents.DrawText(0.5, ref PosY, 0.0, 0, 0.01, 0.05, TextBoxJustify.Left, Box);

            // restore graphics state
            _contents.RestoreGraphicsState();
            return;
        }

    }
}
