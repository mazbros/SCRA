﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class AffiliateReportItem
    {
        [DisplayName("Status")]
        public string Status { get; set; }

        [DisplayName("Person Requesting First Name")]
        public string PersonRequestingFirstName { get; set; }

        [DisplayName("Person Requesting Last Name")]
        public string PersonRequestingLastName { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServicememberId { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstName { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Log Request Done")]
        public string LogRequestDone { get; set; }

        [DisplayName("Log Request Completed By")]
        public string LogRequestCompletedBy { get; set; }

        [DisplayName("SCUSA Sent Date 1")]
        public string ScusaSentDate1 { get; set; }

        [DisplayName("SCUSA Sent Date 2")]
        public string ScusaSentDate2 { get; set; }

        [DisplayName("SCUSA Confirmation Date")]
        public string ScusaConfirmationDate { get; set; }
 
        [DisplayName("Completed")]
        public string Completed { get; set; }
 
        [DisplayName("Response Date")]
        public string ResponseDate { get; set; }

        [DisplayName("Response Method")]
        public string ResponseMethod { get; set; }
        
        [DisplayName("Response Text")]
        public string ResponseText { get; set; }
        
        [DisplayName("Description")]
        public string Description { get; set; }

        [DisplayName("Comment")]
        public string Comment { get; set; }
 
        public static AffiliateReportItem Create(DataRow dr)
        {
            var item = new AffiliateReportItem
            {
                Status = dr["Status"].ToString(),

                PersonRequestingFirstName = dr["PersonRequestingFirstName"].ToString(),
                PersonRequestingLastName = dr["PersonRequestingLastName"].ToString(),

                ServicememberId = dr["ServicememberId"].ToString(),
                ServicememberFirstName = dr["ServicememberFirstName"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                
                LogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["LogRequestDone"]),
                LogRequestCompletedBy = dr["LogRequestCompletedBy"].ToString(),

                Description = dr["Description"].ToString(),
                Comment = dr["Comment"].ToString(),
                ResponseText = dr["ResponseText"].ToString(),
                ResponseDate = string.Format("{0:MM/dd/yyyy}", dr["ResponseDate"]),
                ResponseMethod = dr["ResponseMethod"].ToString(),

                ScusaSentDate1 = string.Format("{0:MM/dd/yyyy}", dr["ScusaSentDate1"]),
                ScusaSentDate2 = string.Format("{0:MM/dd/yyyy}", dr["ScusaSentDate2"]),
                ScusaConfirmationDate = string.Format("{0:MM/dd/yyyy}", dr["ScusaConfirmationDate"]),

                Completed = dr["Completed"].ToString()
            };

            return item;
        }
    }
}