﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.Extensions;
using Scra.Model.InquiryTypes;

namespace Scra.Model.Persons
{
    public class PersonFactory
    {
        public static async Task<Person> Create(PersonName name, Ssn ssn, PersonContacts contacts)
        {
            var contactMethodList = await ContactMethodList.GetInstance();
            return new Person(PersonId.Empty, name, ssn, Address.Empty(), contactMethodList.Default(), contacts, FNumber.Empty(),string.Empty);
        }

        public static async Task<Person> Create()
        {
            var contactMethodList = await ContactMethodList.GetInstance();
            return new Person(PersonId.Empty, PersonName.Empty(), Ssn.Empty(), Address.Empty(), contactMethodList.Default(),
                PersonContacts.Empty(), FNumber.Empty(), string.Empty);
        }

        public static Person Create(PersonId id, PersonName name, Address address, DateTime? dob, Ssn ssn, IList<DependentLink> dependents, 
            ContactMethod contactMethod, PersonContacts contacts, FNumber fNumber, string origin)
        {
            return new Person(id, name, ssn, address, contactMethod, contacts, fNumber, origin)
            {
                Dob = dob,
                DependentLinks = dependents.AsReadOnly()
            };
        }

        public static async Task<Person> CreateAsync(PersonName name, Address address, DateTime? dob, Ssn ssn, PersonContacts contacts, FNumber fNumber, string origin)
        {
            var contactMethodList = await ContactMethodList.GetInstance();
            var person = new Person(PersonId.Empty, name, ssn, address, contactMethodList.Default(),
                contacts, FNumber.Empty(), origin)
            {
                Dob = dob
            };
            person.ChangeFNumber(fNumber);
            return person;
        }

        public static PersonSnapshot CreateSnapshot(PersonId id, PersonName name, Address address, Ssn ssn, FNumber fNumber)
        {
            return new PersonSnapshot(id, fNumber)
            {
                Name = name,
                Address = address,
                Ssn = ssn
            };
        }

        public static PersonSnapshot CreateSnapshot(PersonId id, PersonName name, InquiryType origin)
        {
            return new PersonSnapshot(id, name, origin)
            {
                Id = id,
                Name = name,
                Origin = origin
            };
        }
    }
}
