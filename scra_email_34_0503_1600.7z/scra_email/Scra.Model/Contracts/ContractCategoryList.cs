﻿using System.Collections.Generic;
using Scra.Model.Extensions;

namespace Scra.Model.Contracts
{
    public class ContractCategoryList
    {
        private IReadOnlyCollection<ContractCategory> _items;

        private ContractCategoryList()
        {
        }

        public static readonly IList<ContractCategory> ITEMS = new List<ContractCategory>
        {
            ContractCategory.Empty, ContractCategory.Auto, ContractCategory.Commercial, ContractCategory.ConsumerLoan, ContractCategory.CreditCard,
            ContractCategory.Mortgage, ContractCategory.SafeDepositBox, ContractCategory.Other
        };

        public static ContractCategoryList Create(IList<ContractCategory> items)
        {
            return new ContractCategoryList
            {
                _items = items.AsReadOnly()
            };
        }

        public IReadOnlyCollection<ContractCategory> All()
        {
            return _items;
        }
    }
}
