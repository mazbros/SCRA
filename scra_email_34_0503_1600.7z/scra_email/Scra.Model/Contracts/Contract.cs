﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Model.Contracts
{
    public class Contract
    {
        public ContractId Id { get; set; }
        public string ContractNo { get; set; }
        public DateTime? OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public PersonId PersonId { get; set; }
        public ContractType Type { get; set; }
        public string LegacyNo { get; set; }
        public string CardNo { get; set; }
        public int? Center { get; set; }
        public int? Product { get; set; }
        public bool IsDeleted { get; set; }
        public ContractCategory Category { get; set; }
        public string ContractProductName { get; set; }

        public Contract(ContractId id, PersonId personId, ContractType type, string contractNo, string legacyNo, string cardNo, int? center, int? product, DateTime? openDate, DateTime? closeDate,ContractCategory category, string productName )
        {
            Id = id;
            PersonId = personId;
            Type = type;
            ContractNo = contractNo;
            OpenDate = openDate;
            CloseDate = closeDate;
            LegacyNo = legacyNo;
            CardNo = cardNo;
            Center = center;
            Product = product;
            Category = category;
            ContractProductName = productName;
        }

        public static Contract Create(PersonId personId)
        {
            return new Contract(ContractId.Empty, personId, null, null, null, null, null, null, null, null, ContractCategory.Empty, string.Empty);
        }

        public static Contract CreateRemote(ContractType type, string contractNo, string legacyNo, string cardNo, int center, int product, DateTime openDate, DateTime? closeDate, ContractCategory category, string productName)
        {
            return new Contract(ContractId.Empty, PersonId.Empty, type, contractNo, legacyNo, cardNo, center, product, openDate, closeDate, category, productName);
        }

        public static Contract CopyFromRemote(PersonId personId, Contract contract)
        {
            return new Contract(ContractId.Empty, personId, contract.Type, contract.ContractNo, contract.LegacyNo, contract.CardNo, contract.Center, contract.Product, contract.OpenDate, contract.CloseDate, contract.Category, contract.ContractProductName);
        }

        //public async Task<Tasc> AddBenefit(Benefit benefit, bool isPromo)
        //{
        //    var tascFactory = Di.Get<ITascFactory>();            
        //    var task = await tascFactory.AddBenefits(benefit.ContractId, isPromo);
        //    await benefit.ChangeStatus(BenefitStatus.Applying, task.Id);
        //    return task;
        //}

        //public async Task<Tasc> ContactCustomer(Benefit benefit)
        //{
        //    var tascFactory = Di.Get<ITascFactory>();
        //    var task = await tascFactory.ContactCustomer(benefit);
        //    await benefit.ChangeStatus(task.Id);
        //    return task;
        //}

        //public async Task<Tasc>RemoveBenefit(Benefit benefit)
        //{
        //    var tascFactory = Di.Get<ITascFactory>();            
        //    var task = await tascFactory.RemoveBenefits(benefit.ContractId);
        //    await benefit.ChangeStatus(BenefitStatus.Removing, task.Id);
        //    return task;
        //}

        //public async Task<Tasc> DenyBenefit(Benefit benefit)
        //{         
        //    var tascFactory = Di.Get<ITascFactory>();
        //    var task = await tascFactory.DenyBenefits(benefit.ContractId);
        //    await benefit.ChangeStatus(BenefitStatus.Denying, task.Id);
        //    return task;
        //}

        public Task<Benefit> GetBenefit()
        {
            return GetBenefit(null, PersonId.Empty);
        }

        public async Task<Benefit> GetBenefit(ActiveDuty activeDuty, PersonId personId)
        {
            var repo = Di.Get<IBenefitRepository>();
            var benefits = await repo.LoadByContract(Id);
            var last = benefits.OrderBy(x => x.StartDate).LastOrDefault();
            if (last == null)
            {
                last = Benefit.Create(Id, activeDuty, personId, BenefitStatus.No);                
            }
            return last;
        }
    }
}
