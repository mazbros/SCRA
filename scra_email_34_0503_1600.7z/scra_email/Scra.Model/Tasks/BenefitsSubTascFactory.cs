﻿using System.Collections.Generic;
using Scra.Model.Contracts;

namespace Scra.Model.Tasks
{
    public class BenefitsSubTascFactory
    {
        public static readonly BenefitAction AddBenefit = new BenefitAction("add_benefit");
        public static readonly BenefitAction EditBenefit = new BenefitAction("edit_benefit");
        public static readonly BenefitAction ContactCustomer = new BenefitAction("contact_customer");
        public static readonly BenefitAction ExtendBenefit = new BenefitAction("extend_benefit");
        public static readonly BenefitAction RemoveBenefit = new BenefitAction("remove_benefit");
        public static readonly BenefitAction DenyBenefit = new BenefitAction("deny_benefit");


        public IList<SubTask> Create(Contract contract, BenefitAction action)
        {
            var category = contract.Type == null ? ContractCategory.Empty : contract.Type.Category;

            if (category == ContractCategory.CreditCard && action == AddBenefit)
            {
                return new List<SubTask>
                    {
                        SubTask.CreateNew("Identify current rate (entry in %)", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Identify if Promotional offer exist", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Identify Promotional offer end date", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Perform rate cap at 6%", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Waive all fees", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Calculate interest adjustment", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Calculate refund amount (entry in $$)", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Record Date refunded", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Record date benefits applied", SubTaskType.CreditCardDetail),
                        SubTask.CreateNew("Record expected removal date", SubTaskType.CreditCardDetail),                        
                        SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (category == ContractCategory.CreditCard && action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Edit Benefit Detail", SubTaskType.CreditCardDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (category == ContractCategory.CreditCard && action == RemoveBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Record removal date", SubTaskType.CreditCardDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (category == ContractCategory.ConsumerLoan && action == AddBenefit)
            {
                return new List<SubTask>
                    {
                        SubTask.CreateNew("Identify current rate (entry in %)", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Perform rate cap at 6%", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Waive all fees", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Calculate interest adjustment", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Calculate refund amount (entry in $$)", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Record Date refunded", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Record date benefits applied", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Record expected removal date", SubTaskType.ConsumerLoanDetail),
                        SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (category == ContractCategory.ConsumerLoan && action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Edit Benefit Detail", SubTaskType.ConsumerLoanDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (category == ContractCategory.ConsumerLoan && action == RemoveBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Record removal date", SubTaskType.ConsumerLoanDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (category == ContractCategory.Mortgage && action == AddBenefit)
            {
                return new List<SubTask>
                    {
                        SubTask.CreateNew("Identify current rate (entry in %)", SubTaskType.MortgageDetail),
                        SubTask.CreateNew("Sent to DMI for processing", SubTaskType.MortgageDetail),
                        SubTask.CreateNew("Received Status Update from DMI", SubTaskType.MortgageDetail),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (category == ContractCategory.Mortgage && action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Edit Benefit Detail", SubTaskType.MortgageDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (category == ContractCategory.Mortgage && action == RemoveBenefit)
            {
                return new List<SubTask>
                {                    
                    SubTask.CreateNew("Record removal date", SubTaskType.MortgageDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (category == ContractCategory.Commercial && action == AddBenefit)
            {
                return new List<SubTask>
                    {
                        SubTask.CreateNew("Send every pertinent customer and product information", SubTaskType.CommercialLoanDetail),
                        SubTask.CreateNew("Received status update from LOB", SubTaskType.CommercialLoanDetail),
                        SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (category == ContractCategory.Commercial && action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Edit Benefit Detail", SubTaskType.CommercialLoanDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (category == ContractCategory.Commercial && action == RemoveBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Record removal date", SubTaskType.CommercialLoanDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (category == ContractCategory.Other && action == AddBenefit)
            {
                return new List<SubTask>
                    {
                        SubTask.CreateNew("Send every pertinent customer and product information", SubTaskType.OtherProductsDetail),
                        SubTask.CreateNew("Received status update from LOB", SubTaskType.OtherProductsDetail),
                        SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                        SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                    };
            }
            if (category == ContractCategory.Other && action == EditBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Edit Benefit Detail", SubTaskType.OtherProductsDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.PersonDashboard),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }
            if (category == ContractCategory.Other && action == RemoveBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Record removal date", SubTaskType.OtherProductsDetail),
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.PersonDashboard),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == ContactCustomer)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == ExtendBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            if (action == DenyBenefit)
            {
                return new List<SubTask>
                {
                    SubTask.CreateNew("Communicate with customer", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Save All Documents", SubTaskType.ProductCommunication),
                    SubTask.CreateNew("Assign QA Agent", SubTaskType.Qa),
                };
            }

            return new List<SubTask>
            {
                SubTask.CreateNew("Others")
            };
        }
    }

    public class BenefitAction
    {
        private readonly string _code;
        public string Code
        {
            get { return _code; }
        }

        public BenefitAction(string code)
        {            
            _code = code;
        }
    }
}