﻿using System;
using Scra.Model.BranchOfServices;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public class ActiveDuty
    {
        public static ActiveDuty Create(PersonId personId)
        {
            return new ActiveDuty {PersonId = personId };
        }

        public static ActiveDuty NoActiveDuty()
        {
            return new ActiveDuty { Id = 0 };
        }


        public static ActiveDuty Create(int id, int personId, int branchOfServiceId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate)
        {
            return new ActiveDuty
            {
                Id = id,
                PersonId = new PersonId(personId),
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
            };
        }

        public static ActiveDuty Create(int id, PersonId personId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate, BranchOfService branchOfService)
        {
            return new ActiveDuty
            {
                PersonId = personId,
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
                BranchOfService = branchOfService
            };
        }

        public int Id { get; set; }
        public PersonId PersonId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? NoticeDate { get; set; }
        public BranchOfService BranchOfService { get; set; }
        public ServiceMember ServiceMember { get; set; }

        public static ActiveDuty Copy(ActiveDuty activeDuty)
        {
            return new ActiveDuty()
            {
                Id = activeDuty.Id,
                PersonId = activeDuty.PersonId,
                StartDate = activeDuty.StartDate,
                EndDate = activeDuty.EndDate,
                NoticeDate = activeDuty.NoticeDate,
                BranchOfService = activeDuty.BranchOfService,
                ServiceMember = activeDuty.ServiceMember,

            };
        }

        public bool Changed(ActiveDuty activeDuty)
        {
            var isIdSame = Id == activeDuty.Id;
            var isPersonIdSame = PersonId == activeDuty.PersonId;
            var isStartDateSame = StartDate == activeDuty.StartDate;
            var isEndDateSame = EndDate == activeDuty.EndDate;
            var isNoticeDateSame = NoticeDate == activeDuty.NoticeDate;
            var isBranchOfServiceSame = BranchOfService.Name == activeDuty.BranchOfService.Name;
            var isServiceMemberSame = ServiceMember.PersonId.Value == activeDuty.ServiceMember.PersonId.Value;

            if (isIdSame &&
                isPersonIdSame &&
                isStartDateSame &&
                isEndDateSame &&
                isNoticeDateSame &&
                isBranchOfServiceSame &&
                isServiceMemberSame)
                return false;

            return true;


        }
    }
}