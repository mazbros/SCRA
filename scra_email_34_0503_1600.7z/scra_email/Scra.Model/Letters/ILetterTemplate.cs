﻿using System.Text;
using System.Threading.Tasks;
using Scra.Model.Communication;

namespace Scra.Model.Letters
{
    public interface ILetterTemplate
    {
        Task LoadTemplate(int letterNumber);
        Task<Letter> Generate(Letter letter, object argument);
        string Content { get; set; }
    }
}