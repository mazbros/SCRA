﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.DomainEvents
{
    public interface IDomainEventDispatcher
    {
        Task DispatchAsync(IDomainEvent domainEvent);
        Task DispatchAsync(IList<IDomainEvent> domainEvents);
        Task DispatchAsync(IDomainEventHolder holder);

        void Subscribe<T>(IDomainEventHandler handler) where T : IDomainEvent;
    }
}