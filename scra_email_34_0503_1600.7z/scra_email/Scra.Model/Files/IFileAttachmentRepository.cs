﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.Files
{
    public interface IFileAttachmentRepository
    {
        Task UploadFile(int entityId, string category, FileAttachment newFile);
        Task<IList<FileAttachmentSnapshot>> Load(int id, string category);
        Task Delete(int fileId);
        Task<FileAttachment> Get(int fileId);
    }
}