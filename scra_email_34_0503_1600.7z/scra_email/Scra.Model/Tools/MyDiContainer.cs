﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Exceptions;

namespace Scra.Model.Tools
{
    public class MyDiContainer
    {
        private bool _isPrebuilt;
        private readonly Dictionary<Type, Type> _typeMap = new Dictionary<Type, Type>();
        private readonly Dictionary<Type, object> _instanceMap = new Dictionary<Type, object>();
        private readonly Dictionary<Type, Type[]> _dependencyMap = new Dictionary<Type, Type[]>();

        public object Resolve(Type type)
        {
            if (!_isPrebuilt)
            {
                Prebuild();
            }

            return ResolveImpl(type);
        }

        public void RegisterType(Type from, Type to)
        {
            _isPrebuilt = false;
            if (_typeMap.ContainsKey(from))
            {
                _typeMap[from] = to;
            }
            else
            {
                _typeMap.Add(from, to);
            }
        }

        public void RegisterInstance(Type type, object instance)
        {
            _isPrebuilt = false;
            if (_instanceMap.ContainsKey(type))
            {
                _instanceMap[type] = instance;
            }
            else
            {
                _instanceMap.Add(type, instance);
            }
        }

        private object ResolveImpl(Type type)
        {
            object instance;
            if (_instanceMap.TryGetValue(type, out instance))
            {
                return instance;
            }
            return CreateType(type);
        }

        private object CreateType(Type type)
        {
            Type returnType;
            if (!_typeMap.TryGetValue(type, out returnType))
            {
                throw new AppException(string.Format("DI can't find type {0}.", type.FullName));
            }

            Type[] dependencyTypes;
            if (_dependencyMap.TryGetValue(returnType, out dependencyTypes))
            {
                var dependencies = dependencyTypes.Select(ResolveImpl).ToArray();
                return Activator.CreateInstance(returnType, dependencies);
            }

            return Activator.CreateInstance(returnType);
        }

        private void Prebuild()
        {
            _dependencyMap.Clear();

            foreach (var type in _typeMap.Values)
            {
                _isPrebuilt = true;

                var ctors = type.GetConstructors();
                var ctor = ctors.First();
                var ctorParameters = ctor.GetParameters();
                _dependencyMap.Add(type, ctorParameters.Select(x => x.ParameterType).ToArray());
            }
        }
    }
}