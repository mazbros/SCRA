﻿using System;
using Scra.Model.Persons;

namespace Scra.Model.Users
{
    public struct UserId : IEquatable<UserId>, IRefId
    {
        public static UserId Empty
        {
            get
            {
                return new UserId(0);
            }
        }

        private readonly int _value;

        public int Value
        {
            get { return _value; }
        }

        public UserId(int id)
        {
            _value = id;
        }

        public bool IsNotEmpty()
        {
            return Value > 0;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        public bool Equals(UserId other)
        {
            return _value == other._value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is UserId))
            {
                return false;
            }
            return Equals((UserId)obj);
        }

        public override string ToString()
        {
            return _value.ToString();
        }

        public static bool operator ==(UserId obj1, UserId obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(UserId obj1, UserId obj2)
        {
            return !(obj1 == obj2);
        }
    }
}