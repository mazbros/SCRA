﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scra.AppCore
{
    public class NavigatorArguments
    {
        public NavigatorArguments()
        {
            NavigatorArgumentList = new List<object>();
        }
        public IList<object> NavigatorArgumentList { get; set; }
    }
}
