﻿namespace Scra.Views.PersonDashboard
{
    public partial class ContractsWidget
    {
        public ContractsWidget()
        {
            InitializeComponent();
        }

        public ContractsWidgetModel GetViewModel()
        {
            return (ContractsWidgetModel)DataContext;
        }
    }
}
