﻿namespace Scra.Views.Files
{
    public partial class FileAttachmentsControl
    {
        public FileAttachmentsControl()
        {
            InitializeComponent();
        }

        public FileAttachmentsControlModel GetViewModel()
        {
            return (FileAttachmentsControlModel) DataContext;
        }
    }
}
