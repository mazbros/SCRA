﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tools;

namespace Scra.Views.Benefits
{
    public class ContractSnapshotViewModel : BaseViewModel
    {
        private AppNavigator _navigator;
        private readonly IPersonRepository _personRepository;
        private readonly IBenefitRepository _benefitRepository;

        public string ServiceMemberName { get; set; }
        public string Title { get; set; }
        public ICommand TitleClicked { get; set; }
        public ICommand SelectCommand { get; set; }
        public IList<BenefitEvent> BenefitEventList { get; set; }
        public Person Person { get; set; }
        public BenefitEvent Contract { get; private set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }
        public string ContractNo { get; set; }
        public string AccountNum { get; set; }
        public string ProductName { get; set; }

        public BenefitEvent SelectedBenefitEvent { get; set; }

        public ContractSnapshotViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            _personRepository = Di.Get<IPersonRepository>();
            _benefitRepository = Di.Get<IBenefitRepository>();

            TitleClicked = new Command(OnTitleClicked);
            SelectCommand = new Command(SelectBenefitEvent);
        }

        private void SelectBenefitEvent()
        {
            NavigateBenefitDetail.Navigate(SelectedBenefitEvent);
        }

        private void OnTitleClicked()
        {
            _navigator.Benefits(Person.Id);
        }

        public async Task Load(ContractId contractId, PersonId personId, int benefitId)
        {
            BenefitEventList = await _benefitRepository.LoadEvent(contractId);
            Person = await _personRepository.Get(personId);
            Contract = BenefitEventList.FirstOrDefault();

            SelectedBenefitEvent = BenefitEventList.FirstOrDefault(x => x.BenefitId == benefitId);

            Reload();
        }

        private void Reload()
        {
           FillView();
        }

        private void FillView()
        {
            
            ServiceMemberName = "Servicemember (" + Person.Name.FullName + ")";

            ProductName = ContractCategory.Parse(Contract.SCRA_Code).Name + " - " + Contract.SubProductName;
            ContractNo = Contract.ContractNo;
            AccountNum = Contract.AccountNumber;
            OpenDate = Formatter.Date(Contract.OpenDate);
            CloseDate = Formatter.Date(Contract.CloseDate);
            UpdateAll();
        }
    }
}
