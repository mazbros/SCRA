﻿using System.Threading.Tasks;
using Scra.Configs;
using Scra.Model.Exceptions;
using Scra.Model.Tools;
using Scra.Model.Version;

namespace Scra.Services
{
    public class VersionControlService
    {
        public async Task CheckVersion()
        {
            var repository = Di.Get<IVersionRepository>();
            var dbVersion = await repository.GetDbVersion();
            var dbName = await repository.GetDbName();

            AppConfig.DbName = dbName;

            if (AppConfig.Version < dbVersion.Version)
            {
                var message = "The current application version does not match with the database, please upgrade the application and restart";
                throw new UserException(message);
            }
            else if (AppConfig.Version > dbVersion.Version)
            {
                var message = "The current application version does not match with the database, please upgrade database and restart the application";
                throw new UserException(message);
            }
        }
    }
}