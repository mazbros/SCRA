﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls.Modules
{
    public class SaveCancelModuleViewModel : BaseViewModel
    {
        public SaveCancelModuleViewModel()
        {
            ReadOnlyMode = Di.Get<IUser>().Type.Equals(UserType.Guest);


        }

        public bool ReadOnlyMode { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public void Load(Action save, Action cancle)
        {
            SaveCommand = new Command(() => save());
            CancelCommand = new Command(() => cancle());
            UpdateAll();
        }
    }
}
