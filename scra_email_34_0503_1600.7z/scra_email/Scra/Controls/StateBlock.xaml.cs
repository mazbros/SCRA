﻿using System.Collections.Generic;
using System.Windows;
using Scra.Model.Persons;

namespace Scra.Controls
{
    public partial class StateBlock
    {
        public StateBlock()
        {
            InitializeComponent();
            var list = new List<AddressState>();
            list.Insert(0, new AddressState("",""));
            list.AddRange(AddressState.List);
            States = list;
            
            ComboBox1.ItemsSource = States;
        }

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(StateBlock), new PropertyMetadata("*"));

        public IReadOnlyCollection<AddressState> States { get; set; }

        public AddressState SelectedState
        {
            get { return (AddressState) GetValue(SelectedStateProperty); }
            set { SetValue(SelectedStateProperty, value); }
        }

        public static DependencyProperty SelectedStateProperty = DependencyProperty.Register(
            "SelectedState", typeof(AddressState), typeof(StateBlock), new FrameworkPropertyMetadata(AddressState.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault) );

        public string LabelName
        {   
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(StateBlock), new PropertyMetadata("State"));
    }
}
