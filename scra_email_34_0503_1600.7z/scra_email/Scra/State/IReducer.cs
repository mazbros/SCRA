﻿namespace Scra.State
{
    public interface IReducer<T> where T : IState
    {
        T GetInitial();

        T Reduce(T old, IAct act);

        bool IsApplicable(IAct act);
    }
}