CREATE PROCEDURE [dbo].[spLoadTaskList] 
	@filterPersonID		INT = NULL,
	@filterContractID	INT = NULL,
	@filterTypes		VARCHAR(255),
	@filterStatuses		VARCHAR(255), 
	@filterAssigneeId	INT = NULL,
	@filterQaAssigneeId INT = NULL,
	@filterTaskId		INT = NULL,
	@filterInquiryId	INT = NULL,
	@filterHideAssigned BIT = 0,
	@searchText			VARCHAR(255)
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				DECLARE @SQL VARCHAR(MAX)
				SET @SQL = 'SELECT	T.Id
								, T.Title
								, T.DueDate
								, I.InquiryDate as ContactDate
								, I.ResponseDate
								, T.CreateDate
								, T.Status
								, T.TaskType
								, T.InquiryId
								, T.ContractId
								, T.PersonId
								, P.FirstName
								, P.LastName
								, T.QaComplete
								, T.AssigneeID
								, E.UserName AS AssigneeUserName
								, E.Name as AssigneeName
								, T.QaAssigneeID
								, qae.UserName AS QaAssigneeUserName
								, qae.Name as QaAssigneeName
								, CASE WHEN ISNULL(C.LegacyNo, '''') &lt;&gt; '''' THEN C.LegacyNo
								  WHEN ISNULL(C.CardNo, '''') &lt;&gt; '''' THEN C.CardNo END AS AccountNum
						FROM	dbo.Task T
						JOIN 	dbo.Person P On P.ID = T.PersonID
						LEFT JOIN dbo.Employee E ON E.ID = T.AssigneeID
						LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
						LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
						left join (Select distinct TaskId, ContractID from Benefit) B On B.TaskID = T.ID
						left join Contract C On C.ID = B.ContractID
						WHERE   1=1 '
			            
						IF @filterPersonId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.PersonID = ' + CAST(@filterPersonId as varchar(16))
						END
						IF @filterContractId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.ContractID = ' + CAST(@filterContractId as varchar(16))
						END
						IF LEN(@filterTypes) &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.TaskType IN (' + @filterTypes + ') '
						END
						IF LEN(@filterStatuses) &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.Status IN (' + @filterStatuses + ') '
						END
						IF @filterAssigneeId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND (T.AssigneeID = ' + CAST(@filterAssigneeId as varchar(16)) + ') '
						END
						IF @filterQaAssigneeId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND (T.QaAssigneeID = ' + CAST(@filterQaAssigneeId as varchar(16)) + ') '
						END
						IF @filterHideAssigned &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.AssigneeID is NULL '
						END
						IF @filterTaskId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.Id = ' + CAST(@filterTaskId as varchar(16))
						END
						IF @filterInquiryId &gt; 0 BEGIN
							SET @SQL = @SQL + ' AND T.InquiryId = ' + CAST(@filterInquiryId as varchar(16))
						END
						if LEN(@searchText) &gt; 0 BEGIN
			            
							SET @searchText = REPLACE(@searchText,'''', '''''');

							SET @SQL = @SQL + ' AND (T.[Title] LIKE ''%' + @searchText + '%'' OR ' + CHAR(10) + CHAR(9) +
								   '   [AssigneeID] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') OR ' + CHAR(10) + CHAR(9) +
								   '   [QaAssigneeId] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') /*OR ' + CHAR(10) + CHAR(9) +
								   '   [ModifiedBy] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'')*/ ' + CHAR(10) + CHAR(9) +
								   '   ) '
						END
			            
						SET @SQL = @SQL + '
						ORDER BY T.CreateDate DESC;'
            
					PRINT @SQL            
            		EXEC (@SQL)
					
				COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

/*

EXEC [dbo].[spLoadTaskList]  
	@filterPersonID = NULL,
	@filterTypes = '',
	@filterStatuses	= '',
	@filterAssigneeId = NULL,
	@filterQaAssigneeId = NULL,
	@filterTaskId = 5242,
	@filterInquiryId = NULL,
	@filterHideAssigned  = 0,
	@searchText = ''
*/
