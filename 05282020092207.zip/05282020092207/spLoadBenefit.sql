CREATE PROCEDURE [dbo].[spLoadBenefit]
	@ContractID INT = NULL,
	@BenefitID	INT = NULL,
	@PersonID	INT = NULL
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				DECLARE @SQL varchar(max)
				SET @SQL = '
				SELECT	[ID], [BenefitIntervalId], [ContractID], 
						[PersonID], [ActiveDutyID], [IsPromo], 
						[StartDate], [EndDate], [Status], 
						[DenialReason], [TaskID]
				FROM [dbo].[Benefit]
				WHERE '
				IF @ContractID IS NOT NULL BEGIN
				   SET @SQL = @SQL + '[ContractID] = ' + CAST(@ContractID as VARCHAR(16))
				END
				IF @BenefitID IS NOT NULL BEGIN
				   SET @SQL = @SQL + '[ID] = ' + CAST(@BenefitID as VARCHAR(16))
				END
				IF @PersonID IS NOT NULL BEGIN
				   SET @SQL = @SQL + '[PersonID] = ' + CAST(@PersonID as VARCHAR(16))
				END
				SET @SQL = @SQL + '
				ORDER	BY [StartDate], [ID];'
			
				EXEC (@SQL);
			
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
	
END
