CREATE PROCEDURE [dbo].[spContract_RemoteFetch_NoRestrictions] 
	@FNumber VARCHAR(10)
WITH RECOMPILE	
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @TIPOPERS VARCHAR(1),@CODOPERS INT
	
	SET @TIPOPERS = LEFT(@FNUMBER,1)
	
	IF LEN(@FNUMBER) = 10 BEGIN
		SET @CODOPERS = CONVERT(INT, RIGHT(@FNUMBER,9))
	END ELSE BEGIN
		SET @CODOPERS = CAST(REPLACE(REPLACE(@FNUMBER,'F',''),'J','') as INT)
	END
	
	/* ============================================================== */
	;WITH Table_Result (
	   [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[CategoryName]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[ContractTypeId]
      )  AS (
	/* ============================================================== */	
	SELECT DISTINCT
       @FNUMBER as [FNumber]
      ,CAST(t3.[H1382_IDCENT] as INT) as [Center]
      ,CAST(t3.[H1382_IDPROD] as INT) as [Product]
      ,CAST(t3.[H1382_IDSTIPRO] as INT) as [Subproduct]
      ,CAST(t3.[H1382_ESTANREF] as INT) as [StandardRef]
      ,CAST(t3.[H1382_IDCONTRN] as INT) as [ContractNo]
      ,t5.[H1564_CTOLOCAL] as [LegacyNo]
      ,m.[H4253_XPAN] as [CardNo]
      ,CAST(t3.H1382_FECCONTR AS DATE) as [OpenDate]
      ,(CASE WHEN CAST(t3.H1382_FECBAJA AS DATE) = '9999-12-31' THEN NULL ELSE CAST(t3.H1382_FECBAJA AS DATE) END) as [CloseDate]
      ,t4.[CATEGORY_NAME] as [CategoryName]
      ,t4.[SUB_PRODUCT_NAME]
      ,t4.[SCRA_Code]
      ,t4.[ID] as [ContractTypeId]
	FROM 
	(SELECT [H1382_IDCENT]
		   ,[H1382_IDPROD]
           ,[H1382_IDSTIPRO]
		   ,[H1382_ESTANREF]
		   ,[H1382_IDCONTRN]
           ,[H1382_FECCONTR]
		   ,[H1382_FECBAJA]
		   ,[H1382_TIPOPERS]
		   ,[H1382_CODPERS]
		   ,[H1382_TP_PERS2]
		   ,[H1382_CD_PERS2]
		   ,[H1382_TP_PERS3]
		   ,[H1382_CD_PERS3]
		FROM [SAS_Persona_Cor_Anon].[DATA].[CAD_CONTR_M_S]
		WHERE ([H1382_TIPOPERS] = @TIPOPERS AND [H1382_CODPERS] = @CODOPERS) OR
			  ([H1382_TP_PERS2] = @TIPOPERS AND [H1382_CD_PERS2] = @CODOPERS) OR
			  ([H1382_TP_PERS3] = @TIPOPERS AND [H1382_CD_PERS3] = @CODOPERS)
		--UNION
		-- SELECT H1382_IDCENT
		--   ,H1382_IDPROD
		--   ,H1382_IDSTIPRO
		--   ,H1382_ESTANREF
		--   ,H1382_IDCONTRN
		--   ,H1382_FECCONTR
		--   ,H1382_FECBAJA
		--   ,H1382_TIPOPERS
		--   ,H1382_CODPERS
		--   ,H1382_TP_PERS2
		--   ,H1382_CD_PERS2
		--   ,H1382_TP_PERS3
		--   ,H1382_CD_PERS3
		--FROM [SAS_Persona_Cor_Anon].[ARCH].[CAD_CONTR_M_S]
		--WHERE (H1382_TIPOPERS = @TIPOPERS AND H1382_CODPERS = @CODOPERS) OR
		--	  (H1382_TP_PERS2 = @TIPOPERS AND H1382_CD_PERS2 = @CODOPERS) OR
		--	  (H1382_TP_PERS3 = @TIPOPERS AND H1382_CD_PERS3 = @CODOPERS)
		) t3
			JOIN [dbo].[ContractType] t4
				ON CAST(t3.[H1382_IDPROD] as INT) = CAST(t4.Product as INT) AND
					CAST(t3.[H1382_IDSTIPRO] as INT) = CAST(t4.Sub_Product as INT) AND
					CAST(t3.[H1382_ESTANREF] as INT) = CAST(t4.Standard_Ref as INT) 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t5
				ON CAST(t3.[H1382_IDCONTRN] as INT) = CAST(t5.H1564_IDCONTRN as INT) AND
					CAST(t3.[H1382_IDCENT] as INT) = CAST(t5.H1564_IDCENT as INT) AND
					CAST(t3.[H1382_IDPROD] as INT) = CAST(t5.H1564_IDPROD as INT) 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_MPDT009_M] m
				ON CAST(t3.[H1382_IDCENT] as INT) = CAST(m.[H4253_CENTALTA] as INT) AND
					CAST(t3.[H1382_IDPROD] as INT) = CAST(m.[H4253_CDGPRODU] as INT) AND
					CAST(t3.[H1382_IDCONTRN] as INT) = CAST(m.[H4253_IDCONTRN] as INT) AND [H4253_CDGPRODU] = '500' AND (m.H4253_CODBLQ = 0 OR m.H4253_TEXBLQ LIKE '%CLOS%')
		WHERE 1=1 AND 
			  ((t3.H1382_TIPOPERS = @TIPOPERS AND t3.H1382_CODPERS = @CODOPERS) OR
			   (t3.H1382_TP_PERS2 = @TIPOPERS AND t3.H1382_CD_PERS2 = @CODOPERS) OR
			   (t3.H1382_TP_PERS3 = @TIPOPERS AND t3.H1382_CD_PERS3 = @CODOPERS)) --AND
			  --t4.IsEligible = 1
		GROUP BY  t3.[H1382_IDCENT],t3.[H1382_IDPROD],t3.[H1382_IDSTIPRO],t3.[H1382_ESTANREF],t3.[H1382_IDCONTRN],t5.[H1564_CTOLOCAL]
				  ,m.[H4253_XPAN],t3.[H1382_FECCONTR],t4.[CATEGORY_NAME],t4.[SUB_PRODUCT_NAME],t4.[SCRA_Code],t4.[ID]
				  ,t3.[H1382_FECBAJA]
	/* ================================================================== */
	) 
   
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[ContractTypeId] FROM (
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[ContractTypeId]
      ,ROW_NUMBER() OVER (PARTITION by [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate] order by [CloseDate] DESC) as [RN]
   FROM Table_Result) t1
   WHERE [RN] = 1
	/* ================================================================== */
 	

END

/*

EXEC  [dbo].[spContract_RemoteFetch] @PersonId = 909

*/
