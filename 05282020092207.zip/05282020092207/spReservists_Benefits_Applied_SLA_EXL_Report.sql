CREATE PROCEDURE [dbo].[spReservists_Benefits_Applied_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[DueDate] as [Due Date],
						[SLA Met],
						[Days Since Contact],
						[Next Business Day],
						[NotificationDateStandard] as [Notification Date Standard],
						[ADSDStandard] as [Active Duty Start Date Standard],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') &lt;&gt; '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') &lt;&gt; '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,adr.NoticeDate
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') as DueDate
					,CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as DATE) &lt;= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),''))
							THEN 'Yes' ELSE 'No' END as [SLA Met]
					,CASE WHEN ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') &lt;&gt; ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
							AND ISNULL(bd.BenefitAppliedDate,getdate()) = ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
						THEN 'Yes' ELSE '' END as [Next Business Day]
					,DATEDIFF(day,i.InquiryDate,isnull(bd.BenefitAppliedDate,getdate())) as [Days Since Contact]							
					,CASE WHEN adr.Reserv = 'Yes' THEN
						CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') &lt;&gt; '1900-01-01' THEN
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = CAST(adr.NoticeDate as DATE) THEN 'Yes' ELSE 'No' END 
						ELSE 'No'
						END 
					 ELSE ''
					 END as NotificationDateStandard
					,CASE WHEN adr.Reserv = 'Yes' THEN
						CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') = '1900-01-01' THEN			
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = DATEADD(day,-45,adr.ADSD) THEN 'Yes' ELSE 'No' END
						ELSE 'No'
						END	
					 ELSE ''							
					 END as ADSDStandard
					 FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv, CONVERT(varchar(10),MAX(ad.NoticeDate),121) as NoticeDate 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') &lt;&gt; 'misdirected'
							AND (t.TaskType = 'add_benefit' OR t.TaskType IS NULL)
							
							AND (
									(
										(ISNULL(bd.BenefitAppliedDate,'') &gt;= @DateStart AND ISNULL(bd.BenefitAppliedDate,'') &lt;= @DateEnd)
									) 
									AND bd.BenefitAppliedDate IS NOT NULL
								)
							AND c.IsDeleted = 0
						--AND (ISNULL(bd.BenefitRemovedDate,'') &gt; @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate &lt; @DateEnd
						AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity','Mortgage')
						AND adr.Reserv = 'Yes'
				) th
				ORDER BY SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spReservists_Benefits_Applied_SLA_EXL_Report] @DateStart='2020-02-01',@DateEnd='2020-02-29'
*/
