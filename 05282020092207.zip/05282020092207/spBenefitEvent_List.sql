CREATE PROCEDURE [dbo].[spBenefitEvent_List]
	@PersonId				INT = NULL,
	@ContractId				INT = NULL,
	@BenefitId				INT = NULL
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @PersonId = 0 BEGIN SET @PersonId = NULL END;
				IF @ContractId = 0 BEGIN SET @ContractId = NULL END;

				DECLARE @BenefitIntervalId int
				IF @BenefitId = 0 BEGIN SET @BenefitId = NULL END;
				ELSE BEGIN
					SET @BenefitIntervalId = (Select BenefitIntervalId from Benefit where ID = @BenefitId)
				END
	
				SELECT B.ID as BenefitId
					, B.BenefitIntervalId
					, ISNULL(BD.ID, 0) as BenefitDetailId
					, B.ActiveDutyId
					, I.ID as InquiryId
					, B.[Status] as BenefitStatus
					, T.TaskType
					, T.[Status] as TaskStatus
					, B.TaskId
					, T_Inquiry.ID as InquiryTaskId
					, C.ID as ContractId
					, I.InquiryDate
					, C.ContractNo
					, B.[Timestamp] as ActionDate		
					, T.CreateDate as CreateDate		
		
					, B.PersonID
					, P_AD.FirstName as ServicememberFirstName
					, P_AD.MiddleInitial as ServicememberMiddleName
					, P_AD.LastName as ServicememberLastName
					, CUS_SM.FNumber as ServicememberFnumber

					, P_C.ID as CustomerID
					, P_C.FirstName as CustomerFirstName
					, P_C.MiddleInitial as CustomerMiddleName
					, P_C.LastName as CustomerLastName
					, CUS.FNumber as CustomerFnumber
		
					, T_Inquiry.TaskType as InquiryTaskType	
		
					, dbo.[fnGetBenefitDetail](B.ID, 'BenefitAppliedDate') as BenefitAppliedDate
					, dbo.[fnGetBenefitDetail](B.ID, 'BenefitEffectiveDate') as BenefitEffectiveDate
					, dbo.[fnGetBenefitDetail](B.ID, 'ExpectedRemovalDate') as ExpectedRemovalDate
					, dbo.[fnGetBenefitDetail](B.ID, 'BenefitRemovedDate') as BenefitRemovedDate
					, dbo.[fnGetBenefitDetail](B.ID, 'ExtendDate') as ExtendDate	
					--, BD.BenefitAppliedDate
					--, BD.BenefitEffectiveDate
					--, BD.ExpectedRemovalDate
					--, BD.BenefitRemovedDate
					--, BD.ExtendDate
		
					, B.DenialReason
        
					, A.StartDate as ActiveDutyStartDate
					, A.EndDate as ActiveDutyEndDate

					/*, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.SUB_PRODUCT_NAME ELSE C.ProductName END as 'SUB_PRODUCT_NAME'*/
					--, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.Product_SubType ELSE C.ProductName END as 'SUB_PRODUCT_NAME'
					, dbo.fnproductsubname(C.ID) As SUB_PRODUCT_NAME
					, CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as 'AccountNumber'
					, CT.SCRA_Code
					, C.OpenDate
					, C.CloseDate	
					, C.Charge_Off	       	
					, C.Charge_Off_Note	
					--, Comm.CommunicationDate		

				FROM Benefit B
					RIGHT JOIN [Contract] C 
						ON B.ContractID = C.ID
					JOIN [Person] P_C 
						ON P_C.ID = C.PersonID 
					JOIN [Customer] CUS 
						ON CUS.PersonID = P_C.ID
					JOIN [ContractType] CT 
						ON C.ContractTypeId = CT.ID
					LEFT JOIN [ActiveDuty] A 
						ON A.ID = B.ActiveDutyId
					LEFT JOIN [Person] P_AD 
						ON P_AD.ID = A.PersonID
					LEFT JOIN [Customer] CUS_SM 
						ON CUS_SM.PersonID = P_AD.ID 
					LEFT JOIN [Task] T 
						ON B.TaskID = T.ID
					LEFT JOIN [BenefitDetail] BD 
						ON BD.BenefitId = B.ID
					LEFT JOIN [Inquiry] I 
						ON I.ID = T.InquiryID
					LEFT JOIN [Task] T_Inquiry 
						ON T_Inquiry.InquiryID = I.ID AND T_Inquiry.TaskType = 'request_benefits'
				--left join Communication Comm On Comm.BenefitID = B.ID
				WHERE @PersonId IS NOT NULL AND (C.PersonID IN (SELECT P.ID as PersonId
												FROM Person P
												WHERE P.ID  IN (SELECT ToID FROM PersonToPersonLink WHERE FromID = @PersonId) OR P.ID  IN (SELECT FromID FROM PersonToPersonLink WHERE ToID =@PersonId) OR P.ID = @PersonId
											) AND C.IsDeleted = 0 AND ISNULL(T.[Status],'') &lt;&gt; 'misdirected')
					OR @BenefitId IS NOT NULL AND (B.BenefitIntervalId = @BenefitIntervalId AND isnull(T.Status,'') &lt;&gt; 'misdirected')
					OR @ContractId IS NOT NULL AND C.ID = @ContractId
					OR (@PersonId IS NULL AND @BenefitId IS NULL AND @ContractId IS NULL )
				--order by B.Timestamp desc
				--order by B.[Timestamp] desc,B.BenefitIntervalId desc
				ORDER BY B.BenefitIntervalId DESC
				--B.BenefitIntervalId desc, B.[Timestamp] desc

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END


END

/*
EXEC [dbo].[spBenefitEvent_List] 764
*/
