-- ===============================================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;01/07/2020&gt;
-- Description:	&lt;Expired Accounts Benefits Report with parameters&gt;
-- ===============================================================
CREATE PROCEDURE [dbo].[spExpiration_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT DISTINCT BenefitIntervalId,ContactDate,MAX(th.ContactDAte) as MaxDate,IdentificationMethod,/*DateDMDCSearchPerformed,VerifyBySCRAOrMilOrders,*/ServicememberID,
					FNumber,FirstName,MiddleInitial,LastName,/*ActiveDutyID,*/Branch,Reserv,Startdate,EndDate,/*NoticeDate,*/ADCount,--[Status],
					BenefitAppliedDate,BenefitEffectiveDate,ExpectedRemovalDate,BenefitRemovedDate,ExtendDate,
					CustID,CustFNumber,CustFirstName,CustMiddleInitial,CustLastName,
					ContractNo,AccountNo,ProductType,ProductSubType,ProductOpenDate,ProductCloseDate
				 FROM (
				SELECT DISTINCT
					p.ID as ServicememberID,p.FirstName,p.LastName,p.MiddleInitial,ISNULL(dbo.fnFNumberByPersonId(p.ID),'') as FNumber,
					adr.Branch,adr.Reserv,--ISNULL(CONVERT(VARCHAR(10),adr.NoticeDate,121),'') as NoticeDate,
					ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as StartDate,
					CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') &lt;&gt; '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') &lt;&gt; '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE '' END END as EndDate,
					ISNULL(adr.ADCount ,0) as ADCount,
					CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status],
					CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus,
					dbo.PARTENON_Format(c.ContractNo) as ContractNo, CASE WHEN ISNULL(c.LegacyNo,'') &lt;&gt; '' THEN dbo.LegacyNo_Format(c.LegacyNo)  ELSE dbo.CardNo_Format(c.CardNo) END as AccountNo,
					dbo.fnProductName(c.ContractTypeId) as ProductType,dbo.fnProductSubName(c.ID) as ProductSubType,
					ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate,
					b.BenefitIntervalId,
					ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate,
					ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate,
					ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate,
					c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName,
					ISNULL(CONVERT(VARCHAR(10),i.InquiryDate,121),'') as ContactDate,
					CASE ISNULL(i.IdentificationMethod,'') 
										WHEN 'internal' THEN 'Proactive'
										WHEN 'line_business' THEN 'Line of Business'
										WHEN 'customer' THEN 'Customer Originated'
										WHEN 'third_party' THEN 'Third Party Service Provider'
										WHEN '' THEN ''
										ELSE ''
									END as IdentificationMethod
				FROM [Benefit] b 
						JOIN [Contract] c ON (b.ContractID = c.ID)
							JOIN [Person] p ON c.PersonID = p.ID
								LEFT JOIN [Task] t on b.TaskID = t.ID
									LEFT JOIN Inquiry i on t.InquiryID = i.ID
										JOIN 
											(SELECT b.BenefitIntervalId,MAX(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b.ActiveDutyID) as ADCount,
												MAX(ad.NoticeDate) as NoticeDate,MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b on b.ActiveDutyID = ad.ID WHERE b.BenefitIntervalId IS NOT NULL GROUP BY b.BenefitIntervalID,ad.PersonID) adr
														ON adr.BenefitIntervalId = b.BenefitIntervalId
											JOIN (SELECT bb.BenefitIntervalID
														,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
														,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
														,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
														,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
														,MAX(bd1.ExtendDate) as ExtendDate 
													  FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID

				WHERE p.Origin in ('benefit_request','affiliate')
					AND c.IsDeleted = 0
					AND t.[Status] &lt;&gt; 'misdirected'
					AND t.TaskType &lt;&gt; 'contact_customer'
					--AND ISNULL(bd.BenefitAppliedDate,'') &lt;&gt; ISNULL(bd.BenefitRemovedDate,'')
					AND ((/*((ISNULL(bd.BenefitRemovedDate,'') &gt;= @DateStart AND ISNULL(bd.BenefitRemovedDate,'') &lt;= @DateEnd))
						OR*/ (((ISNULL(bd.ExpectedRemovalDate,'') &gt;= @DateStart AND ISNULL(bd.ExpectedRemovalDate,'') &lt;= @DateEnd)))
						OR (dbo.fnContractTypeByID(c.ID) IN ('Consumer Loan','Credit Card') AND CAST((ISNULL(adr.ADED,'')) as DATE) BETWEEN DATEADD(day,-90,@DateStart) AND DATEADD(day,-90,@DateEnd)
						OR (dbo.fnContractTypeByID(c.ID) IN ('Home Equity','Mortgage') AND CAST((ISNULL(adr.ADED,'')) as DATE) BETWEEN DATEADD(day,-365,@DateStart) AND DATEADD(day,-365,@DateEnd)))))
					) th
					
				GROUP BY BenefitIntervalId,IdentificationMethod,/*DateDMDCSearchPerformed,VerifyBySCRAOrMilOrders,*/ServicememberID,
					FNumber,FirstName,MiddleInitial,LastName,/*ActiveDutyID,*/Branch,Reserv,Startdate,EndDate,/*NoticeDate,*/ADCount,--[Status],
					BenefitAppliedDate,BenefitEffectiveDate,ExpectedRemovalDate,BenefitRemovedDate,ExtendDate,
					CustID,CustFNumber,CustFirstName,CustMiddleInitial,CustLastName,
					ContractNo,AccountNo,ProductType,ProductSubType,ProductOpenDate,ProductCloseDate,th.ContactDate
				HAVING ContactDate = (SELECT MAX(th.ContactDate) WHERE th.BenefitIntervalId = BenefitIntervalId)
				
				ORDER BY ServicememberID,StartDate,EndDate			
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spExpiration_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31'
*/
