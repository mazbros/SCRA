CREATE PROCEDURE [dbo].[spContract_RemoteFetch] 
	@FNumber VARCHAR(10)
WITH RECOMPILE	
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @TIPOPERS VARCHAR(1),@CODOPERS INT
	
	SET @TIPOPERS = LEFT(@FNUMBER,1)
	BEGIN TRY
	IF LEN(@FNUMBER) = 10 BEGIN
		SET @CODOPERS = CONVERT(INT, RIGHT(@FNUMBER,9))
	END ELSE BEGIN
		SET @CODOPERS = CAST(REPLACE(REPLACE(@FNUMBER,'F',''),'J','') as INT)
	END
	end TRY
	begin catch
	SET @CODOPERS =NULL
	end catch
	
	/* ============================================================== */
	;WITH Table_Result (
	   [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[CardIndex]
      ,[OpenDate]
      ,[CloseDate]
      ,[CategoryName]
      ,[SUB_PRODUCT_NAME]
      ,[SCRA_Code]
      ,[ContractTypeId]
      ,[Owner]
      )  AS (
	/* ============================================================== */	
	SELECT DISTINCT
       @FNUMBER as [FNumber]
            ,CAST(t3.[H1424_IDCENT] as INT) as [Center]
      ,CAST(t3.[H1424_IDPROD] as INT) as [Product]
      ,CAST(t3.[H1424_IDSTIPRO] as INT) as [Subproduct]
      ,CAST(t3.[H1424_ESTANREF] as INT) as [StandardRef]
      ,CAST(t3.[H1424_IDCONTRN] as INT) as [ContractNo]
      ,t5.[H1564_CTOLOCAL] as [LegacyNo]
      ,mm.[H4253_XPAN] as [CardNo]
      ,mm.[H4253_CADTARJ] as [CardIndex]
      ,CAST(t3.H1424_FECCONTR AS DATE) as [OpenDate]
      ,(CASE WHEN CAST(t3.H1424_FECBAJA AS DATE) = '9999-12-31' THEN NULL ELSE CAST(t3.H1424_FECBAJA AS DATE) END) as [CloseDate]
      ,t4.[Product_Type] as [CategoryName]
      ,t4.[Product_SubType]
      ,t4.[SCRA_Code]
      ,t4.[ID] as [ContractTypeId]
      ,CASE WHEN [H1424_TIPOPERS] = @TIPOPERS AND [H1424_CODPERS]  = @CODOPERS THEN 'Primary'
			WHEN [H1424_TP_PERS2] = @TIPOPERS AND [H1424_CD_PERS2] = @CODOPERS THEN 'Secondary'
			WHEN [H1424_TP_PERS3] = @TIPOPERS AND [H1424_CD_PERS3] = @CODOPERS THEN 'Thirtiary'
			ELSE '' END as [Owner]
	FROM 
	(SELECT [H1424_IDCENT]
		   ,[H1424_IDPROD]
           ,[H1424_IDSTIPRO]
		   ,[H1424_ESTANREF]
		   ,[H1424_IDCONTRN]
           ,[H1424_FECCONTR]
		   ,[H1424_FECBAJA]
		   ,[H1424_TIPOPERS]
		   ,[H1424_CODPERS]
		   ,[H1424_TP_PERS2]
		   ,[H1424_CD_PERS2]
		   ,[H1424_TP_PERS3]
		   ,[H1424_CD_PERS3]
		FROM [SAS_Persona_Cor_Anon].[DATA].[CAD_CONTR_DIA_S]
		WHERE ([H1424_TIPOPERS] = @TIPOPERS AND [H1424_CODPERS] = @CODOPERS) OR
			  ([H1424_TP_PERS2] = @TIPOPERS AND [H1424_CD_PERS2] = @CODOPERS) OR
			  ([H1424_TP_PERS3] = @TIPOPERS AND [H1424_CD_PERS3] = @CODOPERS)
		) t3
			JOIN [dbo].[ContractType] t4
				ON CAST(t3.[H1424_IDPROD] as INT) = CAST(t4.Product as INT) AND
					CAST(t3.[H1424_IDSTIPRO] as INT) = CAST(t4.Sub_Product as INT) AND
					CAST(t3.[H1424_ESTANREF] as INT) = CAST(t4.Standard_Ref as INT) 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t5
				ON CAST(t3.[H1424_IDCONTRN] as INT) = CAST(t5.H1564_IDCONTRN as INT) AND
					CAST(t3.[H1424_IDCENT] as INT) = CAST(t5.H1564_IDCENT as INT) AND
					CAST(t3.[H1424_IDPROD] as INT) = CAST(t5.H1564_IDPROD as INT) 
			LEFT JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_MPDT009_M] mm 
				ON CAST(t3.[H1424_IDCENT] as INT) = CAST(mm.[H4253_CENTALTA] as INT) AND
					CAST(t3.[H1424_IDPROD] as INT) = CAST(mm.[H4253_CDGPRODU] as INT) AND
					CAST(t3.[H1424_IDCONTRN] as INT) = CAST(mm.[H4253_IDCONTRN] as INT) AND mm.[H4253_CDGPRODU] = '500' 
		WHERE 1=1 AND 
			  t4.IsEligible = 1
		GROUP BY  t3.[H1424_IDCENT],t3.[H1424_IDPROD],t3.[H1424_IDSTIPRO],t3.[H1424_ESTANREF],t3.[H1424_IDCONTRN],t5.[H1564_CTOLOCAL]
				  ,mm.[H4253_XPAN],mm.[H4253_CADTARJ],t3.[H1424_FECCONTR],t4.[Product_Type],t4.[Product_SubType],t4.[SCRA_Code],t4.[ID]
				  ,t3.[H1424_FECBAJA],t3.[H1424_TIPOPERS],t3.[H1424_CODPERS],t3.[H1424_TP_PERS2],t3.[H1424_CD_PERS2],t3.[H1424_TP_PERS3],t3.[H1424_CD_PERS3]
	/* ================================================================== */
	) 
   
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SCRA_Code]
      ,[CategoryName]
	  ,[SUB_PRODUCT_NAME]
      ,[ContractTypeId]
      ,[Owner]
   FROM (
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[SUB_PRODUCT_NAME]
      ,[ContractTypeId]
      ,ROW_NUMBER() OVER (PARTITION BY [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ORDER BY [CloseDate] DESC) as [RN]
      ,[Owner]
   FROM Table_Result
   WHERE [CardNo] IS NULL
   UNION
   SELECT [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ,[LegacyNo]
      ,[CardNo]
      ,[OpenDate]
      ,[CloseDate]
      ,[SCRA_Code]
      ,[CategoryName]
      ,[SUB_PRODUCT_NAME]
      ,[ContractTypeId]
      ,ROW_NUMBER() OVER (PARTITION BY [FNumber]
      ,[Center]
      ,[Product]
      ,[Subproduct]
      ,[StandardRef]
      ,[ContractNo]
      ORDER BY [CardIndex] DESC) as [RN]
      ,[Owner]
   FROM Table_Result
   WHERE [CardNo] IS NOT NULL
   ) t1
   WHERE [RN] = 1
	/* ================================================================== */
 	

END

/*

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F003471269'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F004438576'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F003611403'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F030858742'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F001498096'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F044103969' 
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F005479475'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F004312979'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F004020827'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F004375297'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F002321163'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F003836355'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F002161072'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F012512244'

EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F030858742'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F003611403'
EXEC  [dbo].[spContract_RemoteFetch] @FNumber = 'F005207195'

SELECT TOP 1 H4253_FEOPERAC,H4253_CENTALTA,H4253_CDGPRODU,H4253_IDCONTRN,H4253_XPAN,
	cd.H1424_IDCENT,cd.H1424_IDPROD,cd.H1424_IDCONTRN,cd.H1424_IDSTIPRO,cd.H1424_ESTANREF,
	CONVERT(VARCHAR(10),cast(cd.H1424_FECCONTR as date),121) as H1424_FECCONTR,
	CONVERT(VARCHAR(10),CAST(cd.H1424_FECBAJA as date),121) as H1424_FECBAJA,
	ct.ID,Product,ct.Sub_Product,ct.Standard_Ref,ct.CATEGORY_NAME,ct.CATEGORY_ORIGIN,ct.SUB_PRODUCT_NAME,ct.STANDARD_REF_NAME,
	ct.SUPER,ct.IsEligible,ct.SCRA_Code,ct.Product_Type,ct.Product_SubType,crd.H4253_CADTARJ	
FROM [SAS_Persona_Cor_Anon].[DATA].[CAD_MPDT009_M] crd 
	 JOIN SAS_Persona_Cor_Anon.DATA.CAD_CONTR_DIA_S cd ON crd.H4253_CENTALTA = cd.H1424_IDCENT AND crd.H4253_CDGPRODU = cd.H1424_IDPROD AND crd.H4253_IDCONTRN = cd.H1424_IDCONTRN 
	 JOIN ContractType ct ON cd.H1424_IDPROD = ct.Product AND cd.H1424_IDSTIPRO = ct.Sub_Product AND CAST(cd.H1424_ESTANREF as INT) = ct.Standard_Ref
WHERE crd.H4253_CENTALTA = '7709' AND crd.H4253_CDGPRODU = '500' AND crd.H4253_IDCONTRN = '0227693'
ORDER BY crd.H4253_CADTARJ DESC

*/
