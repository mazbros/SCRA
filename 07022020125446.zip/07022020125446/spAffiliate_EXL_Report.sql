CREATE PROCEDURE [dbo].[spAffiliate_EXL_Report]
AS
BEGIN

	SET NOCOUNT ON;
	
	/* AFFILIATE */
	SELECT [Status] as [Status],
		[RequestDate] as [Contact Date],
		[ContactMethod] as [Contact Method],
		[PersonRequestingFirstName] as [Person Requesting First Name],
		[PersonRequestingLastName] as [Person Requesting Last Name],
		[PersonRequestingEmail] as [Person Requesting Email],
		[dbo].[Phone_Format]([PersonRequestingPhone]) as [Person Requesting Phone],
		[dbo].[OneLineAddress_Format]([PersonRequestingAddress1],
		[PersonRequestingAddress2],[PersonRequestingCity],
		[PersonRequestingState],[PersonRequestingZip]) as [Person Requesting Address],
		[PersonRequestingOrigin] as [Person Requesting Origin],
		[ServicememberID] as [Servicemember ID],
		[ServicememberFirstName] as [Servicemember First Name],
		[ServicememberMiddleInitial] as [Servicemember Middle Initial],
		[ServicememberLastName] as [Servicemember Last Name],
		[ServicememberEmail] as [Servicemember Email],
		[dbo].[Phone_Format]([ServicememberPhone]) as [Servicemember Phone],
		[dbo].[OneLineAddress_Format]([ServicememberAddress1],
		[ServicememberAddress2],[ServicememberCity],
		[ServicememberState],[ServicememberZip]) as [Servicemember Address],
		[ServicememberOrigin] as [Servicemember Origin],
		[LogRequestDone] as [Log Request Done],
		[LogRequestCompletedBy] as [Log Request Completed By],
		[ScusaSentDate1] as [Affiliate/SBO Sent Date 1],
		[ScusaSentDate2] as [Affiliate/SBO Sent Date 2],
		[ScusaConfirmationDate] as [Affiliate/SBO Confirmation Date],
		[Completed] as [Completed],
		[ResponseDate] as [Response Date],
		[ResponseMethod] as [Response Method],
		[ResponseText] as [ResponseText],
		[Description] as [Description],
		[Comment] as [Comment]
	FROM (
	SELECT DISTINCT i.ID,CAST(CONVERT(VARCHAR(10),[InquiryDate],121) as DATE) as 'RequestDate'
	  ,i.[InquiryType]
	  ,ISNULL(dbo.fnResponseMethodName(i.[ContactMethodID]),'') as [ContactMethod]
	  ,t.[Status]
	  --,COALESCE((SELECT TOP 1 [Status] FROM dbo.SubTask WHERE TaskId = (SELECT ID FROM dbo.Task WHERE InquiryID = i.ID) GROUP BY [Title],[Status],[Timestamp] 
			--	 HAVING [Timestamp] = MAX([Timestamp]) AND [Title] &lt;&gt; 'Assign QA Agent' ORDER BY [Timestamp] DESC), CASE [IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE '' END) as [Status]
	  
	  /*,(SELECT CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th )  &gt; 0 THEN 'in_process'
				ELSE CASE WHEN
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'completed'
				ELSE CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'qa_completed'
				ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
				END
			END
		END) as [Status]*/
	  	  
	  ,ISNULL(i.PersonInquiringId,'') as [PersonRequestingId]
	  ,ISNULL((SELECT FirstName FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingFirstName]
	  ,ISNULL((SELECT LastName FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingLastName]
	  
	  ,ISNULL((SELECT [Email] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingEmail]
	  ,ISNULL((SELECT REPLACE([Phone],'0000000000','') FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingPhone]
	  
	  ,ISNULL((SELECT [Address1] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingAddress1]
	  ,ISNULL((SELECT [Address2] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingAddress2]
	  ,ISNULL((SELECT [City] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingCity]
	  ,ISNULL((SELECT [State] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingState]
	  ,ISNULL((SELECT [Zip] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingZip]

	  ,ISNULL((SELECT [Origin] FROM [dbo].[Person] WHERE [ID] = i.PersonInquiringId),'') as [PersonRequestingOrigin]

	  ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
      
      ,ISNULL((SELECT [Email] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberEmail]
	  ,ISNULL((SELECT REPLACE([Phone],'0000000000','') FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberPhone]
	  
	  ,ISNULL((SELECT [Address1] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberAddress1]
	  ,ISNULL((SELECT [Address2] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberAddress2]
	  ,ISNULL((SELECT [City] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberCity]
	  ,ISNULL((SELECT [State] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberState]
	  ,ISNULL((SELECT [Zip] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberZip]

	  ,ISNULL((SELECT [Origin] FROM [dbo].[Person] WHERE [ID] = i.ServicememberId),'') as [ServicememberOrigin]
     
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [dbo].[Task] tt JOIN [dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] &lt;&gt; 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestDone'
      ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [dbo].[Task] tt JOIN [dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] &lt;&gt; 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestCompletedBy'
   	  
      --,[dbo].DecodeUTF8String(ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Description],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'')) as [Description]
      --,[dbo].DecodeUTF8String(ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Comment],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'')) as [Comment]
      --,[dbo].DecodeUTF8String(ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([ResponseText],CHAR(10)+CHAR(13),'|'),CHAR(10),'|'),CHAR(13),'|'),CHAR(9),'    '),'|||','|'),'||','|'),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'')) as [ResponseText]
      
      ,ISNULL(REPLACE(REPLACE([Description],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Description]
      ,ISNULL(REPLACE(REPLACE([Comment],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Comment]
      ,ISNULL(REPLACE(REPLACE([ResponseText],CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [ResponseText]
      
      ,ISNULL(CONVERT(VARCHAR(10),[ResponseDate],121),'') as [ResponseDate]
      ,ISNULL(dbo.fnResponseMethodName([ResponseMethodId]),'') as [ResponseMethod]
      
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaSentDate1,121),'') as ScusaSentDate1
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaSentDate2,121),'') as ScusaSentDate2
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaConfirmationDate,121),'') as ScusaConfirmationDate
      
      ,CASE WHEN /*(SELECT CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th )  &gt; 0 THEN 'in_process'
				ELSE CASE WHEN
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'completed'
				ELSE CASE WHEN 
				(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
					WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title &lt;&gt; 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
					GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
						HAVING [Timestamp] = MAX([Timestamp])) th ) &gt; 0 THEN 'qa_completed'
				ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
				END
			END
		END)*/ t.[Status] IN ('completed','qa_completed','misdirected') THEN 'Yes' ELSE '' END as [Completed]						
						
  FROM [dbo].[Inquiry] i
	LEFT JOIN [dbo].[Person] p ON i.ServicememberId = p.ID
	LEFT JOIN [dbo].[Task] t ON i.ID = t.InquiryID
	LEFT JOIN [dbo].[Customer] c ON p.Id = c.PersonID
	LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [dbo].[ActiveDuty] ad JOIN [dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
	LEFT JOIN [dbo].[Contract] con ON p.Id = con.PersonID and con.IsDeleted = 0
	LEFT JOIN [dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
	LEFT JOIN [dbo].[Employee] e ON i.[AgentID] = e.ID
  WHERE [InquiryType] = 'affiliate' AND (con.IsDeleted = 0 or con.IsDeleted IS NULL)
  ) th
  ORDER BY CAST(CONVERT(VARCHAR(10),[RequestDate],121) as DATE) DESC
  
END


/*
EXEC [dbo].[spAffiliate_EXL_Report]
*/
