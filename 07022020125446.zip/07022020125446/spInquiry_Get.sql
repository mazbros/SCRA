CREATE PROCEDURE [dbo].[spInquiry_Get]
	@ID						INT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @ID = 0 BEGIN SET @ID = NULL END;
	
				SELECT	x.Id, x.PersonInquiringId, x.ServicememberId,
						x.InquiryDate, x.Description, x.InquiryType, x.Comment,
						x.AcknowledgeDate, x.IsCompleted, x.IdentificationMethod,
						x.ContactMethodID, m.Name AS ContactMethodName,
						x.AgentID, e.UserName AS AgentUserName, e.Name AS AgentName,
						x.ScusaSentDate1, x.ScusaSentDate2, x.ScusaConfirmationDate,
						x.ResponseDate, x.ResponseText,
						x.ResponseMethodId, m.Name AS ResponseMethodName,
						x.DependentTypeId, d.Type AS DependentTypeName,
						x.IsOnActiveDuty, x.DMDCValidationDate
				FROM dbo.Inquiry x
					INNER JOIN dbo.ContactMethod m
						ON m.ID = x.ContactMethodID
					LEFT JOIN dbo.Employee e
						ON e.ID = x.AgentID
					LEFT JOIN dbo.DependentType d
						ON d.ID = x.DependentTypeId
				WHERE   x.Id = @ID;
	
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END

END
