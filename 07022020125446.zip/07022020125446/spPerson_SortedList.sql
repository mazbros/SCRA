CREATE PROCEDURE [dbo].[spPerson_SortedList]
	@Search VARCHAR(MAX),
	@SortBy VARCHAR(50),
	@SortDir VARCHAR(50)
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @Search IS NULL BEGIN
					SET @Search = ISNULL(@Search,'')
				END ELSE BEGIN
					SET @Search = @Search
				END
				
				SET @Search = REPLACE(@Search,'''','''''');
				
				DECLARE @sql VARCHAR(MAX)
				SET @sql = '	
				SELECT t1.[ID]      ,t1.[FirstName]
				  ,t1.[LastName]
				  ,t1.[MiddleInitial]
				  ,t1.[SSN]
				  ,t1.[DOB]
				  ,t1.[Address1]
				  ,t1.[Address2]
				  ,t1.[City]
				  ,t1.[State]
				  ,t1.[Zip]
				  ,t1.[Phone]
				  ,t1.[Email]
				  ,t1.[ContactMethodID]
				  ,t1.[Timestamp]
				  ,t1.[ModifiedBy]
				  ,t2.[FNumber]
				  ,t1.[Origin]
			  FROM [dbo].[Person] t1 LEFT JOIN [dbo].[Customer] t2 ON t1.[ID] = t2.[PersonID]
			  JOIN [dbo].[PersonSearch] ps ON t1.ID = ps.ID
			  WHERE 1 = 1 AND ISNULL(ps.[Search],'''') LIKE ''%'+RTRIM(LTRIM(@Search))+'%''
			  AND ISNULL(t1.[Origin],'''') NOT IN (''dmdc_check'',''inquiry'') /* ''affiliate'',  as per request */
			  ORDER BY '
			  IF @SortBy = '' OR @SortBy = 'Name' BEGIN
				SET @sql = @sql + '[LastName], [FirstName] '	
			  END 
			  IF @SortBy = 'SSN' BEGIN
				SET @sql = @sql + '[SSN] '	
			  END 
			  IF @SortBy = 'City' BEGIN
				SET @sql = @sql + '[City] '	
			  END 
			  IF @SortBy = 'State' BEGIN
				SET @sql = @sql + '[State] '	
			  END 
			  IF @SortBy = 'ZIP' BEGIN
				SET @sql = @sql + '[Zip] '	
			  END 
			  IF @SortBy = 'FNumber' BEGIN
				SET @sql = @sql + 't2.[Fnumber] '	
			  END 
			  IF @SortDir = 'Ascending' BEGIN
				SET @sql = @sql + 'ASC'
			  END ELSE BEGIN
				SET @sql = @sql + 'DESC'
			  END
			  
			  EXEC(@sql);
			  
		COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
  
END
