CREATE PROCEDURE [dbo].[spMaintenanceSheet_Update]
	@ID							INT OUT,
	@BenefitId					INT = NULL,
	@IsAddBenefit				BIT = NULL,
	@IsRemoveBenefit			BIT = NULL,
	@IsMaintenanceRuleChange	BIT = NULL,
	@Adjustment					VARCHAR(MAX) = NULL,
	@ModifiedBy					INT,
	@cmd						VARCHAR(50)
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
				
				DECLARE @BenefitIntervalId INT
				SELECT @BenefitIntervalId = BenefitIntervalId FROM Benefit WHERE ID = @BenefitId
				
				IF @ID = 0 BEGIN
								
					INSERT INTO dbo.MaintenanceSheet (BenefitId, BenefitIntervalId, IsAddBenefit, IsRemoveBenefit, IsMaintenanceRuleChange, Adjustment, ModifiedBy, [Timestamp], [EmailSentDate])
					VALUES (@BenefitId,
							@BenefitIntervalId,
							@IsAddBenefit,
							@IsRemoveBenefit,
							@IsMaintenanceRuleChange,
							@Adjustment,
							@ModifiedBy,
							GETDATE(),
							CASE WHEN @cmd = 'email' THEN GETDATE() ELSE NULL END)
							
					SET @ID = SCOPE_IDENTITY();
							
				END ELSE BEGIN
				
					IF @cmd = 'save' BEGIN
						INSERT INTO [hist].[MaintenanceSheet]
						   ([ID]
						   ,[BenefitId]
						   ,[BenefitIntervalId]
						   ,[Adjustment]
						   ,[ModifiedBy]
						   ,[Timestamp]
						   ,[IsAddBenefit]
						   ,[IsMaintenanceRuleChange]
						   ,[IsRemoveBenefit])
						SELECT [ID]
							,[BenefitId]
							,[BenefitIntervalId]
							,[Adjustment]
							,[ModifiedBy]
							,[Timestamp]
							,[IsAddBenefit]
							,[IsMaintenanceRuleChange]
							,[IsRemoveBenefit]
						FROM [dbo].[MaintenanceSheet]
						WHERE [ID] = @ID
					END

					UPDATE dbo.MaintenanceSheet
						SET BenefitId = @BenefitId,
							BenefitIntervalId = @BenefitIntervalId,
							IsAddBenefit = @IsAddBenefit, 
							IsRemoveBenefit = @IsRemoveBenefit, 
							IsMaintenanceRuleChange = @IsMaintenanceRuleChange,
							Adjustment = @Adjustment, 
							ModifiedBy = @ModifiedBy, 
							[Timestamp] = GETDATE(),
							[EmailSentDate] = CASE WHEN @cmd = 'email' THEN GETDATE() ELSE NULL END
					WHERE ID = @ID
				
				END
				
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
		
END
