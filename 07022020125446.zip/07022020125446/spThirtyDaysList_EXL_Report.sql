CREATE PROCEDURE [dbo].[spThirtyDaysList_EXL_Report]
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				SELECT DISTINCT 
					  p.ID as [Servicemember ID]
					 ,p.FirstName as [Servicemember First Name]
					 ,p.MiddleInitial as [Servicemember Middle Initial]
					 ,p.LastName as [Servicemember Last Name]
					 ,cus.FNumber as [FNumber]
					 ,bd.ExpectedRemovalDate as [Expected Removal Date]
					 ,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as [Date Benefit Removed]
					 --,COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate) as [Expected Removal Date 2]
					 --,DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)) as [Days Left]
					 --,CASE WHEN bd.BenefitRemovedDate IS NULL THEN CAST(DateDiff(DAY,CAST(GETDATE() as DATE),bd.ExpectedRemovalDate) as varchar(10)) ELSE '' END as [Days Left]
					 ,DateDiff(DAY,CAST(GETDATE() as DATE),bd.ExpectedRemovalDate) as [Days Left]
					 ,dbo.fnProductName(c.ContractTypeId) + CASE WHEN LEN(dbo.fnProductSubName(c.ID)) = 0 THEN '' ELSE ' - ' + dbo.fnProductSubName(c.ID) END as [Product Name]
					 ,ISNULL(COALESCE(CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN NULL 
											ELSE dbo.LegacyNo_Format(c.LegacyNo) END,
									  CASE WHEN ISNULL(c.CardNo,'') = '' THEN NULL 
											ELSE dbo.CardNo_Format(c.CardNo) END),'') as [Product Account #]
				FROM dbo.Person p 
					INNER JOIN dbo.Customer cus 
						ON p.ID = cus.PersonID
					INNER JOIN dbo.[Contract] c 
						ON p.ID  = c.PersonID
					INNER JOIN dbo.ContractType ct 
						ON c.ContractTypeId = ct.ID
					INNER JOIN dbo.Benefit b 
						ON c.ID = b.ContractID
					--INNER JOIN dbo.BenefitDetail bd 
					--	ON b.ID = bd.BenefitId
					INNER JOIN (SELECT bb.BenefitIntervalID
									,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
									,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
									,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
									,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
									,MAX(bd1.ExtendDate) as ExtendDate 
									FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd 
						ON b.BenefitIntervalId = bd.BenefitIntervalId 
				--WHERE (((DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate))) BETWEEN 0 AND 30))
					--ORDER BY (DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)))
				WHERE (((DateDiff(DAY,CAST(GETDATE() as DATE),bd.ExpectedRemovalDate))) BETWEEN 0 AND 30)
					AND c.IsDeleted = 0
					ORDER BY --(DateDiff(DAY,CAST(GETDATE() as DATE),bd.ExpectedRemovalDate))
					--CASE WHEN bd.BenefitRemovedDate IS NULL THEN CAST(DateDiff(DAY,CAST(GETDATE() as DATE),bd.ExpectedRemovalDate) as varchar(10)) ELSE '' END
					bd.ExpectedRemovalDate

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END
/*
EXEC [dbo].[spThirtyDaysList_EXL_Report]
*/
