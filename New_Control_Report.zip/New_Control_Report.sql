USE [SCRA_DB]
GO
--/*
;with CTE AS (
	SELECT DISTINCT sm.PersonID,s.DateOfContact,s.MethodOfNotification,s.DateDMDCSearchPerformed,s.VerifyBySCRAOrMilOrders
				,s.ActiveAccountEligible,s.BenefitApprovedDeniedPending,s.StatusCode,s.DateBenefitsApplied,s.DateBenefitsEnded,s.[Benefits Effective (as of) Date]
				,s.NotEligReason,s.DenialReason,s.[90DayLetterSentOn],s.BenefitsRecvd,s.Returned,s.AccountNum
	FROM [SCRA_DB_MIGRATE].[dbo].[Sample] s 
	JOIN [dbo].[Servicemember] sm ON s.ServiceMemberID = sm.ServicememberID
	) 
	
--SELECT * FROM CTE;	
SELECT DISTINCT i.ID,CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) as [Date]
	--,i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]
	  ,COALESCE(t.[Status],CASE [IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE NULL END,'qa_completed') as [Status]
      ,COALESCE(i.[InquiryType],p.[Origin]) as [RequestTypeOrOrigin]--,i.InquiryType,p.Origin
      ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
      ,ISNULL(c.FNumber,'') as [FNumber]
      ,ad.ID as ADID
      ,ISNULL(ad.Branch,'') as [Branch]
      ,ISNULL(CAST(ad.IsReserve as varchar(1)),'') as [IsReserve]
      ,ISNULL(CONVERT(VARCHAR(10),ad.NoticeDate, 121),'') as NoticeDate
      ,ISNULL(CONVERT(VARCHAR(10),ad.StartDate, 121),'') as ADStartDate
      ,ISNULL(CONVERT(VARCHAR(10),ad.EndDate, 121),'') as ADEndDate
      ,ISNULL(con.ContractNo,'') as [ContractNo]
      ,CASE WHEN ISNULL(con.LegacyNo,'') = '' THEN ISNULL(con.CardNo,'') ELSE ISNULL(con.LegacyNo,'') END as [AccountNumber]
      ,ISNULL(COALESCE(con.ProductName,ct.SUB_PRODUCT_NAME),'') as [ProductType]
      ,ISNULL(CONVERT(VARCHAR(10),con.OpenDate, 121),'') as ProductOpenDate
      ,ISNULL(CONVERT(VARCHAR(10),con.CloseDate, 121),'') as ProductCloseDate
      ,ISNULL(COALESCE((SELECT TOP 1 CASE WHEN BenefitApprovedDeniedPending = 'Approved' THEN 'applied' ELSE NULL END FROM CTE cte2 WHERE PersonID = p.ID and cte2.AccountNum = CASE WHEN ISNULL(con.LegacyNo,'') = '' THEN ISNULL(con.CardNo,'') ELSE ISNULL(con.LegacyNo,'') END), b.[Status]),'') as [BenefitStatus]
      --,cte.ActiveAccountEligible,(SELECT TOP 1 BenefitApprovedDeniedPending FROM CTE cte2 WHERE cte2.PersonID = p.ID and cte2.AccountNum = CASE WHEN ISNULL(con.LegacyNo,'') = '' THEN ISNULL(con.CardNo,'') ELSE ISNULL(con.LegacyNo,'') END),b.[Status]
      ,ISNULL(b.DenialReason,'') as [DenialReason]
      ,ISNULL(CONVERT(VARCHAR(10),COALESCE(b.StartDate,cast(cte.DateBenefitsApplied as date),bd.BenefitAppliedDate),121),'') as [Benefits Start Date]
      ,ISNULL(CONVERT(VARCHAR(10),CASE WHEN COALESCE(b.StartDate,cast(cte.DateBenefitsApplied as date)) < COALESCE(b.EndDate,cast(cte.DateBenefitsEnded as date),bd.BenefitRemovedDate)
			THEN COALESCE(b.EndDate,cast(cte.DateBenefitsEnded as date),bd.BenefitRemovedDate)
			ELSE NULL END,121),'') as [Benefits End Date]
      ,ISNULL(CONVERT(VARCHAR(10),COALESCE(bd.BenefitEffectiveDate,cast(cte.[Benefits Effective (as of) Date] as date)),121),'') as [BenefitEffectiveDate]
      ,t.ID as TID
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'LogRequestDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE	
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'EnterDetailsDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'MilitaryInfoDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'ProductEligibilityDONE'
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'RespondToRequesterDONE'
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE		
		ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'SaveAllRecordsDONE'
	  ,CASE WHEN t.ID IS NULL THEN 'Carolyn Cafarelli' ELSE
		ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'CompletedBy'

	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Log Request Completed By'
      --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'Enter Details Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Military Info Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Product Eligibility Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Respond to Requestor Completed By'
	  
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestREJECTED'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'EnterDetailsREJECTED'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'MilitaryInfoREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'ProductEligibilityREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RespondToRequesterREJECTED'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'SaveAllRecordsREJECTED'
	  ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RejectedBy'

	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Log Request REJECTED By'
      --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'Enter Details REJECTED By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Military Info REJECTED By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Product Eligibility REJECTED By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Respond to Requestor REJECTED By'
      
      ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaLogRequestDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaEnterDetailsDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaMilitaryInfoDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaProductEligibilityDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaRespondToRequestorDONE'
	  ,CASE WHEN t.ID IS NULL THEN CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) ELSE
		ISNULL((SELECT MAX(QaCompletionDate) FROM (SELECT CONVERT(varchar(10),MAX(st.QaCompletionDate),121) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaSaveAllRecordsDONE'
	  ,CASE WHEN t.ID IS NULL THEN 'Carolyn Cafarelli' ELSE
	  ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') END as 'QaCompletedBy'

	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'QA Log Request Completed By'
      --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'QA Enter Details Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Military Information' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'QA Military Info Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Product Eligibility' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'Qa Product Eligibility Completed By'
	  --,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.QaCompletionDate) as [QaCompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'QA Respond to Requestor Completed By'
	  
	  ,CASE WHEN t.ID IS NULL THEN 'Yes' ELSE
			CASE WHEN (SELECT CASE WHEN 
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NULL AND [QaCompletionDate] IS NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th )  > 0 THEN 'in_process'
					ELSE CASE WHEN
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th ) > 0 THEN 'completed'
					ELSE CASE WHEN 
					(SELECT COUNT(*) FROM (SELECT Title, Status,QaCompletionDate,CompletionDate,[Timestamp] FROM  dbo.SubTask
						WHERE (TaskID = (SELECT ID FROM Task WHERE InquiryID = i.Id)) AND (Title <> 'Assign QA Agent') AND ([CompletionDate] IS NOT NULL AND [QaCompletionDate] IS NOT NULL)
						GROUP BY Title, Status,QaCompletionDate,CompletionDate,[Timestamp]
							HAVING [Timestamp] = MAX([Timestamp])) th ) > 0 THEN 'qa_completed'
					ELSE (SELECT [Status] FROM Task WHERE InquiryID = i.Id)
					END
				END
			END) IN ('qa_completed','misdirected') THEN 'Yes' ELSE '' END 
		END as [Completed]
	  
  FROM [SCRA_DB].[dbo].[Person] p 
  LEFT JOIN [SCRA_DB].[dbo].[Inquiry] i  ON p.ID = i.ServicememberId
  LEFT JOIN [SCRA_DB].[dbo].[Task] t ON i.ID = t.InquiryID
  LEFT JOIN [SCRA_DB].[dbo].[Customer] c ON p.Id = c.PersonID
  LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [SCRA_DB].[dbo].[ActiveDuty] ad JOIN [SCRA_DB].[dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
  LEFT JOIN [SCRA_DB].[dbo].[Contract] con ON p.Id = con.PersonID and con.IsDeleted = 0
  LEFT JOIN [SCRA_DB].[dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
  LEFT JOIN [SCRA_DB].[dbo].[Benefit] b ON p.Id = b.PersonID AND con.ID = b.ContractID and ad.ID = b.ActiveDutyID
  LEFT JOIN [SCRA_DB].[dbo].[BenefitDetail] bd ON b.ID = bd.BenefitId
  LEFT JOIN CTE cte ON p.ID = cte.PersonID
  WHERE 1=1 --COALESCE(i.[InquiryDate],p.[Timestamp]) >= '2019-01-01' 
  AND COALESCE(i.[InquiryType],p.[Origin]) = 'benefit_request'
  AND p.ID > 103
  --AND p.ID = 423
  AND p.ID NOT IN (SELECT DISTINCT PersonInquiringId FROM [SCRA_DB].[dbo].[Inquiry] WHERE PersonInquiringId <> ServicememberId)
ORDER BY CONVERT(VARCHAR(10),COALESCE(i.[InquiryDate],cte.DateOfContact,cte.DateDMDCSearchperformed,p.[Timestamp]),121) desc
--*/

/*
/* DMDC */
SELECT DISTINCT i.ID,CONVERT(VARCHAR(10),[InquiryDate],121) as 'Date'
	  ,[InquiryType]
	  ,COALESCE(t.[Status],CASE [IsCompleted] WHEN 0 THEN 'in_process' WHEN 1 THEN 'completed' ELSE '' END) as [Status]
	  ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
     
   	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestDone'
      ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'LogRequestCompletedBy'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'EnterDetailsDone'
      ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'')  as 'EnterDetailsCompletedBy'
      ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RespondtoRequestorDone'
	  ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'RespondtoRequestorCompletedBy'
	  ,ISNULL((SELECT MAX([CompletionDate]) FROM (SELECT CONVERT(varchar(10),MAX(st.CompletionDate),121) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'SaveAllRecordsDone'
	  ,ISNULL((SELECT TOP 1 dbo.fnGetUserName(th.CompletedBy) FROM (SELECT st.CompletedBy as [CompletedBy], MAX(st.CompletionDate) as [CompletionDate] FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status]<> 'rejected' GROUP BY st.CompletionDate,st.CompletedBy HAVING st.CompletionDate = MAX(st.CompletionDate)) th),'') as 'SaveAllRecordsCompletedBy'	   
		      
      ,ISNULL([Description],'') as [Description]
      ,ISNULL([Comment],'') as [Comment]
      ,ISNULL([ResponseText],'') as [ResponseText]
      ,ISNULL(CONVERT(VARCHAR(10),[ResponseDate],121),'') as [ResponseDate]
      ,ISNULL(dbo.fnResponseMethodName([ResponseMethodId]),'') as [ResponseMethod]
      
      ,ISNULL([IdentificationMethod],'') as [IdentificationMethod]
      ,ISNULL(CONVERT(VARCHAR(10),[DMDCValidationDate],121),'') as [DMDCValidationDate]
  FROM [SCRA_DB].[dbo].[Inquiry] i
	LEFT JOIN [SCRA_DB].[dbo].[Person] p ON i.ServicememberId = p.ID
	LEFT JOIN [SCRA_DB].[dbo].[Task] t ON i.ID = t.InquiryID
	LEFT JOIN [SCRA_DB].[dbo].[Customer] c ON p.Id = c.PersonID
	LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [SCRA_DB].[dbo].[ActiveDuty] ad JOIN [SCRA_DB].[dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[Contract] con ON p.Id = con.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
	LEFT JOIN [SCRA_DB].[dbo].[Employee] e ON i.[AgentID] = e.ID
  WHERE [InquiryType] = 'dmdc_check'
  ORDER BY CONVERT(VARCHAR(10),[InquiryDate],121) DESC
--*/
/*
/* INQUIRY */
SELECT DISTINCT i.ID,CONVERT(VARCHAR(10),[InquiryDate],121) as 'Date'
	  ,[InquiryType]
	  ,t.[Status]
	  ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
     
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Log Request DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Log Request Completed By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'')  as 'Enter Details DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'')  as 'Enter Details  Completed By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Respond to Requestor DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Respond to Requestor  Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Save All Records DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Save All Records  Completed By'
	  
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Log Request REJECTED'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Log Request REJECTED By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'')  as 'Enter Details REJECTED'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'')  as 'Enter Details REJECTED By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Respond to Requestor REJECTED'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Respond to Requestor REJECTED By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Save All Records REJECTED'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Save All Records REJECTED By'
	  
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Log Request DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Log Request Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'')  as 'QA Enter Details DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'')  as 'QA Enter Details Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'Qa Respond to Requestor DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'Qa Respond to Requestor Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Save All Records DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Save All Records CompletedBy'
	  
      ,ISNULL([Description],'') as [Description]
      ,ISNULL([Comment],'') as [Comment]
      ,ISNULL([ResponseText],'') as [ResponseText]
      ,ISNULL(CONVERT(VARCHAR(10),[ResponseDate],121),'') as [ResponseDate]
      ,ISNULL(dbo.fnResponseMethodName([ResponseMethodId]),'') as [ResponseMethod]
      ,ISNULL([IdentificationMethod],'') as [IdentificationMethod]
      ,ISNULL(CONVERT(VARCHAR(10),[DMDCValidationDate],121),'') as [DMDCValidationDate]
  FROM [SCRA_DB].[dbo].[Inquiry] i
	LEFT JOIN [SCRA_DB].[dbo].[Person] p ON i.ServicememberId = p.ID
	LEFT JOIN [SCRA_DB].[dbo].[Task] t ON i.ID = t.InquiryID
	LEFT JOIN [SCRA_DB].[dbo].[Customer] c ON p.Id = c.PersonID
	LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [SCRA_DB].[dbo].[ActiveDuty] ad JOIN [SCRA_DB].[dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[Contract] con ON p.Id = con.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
	LEFT JOIN [SCRA_DB].[dbo].[Employee] e ON i.[AgentID] = e.ID
  WHERE [InquiryType] = 'inquiry'
  ORDER BY CONVERT(VARCHAR(10),[InquiryDate],121) DESC
*/
/*
/* AFFILIATE */
SELECT DISTINCT i.ID,CONVERT(VARCHAR(10),[InquiryDate],121) as 'Date'
	  ,[InquiryType]
	  ,t.[Status]
	  ,ISNULL(CAST(p.Id as varchar(9)),'') as [ServicememberID]
      ,ISNULL(p.FirstName,'') as ServicememberFirstName
      ,ISNULL(p.MiddleInitial,'') as ServicememberMiddleInitial
      ,ISNULL(p.LastName,'') as ServicememberLastName
     
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Log Request DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Log Request Completed By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'')  as 'Enter Details DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'')  as 'Enter Details  Completed By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Respond to Requestor DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Respond to Requestor  Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Save All Records DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] <> 'rejected'),'') as 'Save All Records  Completed By'
	  
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Log Request REJECTED'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Log Request REJECTED By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'')  as 'Enter Details REJECTED'
      ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'')  as 'Enter Details REJECTED By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Respond to Requestor REJECTED'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Respond to Requestor REJECTED By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.CompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Save All Records REJECTED'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.CompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'rejected'),'') as 'Save All Records REJECTED By'
	
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Log Request DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON tt.ID = st.TaskID AND st.Title = 'Log Request' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Log Request Completed By'
      ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'')  as 'QA Enter Details DONE'
      ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Enter Details' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'')  as 'QA Enter Details Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'Qa Respond to Requestor DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Respond to the Requester' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'Qa Respond to Requestor Completed By'
	  ,ISNULL((SELECT CONVERT(varchar(10),st.QaCompletionDate,121) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Save All Records DONE'
	  ,ISNULL((SELECT dbo.fnGetUserName(st.QaCompletedBy) FROM [SCRA_DB].[dbo].[Task] tt JOIN [SCRA_DB].[dbo].[SubTask] st ON st.TaskID = tt.ID and st.Title = 'Save all records' WHERE tt.ID = t.ID and st.[Status] = 'qa_completed'),'') as 'QA Save All Records CompletedBy'
		      
      ,ISNULL([Description],'') as [Description]
      ,ISNULL([Comment],'') as [Comment]
      ,ISNULL([ResponseText],'') as [ResponseText]
      ,ISNULL(CONVERT(VARCHAR(10),[ResponseDate],121),'') as [ResponseDate]
      ,ISNULL(dbo.fnResponseMethodName([ResponseMethodId]),'') as [ResponseMethod]
      
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaSentDate1,121),'') as ScusaSentDate1
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaSentDate2,121),'') as ScusaSentDate2
      ,ISNULL(CONVERT(VARCHAR(10),i.ScusaConfirmationDate,121),'') as ScusaConfirmationDate
            
      ,ISNULL([IdentificationMethod],'') as [IdentificationMethod]
      ,ISNULL(CONVERT(VARCHAR(10),[DMDCValidationDate],121),'') as [DMDCValidationDate]
  FROM [SCRA_DB].[dbo].[Inquiry] i
	LEFT JOIN [SCRA_DB].[dbo].[Person] p ON i.ServicememberId = p.ID
	LEFT JOIN [SCRA_DB].[dbo].[Task] t ON i.ID = t.InquiryID
	LEFT JOIN [SCRA_DB].[dbo].[Customer] c ON p.Id = c.PersonID
	LEFT JOIN (SELECT DISTINCT MAX(ad.ID) as ID,PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve FROM [SCRA_DB].[dbo].[ActiveDuty] ad JOIN [SCRA_DB].[dbo].[BranchOfService] bs ON ad.BranchOfServiceID = bs.ID
			GROUP BY PersonID,StartDate,EndDate,NoticeDate,Branch,IsReserve HAVING StartDate = (SELECT MAX(StartDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) AND 
			(EndDate = (SELECT MAX(EndDate) FROM [SCRA_DB].[dbo].[ActiveDuty] ad2 WHERE ad2.PersonID = ad.PersonID) OR EndDate IS NULL)) ad ON p.ID = ad.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[Contract] con ON p.Id = con.PersonID
	LEFT JOIN [SCRA_DB].[dbo].[ContractType] ct ON con.ContractTypeId = ct.ID
	LEFT JOIN [SCRA_DB].[dbo].[Employee] e ON i.[AgentID] = e.ID
  WHERE [InquiryType] = 'affiliate'
  ORDER BY CONVERT(VARCHAR(10),[InquiryDate],121) DESC
*/