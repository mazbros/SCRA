USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spGetTaskById]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/09/2020>
-- Description:	<Get task and subtask info>
-- =============================================
CREATE PROCEDURE [dbo].[spGetTaskById]
	@taskId INT
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
		SELECT	T.Id
            , T.Title
            , T.DueDate
            , I.InquiryDate as ContactDate
            , I.ResponseDate
            , T.CreateDate
            , T.Status
            , T.TaskType
            , T.InquiryId
            , T.PersonId
            , P.FirstName
            , P.LastName
            , CASE WHEN ISNULL(C.LegacyNo, '') <> '' THEN C.LegacyNo
              WHEN ISNULL(C.CardNo, '') <> '' THEN C.CardNo END AS AccountNum
            , T.ContractId
            , T.QaComplete
            , T.ModifiedBy
            , m.UserName AS ModifiedByUserName
            , m.Name as ModifiedByName
            , T.AssigneeID
            , e.UserName AS AssigneeUserName
            , e.Name as AssigneeName
            , T.QaAssigneeID
            , qae.UserName AS QaAssigneeUserName
            , qae.Name as QaAssigneeName
			

        FROM	dbo.Task T
        JOIN 	dbo.Person P On P.ID = T.PersonID
        LEFT JOIN dbo.Employee m ON m.ID = T.ModifiedBy
        LEFT JOIN dbo.Employee e ON e.ID = T.AssigneeID
        LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
        LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
        left join Contract C On C.ID = T.ContractID
        WHERE   T.Id = @taskId;

        SELECT  x.Id, 
			x.Title
			, x.Code
			, x.Status
			, x.SortNo
			, x.IsComplete
			, x.CompletionDate
			, x.CompletedBy
			, e.UserName AS CompletedByUserName
			, e.Name as CompletedByName
			, x.IsQaComplete
			, x.QaCompletionDate
			, x.QaCompletedBy
			, eq.UserName AS QaCompletedByUserName
			, eq.Name as QaCompletedByName
			, r.RejectionReason
        FROM	dbo.SubTask x
        LEFT JOIN dbo.Employee e ON e.ID = x.CompletedBy
        LEFT JOIN dbo.Employee eq ON eq.ID = x.QaCompletedBy
		LEFT JOIN dbo.RejectionReason r ON r.SubTaskID = x.ID
        WHERE   x.TaskID = @taskId
        ORDER BY x.ID;
        
END


GO

/****** Object:  StoredProcedure [dbo].[spQaRejectionReason_Update]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/06/2020>
-- Description:	<Save QA rejection reason>
-- =============================================
CREATE PROCEDURE [dbo].[spQaRejectionReason_Update]
	@SubTaskId			INT,
	@RejectionReason	VARCHAR(255)	
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
			
				IF (SELECT COUNT(*) FROM [dbo].[RejectionReason] WHERE SubTaskID = @SubTaskId) = 0 BEGIN
					
						INSERT INTO [dbo].[RejectionReason]
							(SubTaskID,
							Rejectionreason)
						VALUES
							(@SubTaskId,
							@RejectionReason)
							
				END ELSE BEGIN 
					
						UPDATE [dbo].[RejectionReason]
							SET [RejectionReason] = @RejectionReason
						WHERE [SubTaskId] = @SubTaskId
					
				END

			COMMIT TRANSACTION
	
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = Convert(NVARCHAR(2048),SUBSTRING(ERROR_MESSAGE(),1,2047));
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
    
END

GO

/****** Object:  StoredProcedure [dbo].[spGetQaRejectionReasonList]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/06/2020>
-- Description:	<Get QA rejection reason list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetQaRejectionReasonList]
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT  [ID], [Name] FROM [dbo].[QaRejectionReason] ORDER BY [SortIndex]
				
			COMMIT TRANSACTION
	
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = Convert(NVARCHAR(2048),SUBSTRING(ERROR_MESSAGE(),1,2047));
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
    
END

GO

/****** Object:  StoredProcedure [dbo].[spEscalation_Get]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spEscalation_Get]    
	@PersonId int

AS   

    SET NOCOUNT ON;  

	select es.ID
		, es.PersonId
		, es.Notes
		, es.ModifiedBy
		, es.Timestamp
		, em.Name
		, em.UserName
		from dbo.Escalation es
		join Employee em on em.ID = es.ModifiedBy
	where PersonId = @PersonId

GO

/****** Object:  StoredProcedure [dbo].[spContract_Get]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[spContract_Get]
	@ID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT x.Id
		, x.Center
		, x.Product
		, x.ContractNo
		, x.LegacyNo
		, x.CardNo
		, x.OpenDate
		, x.CloseDate
		, x.PersonID
		, x.ContractTypeId
		, dbo.fnProductSubName(x.ID) as [SUB_PRODUCT_NAME]
		, t.SCRA_Code
		, x.[Charge_Off]
		, x.[Charge_Off_Note]
FROM	dbo.[Contract] x
	INNER	JOIN dbo.ContractType t 
		ON	t.Id	= x.ContractTypeId
WHERE x.ID = @ID 

END


/*

EXEC [dbo].[spContract_Get] 315

*/

/*
UPDATE [SCRA_DB].[dbo].[Contract] 
	SET [SCRA_DB].[dbo].[Contract].[LegacyNo] = t4.[H1564_CTOLOCAL]
	FROM [SCRA_DB].[dbo].[Contract]  t1 
    JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t4 
		ON t1.Center = t4.H1564_IDCENT AND
			t1.Product = t4.H1564_IDPROD AND
			t1.ContractNo = t4.H1564_IDCONTRN
*/
GO

/****** Object:  StoredProcedure [dbo].[spContract_Update]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[spContract_Update]
	@ID					INT OUT,
	@PersonID			INT,
	@ContractTypeId		INT,
	@ContractNo			VARCHAR(14),
    @LegacyNo			VARCHAR(24),
    @CardNo				VARCHAR(16),
    @Center				INT = NULL,
    @Product			INT = NULL,
    @OpenDate			DATE,
	@CloseDate			DATE = NULL,
	@ProductName		VARCHAR(50) = NULL,
	@IsDeleted			BIT,
	@Charge_Off			BIT,
	@Charge_Off_Note	VARCHAR(MAX)= NULL,
	@ModifiedBy			INT
AS
BEGIN
	SET NOCOUNT ON;
	
	Declare 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

BEGIN

    BEGIN TRY

        BEGIN TRANSACTION   

	
	IF @ID = 0 BEGIN SET @ID = NULL END
	
	IF @ID IS NULL BEGIN
	
				--IF (SELECT COUNT(*) FROM [dbo].[Contract] WHERE [ContractNo] = @ContractNo AND ISNULL([ContractNo],'') <> '') = 0 BEGIN
				
					INSERT INTO [dbo].[Contract]
						   ([PersonID]
						   ,[ContractTypeId]
						   ,[ContractNo]
						   ,[LegacyNo]
						   ,[CardNo]
						   ,[Center]
						   ,[Product]
						   ,[OpenDate]
						   ,[CloseDate]
						   ,[ProductName]
						   ,[Timestamp]
						   ,[ModifiedBy])
					 VALUES
						   (@PersonID
						   ,@ContractTypeId
						   ,@ContractNo
						   ,@LegacyNo
						   ,@CardNo
						   ,@Center
						   ,@Product
						   ,@OpenDate
						   ,@CloseDate
						   ,@ProductName
						   ,GETDATE()
						   ,@ModifiedBy)
						   
				SET @ID = SCOPE_IDENTITY()
			
			--END ELSE BEGIN
				
			--	SET @ID = (SELECT Top 1 ID FROM [dbo].[Contract] WHERE [ContractNo] = @ContractNo)
			
			--END
	
	END ELSE BEGIN
	
			INSERT INTO [hist].[Contract]
				([ID]
				,[PersonID]
				,[ContractTypeId]
				,[ContractNo]
				,[LegacyNo]
				,[CardNo]
				,[Center]
			    ,[Product]
				,[OpenDate]
				,[CloseDate]
				,[ProductName]
				,[IsDeleted]
				,[Timestamp]
				,[ModifiedBy]
				,[Charge_Off]
				,[Charge_Off_Note])
			SELECT
				 [ID]
				,[PersonID]
				,[ContractTypeId]
				,[ContractNo]
				,[LegacyNo]
				,[CardNo]
				,[Center]
				,[Product]
				,[OpenDate]
				,[CloseDate]
				,[ProductName]
				,[IsDeleted]
				,[Timestamp]
				,[ModifiedBy]
				,[Charge_Off]
				,[Charge_Off_Note]
			FROM [dbo].[Contract]
			WHERE [ID] = @ID
	
			UPDATE [dbo].[Contract]
				SET [ContractTypeId] = @ContractTypeId
				   ,[ContractNo] = @ContractNo
				   ,[LegacyNo] = @LegacyNo
				   ,[CardNo] = @CardNo
				   ,[ProductName] = CASE WHEN @ContractTypeId >= 900 THEN @ProductName ELSE [ProductName] END
				   ,[OpenDate] = @OpenDate
				   ,[CloseDate] = @CloseDate
				   ,[IsDeleted] = @IsDeleted
				   ,[Timestamp] = GETDATE()
				   ,[ModifiedBy] = @ModifiedBy
				   ,[Charge_Off] = @Charge_Off
				   ,[Charge_Off_Note] = @Charge_Off_Note
			WHERE [ID] = @ID
	
	END
	
	COMMIT TRANSACTION
	
	END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION        
        SET @ErrorMessage = Convert(NVARCHAR(2048),SUBSTRING(ERROR_MESSAGE(),1,2047));
        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
        SET @ErrorLine    = ERROR_LINE();
        SET @ErrorSeverity= ERROR_SEVERITY();
        SET @ErrorState   = ERROR_STATE();
        GOTO ErrorHandler;
    END CATCH
    RETURN;
    
    ErrorHandler:
        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

END
	
END

--ALTER TABLE hist.[Contract] ALTER COLUMN [LegacyNo] VARCHAR(24) NULL

GO

/****** Object:  StoredProcedure [dbo].[spBenefitEvent_List]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spBenefitEvent_List]
	@PersonId				INT = NULL,
	@ContractId				INT = NULL,
	@BenefitId				INT = NULL
WITH RECOMPILE
AS
BEGIN
	
	IF @PersonId = 0 BEGIN SET @PersonId = NULL END;
	IF @ContractId = 0 BEGIN SET @ContractId = NULL END;

	Declare @BenefitIntervalId int
	IF @BenefitId = 0 BEGIN SET @BenefitId = NULL END;
	ELSE BEGIN
		SET @BenefitIntervalId = (Select BenefitIntervalId from Benefit where ID = @BenefitId)
	end
	
	Select B.ID As BenefitId
		, B.BenefitIntervalId
		, ISNULL(BD.ID, 0) As BenefitDetailId
		, B.ActiveDutyId
        , I.ID As InquiryId
		, B.Status As BenefitStatus
		, T.TaskType
		, T.Status As TaskStatus
		, B.TaskId
		, T_Inquiry.ID As InquiryTaskId
		, C.ID As ContractId
		, I.InquiryDate
		, C.ContractNo
		, B.Timestamp As ActionDate		
		, T.CreateDate As CreateDate		
		
		, B.PersonID
		, P_AD.FirstName As ServicememberFirstName
		, P_AD.MiddleInitial As ServicememberMiddleName
		, P_AD.LastName As ServicememberLastName
		, CUS_SM.FNumber As ServicememberFnumber

		, P_C.ID As CustomerID
		, P_C.FirstName As CustomerFirstName
		, P_C.MiddleInitial As CustomerMiddleName
		, P_C.LastName As CustomerLastName
		, CUS.FNumber As CustomerFnumber
		
		, T_Inquiry.TaskType As InquiryTaskType	
		
		, dbo.[fnGetBenefitDetail](B.ID, 'BenefitAppliedDate') as BenefitAppliedDate
		, dbo.[fnGetBenefitDetail](B.ID, 'BenefitEffectiveDate') as BenefitEffectiveDate
		, dbo.[fnGetBenefitDetail](B.ID, 'ExpectedRemovalDate') as ExpectedRemovalDate
		, dbo.[fnGetBenefitDetail](B.ID, 'BenefitRemovedDate') as BenefitRemovedDate
		, dbo.[fnGetBenefitDetail](B.ID, 'ExtendDate') as ExtendDate	
		--, BD.BenefitAppliedDate
		--, BD.BenefitEffectiveDate
		--, BD.ExpectedRemovalDate
		--, BD.BenefitRemovedDate
		--, BD.ExtendDate
		
		, B.DenialReason
        
		, A.StartDate As ActiveDutyStartDate
		, A.EndDate As ActiveDutyEndDate

		/*, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.SUB_PRODUCT_NAME ELSE C.ProductName END as 'SUB_PRODUCT_NAME'*/
        --, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.Product_SubType ELSE C.ProductName END as 'SUB_PRODUCT_NAME'
		, dbo.fnproductsubname(C.ID) As SUB_PRODUCT_NAME
		, CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as 'AccountNumber'
		, CT.SCRA_Code
		, C.OpenDate
		, C.CloseDate	
		, C.Charge_Off	       	
		, C.Charge_Off_Note	
		--, Comm.CommunicationDate		

	from Benefit As B
	right join [Contract] C On B.ContractID = C.ID
	join Person P_C On P_C.ID = C.PersonID 
	join Customer CUS On CUS.PersonID = P_C.ID
	join ContractType CT ON C.ContractTypeId = CT.ID
	left join ActiveDuty As A On A.ID = B.ActiveDutyId
	left join Person P_AD On P_AD.ID = A.PersonID
	left join Customer CUS_SM On CUS_SM.PersonID = P_AD.ID 
	left join Task T On B.TaskID = T.ID
    left join BenefitDetail BD On BD.BenefitId = B.ID
	left join Inquiry I On I.ID = T.InquiryID
	left join Task T_Inquiry On T_Inquiry.InquiryID = I.ID AND T_Inquiry.TaskType = 'request_benefits'
	--left join Communication Comm On Comm.BenefitID = B.ID
	Where @PersonId is NOT NULL AND (C.PersonID in (Select P.ID As PersonId
									from Person P
									where P.ID  in (Select ToID from PersonToPersonLink where FromID = @PersonId) OR P.ID  in (Select FromID from PersonToPersonLink where ToID =@PersonId) OR P.ID = @PersonId
								) and C.IsDeleted = 0 and isnull(T.Status,'') <> 'misdirected')
	OR @BenefitId is NOT NULL AND (B.BenefitIntervalId = @BenefitIntervalId and isnull(T.Status,'') <> 'misdirected')
	OR @ContractId is NOT NULL AND C.ID = @ContractId
	OR (@PersonId is NULL and @BenefitId is NULL and @ContractId is NULL )
	--order by B.Timestamp desc
	--order by B.[Timestamp] desc,B.BenefitIntervalId desc
	order by B.BenefitIntervalId desc
	--B.BenefitIntervalId desc, B.[Timestamp] desc


END

/*

EXEC [dbo].[spBenefitEvent_List] 764
*/
GO

/****** Object:  StoredProcedure [dbo].[spContract_List]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[spContract_List]
	@PersonID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	CREATE TABLE #temp
	([ID] INT, [DependentTypeId] INT, [DependentType] VARCHAR(50));
	
	INSERT INTO #temp ([ID],[DependentTypeId])
	SELECT CASE WHEN ptpl.[FromID] = @PersonID THEN ptpl.[ToID]
			  WHEN ptpl.[ToID] = @PersonID THEN ptpl.[FromID]
			  ELSE @PersonID
		 END as [PersonID],
		 ptpl.[DependentTypeId] as [DependentTypeId]
	FROM [dbo].[PersonToPersonLink] ptpl
	  WHERE ptpl.[FromID] = @PersonID OR ptpl.[ToID] = @PersonID
	  
	UPDATE #temp SET [DependentType] = t2.[Type]
	  FROM #temp t1 JOIN [dbo].[DependentType] t2 ON t1.DependentTypeId = t2.ID
	  
	INSERT INTO #temp ([ID],[DependentTypeId],[DependentType]) VALUES (@PersonID,0,'');
	
	SELECT t1.[ID]
	  ,t1.[Center]
	  ,t1.[Product]
      ,t1.[ContractNo]
      --,CASE WHEN ISNULL(t1.[ProductName],'') = '' THEN t2.[Product_SubType] ELSE t1.[ProductName] END as 'SUB_PRODUCT_NAME'
      ,dbo.fnProductSubName(t1.ID) as 'SUB_PRODUCT_NAME'
      ,t2.[SCRA_Code]
      ,t2.[ID] as [ContractTypeId]
      ,t1.[OpenDate]
      ,t1.[CloseDate]
      ,t3.[PersonID]
      ,t1.[LegacyNo]
      ,t5.[FirstName]
      ,t5.[LastName]
      ,t5.[MiddleInitial]
      ,t6.[DependentType]
      ,t1.[CardNo]
      ,t1.[Charge_Off]
      ,t1.[Charge_Off_Note]
  FROM [dbo].[Contract] t1 
	JOIN [dbo].[ContractType] t2 
		ON t1.[ContractTypeId] = t2.[ID]
    JOIN [dbo].[Customer] t3 
		ON t1.[PersonID] = t3.[PersonID] AND t3.PersonID IN (SELECT [ID] FROM #temp)
  	JOIN [dbo].[Person] t5
		ON t3.PersonID = t5.[ID]
	JOIN #temp t6 ON t3.PersonID = t6.[ID]
  WHERE t1.[IsDeleted] = 0 

END


/*

EXEC [dbo].[spContract_List] 22

*/

/*
UPDATE [SCRA_DB].[dbo].[Contract] 
	SET [SCRA_DB].[dbo].[Contract].[LegacyNo] = t4.[H1564_CTOLOCAL]
	FROM [SCRA_DB].[dbo].[Contract]  t1 
    JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC] t4 
		ON t1.Center = t4.H1564_IDCENT AND
			t1.Product = t4.H1564_IDPROD AND
			t1.ContractNo = t4.H1564_IDCONTRN
*/
GO

/****** Object:  StoredProcedure [dbo].[spEscalation_Update]    Script Date: 04/28/2020 11:50:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spEscalation_Update] 
	@Id int OUT,
	@PersonId int,
	@Notes varchar(max),
	@ModifiedBy int
AS   

    SET NOCOUNT ON;  
	BEGIN TRANSACTION   

	
	IF @ID = 0 BEGIN SET @ID = NULL END
	
	IF @ID IS NULL BEGIN

	    insert into dbo.Escalation(PersonId, Notes, ModifiedBy, Timestamp)
		values(@PersonId, @Notes, @ModifiedBy, GETDATE())

	END
	COMMIT TRANSACTION

GO


