﻿using System;
using System.IO;
using System.Windows;
using Scra.AppCore;
using Scra.Configs;
using Scra.Model.Logs;
using Scra.Model.Tools;
using Scra.Tools;
using Scra.Views.StartUp;

namespace Scra
{
    public partial class App
    {
        private readonly ILogger _logger;

        public App()
        {
            DiScraModule.Register();
            Di.Set<StartUpViewModel, StartUpViewModel>();
            _logger = Di.Get<ILogger>();
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            var navigator = Di.Get<AppNavigator>();
            navigator.StartUp();
            
            AppDomain.CurrentDomain.UnhandledException += CurrentDomainUnhandledException;

            Cleanup();
        }

        private void CurrentDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var ex = e.ExceptionObject as Exception;
            _logger.Error(ex, "Unhandled exception. Termination:" + e.IsTerminating);
            _logger.Close();
        }

        protected void App_Exit(object sender, ExitEventArgs e)
        {
            Cleanup();
        }

        private static void Cleanup()
        {
            var tempFolder = DirectoryUtility.GetTempDirectory();
            
            foreach (var file in Directory.GetFiles(tempFolder))
            {
                if (!File.Exists(file)) continue;
                if (!FileHelper.IsFileLocked(file))
                {
                    File.Delete(file);
                }
            }
        }
    }
}