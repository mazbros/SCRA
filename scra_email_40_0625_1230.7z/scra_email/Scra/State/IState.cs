﻿namespace Scra.State
{
    public interface IState
    {
        int StateId { get; set; }
    }
}