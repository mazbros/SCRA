﻿namespace Scra.State
{
    public class ShowTaskAct : IAct
    {
        public int TaskId { get; private set; }
        public string Code
        {
            get { return Act.SHOW_TASK; }
        }

        public object Argument { get; set; }

        public ShowTaskAct(int taskId)
        {
            TaskId = taskId;
        }

        public override string ToString()
        {
            return string.Format("{0}. TaskId={1}", Code, TaskId);
        }
    }
}
