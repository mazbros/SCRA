﻿using System;

namespace Scra.Extensions
{
    public static class DoubleExtension
    {
        private const double DEFAULT_PRECISE = 0.000000001;

        public static bool IsNotZero(this double value, double acceptableDifference = DEFAULT_PRECISE)
        {
            return Math.Abs(value) > acceptableDifference;
        }
    }
}
