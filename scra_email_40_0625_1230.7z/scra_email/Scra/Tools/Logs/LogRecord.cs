﻿using System;

namespace Scra.Tools.Logs
{
    internal class LogRecord : ILogRecord
    {
        public LogSeverity Severity { get; set; }
        public Exception Exception { get; set; }
        public string Message { get; set; }
    }
}