﻿using System.IO;
using System.Reflection;

namespace Scra.Tools
{
    public static class DirectoryUtility
    {
        private const string TEMP = "Temp";

        private static string GetCurrentDirectory()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        public static string GetTempDirectory()
        {
            var temp = Path.Combine(GetCurrentDirectory(), TEMP);
            if (!Directory.Exists(temp))
            {
                Directory.CreateDirectory(temp);
            }

            return temp;
        }
    }
}
