﻿using System.Windows;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public class PhoneNumberBlock : MaskBlock
    {
        public PhoneNumberBlock()
        {
            Setup(@"\d{3}-\d{3}-\d{4}", PhoneNumber.Empty().GetDisplay(), new[] { '-' });

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public PhoneNumber Value
        {
            get
            {
                var text = (string)GetValue(TextValueProperty);
                return PhoneNumber.Parse(text);
            }
            set
            {
                SetValue(ValueProperty, value);
                SetValue(TextValueProperty, value.GetDisplay());
            }
        }

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(PhoneNumber), typeof(PhoneNumberBlock),
            new FrameworkPropertyMetadata(PhoneNumber.Empty(), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ValueChange));

        private static void ValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var number = (PhoneNumber)e.NewValue;
            d.SetValue(TextValueProperty, number.GetDisplay());
        }

        protected override void InputTextChanged(string newValue)
        {
            var number = PhoneNumber.Parse(newValue);
            Value = number;
        }
    }
}
