﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Scra.Controls.MessageDialog
{
    public partial class MessageDialogView
    {
        private static MessageDialogView _messageBox;
        private static MessageBoxResult _result = MessageBoxResult.No;

        public MessageDialogView()
        {
            InitializeComponent();
        }

        public static MessageBoxResult Show(string caption, string text, MessageBoxButton button, MessageDialogImage image)
        {
            _messageBox = new MessageDialogView { TxtMsg = { Text = text }, MessageTitle = { Text = caption } };
            SetVisibilityOfButtons(button);
            SetImageOfMessageBox(image);
            _messageBox.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            _messageBox.ShowDialog();
            return _result;
        }

        public static MessageBoxResult Show(string text, MessageBoxButton button, MessageDialogImage image)
        {
            return Show(GetCaptionByImageType(image), text, button, image);
        }

        private static string GetCaptionByImageType(MessageDialogImage image)
        {
            switch (image)
            {
                case MessageDialogImage.Error:
                    return "Error";
                case MessageDialogImage.Information:
                    return "Information";
                case MessageDialogImage.Ok:
                    return "Ok";
                case MessageDialogImage.Question:
                    return "Question";
                case MessageDialogImage.Warning:
                    return "Warning";
                default:
                    return "Error";
            }
        }

        private static void SetVisibilityOfButtons(MessageBoxButton button)
        {
            switch (button)
            {
                case MessageBoxButton.OK:
                    _messageBox.BtnCancel.Visibility = Visibility.Collapsed;
                    _messageBox.BtnNo.Visibility = Visibility.Collapsed;
                    _messageBox.BtnYes.Visibility = Visibility.Collapsed;
                    _messageBox.BtnOk.Focus();
                    break;
                case MessageBoxButton.OKCancel:
                    _messageBox.BtnNo.Visibility = Visibility.Collapsed;
                    _messageBox.BtnYes.Visibility = Visibility.Collapsed;
                    _messageBox.BtnCancel.Focus();
                    break;
                case MessageBoxButton.YesNo:
                    _messageBox.BtnOk.Visibility = Visibility.Collapsed;
                    _messageBox.BtnCancel.Visibility = Visibility.Collapsed;
                    _messageBox.BtnNo.Focus();
                    break;
                case MessageBoxButton.YesNoCancel:
                    _messageBox.BtnOk.Visibility = Visibility.Collapsed;
                    _messageBox.BtnCancel.Focus();
                    break;
            }
        }

        private static void SetImageOfMessageBox(MessageDialogImage image)
        {
            switch (image)
            {
                case MessageDialogImage.Warning:
                    _messageBox.SetImage("warning.png");
                    break;
                case MessageDialogImage.Information:
                    _messageBox.SetImage("information.png");
                    break;
                case MessageDialogImage.Error:
                    _messageBox.SetImage("error.png");
                    break;
                case MessageDialogImage.Ok:
                    _messageBox.SetImage("ok.png");
                    break;
                case MessageDialogImage.Question:
                    _messageBox.SetImage("warning.png");
                    break;
                default:
                    _messageBox.Img.Visibility = Visibility.Collapsed;
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender.Equals(BtnOk))
                _result = MessageBoxResult.OK;
            else if (sender.Equals(BtnYes))
                _result = MessageBoxResult.Yes;
            else if (sender.Equals(BtnNo))
                _result = MessageBoxResult.No;
            else if (sender.Equals(BtnCancel))
                _result = MessageBoxResult.Cancel;
            else
                _result = MessageBoxResult.None;

            if (_messageBox != null)
            {
                _messageBox.Close();
                _messageBox = null;
            }
        }

        private void SetImage(string imageName)
        {
            var uri = "/Images/MessageDialog/" + imageName;
            var uriSource = new Uri(uri, UriKind.RelativeOrAbsolute);
            Img.Source = new BitmapImage(uriSource);
        }
    }
}
