using System;
using System.Globalization;
using System.Windows.Data;
using Scra.Model.Persons;

namespace Scra.Controls.Converters
{
    public class AddressFormatConverter: IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return null;

            var addr = (Address) value;
            return addr.GetFullOneLine();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}