﻿using System.Windows;
using System.Windows.Input;

namespace Scra.Views.Benefits
{
    public partial class ServicememberInformationView
    {
        public ServicememberInformationView()
        {
            InitializeComponent();  
        }

        public ServicememberInformationViewModel GetViewModel()
        {
            return (ServicememberInformationViewModel)DataContext;
        }


        private void ListView_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectedCommand.Execute(null);
        }
    }
}
