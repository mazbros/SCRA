﻿using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class DenialReasonViewModel : BaseViewModel
    {
        private readonly ShellViewModel _shellViewModel;
        private string _denialReason;
        private bool _isDenialReasonEntered;

        public DenialReasonViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _shellViewModel = Di.Get<ShellViewModel>();

            OnViewLoaded = OnLoaded;
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
        }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public string DenialReason
        {
            get { return _denialReason; }
            set
            {
                SetProperty(ref _denialReason, value);
                IsDenialReasonEntered = value.IsNotEmpty();
            }
        }

        public bool IsDenialReasonEntered
        {
            get { return _isDenialReasonEntered; }
            set { SetProperty(ref _isDenialReasonEntered, value); }
        }

        private void Cancel()
        {
            CloseView();
        }

        private void Save()
        {
            _shellViewModel.IsUiBusy = true;
            var benefit = (Benefit)Arguments;

            benefit.DenialReason = DenialReason;
            CloseView();

            _shellViewModel.IsUiBusy = false;

        }

        private void OnLoaded()
        {

        }
    }
}
