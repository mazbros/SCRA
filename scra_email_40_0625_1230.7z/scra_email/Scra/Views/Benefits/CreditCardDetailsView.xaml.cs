﻿using System.Windows;
using System.Windows.Controls;


namespace Scra.Views.Benefits
{
    public partial class CreditCardDetailsView
    {
        public CreditCardDetailsView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ContractSnapshot = ContractSnapshotView.GetViewModel();
        }

        public CreditCardDetailsViewModel GetViewModel()
        {
            return (CreditCardDetailsViewModel) DataContext;
        }
    }
}
