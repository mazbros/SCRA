﻿using System.Windows.Controls;

namespace Scra.Views.Reports
{
    /// <inheritdoc cref="UserControl" />
    /// <summary>
    /// Interaction logic for ReportsListView.xaml
    /// </summary>
    public partial class ReportsListView
    {
        public ReportsListView()
        {
            InitializeComponent();
        }
    }
}
