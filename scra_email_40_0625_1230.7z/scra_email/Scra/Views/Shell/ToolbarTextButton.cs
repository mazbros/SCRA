﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Scra.Views.Shell
{
    public class ToolbarTextButton : Button
    {
        public ToolbarTextButton()
        {
            var isSelectedBinding = new Binding
            {
                Source = this,
                Path = new PropertyPath("Props.IsSelected"),
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            BindingOperations.SetBinding(this, IsSelectedProperty, isSelectedBinding);

            var isEnabledBinding = new Binding
            {
                Source = this,
                Path = new PropertyPath("Props.IsEnabled"),
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            BindingOperations.SetBinding(this, IsEnabledProperty, isEnabledBinding);

            var commandBinding = new Binding
            {
                Source = this,
                Path = new PropertyPath("Props.Command"),
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            BindingOperations.SetBinding(this, CommandProperty, commandBinding);

            var visibilityBinding = new Binding
            {
                Source = this,
                Path = new PropertyPath("Props.Visibility"),
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            BindingOperations.SetBinding(this, VisibilityProperty, visibilityBinding);
        }

        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }
        public static readonly DependencyProperty IsSelectedProperty = DependencyProperty.Register(
            "IsSelected", typeof(bool), typeof(ToolbarTextButton), new FrameworkPropertyMetadata(false)
        );

        public ToolbarTextButtonProps Props
        {
            get { return (ToolbarTextButtonProps)GetValue(PropsProperty); }
            set { SetValue(PropsProperty, value); }
        }
        public static readonly DependencyProperty PropsProperty = DependencyProperty.Register(
            "Props", typeof(ToolbarTextButtonProps), typeof(ToolbarTextButton), new FrameworkPropertyMetadata(new ToolbarTextButtonProps())
        );
    }
}