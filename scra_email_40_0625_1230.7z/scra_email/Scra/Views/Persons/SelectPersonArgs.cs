﻿using System;
using System.Collections.Generic;
using Scra.Model.Persons;

namespace Scra.Views.Persons
{
    public class SelectPersonArgs
    {
        public Action<PersonId> OnSuccess { get; set; }

        public string Message { get; set; }
        public PersonId SelectedPersonId { get; set; }
        public IList<Person> PeopleList { get; set; }
        public Decision Decision { get; set; }
    }

    public enum Decision
    {
        AddNew = 0,
        SelectOne,
        Cancel
    }
}