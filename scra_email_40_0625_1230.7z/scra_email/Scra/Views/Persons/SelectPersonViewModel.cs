﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.Persons
{
    public class SelectPersonViewModel : BaseViewModel
    {
        private readonly IPersonRepository _repository;
        private IList<PersonListItem> _items;
        private PersonListItem _selectedPerson;
        private string _searchText;
        private Action _successAction;
        private AppNavigator _navigator;

        public SelectPersonViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            _repository = Di.Get<IPersonRepository>();
            OnViewLoaded = OnLoaded;
            AddCommand = new Command(AddPerson);
            SelectPersonCommand = new Command(SelectPerson);
            SearchCommand = new Command(Search);
            CancelCommand = new Command(Cancel);

            IsPersonSelected = false;
            OnViewClosed = OnClosed;
        }

        public ICommand SelectPersonCommand { get; set; }
        public ICommand SearchCommand { get; set; }
        public ICommand AddCommand { set; get; }
        public ICommand CancelCommand { get; set; }
        public SelectPersonArgs Argument { get; set; }

        public string SearchText
        {
            get { return _searchText; }
            set { SetProperty(ref _searchText, value); }
        }

        public IList<PersonListItem> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public PersonListItem SelectedPerson
        {
            get { return _selectedPerson; }
            set
            {
                SetProperty(ref _selectedPerson, value);
                IsPersonSelected = true;
                UpdateAll();
            }
        }

        public bool IsAddMode { get; set; }
        public bool IsPersonSelected { get; set; }
        public string Message { get; set; }

        private async void AddPerson()
        {
            if (IsAddMode)
            {
                _navigator.AddPerson();
                await ReloadList();
            }
            else
            {
                Argument.Decision = Decision.AddNew;
                CloseView();
            }
        }

        private async void Search()
        {
            await ReloadList();
        }

        private void Cancel()
        {
            Argument.Decision = Decision.Cancel;
            CloseView();
        }

        private void OnClosed()
        {
            if (_successAction == null)
            {
                return;
            }
            _successAction();
        }

        private void SelectPerson()
        {
            if (_selectedPerson == null)
            {
                return;
            }

            if (Argument.PeopleList == null)
            {
                _successAction = () => Argument.OnSuccess(_selectedPerson.Id);
            }
            else
            {
                Argument.SelectedPersonId = _selectedPerson.Id;
            }

            Argument.Decision = Decision.SelectOne;
            CloseView();
        }

        private async void OnLoaded()
        {
            await ReloadList();
        }

        private async Task ReloadList()
        {
            Argument = (SelectPersonArgs)Arguments;
            if (Argument.PeopleList == null)
            {
                IsAddMode = true;
                var models = await _repository.Load(SearchText);
                Items = models.Select(PersonListItem.Create).ToList();
            }
            else
            {
                IsAddMode = false;
                Argument.Decision = Decision.AddNew;
                Message = Argument.Message;
                Items = Argument.PeopleList.Select(PersonListItem.CreateSimple).ToList();                
            }

            UpdateAll();
        }
    }
}
