﻿using Scra.Tools;

namespace Scra.Views.Tasks
{
    public partial class TaskQaAssigneeSwitcher
    {
        public TaskQaAssigneeSwitcher()
        {
            InitializeComponent();
            Loaded += TaskAssigneeSwitcher_Loaded;
        }

        private void TaskAssigneeSwitcher_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            TaskListItem vm;
            if (TryCast.Cast<TaskListItem>(DataContext, out vm))
            {
                if (vm.QaAssignee is TaskAssigneeAdminControlModel)
                {
                    var view = new TaskAssigneeAdminControl {DataContext = vm.QaAssignee};
                    Panel.Children.Add(view);
                }
                else
                {
                    var view = new TaskAssigneeControl {DataContext = vm.QaAssignee};
                    Panel.Children.Add(view);
                }
            }
        }
    }
}
