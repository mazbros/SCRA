﻿using Scra.AppCore;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;
using Scra.Tools;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.InquiryTypes;
using Scra.Views.Shell;

namespace Scra.Views.Tasks
{
    public class TaskListViewModel : BaseViewModel, IDisposable
    {
        private readonly ITaskRepository _taskRepository;
        private TaskListItem _selectedItem;
        private readonly AppNavigator _navigator;
        private readonly Action _unsubscribeFromFlowStatusChange;

        private readonly IUser _user;
        private readonly IUiThread _uiThread;
        private int _taskId;
        private readonly ShellViewModel _isUiBusy;
        private readonly ShellViewModel _shellViewModel;
        private string _searchText;
        //private string _direction;
        private readonly IMessageDialog _messageDialog;
        private IList<TaskListItem> _items;
        private IList<TaskListItem> _pagedItems;
        private readonly IDispatcher _dispatcher;

        private int _pageIndex;

        private int _pageSize;
        private int _itemLow;
        private int _itemHigh;
        private bool _isPreviousEnabled;
        private bool _isNextEnabled;
        private string _pagingStats;
        private int _page;

        public TaskListViewModel()
        {
            if (InDesignMode())
            {
                return;
            }
            SubTaskIdentifier = SubTaskType.Qa;

            _taskRepository = Di.Get<ITaskRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            SelectCommand = new Command(Select);
            _navigator = Di.Get<AppNavigator>();
            _uiThread = Di.Get<IUiThread>();
            var store = Di.Get<IAppStore>();
            _user = Di.Get<IUser>();
            _isUiBusy = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();

            _unsubscribeFromFlowStatusChange = store.SubscribeCommand(Act.TASK_STATUS_CHANGED, OnTaskStatusChanged);

            Items = new ObservableCollection<TaskListItem>();
            _shellViewModel = Di.Get<ShellViewModel>();
            //_direction = "Ascending";

            OnViewLoaded = OnLoaded;

            ClearFilterCommand = new Command(ClearFilter);

            SearchCommand = new Command(Search);
            ClearCommand = new Command(ClearSearch);

            PreviousCommand = new Command(Previous);
            NextCommand = new Command(Next);

            RequestTypesFilter = new ObservableCollection<TaskType>();
            TaskStatusFilter = new ObservableCollection<TascStatus>();
            Filters = new LoadTasksFilter();

             Pages = new ObservableCollection<int> {5, 10, 15, 20, 25};

            IsAllStatusChecked = true;
            IsAllAssigneeChecked = true;
        }

        public ICommand SelectCommand { get; set; }

        public bool IsQaCompletedChecked { get; set; }
        public bool IsRejectedChecked { get; set; }
        public bool IsMisdirectedChecked { get; set; }
        public bool IsAllAssigneeChecked { get; set; }
        public bool IsMineChecked { get; set; }
        public bool IsUnassignedChecked { get; set; }
        public bool IsAllStatusChecked { get; set; }
        public bool IsInProgressChecked { get; set; }
        public bool IsCompletedChecked { get; set; }

        public ICommand ClearFilterCommand { get; set; }
        public bool IsFilterAvailable { get; set; }   
        
        public ICommand SearchCommand { get; set; }
        public ICommand ClearCommand { get; set; }

        public ICommand PreviousCommand { get; set; }
        public ICommand NextCommand { get; set; }
        public SubTaskType SubTaskIdentifier { get; private set; }
        public ObservableCollection<int> Pages { get; set; }

        public ObservableCollection<TaskType> RequestTypesFilter { get; set; }
        public TaskType SelectedRequestTypeFilter { get; set; }

        public ObservableCollection<TascStatus> TaskStatusFilter { get; set; }
        public TascStatus SelectedTaskStatusFilter { get; set; }

        public IList<User> TaskAgentsFilter { get; set; }
        public User SelectedTaskAgentsFilter { get; set; }

        public IList<User> QaAgentsFilter { get; set; }
        public User SelectedQaAgentsFilter { get; set; }

        public UserList UserList { get; private set; }
        public LoadTasksFilter Filters { get; set; }

        private void ClearFilter()
        {
            SelectedRequestTypeFilter = TaskType.Empty;
            SelectedTaskStatusFilter = TascStatus.Empty;
            SelectedTaskAgentsFilter = User.Empty;
            SelectedQaAgentsFilter = User.Empty;
            Filters = new LoadTasksFilter();
            ApplyFilterHandler();
        }

        public void ApplyTypeFilter()
        {
            if (SelectedRequestTypeFilter == TaskType.Empty)
            {
                Filters.Types = null;
            }
            else
            {
                Filters.Types = new List<TaskType>
                {
                    SelectedRequestTypeFilter
                };               
            }
            ApplyFilterHandler();
        }

        public void ApplyStatusFilter()
        {
            if (SelectedTaskStatusFilter == TascStatus.Empty)
            {
                Filters.Statuses = null;
            }
            else
            {
                Filters.Statuses = new List<TascStatus>()
                {
                    SelectedTaskStatusFilter
                };
            }
            ApplyFilterHandler();
        }

        public void ApplyTaskAssigneeFilter()
        {
            Filters.AssigneeId = SelectedTaskAgentsFilter.Id;
            ApplyFilterHandler();
        }

        public void ApplyQaAssigneeFilter()
        {
            Filters.QaAssigneeId = SelectedQaAgentsFilter.Id;
            ApplyFilterHandler();
        }

        public IList<TaskListItem> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public IList<TaskListItem> PagedItems
        {
            get { return _pagedItems; }
            set { SetProperty(ref _pagedItems, value); }
        }

        private async void Next()
        {
            await ReloadList(NextCommand);
        }

        private async void Previous()
        {
            await ReloadList(PreviousCommand);
        }

        public int Page
        {
            get { return _page; } 
            set { SetProperty(ref _page, value); }
        }

        public bool IsPreviousEnabled
        {
            get { return _isPreviousEnabled; }
            set { SetProperty(ref _isPreviousEnabled, value); }
        }

        public bool IsNextEnabled
        {
            get { return _isNextEnabled; }
            set { SetProperty(ref _isNextEnabled, value); }
        }

        public string PagingStats
        {
            get { return _pagingStats; }
            set { SetProperty(ref _pagingStats, value); }
        }

        public string SearchText
        {
            get { return _searchText; }
            set { SetProperty(ref _searchText, value); }
        }
        
        private void OnTaskStatusChanged(IAct obj)
        {
            _uiThread.Execute(ReloadListSync);
        }

        private void Select()
        {
            if (SelectedItem == null)
            {
                return;
            }
            _navigator.Task(SelectedItem.Id);
        }

        private async void Search()
        {
            await ReloadList(null);

            UpdatePages();

            Page = Items.Count;
        }

        private void UpdatePages()
        {
            _uiThread.Execute(() =>
            {
                Pages.Clear();

                var i = 5;

                if (i < Items.Count)
                {
                    Pages.Add(i);

                    while (i <= Items.Count)
                    {
                        i = +i <= 25 ? i + 5 :
                            i == 50 ? i + 50 :
                            i == 100 ? i + 100 :
                            i == 200 ? i + 300 :
                            i >= 500 ? i + 500 :
                            i + 10;

                        if (i >= Items.Count) break;

                        Pages.Add(i);
                    }

                    Pages.Add(Items.Count);
                    //Page = Pages.Count >= 3 ? Pages[2] : Pages[0];
                }
                else
                {
                    Pages.Add(Items.Count);
                    //Page = Items.Count;
                }

                UpdateAll();
            });
        }

        private void ClearSearch()
        {
            SearchText = string.Empty;
            Search();
        }

        private async void OnLoaded()
        {
            var task = (IdArgs) Arguments;
            _taskId = task == null ? 0 : task.Id;
            if(_taskId == 0)
                _navigator.CloseLeftPanel();

            _isUiBusy.IsUiBusy = true;
           
            _pageIndex = -1;

            UserList = await UserList.GetInstance();

            FillRequestTypeFilters();
            FillTaskStatusFilters();
            FillUserFilters();

            await ReloadList(null);

            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));

            UpdatePages();

            Page = Items.Count;
        }

        private async void ApplyFilterHandler()
        {
            _isUiBusy.IsUiBusy = true;
            await ReloadList(null);

            _isUiBusy.IsUiBusy = false;
        }

        public TaskListItem SelectedItem
        {
            get { return _selectedItem; }
            set { SetProperty(ref _selectedItem, value); }
        }

        
        private async void ReloadListSync()
        {
            await ReloadList(null);
        }

        private void FillRequestTypeFilters()
        {
            RequestTypesFilter.Update(TaskType.RequestTypeList);
        }

        private void FillTaskStatusFilters()
        {
            TaskStatusFilter.Update(TascStatus.TascStatusList);
        }

        private void FillUserFilters()
        {
            var users = UserList.AllNotReadOnly().ToList();
            users.Insert(0, User.Empty);
            
            TaskAgentsFilter = users.ToList();
            QaAgentsFilter = users.ToList();
        }

        public async Task ReloadList(ICommand command)
        {           
            IsFilterAvailable = _taskId == 0;
            if(_taskId != 0 )
                Filters.TaskId = _taskId;

            var models = await _taskRepository.Load(Filters, SearchText);
            var assigneeFactory = Di.Get<TaskAssigneeControlModelFactory>();
            
            var items = models.Select(x => TaskListItem.Create(x, assigneeFactory, UserList, Reload, QaSelected));

            Items = items.ToList();

            try
            {
                _shellViewModel.IsUiBusy = true;

                _pageSize = Items.Count;//Page;

                if (command == null)
                {
                    _pageIndex = 0;
                }

                if (command == NextCommand)
                {
                    _pageIndex++;
                }

                if (command == PreviousCommand)
                {
                    _pageIndex--;
                }

                _pagedItems = _items.Count >= _pageSize ? _items.Skip(_pageIndex * _pageSize).Take(_pageSize).ToList() : _items;

                if (_pageIndex < 1)
                {
                    _itemLow = 1;
                    _itemHigh = _items.Count <= _pageSize ? _items.Count : _pageSize;
                    _isPreviousEnabled = false;
                    _isNextEnabled = _itemHigh != _items.Count;
                }
                else
                {
                    _itemLow = _pageIndex * (_items.Count <= _pageSize ? 0 : _pageSize) + 1;

                    _itemHigh = _items.Count <= _pageSize ? _items.Count :
                        _itemLow + _pageSize - 1 >= _items.Count ? _items.Count : _itemLow + _pageSize - 1;

                    _isPreviousEnabled = true;
                    _isNextEnabled = _itemHigh != _items.Count;
                }

                //_pagingStats = _itemLow + " - " + _itemHigh + " of " + Items.Count;
                _pagingStats = "" + Items.Count + (Items.Count.ToString().EndsWith("1") ? " record" :" records");
                PagingStats = _pagingStats;
                if (PreviousCommand != null) PreviousCommand.CanExecute(_isPreviousEnabled);
                if (NextCommand != null) NextCommand.CanExecute(_isNextEnabled);

                PagedItems = _pagedItems.ToList();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during loading.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
                UpdateAll();
            }
        }

        private async void QaSelected()
        {
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
            await _dispatcher.DispatchAsync(new ReloadTaskAct(_taskId));
            Reload();
        }

        private async void Reload()
        {
            await ReloadList(null);
        }

        private LoadTasksFilter GetFilter()
        {
            var statuses = new List<TascStatus>();

            if (IsInProgressChecked)
            {
                statuses.Add(TascStatus.InProcess);
            }
            if (IsCompletedChecked)
            {
                statuses.Add(TascStatus.Completed);
            }
            if (IsQaCompletedChecked)
            {
                statuses.Add(TascStatus.QaCompleted);
            }
            if (IsRejectedChecked)
            {
                statuses.Add(TascStatus.Rejected);
            }
            if (IsMisdirectedChecked)
            {
                statuses.Add(TascStatus.Misdirected);
            }

            var filter = new LoadTasksFilter
            {
                Statuses = statuses,
                HideAssigned = IsUnassignedChecked,
                AssigneeId = IsMineChecked ? _user.Id : UserId.Empty,
                QaAssigneeId = IsMineChecked ? _user.Id : UserId.Empty
            };
            return filter;
        }

        public void Dispose()
        {
            if (_unsubscribeFromFlowStatusChange != null)
            {
                _unsubscribeFromFlowStatusChange();
            }
        }
    }
}