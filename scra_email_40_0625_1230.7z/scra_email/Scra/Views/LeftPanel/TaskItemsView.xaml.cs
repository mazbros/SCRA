﻿namespace Scra.Views.LeftPanel
{
    public partial class TaskItemsView
    {
        public TaskItemsView()
        {
            InitializeComponent();
        }
    }
}
