﻿namespace Scra.Views.LeftPanel
{
    /// <summary>
    /// Interaction logic for PersonListView.xaml
    /// </summary>
    public partial class PersonHistoryListView
    {
        public PersonHistoryListView()
        {
            InitializeComponent();
        }

    }
}
