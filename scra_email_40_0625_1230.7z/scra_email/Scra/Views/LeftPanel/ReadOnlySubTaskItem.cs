﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Tasks;
using Scra.Model.Users;

namespace Scra.Views.LeftPanel
{
    public class ReadOnlySubTaskItem
    {
        public string Title { get; set; }
        public string CompletionDate { get; set; }
        public string CompleteBy { get; set; }
        public bool IsQaPerformed { get; set; }
        public bool IsQaComplete { get; set; }
        public bool IsRejected { get; set; }
        public string QaCompleteBy { get; set; }
        public string QaCompletionDate { get; set; }
        public ICommand TitleClicked { get; set; }
        public bool IsQaAvailable { get; set; }
        public bool IsQaToolTipVisible { get; set; }

        public static CompleteSubTaskItem Create(SubTask item, IUser currentUser, Tasc tasc, Action loadRelatedPage)
        {
            var status = item.Status;
            var completion = item.Completion;
            var qaCompletion = item.QaCompletion;

            var isQaReady = status == SubTaskStatus.Completed;

            var completeSubTaskItem = new CompleteSubTaskItem()
            {
                Title = item.ItemId + ". " + item.Title,
                TitleClicked = new Command(loadRelatedPage),

                CompletionDate = completion == null ? null : Formatter.DateTime(completion.Time),
                CompleteBy = completion == null ? "In Process" : "Task performed by: " + completion.User.DisplayName,

                
                IsQaPerformed = status == SubTaskStatus.QaCompleted || status == SubTaskStatus.Rejected,
                IsQaComplete = status == SubTaskStatus.QaCompleted,
                IsRejected = status == SubTaskStatus.Rejected,

                QaCompletionDate = qaCompletion == null ? null : Formatter.DateTime(qaCompletion.Time),
                QaCompleteBy = qaCompletion == null ? "In Process" : "QA performed by: " + qaCompletion.User.DisplayName,

            };
            return completeSubTaskItem;
        }
    }
}