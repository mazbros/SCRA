﻿using System;
using System.Windows.Input;
using Scra.AppCore;

namespace Scra.Views.LeftPanel
{
    public class ModifiedRecordVm
    {
        public int Id { get; private set; }
        public string FullName { get; set; }
        public ICommand NameClicked { get; set; }
        public DateTime? Timestamp { get; set; }

        public static ModifiedRecordVm Create(int id, string fullName, DateTime? timestamp, Action<int>action)
        {
            var record = new ModifiedRecordVm
            {
                Id = id,
                FullName = fullName,
                Timestamp = timestamp,
                NameClicked = new Command(()=>action(id)),
            };

            return record;
        }
    }
}