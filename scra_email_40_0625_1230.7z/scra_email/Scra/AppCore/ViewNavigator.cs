﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Scra.Controls.MessageDialog;
using Scra.Extensions;
using Scra.Model.Logs;
using Scra.Views.Shell;

namespace Scra.AppCore
{
    public class ViewNavigator : IViewNavigator
    {
        private readonly ILogger _logger;
        private readonly IMessageDialog _messageDialog;
        private IList<Type> _viewTypes;
        private IShell _shell;
        private UserControl _currentView;

        private readonly Stack<Tuple<Type, object>> _history = new Stack<Tuple<Type, object>>();

        public ViewNavigator(ILogger logger, IMessageDialog messageDialog)
        {
            _logger = logger;
            _messageDialog = messageDialog;
        }

        public void ShowDialog<T>(object args = null) where T : IViewModel
        {
            var view = CreateView<T>();
            var window = WrapToWindow(view);
            LinkArgs(window, args);
            LinkWindowToViewModel(window, view);

            try
            {
                window.ShowDialog();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Open " + typeof(T));
                _messageDialog.Warning("Error during opening window.");
            }
        }

        public T CreateControl<T>(object args) where T : IViewModel
        {
            var window = CreateControlView<T>();
            LinkArgs(window, args);
            var viewModel = LinkControlToViewModel(window);
            return (T)(object)viewModel;
        }

        public void Show<T>(object args = null) where T : IViewModel
        {
            SaveHistory<T>(args);
            var userControl = ShowView<T>(args);
            DisposeView(_currentView);
            _currentView = userControl;
        }

        public void Setup(IShell shell)
        {
            _shell = shell;
        }

        public void ShowMainWindow<T>() where T : IViewModel
        {
            var view = CreateView<T>();
            var window = WrapToWindow(view);
            LinkWindowToViewModel(window, view);

            Application.Current.MainWindow = window;
            window.Show();
        }

        public void Back()
        {
            if (_history.Count < 2)
            {
                return;
            }

            var method = GetType().GetMethod("Show");
            if (method == null)
            {
                throw new InvalidOperationException("Expected method Show");
            }

            _history.Pop();
            var prev = _history.Pop();

            var genericMethod = method.MakeGenericMethod(prev.Item1);
            genericMethod.Invoke(this, new []{ prev.Item2 });
        }

        public UserControl ShowView<T>(object args) where T : IViewModel
        {
            var view = (UserControl)CreateView<T>();
            LinkControlToViewModel(view);
            _shell.ShowChild(view);
            var vm = view.DataContext as BaseViewModel;
            if (vm != null)
            {
                vm.Arguments = args;
                if (vm.OnViewLoaded != null)
                {
                    vm.OnViewLoaded();
                }
            }

            return view;
        }

        private void DisposeView(UserControl control)
        {
            if (control == null)
            {
                return;
            }
            var vm = control.DataContext as BaseViewModel;
            if (vm != null && vm.OnViewClosed != null)
            {
                vm.OnViewClosed();
            }

            var disposable = control.DataContext as IDisposable;
            if (disposable != null)
            {
                disposable.Dispose();
            }
        }

        private void SaveHistory<T>(object args) where T : IViewModel
        {
            _history.Push(new Tuple<Type, object>(typeof(T), args));
        }

        private ContentControl CreateControlView<T>()
        {
            var viewType = GetViewType<T>();
            return Activator.CreateInstance(viewType) as ContentControl;
        }

        private object CreateView<T>()
        {
            var viewType = GetViewType<T>();
            return Activator.CreateInstance(viewType);
        }

        private Window WrapToWindow(object view)
        {
            var window = view as Window;
            if (window != null)
            {
                return window;
            }
            return CreateWindow((UserControl)view);
        }

        private Window CreateWindow(UserControl view)
        {
            var mainWindow = Application.Current.MainWindow;
            var window = new Window
            {
                Content = view,
                ShowInTaskbar = false,
                ResizeMode = ResizeMode.NoResize,
                DataContext = view.DataContext,
                WindowStyle = WindowStyle.None
            };
            if (view.Height.IsNotZero())
            {
                window.Height = view.Height;
                window.Width = view.Width;
            }
            if (view.MaxWidth.IsNotZero())
            {
                window.MaxWidth = view.MaxWidth;
            }
            if (view.MaxHeight.IsNotZero())
            {
                window.MaxHeight = view.MaxHeight;
            }
            if (mainWindow != null)
            {
                window.Owner = mainWindow;
                window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            }
            else
            {
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            }

            return window;
        }

        private Type GetViewType<T>()
        {
            var viewTypes = GetViewTypes();
            var viewName = getViewName<T>();
            return viewTypes.First(x => x.Name == viewName);
        }

        private string getViewName<T>()
        {
            var name = typeof(T).Name.Replace("ViewModel", "");
            return name + "View";
        }

        private void LinkWindowToViewModel(Window window, object view)
        {
            var viewModel = window.DataContext as BaseViewModel;
            if (viewModel == null)
            {
                return;
            }

            viewModel.CloseView = window.Close;
            viewModel.View = view;
            var viewModelTypeName = viewModel.GetType().Name;

            if (viewModel.OnViewLoaded != null)
            {
                window.Loaded += (s, a) =>
                {
                    try
                    {
                        if (viewModel.OnViewLoaded != null)
                        {
                            viewModel.OnViewLoaded();
                        }
                    }
                    catch (Exception ex)
                    {
                        var message = string.Format("VM {0} Load", viewModelTypeName);
                        _logger.Error(ex, message);
                    }
                };
            }
            if (viewModel.OnViewClosed != null)
            {
                window.Closed += (s, a) =>
                {
                    try
                    {
                        if (viewModel.OnViewClosed != null)
                        {
                            viewModel.OnViewClosed();
                        }
                    }
                    catch (Exception ex)
                    {
                        var message = string.Format("VM {0} Closed", viewModelTypeName);
                        _logger.Error(ex, message);
                    }
                };
            }
        }

        private ControlViewModel LinkControlToViewModel(ContentControl window)
        {
            var viewModel = window.DataContext as ControlViewModel;
            if (viewModel == null)
            {
                return null;
            }

            viewModel.View = window;
            return viewModel;
        }

        private void LinkArgs(Window window, object args)
        {
            if (args == null)
            {
                return;
            }

            var viewModel = window.DataContext as BaseViewModel;
            if (viewModel == null)
            {
                return;
            }

            viewModel.Arguments = args;
        }

        private void LinkArgs(ContentControl window, object args)
        {
            if (args == null)
            {
                return;
            }
            var viewModel = window.DataContext as ControlViewModel;
            if (viewModel == null)
            {
                return;
            }

            viewModel.Arguments = args;
        }

        private IList<Type> GetViewTypes()
        {
            if (_viewTypes == null)
            {
                _viewTypes = typeof(App)
                    .Assembly
                    .GetTypes()
                    .Where(x => x.IsSubclassOf(typeof(UserControl)) || x.IsSubclassOf(typeof(Window)))
                    .ToList();
            }
            return _viewTypes;
        }

        public void ShutDown()
        {
            Application.Current.Dispatcher.InvokeAsync(() =>
            {
                Application.Current.Shutdown();
            });
        }
    }
}