﻿using Scra.Model.DomainEvents;

namespace Scra.Model.Inquiries
{
    public class InquiryAcknowledgeEvent : IDomainEvent
    {
        public int InquiryId { get; private set; }

        public InquiryAcknowledgeEvent(int inquiryId)
        {
            InquiryId = inquiryId;
        }

        public override string ToString()
        {
            return "InquiryAcknowledgeEvent InquiryId=" + InquiryId;
        }
    }
}