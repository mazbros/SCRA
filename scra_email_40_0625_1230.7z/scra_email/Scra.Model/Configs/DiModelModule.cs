﻿using Scra.Model.DomainEvents;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Model.Configs
{
    public class DiModelModule
    {
        public static void Register()
        {
            Di.Set<IDomainEventDispatcher, DomainEventDispatcher>();
            Di.Set<ITascFactory, TascFactory>();
            Di.Set<InquirySubTascFactory>();
        }
    }
}
