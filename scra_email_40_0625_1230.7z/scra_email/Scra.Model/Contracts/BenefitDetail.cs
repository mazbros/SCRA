﻿using System;

namespace Scra.Model.Contracts
{
    public class BenefitDetail
    {
        public int Id { get; set; }
        public int BenefitId { get; set; }
        public decimal CurrentRate { get; set; }
        public DateTime? DmiSentDate { get; set; }
        public DateTime? ConfirmationReceivedDate { get; set; }
        public bool IsPromotionalOffer { get; set; }
        public DateTime? PromotionEndDate { get; set; }
        public bool IsRateCapPerformed { get; set; }
        public bool IsFeeWaived { get; set; }
        public decimal FeeRefundAmount { get; set; }
        public DateTime? DateFeesRefunded { get; set; }
        public bool IsStatementsPending { get; set; }
        public bool IsInterestAdjustmentCalculated { get; set; }
        public decimal InterestRefunded { get; set; }
        public DateTime? RefundDate { get; set; }
        public DateTime? BenefitAppliedDate { get; set; }
        public DateTime? DateBenefitExpected { get; set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public DateTime? ExpectedRemovalDate { get; set; }
        public DateTime? BenefitRemovedDate { get; set; }
        public bool Block41 { get; set; }
                
        
        public DateTime? StatementDate { get; set; }
        public static BenefitDetail Empty = new BenefitDetail();

        public BenefitDetail()
        {

        }

        public BenefitDetail(int id, int benefitId, decimal currentRate, bool block41, DateTime? dmiSentDate,
            DateTime? confirmationReceivedDate, bool isPromotionalOffer, DateTime? promotionEndDate,
            bool isRateCapPerformed, bool isFeeWaived, decimal feeRefundAmount, DateTime? dateFeesRefunded,
            bool isStatementsPending, DateTime? statementDate, bool isInterestAdjustmentCalculated,
            decimal interestRefunded, DateTime? refundDate,
            DateTime? benefitAppliedDate, 
            DateTime? dateBenefitExpected, 
            DateTime? benefitEffectiveDate, 
            DateTime? expectedRemovalDate,
            DateTime? benefitRemovedDate)
        {
            Id = id;
            BenefitId = benefitId;
            CurrentRate = currentRate;
            Block41 = block41;
            DmiSentDate = dmiSentDate;
            ConfirmationReceivedDate = confirmationReceivedDate;
            IsPromotionalOffer = isPromotionalOffer;
            PromotionEndDate = promotionEndDate;
            IsRateCapPerformed = isRateCapPerformed;
            IsFeeWaived = isFeeWaived;
            FeeRefundAmount = feeRefundAmount;
            DateFeesRefunded = dateFeesRefunded;
            IsStatementsPending = isStatementsPending;
            StatementDate = statementDate;
            IsInterestAdjustmentCalculated = isInterestAdjustmentCalculated;
            InterestRefunded = interestRefunded;
            RefundDate = refundDate;
            BenefitAppliedDate = benefitAppliedDate;
            DateBenefitExpected = dateBenefitExpected;
            BenefitEffectiveDate = benefitEffectiveDate;
            ExpectedRemovalDate = expectedRemovalDate;
            BenefitRemovedDate = benefitRemovedDate;
        }

        public static BenefitDetail CopyPartial(BenefitDetail benefitDetail)
        {
            var newRecord = new BenefitDetail()
            {
                Id = 0,
                CurrentRate = benefitDetail.CurrentRate,
                BenefitAppliedDate = benefitDetail.BenefitAppliedDate,
                DateBenefitExpected = benefitDetail.DateBenefitExpected,
                BenefitEffectiveDate = benefitDetail.BenefitEffectiveDate,
                ExpectedRemovalDate = benefitDetail.ExpectedRemovalDate,
                BenefitRemovedDate = benefitDetail.BenefitRemovedDate,

            };

            return newRecord;
        }

        public static BenefitDetail CopyAll(BenefitDetail benefitDetail)
        {
            var newRecord = new BenefitDetail()
            {
                Id = benefitDetail.Id,
                BenefitId = benefitDetail.BenefitId,
                CurrentRate = benefitDetail.CurrentRate,
                Block41 = benefitDetail.Block41,
                DmiSentDate = benefitDetail.DmiSentDate,
                ConfirmationReceivedDate = benefitDetail.ConfirmationReceivedDate,
                IsPromotionalOffer = benefitDetail.IsPromotionalOffer,
                PromotionEndDate = benefitDetail.PromotionEndDate,
                IsRateCapPerformed = benefitDetail.IsRateCapPerformed,
                IsFeeWaived = benefitDetail.IsFeeWaived,
                FeeRefundAmount = benefitDetail.FeeRefundAmount,
                DateFeesRefunded = benefitDetail.DateFeesRefunded,
                IsStatementsPending = benefitDetail.IsStatementsPending,
                StatementDate = benefitDetail.StatementDate,
                IsInterestAdjustmentCalculated = benefitDetail.IsInterestAdjustmentCalculated,
                InterestRefunded = benefitDetail.InterestRefunded,
                RefundDate = benefitDetail.RefundDate,
                BenefitAppliedDate = benefitDetail.BenefitAppliedDate,
                DateBenefitExpected = benefitDetail.DateBenefitExpected,
                BenefitEffectiveDate = benefitDetail.BenefitEffectiveDate,
                ExpectedRemovalDate = benefitDetail.ExpectedRemovalDate,
                BenefitRemovedDate = benefitDetail.BenefitRemovedDate,
            };

            return newRecord;
        }

        public static BenefitDetail CreateMortgage(int benefitId)
        {
            return CreateInternal(benefitId);
        }

        public static BenefitDetail CreateCreditCard(int benefitId)
        {
            return CreateInternal(benefitId);
        }

        public static BenefitDetail ConsumerLoan(int benefitId)
        {
            return CreateInternal(benefitId);
        }

        private static BenefitDetail CreateInternal(int benefitId)
        {
            return new BenefitDetail(0, benefitId, 0, false,null, null, false, null,
                false, false, 0, null, false, null,false, 0,
                null, null, null, null, null, null);
        }

        public bool UnChanged(BenefitDetail benefitDetail)
        {
            if (benefitDetail == null)
                return false;

            if (BenefitId != benefitDetail.BenefitId ||
                CurrentRate != benefitDetail.CurrentRate ||
                Block41 != benefitDetail.Block41 ||
                DmiSentDate != benefitDetail.DmiSentDate ||
                ConfirmationReceivedDate != benefitDetail.ConfirmationReceivedDate ||
                IsPromotionalOffer != benefitDetail.IsPromotionalOffer ||
                PromotionEndDate != benefitDetail.PromotionEndDate ||
                IsRateCapPerformed != benefitDetail.IsRateCapPerformed ||
                IsFeeWaived != benefitDetail.IsFeeWaived ||
                FeeRefundAmount != benefitDetail.FeeRefundAmount ||
                DateFeesRefunded != benefitDetail.DateFeesRefunded ||
                IsStatementsPending != benefitDetail.IsStatementsPending ||
                StatementDate != benefitDetail.StatementDate ||
                IsInterestAdjustmentCalculated != benefitDetail.IsInterestAdjustmentCalculated ||
                InterestRefunded != benefitDetail.InterestRefunded ||
                RefundDate != benefitDetail.RefundDate ||
                BenefitAppliedDate != benefitDetail.BenefitAppliedDate ||
                DateBenefitExpected != benefitDetail.DateBenefitExpected ||
                BenefitEffectiveDate != benefitDetail.BenefitEffectiveDate ||
                ExpectedRemovalDate != benefitDetail.ExpectedRemovalDate ||
                BenefitRemovedDate != benefitDetail.BenefitRemovedDate
            )
                return false;
                        
            return true;
            

        }
    }
}