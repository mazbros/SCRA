﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.Tasks;

namespace Scra.Model.Contracts
{
    public interface IBenefitRepository
    {
        Task<IList<Benefit>> LoadByContract(ContractId contractId);
        Task<Benefit> LoadById(int benefitId);
        Task Save(Benefit benefit);
        Task<Benefit> GetBenefitByTask(int taskId);
        Task<IList<Benefit>> LoadByPerson(int id);
        Task<IList<BenefitEvent>> LoadEvent(PersonId personId);
        Task<IList<BenefitEvent>> LoadEvent(ContractId contractId);
    }
}