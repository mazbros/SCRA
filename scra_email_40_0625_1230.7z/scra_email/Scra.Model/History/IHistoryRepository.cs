﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;

namespace Scra.Model.History
{
    public interface IHistoryRepository
    {
        Task<IList<PersonSnapshot>> LoadModifiedRecords(DateTime? date);
        Task<IList<ActiveDuty>> GetActiveDutyHistory(int personId, DateTime? timestamp);
        Task<IList<Contract>> GetContractHistory(int personId, DateTime? timestamp);
    }
}