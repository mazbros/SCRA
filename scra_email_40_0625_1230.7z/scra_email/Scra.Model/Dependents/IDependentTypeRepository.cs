﻿using System.Threading.Tasks;

namespace Scra.Model.Dependents
{
    public interface IDependentTypeRepository
    {
        Task<DependentTypeList> GetList();
    }
}