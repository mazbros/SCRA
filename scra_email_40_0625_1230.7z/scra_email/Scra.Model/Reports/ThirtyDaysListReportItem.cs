﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class ThirtyDaysListReportItem
    {
        #region Properties
        [DisplayName("ServicememberID")]
        public string ServicememberId { get; set; }

        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("First Name")]
        public string FirstName { get; set; }

        [DisplayName("FNumber")]
        public string FNumber { get; set; }

        [DisplayName("Benefit Removed Date")]
        public string BenefitRemovedDate { get; set; }

        [DisplayName("Days Left")]
        public string DaysLeft { get; set; }

        [DisplayName("Product Name")]
        public string ProductName { get; set; }
        #endregion
        public static ThirtyDaysListReportItem Create(DataRow dr)
        {
            var item = new ThirtyDaysListReportItem
            {
                ServicememberId = dr["ID"].ToString(),
                LastName = dr["LastName"].ToString(),
                FirstName = dr["FirstName"].ToString(),
                FNumber = dr["FNumber"].ToString(),
                BenefitRemovedDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitRemovedDate"]),
                DaysLeft = dr["DaysLeft"].ToString(),
                ProductName = dr["SUB_PRODUCT_NAME"].ToString()
            };

            return item;
        }
    }
}