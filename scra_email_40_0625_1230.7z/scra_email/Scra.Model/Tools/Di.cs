﻿using System;
using System.Diagnostics;

namespace Scra.Model.Tools
{
    public class Di
    {
        private static readonly MyDiContainer _container = new MyDiContainer();

        [DebuggerStepThrough]
        public static object Get(Type type)
        {
            return _container.Resolve(type);
        }

        [DebuggerStepThrough]
        public static T Get<T>()
        {
            return (T)Get(typeof(T));
        }

        public static TClass SetAndCreate<TClass>()
        {
            var type = typeof(TClass);
            _container.RegisterType(type, type);
            return Get<TClass>();
        }

        public static void Set<TInterface, TClass>() where TClass : TInterface
        {
            _container.RegisterType(typeof(TInterface), typeof(TClass));
        }

        public static void Set<TInterface>()
        {
            _container.RegisterType(typeof(TInterface), typeof(TInterface));
        }

        public static void Set<TInterface>(TInterface instance)
        {
            _container.RegisterInstance(typeof(TInterface), instance);
        }

        public static void Set(Type type, object instance)
        {
            _container.RegisterInstance(type, instance);
        }

        public static void Set(Type interfaceType, Type implementationType)
        {
            _container.RegisterType(interfaceType, implementationType);
        }
    }
}
