﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.BranchOfServices;

namespace Scra.DataAccess.Servicemembers
{
    internal class BranchOfServiceRepository : IBranchOfServiceRepository
    {
        private readonly SqlExecutor _sqlExecutor;

        public BranchOfServiceRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<BranchOfServiceList> GetList()
        {
            var query = "SELECT ID, Branch, IsReserve FROM dbo.BranchOfService ORDER BY Branch";
            var items = await _sqlExecutor.Execute(query, ConvertBranchOfService);
            return BranchOfServiceList.Create(items);
        }

        private BranchOfService ConvertBranchOfService(IRowData record)
        {
            var id = record.AsInt(RefColumn.ID);
            var name = record.AsString("Branch");
            var isReserve = record.AsBool("IsReserve");
            return BranchOfService.Create(id, name, isReserve);
        }
    }
}