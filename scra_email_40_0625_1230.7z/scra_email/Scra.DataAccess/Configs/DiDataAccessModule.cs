﻿using Scra.DataAccess.Communication;
using Scra.DataAccess.Contracts;
using Scra.DataAccess.Core;
using Scra.DataAccess.Files;
using Scra.DataAccess.History;
using Scra.DataAccess.Inquiries;
using Scra.DataAccess.Letters;
using Scra.DataAccess.Persons;
using Scra.DataAccess.Reports;
using Scra.DataAccess.Servicemembers;
using Scra.DataAccess.Tasks;
using Scra.DataAccess.Users;
using Scra.DataAccess.Version;
using Scra.Model.BranchOfServices;
using Scra.Model.Communication;
using Scra.Model.ContactMethods;
using Scra.Model.Contracts;
using Scra.Model.Dependents;
using Scra.Model.Files;
using Scra.Model.History;
using Scra.Model.Inquiries;
using Scra.Model.Letters;
using Scra.Model.Persons;
using Scra.Model.Reports;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.Model.Version;

namespace Scra.DataAccess.Configs
{
    public static class DiDataAccessModule
    {
        public static void Register()
        {
            Di.Set<IPersonRepository, PersonRepository>();
            Di.Set<IPersonNoteRepository, PersonNoteRepository>();
            Di.Set<IDependentTypeRepository, DependentTypeRepository>();
            Di.Set<IServiceMemberRepository, ServiceMemberRepository>();
            Di.Set<IBranchOfServiceRepository, BranchOfServiceRepository>();
            Di.Set<IContactMethodRepository, ContactMethodRepository>();
            Di.Set<IUserRepository, UserRepository>();
            Di.Set<IContractRepository, ContractRepository>();
            Di.Set<ITaskRepository, TaskRepository>();
            Di.Set<IInquiryRepository, InquiryRepository>();
            Di.Set<IFileAttachmentRepository, FileAttachmentRepository>();
            Di.Set<IBenefitRepository, BenefitRepository>();
            Di.Set<IVersionRepository, VersionRepository>();
            Di.Set<IContractTypeRepository, ContractTypeRepository>();
            Di.Set<IBenefitDetailRepository, BenefitDetailRepository>();
            Di.Set<ICommunicationRepository, CommunicationRepository>();
            Di.Set<ILetterRepository, LetterRepository >();
            Di.Set<IReportsRepository, ReportsRepository>();
            Di.Set<SpExecutor>();
            //Di.Set<ISqlExecutor,SqlExecutor>();
            Di.Set<SqlExecutor>();
            Di.Set<IDbConfig,DbConfig>();
            Di.Set<IHistoryRepository, HistoryRepository>();
        }
    }
}
