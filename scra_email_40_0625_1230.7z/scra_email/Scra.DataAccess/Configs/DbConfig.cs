﻿namespace Scra.DataAccess.Configs
{
    public class DbConfig : IDbConfig
    {
        public string ConnectionString { get; set; }
    }
}
