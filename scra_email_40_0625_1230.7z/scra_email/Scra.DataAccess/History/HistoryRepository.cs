﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.BranchOfServices;
using Scra.Model.Contracts;
using Scra.Model.History;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;

namespace Scra.DataAccess.History
{
    public class HistoryRepository : IHistoryRepository
    {
        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        private const string GET_MODIFIED_PERSON_BY_DATE = @"
SELECT DISTINCT p.ID,p.FirstName,p.MiddleInitial,p.LastName,th.[Timestamp],th.[Category]
    FROM [dbo].[Person] p
        JOIN (SELECT [PersonID], [Timestamp],[Category] FROM (
                SELECT [ID] as PersonID, [Timestamp], 'PERS' as Category FROM [dbo].[Person] WHERE [Timestamp] > @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'AD' as Category FROM [dbo].[ActiveDuty] WHERE [Timestamp] > @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'CONTR' as Category FROM [dbo].[Contract] WHERE [Timestamp] > @Timestamp
        ) u
    GROUP BY [PersonID],[Timestamp],[Category]
    HAVING [Timestamp] = (SELECT MAX([Timestamp]) 
                            FROM (
                                SELECT [ID] as PersonID,[Timestamp] FROM [dbo].[Person] p WHERE [Timestamp] > @Timestamp AND p.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID],[Timestamp] FROM [dbo].[ActiveDuty] a WHERE [Timestamp] > @Timestamp AND a.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID],[Timestamp] FROM [dbo].[Contract] c WHERE [Timestamp] > @Timestamp AND c.[ID] = u.[PersonID]) uu )
    ) th 
        ON p.[ID] = th.[PersonID]
            WHERE p.[Origin] NOT IN ('dmdc_check','inquiry')
        ORDER BY [Timestamp] DESC
";

        private const string GET_MODIFIED_AD_BY_DATE = @"
if @Timestamp <  (select max(Timestamp) from ActiveDuty where PersonID = @PersonId)
begin
	select AD.ID, BS.ID As BranchOfServiceID, BS.Branch, BS.IsReserve, AD.StartDate, AD.EndDate, AD.NoticeDate, AD.Timestamp, E.Name As ModifiedBy, AD.PersonID 
	from
		(Select ID, BranchOfServiceID, StartDate, EndDate, NoticeDate, Timestamp, ModifiedBy, PersonID from ActiveDuty where PersonID = @PersonId
		union 
		Select TOP 1 ID, BranchOfServiceID, StartDate, EndDate, NoticeDate, Timestamp, ModifiedBy, PersonID from hist.ActiveDuty where PersonID = @PersonId ORDER BY [Timestamp] DESC) AD
	left join Employee E on E.ID = AD.ModifiedBy
	left join BranchOfService BS on BS.ID = AD.BranchOfServiceID
	order by Timestamp desc
end
";

        private const string GET_CONTRACT_HISTORY = @"
if @Timestamp <  (select max(Timestamp) from Contract where PersonID = @PersonId)
begin
	select C.ID, C.ContractNo, C.OpenDate, C.CloseDate, C.IsDeleted, C.Timestamp, C.PersonID, E.Name As ModifiedBy
		, CT.SCRA_Code
		, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.SUB_PRODUCT_NAME ELSE C.ProductName END as 'SUB_PRODUCT_NAME'
		, CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as 'AccountNumber'

	from(
		select ID, ContractNo, OpenDate, CloseDate, IsDeleted, Timestamp, ModifiedBy, PersonID, LegacyNo, ContractTypeId, Center, Product, CardNo, ProductName from Contract where PersonId = @PersonId
		union
		select TOP 1 ID, ContractNo, OpenDate, CloseDate, IsDeleted, Timestamp, ModifiedBy, PersonID, LegacyNo, ContractTypeId, Center, Product, CardNo, ProductName from hist.Contract where PersonId = @PersonId ORDER BY [Timestamp] DESC) C
	join ContractType CT ON C.ContractTypeId = CT.ID
	left join Employee E on E.ID = C.ModifiedBy
    where c.IsDeleted = 0
	order by Timestamp desc
end
";

        public HistoryRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public async Task<IList<PersonSnapshot>> LoadModifiedRecords(DateTime? date)
        {
            var sql = GET_MODIFIED_PERSON_BY_DATE.Replace("@Timestamp", "'" + date + "'");
            return await _sqlExecutor.Execute(sql, ToPersonSnapshotWithTimestamp);
        }

        public async Task<IList<ActiveDuty>> GetActiveDutyHistory(int personId, DateTime? timestamp)
        {
            var sql = GET_MODIFIED_AD_BY_DATE.Replace("@PersonId", personId.ToString()).Replace("@Timestamp", "'" + timestamp + "'");
            return await _sqlExecutor.Execute(sql, ToActiveDuty);
        }

        public async Task<IList<Contract>> GetContractHistory(int personId, DateTime? timestamp)
        {
            var sql = GET_CONTRACT_HISTORY.Replace("@PersonId", personId.ToString()).Replace("@Timestamp", "'" + timestamp + "'");
            return await _sqlExecutor.Execute(sql, ToContract);
        }

        private Contract ToContract(IRowData row)
        {
            var id = row.AsInt("ID");
            var personId = row.AsInt("PersonID");
            var contractNo = row.AsString("ContractNo");
            var accountNumber = row.AsString("AccountNumber");
            var contractType = row.AsString("SCRA_Code");
            var productName = row.AsString("SUB_PRODUCT_NAME");
            var openDate = row.AsDateTime("OpenDate");
            var closeDate = row.AsDateTime("CloseDate");
            var isDeleted = row.AsBool("IsDeleted");

            var timestamp = row.AsDateTime("Timestamp");
            var modifiedBy = row.AsString("ModifiedBy");

            var contract = Contract.Create(new ContractId(id), new PersonId(personId), contractNo, accountNumber, contractType, productName, openDate, closeDate, isDeleted, timestamp, modifiedBy);
            return contract;
        }

        private ActiveDuty ToActiveDuty(IRowData row)
        {
            var id = row.AsInt("ID");

            var branchId = row.AsInt("BranchOfServiceID");
            var branch = row.AsString("Branch");
            var isReserve = row.AsBool("IsReserve");
            var bs = BranchOfService.Create(branchId, branch, isReserve);

            var adsd = row.AsDateTime("StartDate");
            var noticeDate = row.AsDateTime("NoticeDate");
            var aded = row.AsDateTime("EndDate");

            var timestamp = row.AsDateTime("Timestamp");
            var modifiedBy = row.AsString("ModifiedBy");

            return ActiveDuty.Create(id, adsd, aded, noticeDate, bs, timestamp, modifiedBy);
        }

        //private PersonSnapshot ToPersonSnapshot(IRowData row)
        //{
        //    var id = row.AsInt("ID");
        //    var firstName = row.AsString("FirstName");
        //    var middleName = row.AsString("MiddleInitial");
        //    var lastName = row.AsString("LastName");

        //    var person = new PersonSnapshot(new PersonId(id), PersonName.Create(firstName,middleName, lastName));

        //    return person;
        //}

        private PersonSnapshot ToPersonSnapshotWithTimestamp(IRowData row)
        {
            var id = row.AsInt("ID");
            var firstName = row.AsString("FirstName");
            var middleName = row.AsString("MiddleInitial");
            var lastName = row.AsString("LastName");
            var timestamp = DateTime.Parse(row.AsDateTime("Timestamp").ToString()) ;

            var person = new PersonSnapshot(new PersonId(id), PersonName.Create(firstName, middleName, lastName), timestamp);

            return person;
        }
    }
}