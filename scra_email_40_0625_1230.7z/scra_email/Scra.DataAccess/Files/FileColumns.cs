﻿namespace Scra.DataAccess.Files
{
    public class FileColumns
    {
        public const string ENTITY = "Entity";
        public const string ENTITY_ID= "EntityId";
        public const string FILE_NAME = "FileName";
        public const string ID = "ID";
        public const string FILE_CONTENT= "FileContent";
    }
}