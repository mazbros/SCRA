USE [SCRA_DB]
GO

/****** Object:  Table [dbo].[ActiveDutyDetail]    Script Date: 09/16/2019 14:13:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ActiveDutyDetail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[VerifiedBy] [int] NOT NULL,
	[VerifiedDate] [date] NULL,
	[Timestamp] [datetime] NULL,
	[ModifiedBy] [int] NULL,
	[ActiveDutyID] [int] NULL,
 CONSTRAINT [PK_ActiveDutyDetail] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[ActiveDutyDetail]  WITH CHECK ADD  CONSTRAINT [FK_ActiveDutyDetail_ActiveDuty] FOREIGN KEY([ActiveDutyID])
REFERENCES [dbo].[ActiveDuty] ([ID])
GO

ALTER TABLE [dbo].[ActiveDutyDetail] CHECK CONSTRAINT [FK_ActiveDutyDetail_ActiveDuty]
GO


USE [SCRA_DB]
GO

/****** Object:  Table [dbo].[VerifiedByItem]    Script Date: 09/16/2019 14:14:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[VerifiedByItem](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[VerifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_VerifiedByItem] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

select * FROM ActiveDuty ad 
		LEFT JOIN ActiveDutyDetail ad2 ON ad.ID = ad2.ActiveDutyId
		 JOIN Person p on ad.PersonID = p.ID
			LEFT JOIN ServiceMember sm ON p.ID = sm.PersonID
				LEFT JOIN Migration_History mh ON sm.ServicememberID = mh.ServiceMemberID