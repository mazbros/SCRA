USE [SCRA_DB_MIGRATE]
GO

/****** Object:  Table [dbo].[Sample]    Script Date: 04/17/2019 13:07:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Sample](
	[DateOfContact] [datetime] NULL,
	[MethodOfNotification] [nvarchar](255) NULL,
	[DateDMDCSearchPerformed] [datetime] NULL,
	[VerifyBySCRAOrMilOrders] [nvarchar](255) NULL,
	[Notification Date] [datetime] NULL,
	[BenefitApprovedDeniedPending] [nvarchar](255) NULL,
	[StatusCode] [nvarchar](255) NULL,
	[NotEligReason] [nvarchar](255) NULL,
	[DenialReason] [nvarchar](255) NULL,
	[ServiceMemberID] [float] NULL,
	[ServicememberLastName] [nvarchar](255) NULL,
	[ServicememberFirstname] [nvarchar](255) NULL,
	[ServicememberMiddleInitial] [nvarchar](255) NULL,
	[FNumber] [nvarchar](255) NULL,
	[SocialSecurityNumber] [nvarchar](255) NULL,
	[BranchOfService] [nvarchar](255) NULL,
	[ADStartDate] [datetime] NULL,
	[ADEndDate] [datetime] NULL,
	[Benefits Effective (as of) Date] [datetime] NULL,
	[DateBenefitsApplied] [datetime] NULL,
	[DateBenefitsEnded] [datetime] NULL,
	[ProductType] [nvarchar](255) NULL,
	[SubType] [nvarchar](255) NULL,
	[AccountNum] [nvarchar](255) NULL,
	[ProductStartDate] [datetime] NULL,
	[ProductEndDate] [datetime] NULL,
	[ActiveAccountEligible] [bit] NOT NULL,
	[Address1] [nvarchar](255) NULL,
	[Address2] [nvarchar](255) NULL,
	[City] [nvarchar](255) NULL,
	[State] [nvarchar](255) NULL,
	[Zip] [nvarchar](255) NULL,
	[Email] [nvarchar](255) NULL,
	[BenefitsRecvd] [bit] NOT NULL,
	[Interest Rate before SCRA] [float] NULL,
	[Interest Adjustment] [bit] NOT NULL,
	[Promo Rate End Date] [nvarchar](255) NULL,
	[RefundAmount] [nvarchar](255) NULL,
	[RefundDate] [nvarchar](255) NULL,
	[Comments] [nvarchar](255) NULL,
	[AdditionalComments] [nvarchar](255) NULL,
	[LetterID] [float] NULL,
	[DateSent] [datetime] NULL,
	[LetterCode] [nvarchar](255) NULL,
	[LetterName] [nvarchar](255) NULL,
	[Returned] [bit] NULL,
	[Phone] [nvarchar](255) NULL,
	[DOB] [date] NULL,
	[CoBorrower_Name] [varchar](255) NULL,
	[CoBorrower_SSN] [varchar](255) NULL,
	[CoBorrower_DOB] [date] NULL,
	[90DayLetterSentOn] [date] NULL,
	[LOB_Contact] [varchar](255) NULL,
	[BenefitsRequestedBy] [varchar](255) NULL,
	[Account] [varchar](4) NULL,
	[LetterLongDesc] [varchar](255) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


