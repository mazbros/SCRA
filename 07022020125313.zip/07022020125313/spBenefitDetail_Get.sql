CREATE PROCEDURE [dbo].[spBenefitDetail_Get]
	@BenefitId				INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

		BEGIN
	
			BEGIN TRY

				BEGIN TRANSACTION
	
					DECLARE @TaskType 			varchar(255)
					DECLARE @BenefitIntervalId 	int = 0
					DECLARE @BenefitDetailId 	int = 0
					DECLARE @RemoveCount 		int = 0
					DECLARE @ExtendCount 		int = 0

					SET @TaskType = (SELECT T.[TaskType] 
									 	FROM [Benefit] B
									 		LEFT JOIN [Task] T ON B.[TaskID] = T.[ID]
												WHERE B.ID = @BenefitId)

					SET @BenefitIntervalId = (SELECT [BenefitIntervalId]
											  	FROM [Benefit]
													WHERE [ID] = @BenefitId)

					SET @BenefitDetailId = (SELECT BD.[ID] 
												FROM [Benefit] B
													JOIN [BenefitDetail] BD ON BD.[BenefitId] = B.[ID]
														WHERE B.[ID] = @BenefitId)

					SET @RemoveCount = (SELECT count(*)
											FROM [Benefit] b
												LEFT JOIN [Task] T ON B.[TaskID] = T.[ID]
											WHERE B.[BenefitIntervalId] = @BenefitIntervalId
												AND t.[TaskType] = 'remove_benefit')

					SET @ExtendCount = (SELECT count(*)
											FROM [Benefit] b
												LEFT JOIN [Task] T ON B.[TaskID] = T.[ID]
												WHERE B.BenefitIntervalId = @BenefitIntervalId
													AND t.TaskType = 'extend_benefit')
					
					PRINT @BenefitIntervalId
					PRINT @RemoveCount
					PRINT @ExtendCount
					
						
					--if((SELECT count(*) FROM BenefitDetail where BenefitId = @BenefitId) &gt; 0 or @TaskType = 'remediation_reimbursement' or @RemoveCount &gt; 1 or @ExtendCount &gt; 1) 
					IF (@TaskType = 'remediation_reimbursement') BEGIN
						SELECT * FROM BenefitDetail WHERE BenefitId = @BenefitId
					END ELSE BEGIN
						IF (@BenefitDetailId is null) BEGIN
							SELECT BD.*
								FROM [Benefit] B
									JOIN (SELECT * FROM [Task] 
											WHERE [TaskType] = 'add_benefit' 
												AND [Status] &lt;&gt; 'misdirected') T ON T.ID = B.TaskID
									LEFT JOIN [Benefit] B0 ON B0.[BenefitIntervalId] = B.[BenefitIntervalId]
									JOIN [BenefitDetail] BD On BD.[BenefitId] = B.ID
								WHERE B0.[ID] = @BenefitId
						END ELSE BEGIN
							SELECT * FROM BenefitDetail where Id = @BenefitDetailId
						END
					END

				COMMIT TRANSACTION
	    
			END TRY
		    
			BEGIN CATCH
				ROLLBACK TRANSACTION        
				SET @ErrorMessage = ERROR_MESSAGE();
				SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
				SET @ErrorLine    = ERROR_LINE();
				SET @ErrorSeverity= ERROR_SEVERITY();
				SET @ErrorState   = ERROR_STATE();
				GOTO ErrorHandler;
			END CATCH
			RETURN;
		    
			ErrorHandler:
				RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
							@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
		END
END

/*
EXEC [dbo].[spBenefitDetail_Get] 1316 --319 
*/
