CREATE PROCEDURE [dbo].[spPerson_RemoteFetch]
	@FNo VARCHAR(10) = '',
	@SSN VARCHAR(9) = ''
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				DECLARE @TIPOPERS VARCHAR(1),@CODPERS INT, @PERIOD DATE
				
				SET @PERIOD = (SELECT MAX([AS_OF_DATE]) FROM [CUSTDASH].[OLD].[CAD_CONTR_M_S])
				
				IF LEN(@FNo) &gt; 0 BEGIN
				
					SET @TIPOPERS = LEFT(@FNo,1)
					SET @CODPERS = CONVERT(INT, RIGHT(@FNo,9))
				
				END ELSE BEGIN
				
					IF LEN(@SSN) &gt; 0 BEGIN	
						
						SET @TIPOPERS = (SELECT [TIPOPERS] FROM [CUSTDASH].[OLD].[CAD_PERSONA_COR] WHERE [CD_DOCUM] = @SSN AND [AS_OF_DATE] = @PERIOD)
						SET @CODPERS = (SELECT [CODPERS] FROM [CUSTDASH].[OLD].[CAD_PERSONA_COR] WHERE [CD_DOCUM] = @SSN AND [AS_OF_DATE] = @PERIOD)

					END 
					
				END
				
				IF LEN(@TIPOPERS) &gt; 0 AND LEN(@CODPERS) &gt; 0 BEGIN
				
					SELECT pc.[TIPOPERS]+REPLICATE('0',9-LEN(CAST(pc.[CODPERS] as VARCHAR(9))))+CAST(pc.[CODPERS] as varchar(9)) as [FNUMBER]
						  ,pc.[CD_DOCUM] as [SSN]
						  ,pc.[FECNACIM] as [DOB]
						  ,pc.[NOMPPAL] as [FirstName]
						  ,pc.[NOMSECU] as [MiddleInitial]
						  ,pc.[NOMREST] as [LastNAme]
						  ,
						  CASE WHEN LEN(
						  CASE WHEN LEN(c.[H9776_DIRELEF1]) &gt; 0 THEN c.[H9776_DIRELEF1] 
								ELSE CASE WHEN LEN(c.[H9776_DIRELEF2]) &gt; 0 THEN c.[H9776_DIRELEF2] 
										ELSE CASE WHEN LEN(c.[H9776_DIRELEF3]) &gt; 0 THEN c.[H9776_DIRELEF3]
												ELSE CASE WHEN LEN(c.[H9776_DIRELEM1]) &gt; 0 THEN c.[H9776_DIRELEM1]	
														ELSE CASE WHEN LEN(c.[H9776_DIRELEM2]) &gt; 0 THEN c.[H9776_DIRELEM2]
																ELSE CASE WHEN LEN(c.[H9776_DIRELEM3]) &gt; 0 THEN c.[H9776_DIRELEM3]
																		ELSE ''
																	END	
															END
													END
									END
								END	
						   END) = 11 THEN SUBSTRING(CASE WHEN LEN(c.[H9776_DIRELEF1]) &gt; 0 THEN c.[H9776_DIRELEF1] 
								ELSE CASE WHEN LEN(c.[H9776_DIRELEF2]) &gt; 0 THEN c.[H9776_DIRELEF2] 
										ELSE CASE WHEN LEN(c.[H9776_DIRELEF3]) &gt; 0 THEN c.[H9776_DIRELEF3]
												ELSE CASE WHEN LEN(c.[H9776_DIRELEM1]) &gt; 0 THEN c.[H9776_DIRELEM1]	
														ELSE CASE WHEN LEN(c.[H9776_DIRELEM2]) &gt; 0 THEN c.[H9776_DIRELEM2]
																ELSE CASE WHEN LEN(c.[H9776_DIRELEM3]) &gt; 0 THEN c.[H9776_DIRELEM3]
																		ELSE ''
																	END	
															END
													END
									END
								END	
						   END,2,10) ELSE CASE WHEN LEN(c.[H9776_DIRELEF1]) &gt; 0 THEN c.[H9776_DIRELEF1] 
								ELSE CASE WHEN LEN(c.[H9776_DIRELEF2]) &gt; 0 THEN c.[H9776_DIRELEF2] 
										ELSE CASE WHEN LEN(c.[H9776_DIRELEF3]) &gt; 0 THEN c.[H9776_DIRELEF3]
												ELSE CASE WHEN LEN(c.[H9776_DIRELEM1]) &gt; 0 THEN c.[H9776_DIRELEM1]	
														ELSE CASE WHEN LEN(c.[H9776_DIRELEM2]) &gt; 0 THEN c.[H9776_DIRELEM2]
																ELSE CASE WHEN LEN(c.[H9776_DIRELEM3]) &gt; 0 THEN c.[H9776_DIRELEM3]
																		ELSE ''
																	END	
															END
													END
									END
								END	
						   END END  as [PHONE]
						  
						  ,CASE WHEN LEN(c.[H9776_DIRELEE1]) &gt; 0 THEN c.[H9776_DIRELEE1] ELSE c.[H9776_DIRELEE2] END as [EMAIL]
						  ,c.[H9776_DOMDIR1]  as [ADDRESS1]
						  ,c.[H9776_DOMRDIR1] as [ADDRESS2]
						  ,c.[H9776_NMLOCAL1] as [CITY]
						  ,c.[H9776_DISTRIT1] as [ZIP]
						  ,c.[H9776_NOMPROV1] as [STATE]
						  ,c.[H9776_CODPAIS1] as [COUNTRY]
						  ,'' as [ORIGIN]
				  
					  FROM [CUSTDASH].[OLD].[CAD_PERSONA_COR] pc 
						JOIN [SAS_Persona_Cor_Anon].[DATA].[CAD_CONTACTOS] c
							ON pc.[TIPOPERS] = c.[H9776_TIPOPERS] AND pc.[CODPERS] = c.[H9776_CODPERS]
						WHERE [AS_OF_DATE] = @PERIOD AND pc.[TIPOPERS] = @TIPOPERS AND pc.[CODPERS] = @CODPERS

				END
				
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

/*
DECLARE @FNo varchar(10)
DECLARE @SSN varchar(9)

SET @SSN = '335920040'
--031-56-0165'--'199643614'

EXECUTE [SCRA_DB].[dbo].[spPerson_RemoteFetch] 
   @FNo = N''
  ,@SSN = @SSN
  
SELECT [TIPOPERS] FROM [CUSTDASH].[OLD].[CAD_PERSONA_COR] WHERE [CD_DOCUM] = @SSN
SELECT [CODPERS] FROM [CUSTDASH].[OLD].[CAD_PERSONA_COR] WHERE [CD_DOCUM] = @SSN
*/
