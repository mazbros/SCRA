
CREATE PROCEDURE [dbo].[spTaskCompletionByTaskType_Report] 
	@TaskType varchar(24) = ''
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @sql varchar(max)
	
	SET @sql = '	
	SELECT CreateDate as ''Date'',
		CASE TaskType 
			WHEN ''request_dmdc_check'' THEN ''DMDC Validation'' 
			WHEN ''request_inquiry''	THEN ''Inquiry''
			WHEN ''request_affiliate''	THEN ''Affilliate or SBO''
			WHEN ''request_benefits''	THEN ''Benefit Request and Eligibility Determination''
			WHEN ''add_benefit''		THEN ''Add Benefit''
			WHEN ''remove_benefit''		THEN ''Remove Benefit''
			WHEN ''deny_benefit''		THEN ''Deny Benefit''
			ELSE '''' END as ''Task Type'',
		ISNULL([in_process],'''')	AS ''In Process'',
		ISNULL([completed],'''')	AS ''Completed'',
		ISNULL([qa_completed],'''') AS ''QA Completed'',
		ISNULL([rejected],'''')		AS ''Rejected'',
		ISNULL([misdirected],'''')	AS ''Misdirected'',
		ISNULL([in_process],'''') + 
		ISNULL([completed],'''') + 
		ISNULL([qa_completed],'''') + 
		ISNULL([rejected],'''') + 
		ISNULL([misdirected],'''') AS ''Total''
	FROM (
	SELECT CONVERT(varchar(10), CreateDate, 101) AS CreateDate,TaskType,[Status], COUNT(*) as cnt FROM Task '
	IF @TaskType &lt;&gt; '' BEGIN
		SET @sql = @sql + '
			WHERE TaskType = ''' + @TaskType + ''' '
	END
	SET @sql = @sql + '
	GROUP BY CONVERT(varchar(10), CreateDate, 101),TaskType,[Status]
	) src
	PIVOT
	(
	SUM(cnt) for [Status] IN ([in_process],[completed],[qa_completed],[rejected],[misdirected])
	) pvt
	ORDER BY CONVERT(varchar(10), CreateDate, 101) DESC  
'

PRINT @sql

EXEC (@sql)	 

END
