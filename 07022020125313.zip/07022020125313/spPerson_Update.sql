CREATE PROCEDURE [dbo].[spPerson_Update]
(
	@ID						INT OUTPUT,
	@FirstName				VARCHAR(255),
	@LastName				VARCHAR(255),
	@MiddleInitial			VARCHAR(255),
	@Ssn					VARCHAR(255),
	@DOB					DATE = NULL,
	
	@Address1				VARCHAR(255),
	@Address2				VARCHAR(255),
	@City					VARCHAR(255),
	@State					VARCHAR(255),	
	@Zip					VARCHAR(255),
	
	@Phone					VARCHAR(255),
	@Email					VARCHAR(255),
	@ContactMethodID		INT,
	@ModifiedBy				INT,
	
	@FNumber				VARCHAR(10),
	
	@Search					VARCHAR(MAX),
	
	@Origin					VARCHAR(50)
)
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
		
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION   

				IF NOT EXISTS(SELECT [ID] FROM dbo.[Person] WHERE [ID] = @ID) BEGIN
				
					INSERT INTO [dbo].[Person]
						   ([FirstName]
						   ,[LastName]
						   ,[MiddleInitial]
						   ,[SSN]
						   ,[DOB]
						   ,[Address1]
						   ,[Address2]
						   ,[City]
						   ,[State]
						   ,[Zip]
						   ,[Phone]
						   ,[Email]
						   ,[ContactMethodID]
						   ,[Timestamp]
						   ,[Search]
						   ,[ModifiedBy]
						   ,[Origin])
					 VALUES
						   (@FirstName
						   ,@LastName
						   ,@MiddleInitial
						   ,@Ssn
						   ,@DOB
						   ,@Address1
						   ,@Address2
						   ,@City
						   ,@State
						   ,@Zip
						   ,@Phone
						   ,@Email
						   ,@ContactMethodID
						   ,GETDATE()
						   ,@Search
						   ,@ModifiedBy
						   ,@Origin)
						   
					SET @ID = SCOPE_IDENTITY()
					
				END ELSE BEGIN
					
					INSERT INTO [hist].[Person]
						   ([ID]
						   ,[FirstName]
						   ,[LastName]
						   ,[MiddleInitial]
						   ,[SSN]
						   ,[DOB]
						   ,[Address1]
						   ,[Address2]
						   ,[City]
						   ,[State]
						   ,[Zip]
						   ,[Phone]
						   ,[Email]
						   ,[ContactMethodID]
						   ,[Timestamp]
						   ,[ModifiedBy]
						   ,[Origin])
					 SELECT [ID]
						   ,[FirstName]
						   ,[LastName]
						   ,[MiddleInitial]
						   ,[SSN]
						   ,[DOB]
						   ,[Address1]
						   ,[Address2]
						   ,[City]
						   ,[State]
						   ,[Zip]
						   ,[Phone]
						   ,[Email]
						   ,[ContactMethodID]
						   ,[Timestamp]
						   ,[ModifiedBy]
						   ,[Origin]
						FROM [dbo].[Person]
						WHERE [ID] = @ID
					
					UPDATE [dbo].[Person]
						SET [FirstName] = @FirstName
						   ,[LastName] = @LastName
						   ,[MiddleInitial] = @MiddleInitial
						   ,[SSN] = @Ssn
						   ,[DOB] = @DOB
						   ,[Address1] = @Address1
						   ,[Address2] = @Address2
						   ,[City] = @City
						   ,[State] = @State
						   ,[Zip] = @Zip
						   ,[Phone] = @Phone
						   ,[Email] = @Email
						   ,[ContactMethodID] = @ContactMethodID
						   ,[Timestamp] = GETDATE()
						   ,[Search] = @Search
						   ,[ModifiedBy] = @ModifiedBy
						WHERE [ID] = @ID

				END
				
				EXEC [dbo].[spCustomer_Update] @FNumber, @ID, @ModifiedBy
			
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
	
END
