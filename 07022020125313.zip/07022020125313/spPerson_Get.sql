CREATE PROCEDURE [dbo].[spPerson_Get]
	@ID int
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT t1.[ID]
				  ,t1.[FirstName]
				  ,t1.[LastName]
				  ,t1.[MiddleInitial]
				  ,t1.[SSN]
				  ,t1.[DOB]
				  ,t1.[Address1]
				  ,t1.[Address2]
				  ,t1.[City]
				  ,t1.[State]
				  ,t1.[Zip]
				  ,t1.[Phone]
				  ,t1.[Email]
				  ,t1.[ContactMethodID]
				  ,t2.[FNumber]
				  ,t1.[Origin]
			  FROM [dbo].[Person] t1 LEFT JOIN [dbo].[Customer] t2 ON t1.[ID] = t2.[PersonID]
			  WHERE t1.[ID] = @ID
			  
			  SELECT [ID]
					 ,CASE WHEN [FromID] = @ID THEN [ToID]
						  WHEN [ToID] = @ID THEN [FromID]
						  ELSE @ID
					 END as [PersonID]
					 ,[DependentTypeID]
					 ,[StartDate]
					 ,[EndDate]
				FROM [dbo].[PersonToPersonLink]
				  WHERE [FromID] = @ID OR [ToID] = @ID
				
				--SELECT t1.[ID]
			 --     ,t1.[CustomerID]
			 --     ,t1.[Center]
			 --     ,t1.[Product]
			 --     ,t1.[StandardRef]
			 --     ,t1.[Subproduct]
			 --     ,t1.[ContractNo]
			 --     ,t2.[SUB_PRODUCT_NAME]
			 --     ,t2.[CATEGORY_NAME]
			 --     ,t2.[STANDARD_REF_NAME]
			 --     ,t1.[OpenDate]
			 --     ,t1.[CloseDate]
			 -- FROM [SCRA_DB].[dbo].[Contract] t1 JOIN [CUSTDASH].[dbo].[CATALOG] t2 
				--ON t1.[Product] = t2.[PRODUCT] AND
			 --      t1.[StandardRef] = t2.[STANDARD_REF] AND
			 --      t1.[Subproduct] = t2.[SUB_PRODUCT]
			 --   JOIN [dbo].[Customer] t3 ON t1.[CustomerID] = t3.[ID] AND t3.PersonID = @ID
			 -- WHERE t1.[IsDeleted] = 0 
			 
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
  
END
