CREATE PROCEDURE [dbo].[spBenefit_Create]
	@ContractId		INT,
	@ActiveDutyId	INT,
	@PersonId		INT,
	@Status			VARCHAR(50),
	@IsPromo		BIT,
	@StartDate		DATE = NULL,
	@EndDate		DATE = NULL,
	@ModifiedBy		INT,
	@DenialReason	VARCHAR(MAX),
	@BenefitIntervalId int = null,
	@ID				INT OUT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	Declare 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

BEGIN

    BEGIN TRY

        BEGIN TRANSACTION 
        
		if(@BenefitIntervalId is null or @BenefitIntervalId = 0) begin
			set @BenefitIntervalId = (select max(isnull (BenefitIntervalId, 0)) + 1 from Benefit)
		end

		INSERT INTO [dbo].[Benefit]
           ([ContractID]
           ,[Timestamp]
           ,[ModifiedBy]
           ,[PersonID]
           ,[ActiveDutyID]
           ,[IsPromo]
           ,[StartDate]
           ,[EndDate]
           ,[Status]
           ,[DenialReason]
		   ,[BenefitIntervalId])
     VALUES
           (@ContractID,
			GETDATE(),
            @ModifiedBy,
            @PersonID,
            @ActiveDutyID,
            @IsPromo,
			@StartDate,
			@EndDate,
			@Status,
			@DenialReason,
			@BenefitIntervalId)
			
	SELECT @ID = SCOPE_IDENTITY();		
	
	SELECT BenefitIntervalId from Benefit where ID = @ID
	
	COMMIT TRANSACTION
    
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION        
        SET @ErrorMessage = ERROR_MESSAGE();
        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
        SET @ErrorLine    = ERROR_LINE();
        SET @ErrorSeverity= ERROR_SEVERITY();
        SET @ErrorState   = ERROR_STATE();
        GOTO ErrorHandler;
    END CATCH
    RETURN;
    
    ErrorHandler:
        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

END			

END
