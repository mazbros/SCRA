CREATE PROCEDURE [dbo].[spContract_List]
	@PersonID INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				CREATE TABLE #temp
					([ID] INT, [DependentTypeId] INT, [DependentType] VARCHAR(50));
	
				INSERT INTO #temp ([ID],[DependentTypeId])
				SELECT CASE WHEN ptpl.[FromID] = @PersonID THEN ptpl.[ToID]
							WHEN ptpl.[ToID] = @PersonID THEN ptpl.[FromID]
							ELSE @PersonID
						END as [PersonID],
						ptpl.[DependentTypeId] as [DependentTypeId]
				FROM [dbo].[PersonToPersonLink] ptpl
					WHERE ptpl.[FromID] = @PersonID OR ptpl.[ToID] = @PersonID
	  
				UPDATE #temp SET [DependentType] = t2.[Type]
					FROM #temp t1 JOIN [dbo].[DependentType] t2 ON t1.DependentTypeId = t2.ID
	  
				INSERT INTO #temp ([ID],[DependentTypeId],[DependentType]) VALUES (@PersonID,0,'');
	
				SELECT t1.[ID]
					,t1.[Center]
					,t1.[Product]
					,t1.[ContractNo]
					--,CASE WHEN ISNULL(t1.[ProductName],'') = '' THEN t2.[Product_SubType] ELSE t1.[ProductName] END as 'SUB_PRODUCT_NAME'
					,dbo.fnProductSubName(t1.ID) as 'SUB_PRODUCT_NAME'
					,t2.[SCRA_Code]
					,t2.[ID] as [ContractTypeId]
					,t1.[OpenDate]
					,t1.[CloseDate]
					,t3.[PersonID]
					,t1.[LegacyNo]
					,t5.[FirstName]
					,t5.[LastName]
					,t5.[MiddleInitial]
					,t6.[DependentType]
					,t1.[CardNo]
					,t1.[Charge_Off]
					,t1.[Charge_Off_Note]
				FROM [dbo].[Contract] t1 
					JOIN [dbo].[ContractType] t2 
						ON t1.[ContractTypeId] = t2.[ID]
					JOIN [dbo].[Customer] t3 
						ON t1.[PersonID] = t3.[PersonID] AND t3.PersonID IN (SELECT [ID] FROM #temp)
  					JOIN [dbo].[Person] t5
						ON t3.PersonID = t5.[ID]
					JOIN #temp t6 ON t3.PersonID = t6.[ID]
				WHERE t1.[IsDeleted] = 0 

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END


/*
EXEC [dbo].[spContract_List] 22
*/
