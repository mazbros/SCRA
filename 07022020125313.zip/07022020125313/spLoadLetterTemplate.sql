-- =============================================
-- Author:		&lt;Aleksey Mazur&gt;
-- Create date: &lt;03/10/2020&gt;
-- Description:	&lt;Load letter template&gt;
-- =============================================
CREATE PROCEDURE [dbo].[spLoadLetterTemplate]
	@id INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT CONVERT(varchar(max), [Template], 0) as [Template] 
		FROM [dbo].[Letter_DATA] 
			WHERE LetterNumber = @id;

END
