CREATE PROCEDURE [dbo].[spGetBenefitInformation]
	@BenefitId INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  	INT,
			@ErrorSource    SYSNAME,
			@ErrorState 	INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT B.ID as [BenefitId]
					 , A.ID as [ActiveDutyId]
					 , C.ID as [ContractId]
					 , D.ID as [BenefitDetailId]
					 , A.StartDate as [ActiveDutyStartDate]
					 , A.EndDate as [ActiveDutyEndDate]
					 , D.BenefitEffectiveDate
					 , D.ExpectedRemovalDate as [BenefitExpectedRemovalDate]
					 , D.BenefitRemovedDate
					 , dbo.fnProductSubName(C.ID) as [SUB_PRODUCT_NAME]      
					 , CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as [AccountNumber]
					 , T.SCRA_Code
					 , C.OpenDate
					 , C.CloseDate
				FROM [Benefit] as B
						LEFT JOIN [ActiveDuty] as A ON A.ID = B.ActiveDutyId
						LEFT JOIN [BenefitDetail] as D ON D.BenefitId = B.ID
						JOIN [Contract] as C ON C.ID = B.ContractID
						JOIN ContractType T ON C.ContractTypeId = T.ID
				WHERE C.IsDeleted = 0 AND B.ID = @BenefitId;

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	END

END
