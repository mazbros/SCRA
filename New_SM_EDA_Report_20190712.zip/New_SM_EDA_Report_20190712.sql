;with CTE AS (
	SELECT DISTINCT sm.PersonID,s.DateOfContact,s.MethodOfNotification,s.DateDMDCSearchPerformed,s.VerifyBySCRAOrMilOrders
				,s.ActiveAccountEligible,s.BenefitApprovedDeniedPending,s.StatusCode
				,s.NotEligReason,s.DenialReason,s.[90DayLetterSentOn],s.BenefitsRecvd,s.Returned,s.Account
	FROM [SCRA_DB].[dbo].[Migration_History] s 
	JOIN [dbo].[Servicemember] sm ON s.ServiceMemberID = sm.ServicememberID
	) 
	SELECT DISTINCT
		 CAST(pp.DateOfContact as date)		AS DateOfContact
		 ,CAST(st.CompletionDate as date)	AS LogDate
		--,cm.Name,
			--cte.MethodOfNotification
			,pp.Contactmethod
		--,COALESCE(cm.Name,
		--	cte.MethodOfNotification)					
											AS MethodOfNotification
		--,CAST(cte.DateDMDCSearchPerformed 
		--					as DATE)		
		,''									AS DateDMDCSearchPerformed
		,cte.VerifyBySCRAOrMilOrders		AS VerifyBySCRAOrMilOrders
		,ad.NoticeDate						AS DateMilitaryOrdersReceived
		--,dbo.fnGetUserName(
		--	COALESCE(t.AssigneeID,
		--				i.ModifiedBy))		AS Agent
		,dbo.fnGetUserName(t.AssigneeID)	AS Agent
		,dbo.fnGetUserName(t.QaAssigneeId)	AS QCAgent
		,CASE WHEN t.[Status] = 'completed' THEN 'Completed'
			  WHEN t.[Status] = 'qa_completed' THEN 'QA Completed'
			  WHEN t.[Status] = 'misdirected' THEN 'Misdirected'
			  WHEN t.[Status] = 'in_process' THEN 'In Process'
			  WHEN t.[Status] = 'rejected' THEN 'Rejected'
			  ELSE t.[Status] END			As TaskStatus
		--,COALESCE(CASE WHEN ISNULL(b.DenialReason	,'') <> '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status])-1) 
		--				ELSE CASE WHEN ISNULL(b.[Status],'') <> '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status])-1)
		--					ELSE NULL END END,
		--					cte.BenefitApprovedDeniedPending)
		--									AS BenefitApprovedDeniedPending
		--,b.[Status]
		,(SELECT DISTINCT UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status])-1) FROM dbo.Benefit bbb 
			WHERE bbb.ID = b.ID AND 
				  bbb.ContractID = b.ContractID AND 
				  --bbb.ActiveDutyID = ad.ID AND 
				  (bbb.PersonID = pp.ID OR bbb.PersonID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))  as [BenefitApprovedDeniedPending]
		,COALESCE(CASE WHEN ISNULL(b.DenialReason,'') <> '' THEN 'Not Eligible' 
					ELSE 
						CASE WHEN b.[Status] IN ('applying','applied','removing') THEN 'Active Duty' ELSE NULL END END,
						cte.StatusCode)
											AS StatusCode
		--,b.DenialReason						AS NotEligReason
		--,b.DenialReason
		,(SELECT DenialReason FROM dbo.Benefit bbb WHERE bbb.ID = b.ID AND bbb.ContractID = b.ContractID and /*bbb.ActiveDutyID = ad.ID and*/ (bbb.PersonID = pp.ID OR bbb.PersonID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))  as [NotEligReason]
		,(SELECT DenialReason FROM dbo.Benefit bbb WHERE bbb.ID = b.ID AND bbb.ContractID = b.ContractID and /*bbb.ActiveDutyID = ad.ID and*/ (bbb.PersonID = pp.ID OR bbb.PersonID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))  as [DenialReason]
		,pp.ID								AS ServiceMemberID
		,pp.LastName						AS ServicememberLastName
		,pp.FirstName						AS ServicememberFirstname
		,pp.MiddleInitial					AS ServicememberMiddleInitial
		,pp.DOB								AS DOB
		,cust.FNumber
		,pp.SSN								AS SocialSecurityNumber
		,bos.Branch							AS BranchOfService
		,ad.StartDate						AS ADStartDate
		,ad.EndDate							AS ADEndDate
		,bd.BenefitAppliedDate				AS DateBenefitsApplied
		,bd.ExpectedRemovalDate				AS ExpectedRemovalDate
		,bd.BenefitRemovedDate				AS DateBenefitsEnded
		,bd.BenefitEffectiveDate			AS BenefitsEffectiveDate
		,CASE WHEN ct.SCRA_Code = 'auto' THEN 'Auto'
			  WHEN ct.SCRA_Code = 'commercial' THEN 'Commercial Loan'
			  WHEN ct.SCRA_Code = 'consumer_loan' THEN 'Consumer Loan'
			  WHEN ct.SCRA_Code = 'credit_card' THEN 'Credit Card'
			  WHEN ct.SCRA_Code = 'mortgage' THEN 'Mortgage'
			  WHEN ct.SCRA_Code = 'safe_dep_box' THEN 'Safe Deposit Box'
			  WHEN ISNULL(ct.SCRA_Code,'') = '' THEN ''
			  ELSE 'Other' END
											AS ProductType
		,ct.SUB_PRODUCT_NAME				AS SubType
		,COALESCE(
			CASE 
				WHEN ISNULL(cnt.LegacyNo,'') = '' 
				THEN NULL 
				ELSE cnt.LegacyNo END,
			CASE 
				WHEN ISNULL(cnt.CardNo,'') = '' 
				THEN NULL 
				ELSE cnt.CardNo END,
			CASE 
				WHEN ISNULL(cnt.ContractNo,'') = '' 
				THEN NULL 
				ELSE cnt.ContractNo END)	AS AccountNum
		,cnt.OpenDate						AS StartDate
		,cnt.CloseDate						AS EndDate
		,COALESCE(CASE WHEN cte.ActiveAccountEligible = 0 THEN 'FALSE'
					   WHEN cte.ActiveAccountEligible = 1 THEN 'TRUE'
					   ELSE NULL END,
			CASE WHEN ISNULL(b.DenialReason	,'') <> '' 
					THEN 'FALSE' 
					ELSE 
						CASE WHEN b.[Status] IN ('applying','applied','removing') 
							THEN 'TRUE' ELSE 'FALSE' END END)
											AS ActiveAccountEligible
		,pp.Address1
		,pp.Address2
		,pp.City
		,pp.[State]
		,pp.Zip
		,pp.Email
		,COALESCE(CASE WHEN cte.BenefitsRecvd = 0 THEN 'FALSE'
					   WHEN cte.BenefitsRecvd = 1 THEN 'TRUE'
					   ELSE NULL END,
			CASE WHEN ISNULL(b.DenialReason	,'') <> '' 
					THEN 'FALSE' 
					ELSE 
						CASE WHEN b.[Status] IN ('applying','applied','removing') 
							THEN 'TRUE' ELSE 'FALSE' END END)
											AS BenefitsRecvd
		,bd.CurrentRate						AS [Interest Rate before SCRA]
		,bd.IsInterestAdjustmentCalculated	AS [Interest Adjustment]
		,bd.PromotionEndDate				AS [Promo Rate End Date] 
		,bd.InterestRefunded				AS RefundAmount
		,bd.InterestRefundedDate			AS RefundDate
		,REPLACE(STUFF((SELECT ',' + note.Comment FROM dbo.Note note WHERE PersonID = pp.ID ORDER BY note.[Timestamp] DESC FOR XML PATH('')),1,1,''),',',CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)) as Comments
		--,REPLACE(REPLACE(REPLACE(note.Comment,CHAR(13)+CHAR(10),'|'),CHAR(34),''''''),CHAR(9),' ') AS Comments
		--,REPLACE(REPLACE(REPLACE(note.Comment,CHAR(13)+CHAR(10),'|'),CHAR(34),''''''),CHAR(9),' ') AS AdditionalComments
		--,com.ID								AS LetterID
		--,com.CommunicationDate				AS DateSent
		--,com.LetterId						AS LetterCode
		--,cte.Returned						AS Returned
		--,RIGHT(COALESCE(cte.Account,CASE WHEN ISNULL(cnt.LegacyNo,'') = '' THEN NULL ELSE cnt.LegacyNo END,CASE WHEN ISNULL(cnt.CardNo,'') = '' THEN NULL ELSE cnt.CardNo END),4)						
		--									AS Account
		--,ld.LetterName						AS LetterName
		--,datediff(day,ISNULL(com.CommunicationDate,''),ISNULL(pp.DateOfContact,'')) as Delta
INTO #Temp		
	 FROM (SELECT DISTINCT
       p.ID,p.FirstName,p.LastName,p.MiddleInitial,p.SSN,p.DOB,p.Address1,p.Address2,p.City,p.[State],p.Zip,p.Phone,p.Email,dbo.fnResponseMethodName(p.ContactMethodID) as Contactmethod
,i.InquiryDate as DateOfContact from Person p 
			 JOIN Inquiry i ON p.ID = i.Servicememberid
	WHERE Origin <> 'dmdc_check' --and InquiryType = 'benefit_request'
	UNION
	SELECT DISTINCT
       p.ID,p.FirstName,p.LastName,p.MiddleInitial,p.SSN,p.DOB,p.Address1,p.Address2,p.City,p.[State],p.Zip,p.Phone,p.Email,cte.MethodOfNotification as ContactMethod
       --dbo.fnResponseMethodName(p.ContactMethodID) as ContactMethod
,cte.DateOfContact as DateOfContact from Person p 
			 JOIN CTE cte ON p.ID = cte.PersonID
	WHERE Origin <> 'dmdc_check') pp   
		
		outer apply(Select distinct FNumber from dbo.Customer where PersonID=pp.ID and PersonID in (Select ppp.ID As PersonId from Person ppp 
						where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID ) OR ppp.ID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))) cust
						
		--outer apply( Select distinct ID,CommunicationDate,LetterId,TaskId,PersonId,BenefitID from dbo.Communication where PersonID in (Select ppp.ID As PersonId from Person ppp 
		--					where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID )))) com
							
		outer apply (Select distinct  ContactMethodID from dbo.Inquiry where COALESCE(ServicememberId,PersonInquiringId) in (Select ppp.ID As PersonId from Person ppp 
							where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID ) OR ppp.ID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))) r
			LEFT JOIN dbo.ContactMethod cm 
				ON r.ContactMethodId = cm.ID
				
		outer apply (Select * from dbo.ActiveDuty a where a.PersonID in (Select ppp.ID As PersonId from Person ppp 
							where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID ) OR ppp.ID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)))) ad
			INNER JOIN dbo.BranchOfService bos 
				ON bos.ID = ad.BranchOfServiceID
				
		outer apply (select * from dbo.Benefit bb where bb.PersonID in (Select ppp.ID As PersonId from Person ppp 
							where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID ) OR ppp.ID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID))
									or bb.ContractID IN (SELECT ID FROM dbo.[Contract] WHERE (PersonID = pp.ID OR PersonID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)) and ID = bb.ContractID)
									AND bb.ActiveDutyID = ad.ID --IN (SELECT ID FROM ActiveDuty WHERE PersonID = pp.ID AND ID = ad.ID) 
									--AND bb.ID = com.BenefitID
										/*(and (datepart(year,pp.DateOfContact) = DATEPART(year,ad.StartDate) or DATEPART(year,pp.DateOfContact) = DATEPART(year,ad.EndDate))*/ ) ) b
			 LEFT JOIN dbo.BenefitDetail bd 
				ON b.ID = bd.BenefitId
				
		outer apply (select * from dbo.[Contract] c where b.ContractID = c.ID AND c.IsDeleted = 0 AND c.PersonID in (Select ppp.ID As PersonId from Person ppp 
							where ( ppp.ID = pp.ID OR ppp.ID IN (Select ServicememberId from dbo.Inquiry i WHERE i.ServicememberId = pp.ID ) OR ppp.ID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID))
							AND c.ID = b.ContractID)
							AND b.ContractID = c.ID) cnt
			LEFT JOIN dbo.ContractType ct 
				ON cnt.ContractTypeId = ct.ID					
				
		LEFT JOIN CTE cte on pp.ID = cte.PersonID									

		--LEFT JOIN dbo.Letter_DATA ld 
		--		ON com.LetterId = ld.ID AND com.PersonID = pp.ID
				
		LEFT JOIN dbo.Task t ON (pp.ID = t.PersonID OR t.PersonID IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID)) and b.TaskID = t.ID 
		
		LEFT JOIN dbo.SubTask st ON (t.ID = st.TaskID and st.SortNo = 1)
		
		--+-
		LEFT JOIN dbo.Inquiry i ON pp.ID = i.ServicememberId OR i.ServicememberId IN (Select FromID FROM PersonToPersonLink WHERE ToID = pp.ID) --and (pp.DateOfContact = i.InquiryDate)
		
		--where pp.ID IN (1498/*,648*/) --
		--and  CAST(pp.DateOfContact as date) between '2019-06-01' and '2019-06-30' -- and
		WHERE 1=1 AND ISNULL(t.TaskType,'') <> 'contact_customer'
						
ORDER BY CAST(pp.DateOfContact as date) DESC,pp.ID

--SELECT * FROM #Temp Where ServiceMemberID = 648--680--1723--516--1498---382--

--SELECT * FROM #Temp 
--	WHERE
--			(DateOfContact BETWEEN ADStartDate AND ISNULL(ADEndDate,CAST(GETDATE() AS DATE)) OR 
--				ISNULL(DateBenefitsApplied,CAST(GETDATE() as DATE)) BETWEEN  ADStartDate AND ISNULL(ADEndDate,CAST(GETDATE() AS DATE)))
--			--and ((BenefitApprovedDeniedPending IN ('Applying','Applied','Denied','Denying') AND DateBenefitsEnded IS NULL) OR
--			--	(BenefitApprovedDeniedPending IN ('Removed','Removing') AND DateBenefitsEnded IS NOT NULL))
--			and datediff(day,ISNULL(DateSent,''),ISNULL(DateOfContact,'')) >= 0 
				
	--AND ServiceMemberID = 1815--680--648--1723--516--1498---382--
--	AND DateOfContact IS NOT NULL

SELECT * FROM #Temp 
	WHERE
			(DateOfContact BETWEEN ADStartDate AND ISNULL(ADEndDate,CAST(GETDATE() AS DATE)) --OR 
				--ISNULL(DateBenefitsApplied,CAST(GETDATE() as DATE)) BETWEEN  ADStartDate AND ISNULL(ADEndDate,CAST(GETDATE() AS DATE))
				) AND 
			(
				(BenefitApprovedDeniedPending IN ('Applying','Applied') AND DateBenefitsEnded IS NULL) OR
				(BenefitApprovedDeniedPending IN ('Denied','Denying') AND DateBenefitsApplied IS NULL) OR
				(BenefitApprovedDeniedPending IN ('Removed','Removing') AND DateBenefitsEnded IS NOT NULL) /*OR
				(BenefitApprovedDeniedPending IS NULL)*/
			)
			--and datediff(day,ISNULL(DateSent,''),ISNULL(DateOfContact,'')) >= 0 
				
	--AND ServiceMemberID = 355 --789 --1815 --382 --1498 --516 --1723 --680 --384 --648 --891--
	--AND DateOfContact IS NOT NULL
	AND ISNULL(TaskStatus,'') <> 'Misdirected'
	ORDER BY DateOfContact DESC

DROP TABLE #Temp	
