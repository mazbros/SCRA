USE [SCRA_DB]
GO
/****** Object:  Table [dbo].[QaRejectionReason]    Script Date: 03/10/2020 11:29:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QaRejectionReason](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL,
 CONSTRAINT [PK_QaRejection_Reason] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[QaRejectionReason] ON
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (1, N'Date Input', 1)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (2, N'Request Type', 2)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (3, N'Contact Method', 3)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (4, N'Identification Method', 4)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (5, N'Response Method', 5)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (6, N'Requester Information', 6)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (7, N'Servicemember Information', 7)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (8, N'Product Details', 8)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (9, N'Branch of Service', 9)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (10, N'Service Verification', 10)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (11, N'Eligibility Determination', 11)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (12, N'Denial Reason', 12)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (13, N'Interest Adjustment Amount', 13)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (14, N'Fee Refund Amount', 14)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (15, N'Current Interest Rate', 15)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (16, N'Benefit Checkbox', 16)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (17, N'Case File Note', 17)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (18, N'Case File Attachment', 18)
INSERT [dbo].[QaRejectionReason] ([ID], [Name], [SortIndex]) VALUES (19, N'Other', 19)
SET IDENTITY_INSERT [dbo].[QaRejectionReason] OFF
/****** Object:  Table [dbo].[DenialReason]    Script Date: 03/10/2020 11:29:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DenialReason](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL,
 CONSTRAINT [PK_Denial_Reason] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[DenialReason] ON
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (1, N'Active Duty Prior to Contract', 1)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (2, N'Contract after release from Active Duty', 2)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (3, N'Contract Closed prior to Active Duty', 3)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (4, N'Contract Closed prior to proactive project start date 3/1/17', 4)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (5, N'Active Duty ended before Proactive Project Start Date 3/1/17', 5)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (6, N'Request rec''d more than 180 days after release from Active Duty', 6)
INSERT [dbo].[DenialReason] ([ID], [Name], [SortIndex]) VALUES (7, N'Servicemember is not an Owner or Co-Holder on Contract', 7)
SET IDENTITY_INSERT [dbo].[DenialReason] OFF

/****** Object:  StoredProcedure [dbo].[spGetTaskIDbyInquiryID]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/09/2020>
-- Description:	<Get task by inqiury ID>
-- =============================================
CREATE PROCEDURE [dbo].[spGetTaskIDbyInquiryID] 
	@id int
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;

	SELECT [ID] FROM [dbo].[Task] WHERE [InquiryID] = @id ORDER BY [CreateDate]

END

GO

/****** Object:  StoredProcedure [dbo].[spGetUserList]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/09/2020>
-- Description:	<Get list of users>
-- =============================================
CREATE PROCEDURE [dbo].[spGetUserList]
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [ID], [UserName], [Name], [Active], [Type] FROM [dbo].[Employee] ORDER BY [Name];
    
END

GO

/****** Object:  StoredProcedure [dbo].[spGetTaskById]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/09/2020>
-- Description:	<Get task and subtask info>
-- =============================================
CREATE PROCEDURE [dbo].[spGetTaskById]
	@taskId INT
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
		SELECT	T.Id
            , T.Title
            , T.DueDate
            , I.InquiryDate as ContactDate
            , I.ResponseDate
            , T.CreateDate
            , T.Status
            , T.TaskType
            , T.InquiryId
            , T.PersonId
            , P.FirstName
            , P.LastName
            , CASE WHEN ISNULL(C.LegacyNo, '') <> '' THEN C.LegacyNo
              WHEN ISNULL(C.CardNo, '') <> '' THEN C.CardNo END AS AccountNum
            , T.ContractId
            , T.QaComplete
            , T.ModifiedBy
            , m.UserName AS ModifiedByUserName
            , m.Name as ModifiedByName
            , T.AssigneeID
            , e.UserName AS AssigneeUserName
            , e.Name as AssigneeName
            , T.QaAssigneeID
            , qae.UserName AS QaAssigneeUserName
            , qae.Name as QaAssigneeName    
        FROM	dbo.Task T
        JOIN 	dbo.Person P On P.ID = T.PersonID
        LEFT JOIN dbo.Employee m ON m.ID = T.ModifiedBy
        LEFT JOIN dbo.Employee e ON e.ID = T.AssigneeID
        LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
        LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
        left join Contract C On C.ID = T.ContractID
        WHERE   T.Id = @taskId;

        SELECT  x.Id, x.Title, x.Code, x.Status, x.SortNo,
	            x.IsComplete, x.CompletionDate, x.CompletedBy, e.UserName AS CompletedByUserName, e.Name as CompletedByName,
                x.IsQaComplete, x.QaCompletionDate, x.QaCompletedBy, eq.UserName AS QaCompletedByUserName, eq.Name as QaCompletedByName
        FROM	dbo.SubTask x
        LEFT JOIN dbo.Employee e
            ON e.ID = x.CompletedBy
        LEFT JOIN dbo.Employee eq
            ON eq.ID = x.QaCompletedBy
        WHERE   x.TaskID = @taskId
        ORDER BY x.ID;
        
END

GO

/****** Object:  StoredProcedure [dbo].[spGetQaRejectionReasonList]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/06/2020>
-- Description:	<Get QA rejection reason list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetQaRejectionReasonList]
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;

    SELECT  [ID], [Name] FROM [dbo].[QaRejectionReason] ORDER BY [SortIndex]
    
END

GO

/****** Object:  StoredProcedure [dbo].[spGetDenialReasonList]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/05/2020>
-- Description:	<Get denial reason list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetDenialReasonList]
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;

    SELECT  [ID], [Name] FROM [dbo].[DenialReason] ORDER BY [SortIndex]
    
END

GO

/****** Object:  StoredProcedure [dbo].[spLoadTaskList]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <02/25/2020>
-- Description:	<Getting filtered task list>
-- =============================================
CREATE PROCEDURE [dbo].[spLoadTaskList] 
	@filterPersonID		INT,
	@filterContractID	INT,
	@filterTypes		varchar(255),
	@filterStatuses		varchar(255), 
	@filterAssigneeId	INT,
	@filterQaAssigneeId INT,
	@filterTaskId		INT,
	@filterHideAssigned BIT,
	@searchText			varchar(255)
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE @SQL VARCHAR(MAX)
	SET @SQL = 'SELECT	T.Id
		            , T.Title
		            , T.DueDate
                    , I.InquiryDate as ContactDate
                    , I.ResponseDate
		            , T.CreateDate
		            , T.Status
		            , T.TaskType
		            , T.InquiryId
                    , T.ContractId
		            , T.PersonId
		            , P.FirstName
		            , P.LastName
		            , T.QaComplete
		            , T.AssigneeID
                    , E.UserName AS AssigneeUserName
                    , E.Name as AssigneeName
                    , T.QaAssigneeID
                    , qae.UserName AS QaAssigneeUserName
                    , qae.Name as QaAssigneeName
                    , CASE WHEN ISNULL(C.LegacyNo, '''') <> '''' THEN C.LegacyNo
                      WHEN ISNULL(C.CardNo, '''') <> '''' THEN C.CardNo END AS AccountNum
            FROM	dbo.Task T
            JOIN 	dbo.Person P On P.ID = T.PersonID
            LEFT JOIN dbo.Employee E ON E.ID = T.AssigneeID
            LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
            LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
            left join (Select distinct TaskId, ContractID from Benefit) B On B.TaskID = T.ID
			left join Contract C On C.ID = B.ContractID
            WHERE   1=1 '
            
            IF @filterPersonId > 0 BEGIN
				SET @SQL = @SQL + ' AND T.PersonID = ' + CAST(@filterPersonId as varchar(16))
            END
            IF @filterContractId > 0 BEGIN
				SET @SQL = @SQL + ' AND T.ContractID = ' + CAST(@filterContractId as varchar(16))
            END
            IF LEN(@filterTypes) > 0 BEGIN
				SET @SQL = @SQL + ' AND T.TaskType IN (' + @filterTypes + ') '
            END
            IF LEN(@filterStatuses) > 0 BEGIN
				SET @SQL = @SQL + ' AND T.Status IN (' + @filterStatuses + ') '
            END
            IF @filterAssigneeId > 0 BEGIN
				SET @SQL = @SQL + ' AND (T.AssigneeID = ' + CAST(@filterAssigneeId as varchar(16)) + ') '
            END
            IF @filterQaAssigneeId > 0 BEGIN
				SET @SQL = @SQL + ' AND (T.QaAssigneeID = ' + CAST(@filterQaAssigneeId as varchar(16)) + ') '
            END
            IF @filterHideAssigned > 0 BEGIN
				SET @SQL = @SQL + ' AND T.AssigneeID is NULL '
            END
            IF @filterTaskId > 0 BEGIN
				SET @SQL = @SQL + ' AND T.Id = ' + CAST(@filterTaskId as varchar(16))
            END
            if LEN(@searchText) > 0 BEGIN
            
                SET @searchText = REPLACE(@searchText,'''', '''''');

                SET @SQL = @SQL + ' AND (T.[Title] LIKE ''%' + @searchText + '%'' OR ' + CHAR(10) + CHAR(9) +
                       '   [AssigneeID] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') OR ' + CHAR(10) + CHAR(9) +
                       '   [QaAssigneeId] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') /*OR ' + CHAR(10) + CHAR(9) +
                       '   [ModifiedBy] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'')*/ ' + CHAR(10) + CHAR(9) +
                       '   ) '
            END
            
            SET @SQL = @SQL + '
            ORDER BY T.CreateDate DESC;'
            
PRINT @SQL            
            
EXEC (@SQL)

END

GO

/****** Object:  StoredProcedure [dbo].[spGetCommunication]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <02/25/2020>
-- Description:	<Getting communication for a task or for a person>
-- ===============================================================
CREATE PROCEDURE [dbo].[spGetCommunication] 
	@taskId		INT = NULL,
	@PersonId	INT = NULL
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @SQL varchar(max)
	SET @SQL = '
	SELECT	[ID],[PersonID],[BenefitID],[CommunicationDate],[ContactMethodId],[ResponseText],[LetterId],[TaskId]
		FROM	[dbo].[Communication]
			WHERE   1 = 1 ' 
			
			IF LEN(@taskId) > 0 BEGIN 
				SET @SQL = @SQL + ' AND TaskId = ' + CAST(@taskId as varchar(16))
			END
			IF LEN(@PersonID) > 0 BEGIN
				SET @SQL = @SQL + ' AND PersonId= ' + CAST(@PersonId as varchar(16)) 
			END
	
	SET @SQL = @SQL + '
			ORDER BY [Timestamp] DESC;'

	EXEC(@SQL)        
            
END

GO

/****** Object:  StoredProcedure [dbo].[spLoadContractType]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <02/25/2020>
-- Description:	<Loading contract type info>
-- =============================================
CREATE PROCEDURE [dbo].[spLoadContractType] 
	@categoryCode varchar(55)
AS
BEGIN

	SET NOCOUNT ON;

	SELECT	[ID] AS ContractTypeId, [SCRA_Code], [SUB_PRODUCT_NAME]
		FROM	dbo.ContractType
	WHERE [SCRA_Code] = @categoryCode;

END

GO

/****** Object:  StoredProcedure [dbo].[spReservists_Benefits_Applied_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spReservists_Benefits_Applied_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date],
						[SLA Met],
						[Days Since Contact],
						[NotificationDateStandard] as [Notification Date Standard],
						[ADSDStandard] as [Active Duty Start Dadte Standard]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,adr.NoticeDate
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') as DueDate
					,CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as DATE) <= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),''))
							THEN 'Yes' ELSE 'No' END as [SLA Met]
					,DATEDIFF(day,i.InquiryDate,isnull(bd.BenefitAppliedDate,getdate())) as [Days Since Contact]							
					,CASE WHEN adr.Reserv = 'Yes' THEN
						CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') <> '1900-01-01' THEN
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = CAST(adr.NoticeDate as DATE) THEN 'Yes' ELSE 'No' END 
						ELSE 'No'
						END 
					 ELSE ''
					 END as NotificationDateStandard
					,CASE WHEN adr.Reserv = 'Yes' THEN
						CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') = '1900-01-01' THEN			
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = DATEADD(day,-45,adr.ADSD) THEN 'Yes' ELSE 'No' END
						ELSE 'No'
						END	
					 ELSE ''							
					 END as ADSDStandard
					 FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv, CONVERT(varchar(10),MAX(ad.NoticeDate),121) as NoticeDate 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND (t.TaskType = 'add_benefit' OR t.TaskType IS NULL)
							
							AND (
									(
										(ISNULL(bd.BenefitAppliedDate,'') >= @DateStart AND ISNULL(bd.BenefitAppliedDate,'') <= @DateEnd)
									) 
									AND bd.BenefitAppliedDate IS NOT NULL
								)
							AND c.IsDeleted = 0
						--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate < @DateEnd
						AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity')
						AND adr.Reserv = 'Yes'
				) th
				ORDER BY SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spReservists_Benefits_Applied_SLA_EXL_Report] @DateStart='2019-01-01',@DateEnd='2019-12-31'
*/

GO

/****** Object:  StoredProcedure [dbo].[spBenefit_Applied_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spBenefit_Applied_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date],
						[SLA Met],
						[Days Since Contact],
						[Next Business Day]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') as DueDate
					,ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') as DueDateNBD
					,CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as DATE) <= CAST(ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') as DATE) THEN 'Yes' ELSE 'No' END as [SLA Met]
					,ISNULL(CONVERT(VARCHAR(10),
							DATEDIFF(day,ISNULL(i.InquiryDate,getdate()),bd.BenefitAppliedDate)),'') as [Days Since Contact]
					,CASE WHEN ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') <> ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
							AND ISNULL(bd.BenefitAppliedDate,getdate()) = ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
						THEN 'Yes' ELSE '' END as [Next Business Day]
				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND (t.TaskType = 'add_benefit' OR t.TaskType IS NULL)
							
							AND (
									(
										(ISNULL(bd.BenefitAppliedDate,'') >= @DateStart AND ISNULL(bd.BenefitAppliedDate,'') <= @DateEnd)
									) 
									AND bd.BenefitAppliedDate IS NOT NULL
								)
							AND c.IsDeleted = 0
						--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate < @DateEnd
						AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity')
				) th
				ORDER BY SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spBenefit_Applied_SLA_EXL_Report] @DateStart='2019-01-01',@DateEnd='2019-12-31'
*/

GO

/****** Object:  StoredProcedure [dbo].[spBenefits_Removed_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spBenefits_Removed_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date],
						[SLA Met],
						[Days Since Due Date],
						[Next Business Day]
				FROM (
				SELECT	BenefitIntervalId,ContactDate,IdentificationMethod,/*OriginalMethodOfContact,*/SMID,FNumber,SMFirstName,SMMiddleInitial,SMLastName,Branch,Reserv,ADSD,
						ADED,[Status],TaskStatus,BenefitAppliedDate,BenefitEffectiveDate,ExpectedRemovalDate,BenefitRemovedDate,ExtendDate,CustID,
						CustFNumber,CustFirstName,CustMiddleInitial,CustLastName,ContractNo,AccountNo,ProductType,ProductSubType,ProductOpenDate,ProductCloseDate,
						DueDate,[SLA Met],[Days Since Due Date], CASE WHEN [Days Since Due Date] > [Days Since Due Date (Next Business Day)] THEN 'Yes' ELSE '' END as 'Next Business Day'
				FROM (
				SELECT DISTINCT ROW_NUMBER() OVER (PARTITION BY b.BenefitIntervalID ORDER BY i.inquiryDate DESC) as RN,b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(VARCHAR(10),CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
						ISNULL(CONVERT(VARCHAR(10),COALESCE(bd.ExpectedRemovalDate,dbo.fnGetNextBusinessDay(CASE WHEN adr.ADED = '9999-12-31' THEN NULL ELSE DATEADD(day, 90, adr.ADED) END)),121),'') 
						ELSE ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'')
					 END,121),'') as DueDate
					,CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
						CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as DATE) <= 
								COALESCE(dbo.fnGetNextBusinessDay(DATEADD(day, 90, adr.ADED)),dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate)) THEN 'Yes' ELSE 'No' END
						ELSE '' END
					 ELSE 
						CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as DATE) <= dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate) THEN 'Yes' ELSE 'No' END
							ELSE '' 
						END
					 END as [SLA Met]
					 ,ISNULL(CONVERT(VARCHAR(10),
							CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								DATEDIFF(day,
									CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
										ISNULL(COALESCE(bd.ExpectedRemovalDate,dbo.fnGetNextBusinessDay(CASE WHEN adr.ADED = '9999-12-31' THEN NULL ELSE dbo.fnGetNextBusinessDay(DATEADD(day,90,adr.ADED)) END)),'') 
									ELSE ISNULL(bd.ExpectedRemovalDate,GETDATE())
									END,ISNULL(bd.BenefitRemovedDate,GETDATE()))
							ELSE NULL END),'') as [Days Since Due Date]
					 ,ISNULL(CONVERT(VARCHAR(10),
							CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								DATEDIFF(day,
									CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
										ISNULL(COALESCE(dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate),dbo.fnGetNextBusinessDay(DATEADD(day,90,adr.ADED))),'')
									ELSE ISNULL(dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate),GETDATE()) 
									END,ISNULL(bd.BenefitRemovedDate,GETDATE()))
							ELSE NULL END),'') as [Days Since Due Date (Next Business Day)]
				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														JOIN [Customer] sm on   sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND t.TaskType IN ('remove_benefit')
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND b.[Status] IN ('removed','removing')
							AND c.IsDeleted = 0
							AND ISNULL(bd.BenefitRemovedDate,'') >= @DateStart AND ISNULL(bd.BenefitRemovedDate,'') <= @DateEnd
							AND	ISNULL(bd.ExtendDate,'1900-01-01') < ISNULL(bd.BenefitRemovedDate,'9999-12-31') 
							--AND ISNULL(bd.BenefitAppliedDate,'') <> ISNULL(bd.BenefitRemovedDate,'')
							AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity')
					) th
				WHERE RN = 1
				) th2
				ORDER BY BenefitRemovedDate
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spBenefits_Removed_SLA_EXL_Report] @DateStart='2019-01-01',@DateEnd='2019-12-31'
*/

GO

/****** Object:  StoredProcedure [dbo].[spDenied_Ineligible_Letter_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spDenied_Ineligible_Letter_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date],
						[CommunicationDate] as [Communication Date],
						[SLA Met],
						[Days Since Contact]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN CASE WHEN LEN(p.Origin) > 0 THEN UPPER(SUBSTRING(p.Origin,1,1))+SUBSTRING(p.Origin,2,LEN(p.Origin) - 1) ELSE '' END
						ELSE ''
					END as IdentificationMethod
					,b.PersonID as SMID,ISNULL(sm.FNumber,'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					,ISNULL(adr.Branch,'') as Branch,ISNULL(adr.Reserv,'') as Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE '' END END as ADED 
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,ISNULL(b.DenialReason,'') as DenialReason
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,ISNULL(cust.FNumber,'') as CustFNumber,ISNULL(cp.FirstName,'') as CustFirstName
					,ISNULL(cp.MiddleInitial,'') as CustMiddleInitial,ISNULL(cp.LastName,'') as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'')) as DueDate
					,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as CommunicationDate
					,CASE WHEN com.CommunicationDate <= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'')) THEN 'Yes' 
						   ELSE CASE WHEN com.CommunicationDate IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,ISNULL(com.CommunicationDate,getdate())) as [Days Since Contact]						   
					 FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON b.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											LEFT JOIN 
													(SELECT b.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b.ActiveDutyID) as ADCount, 
														   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
													FROM ActiveDuty ad JOIN Benefit b on b.ActiveDutyID = ad.ID WHERE b.BenefitIntervalId IS NOT NULL GROUP BY b.BenefitIntervalID,ad.PersonID) adr
													ON b.BenefitIntervalId = adr.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 RIGHT JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													LEFT JOIN [Customer] cust on c.PersonID = cust.PersonID
														LEFT JOIN [Person] cp ON cust.PersonID = cp.ID
															LEFT JOIN [Customer] sm on sm.PersonID = adr.PersonID
																LEFT JOIN [Person] smn on smn.ID = adr.PersonID
																	LEFT JOIN [Communication] com ON (b.PersonID = ISNULL(com.PersonID,'') /* DELETE NEXT TWO LINES TO INCLUDE MORE PEOPLE THAT SHOULD BE INCLUDED */
																					AND ISNULL(com.BenefitId,'') IN (SELECT ID FROM Benefit WHERE BenefitIntervalId = b.BenefitIntervalId) 
																					AND ISNULL(com.TaskID,'') = t.ID
																					)
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND b.[Status] IN ('denied','denying')
							AND (t.TaskType = 'deny_benefit')
							--AND i.InquiryDate >= @DateStart 
							--AND i.InquiryDate <= @DateEnd
							AND ((i.InquiryDate BETWEEN @DateStart AND @DateEnd) OR (ISNULL(com.CommunicationDate,'') BETWEEN @DateStart AND @DateEnd))
							AND ISNULL(c.IsDeleted,'') = 0
							--AND (ISNULL(com.CommunicationDate,'') BETWEEN @DateStart AND @DateEnd)
							AND (ISNULL(i.IdentificationMethod,'') <> 'internal' 
							AND ISNULL(com.LetterId,'3') = 3)
						--ORDER BY ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),''),b.PersonID							
				) th
				ORDER BY ISNULL(CONVERT(VARCHAR(10),cast(ContactDate as DATE),121),''),SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spDenied_Ineligible_Letter_SLA_EXL_Report] @DateStart='2019-01-01',@DateEnd='2019-12-31'
*/

GO

/****** Object:  StoredProcedure [dbo].[spGN_Letter_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spGN_Letter_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date],
						[CommunicationDate] as [Communication Date],
						[SLA Met],
						[Days Since Contact]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,adr.NoticeDate
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(varchar(10),dbo.fnGetNextBusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') as DueDate
					,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as CommunicationDate
					,CASE WHEN ISNULL(CONVERT(varchar(10),dbo.fnGetNextBusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') >= com.CommunicationDate THEN 'Yes' 
						   ELSE CASE WHEN com.CommunicationDate IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,isnull(com.CommunicationDate,getdate())) as [Days Since Contact]
					 FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											LEFT JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv, CONVERT(varchar(10),MAX(ad.NoticeDate),121) as NoticeDate 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN [Person] smn on smn.ID = adr.PersonID
															LEFT JOIN [Communication] com ON (b.PersonID = com.PersonID 
																					AND ISNULL(com.BenefitId,'') IN (SELECT ID FROM Benefit WHERE BenefitIntervalId = b.BenefitIntervalId) 
																					AND ISNULL(com.TaskID,'') = t.ID)
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND b.[Status] IN ('applied','applying')
							AND (t.TaskType = 'add_benefit')
							--AND (ISNULL(com.CommunicationDate,'') BETWEEN @DateStart AND @DateEnd/* OR com.CommunicationDate IS NULL*/)
							AND i.InquiryDate >= @DateStart AND i.InquiryDate <= @DateEnd
							AND c.IsDeleted = 0
							AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card')
							AND ISNULL(com.LetterId,'9') = 9
				) th
				ORDER BY SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spGN_Letter_SLA_EXL_Report] @DateStart='2019-01-01',@DateEnd='2019-12-31'
*/

GO

/****** Object:  StoredProcedure [dbo].[spRequest_Received_Letter_SLA_EXL_Report]    Script Date: 03/10/2020 11:27:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spRequest_Received_Letter_SLA_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT ContactDate,IdentificationMethod,OriginalMethodOfContact,SMID,FNumber,SMFirstName,SMMiddleInitial,SMLastName,DueDate,CommunicationDate,[SLA Met],[Days Since Contact]--,DATENAME(weekday,ContactDate) as ContactDay,DATENAME(weekday,DueDate) as DueDay,DATENAME(weekday,CommunicationDate) as CommDate 
FROM (
SELECT DISTINCT ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,p.ID as SMID,ISNULL(COALESCE(cust.FNumber,sm.FNumber),'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					,dbo.fnGetNextBusinessDay(ISNULL(CONVERT(VARCHAR(10),DATEADD(day, 15, i.InquiryDate),121),'')) as DueDate
					,ISNULL(CONVERT(VARCHAR(10),com.LetterID),'') as LetterID
					,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as Date1
					,ISNULL(CONVERT(VARCHAR(10),i.ResponseDate,121),'') as Date2
					,ISNULL(CONVERT(VARCHAR(10),COALESCE(com.CommunicationDate,i.ResponseDate),121),'') as CommunicationDate
					,ISNULL(i.ResponseMethodID,'') as InquiryResponseMethod
					,CASE WHEN  COALESCE(com.CommunicationDate,i.ResponseDate) <= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 15, i.InquiryDate),121),'')) THEN 'Yes' 
						   ELSE CASE WHEN COALESCE(com.CommunicationDate,i.ResponseDate) IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,isnull(COALESCE(com.CommunicationDate,i.ResponseDate),getdate())) as [Days Since Contact]
					 FROM [Inquiry] i 
							JOIN [Task] t ON i.ID = t.InquiryID
								JOIN [Person] p ON i.ServicememberId = p.ID
									LEFT JOIN [Contract] c ON (p.ID = c.PersonID)
										LEFT JOIN [Customer] cust on p.ID = cust.PersonID
											LEFT JOIN [ActiveDuty] ad ON p.ID = ad.PersonID
												LEFT JOIN [Communication] com ON p.ID = com.PersonID AND ISNULL(com.TaskID,'') = t.ID
													LEFT JOIN [Customer] sm on sm.PersonID = ad.PersonID
														LEFT JOIN [Person] smn on smn.ID = ad.PersonID
					WHERE 1=1
						
						AND (i.InquiryType = 'benefit_request'
						AND t.TaskType = 'request_benefits'
						AND ISNULL(i.IdentificationMethod,'') <> 'internal' 
						AND ((ISNULL(com.LetterId,'') = 2 OR com.LetterId IS NULL))
							OR (i.ResponseMethodId = 3 AND i.ResponseText LIKE '%request received%'))
						AND ISNULL(COALESCE(com.CommunicationDate,i.ResponseDate),'1900-01-01') BETWEEN @DateStart and @DateEnd
					) th 
			WHERE (LetterID = 2 OR LetterID = '') AND IdentificationMethod <> '' AND (InquiryResponseMethod = 3 OR InquiryResponseMethod = '')
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spExpiredAccounts_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31'
*/

GO

