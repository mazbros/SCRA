USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spGetContractHistory]    Script Date: 03/11/2020 14:26:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Get modified active duty by date>
-- ===============================================
CREATE PROCEDURE [dbo].[spGetContractHistory]
	@PersonID INT,
	@Timestamp datetime
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;

    IF @Timestamp < (SELECT MAX([Timestamp]) FROM [Contract] WHERE [PersonID] = @PersonId) BEGIN

		SELECT	C.[ID], C.[ContractNo], C.[OpenDate], C.[CloseDate], 
				C.[IsDeleted], C.[Timestamp], C.[PersonID], E.[Name] As ModifiedBy,
				CT.[SCRA_Code], dbo.fnProductSubName(C.ID) as [SUB_PRODUCT_NAME],
				CASE WHEN ISNULL(C.[LegacyNo], '') = '' THEN C.[CardNo] ELSE C.[LegacyNo] END as AccountNumber
		FROM(
			SELECT	[ID], [ContractNo], [OpenDate], [CloseDate], [IsDeleted], 
					[Timestamp], [ModifiedBy], [PersonID], [LegacyNo], 
					[ContractTypeId], [Center], [Product], [CardNo], 
					[ProductName] FROM [Contract] WHERE [PersonID] = @PersonId
			UNION
			SELECT TOP 1 [ID], [ContractNo], [OpenDate], [CloseDate], [IsDeleted], 
					[Timestamp], [ModifiedBy], [PersonID], [LegacyNo], 
					[ContractTypeId], [Center], [Product], [CardNo], 
					[ProductName] FROM [hist].[Contract] WHERE [PersonId] = @PersonId ORDER BY [Timestamp] DESC) C
		JOIN [ContractType] CT ON C.[ContractTypeId] = CT.ID
		LEFT JOIN [Employee] E ON E.[ID] = C.[ModifiedBy]
		where C.[IsDeleted] = 0
		ORDER BY [Timestamp] DESC
	
	END

END

GO

/****** Object:  StoredProcedure [dbo].[spGetModifiedActiveDutyByDate]    Script Date: 03/11/2020 14:26:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Get modified active duty by date>
-- ===============================================
CREATE PROCEDURE [dbo].[spGetModifiedActiveDutyByDate]
	@PersonID INT,
	@Timestamp datetime
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;

    IF @Timestamp < (SELECT MAX([Timestamp]) FROM [ActiveDuty] WHERE PersonID = @PersonId) BEGIN

		select	AD.[ID], BS.[ID] As BranchOfServiceID, 
				BS.[Branch], BS.[IsReserve], AD.[StartDate], 
				AD.[EndDate], AD.[NoticeDate], AD.[Timestamp], 
				E.[Name] As ModifiedBy, AD.[PersonID]
		FROM
			(SELECT [ID], [BranchOfServiceID], [StartDate], [EndDate], 
					[NoticeDate], [Timestamp], [ModifiedBy], [PersonID] 
				FROM [ActiveDuty] WHERE [PersonID] = @PersonId
			UNION 
			SELECT TOP 1 [ID], [BranchOfServiceID], [StartDate], [EndDate], 
					[NoticeDate], [Timestamp], [ModifiedBy], [PersonID] 
				FROM [hist].[ActiveDuty] WHERE [PersonID] = @PersonId ORDER BY [Timestamp] DESC) AD
		LEFT JOIN [Employee] E on E.[ID] = AD.[ModifiedBy]
		LEFT JOIN [BranchOfService] BS on BS.[ID] = AD.[BranchOfServiceID]
		ORDER BY [Timestamp] DESC
	
	END

END

GO

/****** Object:  StoredProcedure [dbo].[spGetModifiedPersonByDate]    Script Date: 03/11/2020 14:26:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/11/2020>
-- Description:	<Get modified person by date>
-- =============================================
CREATE PROCEDURE [dbo].[spGetModifiedPersonByDate]
	@Timestamp datetime
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT DISTINCT p.[ID], p.[FirstName], p.[MiddleInitial], p.[LastName], th.[Timestamp], th.[Category]
    FROM [dbo].[Person] p
        JOIN (SELECT [PersonID], [Timestamp], [Category] FROM (
                SELECT [ID] as PersonID, [Timestamp], 'PERS' as Category FROM [dbo].[Person] WHERE [Timestamp] > @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'AD' as Category FROM [dbo].[ActiveDuty] WHERE [Timestamp] > @Timestamp
                UNION
                SELECT [PersonID], [Timestamp], 'CONTR' as Category FROM [dbo].[Contract] WHERE [Timestamp] > @Timestamp
        ) u
    GROUP BY [PersonID], [Timestamp], [Category]
    HAVING [Timestamp] = (SELECT MAX([Timestamp]) 
                            FROM (
                                SELECT [ID] as PersonID, [Timestamp] FROM [dbo].[Person] p WHERE [Timestamp] > @Timestamp AND p.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID], [Timestamp] FROM [dbo].[ActiveDuty] a WHERE [Timestamp] > @Timestamp AND a.[ID] = u.[PersonID]
                                UNION
                                SELECT [PersonID], [Timestamp] FROM [dbo].[Contract] c WHERE [Timestamp] > @Timestamp AND c.[ID] = u.[PersonID]) uu )
    ) th 
        ON p.[ID] = th.[PersonID]
            WHERE p.[Origin] NOT IN ('dmdc_check','inquiry')
        ORDER BY [Timestamp] DESC
        
END

GO

