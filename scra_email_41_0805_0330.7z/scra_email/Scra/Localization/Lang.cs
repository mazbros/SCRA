﻿namespace Scra.Localization
{
    public class Lang
    {
        public static class Error
        {
            public static string UnexpectedError = "An unexpected error occurred. Save your pending work and restart the program. See the log file for details.";
        }
    }
}
