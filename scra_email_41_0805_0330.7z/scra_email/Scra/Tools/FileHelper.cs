﻿using System.Diagnostics;
using System.IO;

namespace Scra.Tools
{
    public class FileHelper
    {
        public static bool IsFileLocked(string filePath)
        {
            return IsFileLocked(new FileInfo(filePath));
        }

        public static bool IsFileLocked(FileInfo file)
        {
            if (!file.Exists)
            {
                return false;
            }

            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                return true;
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }
            }

            return false;
        }

        public static void Open(string filePath)
        {
            Process.Start(filePath);
        }
    }
}
