﻿using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Scra.Model.Exceptions;
using Scra.Model.Logs;

namespace Scra.Tools.Logs
{
    public class Logger : ILogger
    {
        private int _processorsCount;
        private readonly ConcurrentQueue<LogRecord> _logs = new ConcurrentQueue<LogRecord>();
        private ILogAppender[] _loggers = new ILogAppender[0];

        public void AddAppender(ILogAppender logAppender)
        {
            var list = _loggers.ToList();
            list.Add(logAppender);
            _loggers = list.ToArray();
        }

        public void Error(Exception e)
        {
            if (e is WarningException || e is AppException)
            {
                LogAsync(LogSeverity.Warning, e, null);
            }
            else
            {
                LogAsync(LogSeverity.Error, e, null);
            }
        }

        public void Error(string message)
        {
            LogAsync(LogSeverity.Error, null, message);
        }

        public void Error(Exception e, string message)
        {
            LogAsync(LogSeverity.Error, e, message);
        }

        public void Debug(string message)
        {
            LogAsync(LogSeverity.Debug, null, message);
        }

        public void Log(string message)
        {
            LogAsync(LogSeverity.None, null, message);
        }

        public void Warning(string message)
        {
            LogAsync(LogSeverity.Warning, null, message);
        }

        public void Warning(Exception e, string message)
        {
            LogAsync(LogSeverity.Warning, e, message);
        }

        private void LogAsync(LogSeverity severity, Exception exception, string message)
        {
            var item = new LogRecord {Severity = severity, Exception = exception, Message = message};
            _logs.Enqueue(item);

            if (Interlocked.CompareExchange(ref _processorsCount, 1, 0) == 0)
            {
                Task.Run(() => ProcessQueue());
            }
        }

        private void ProcessQueue()
        {
            LogRecord item;
            while (_logs.TryDequeue(out item))
            {
                foreach (var logger in _loggers)
                {
                    logger.Log(item);
                }
            }

            Interlocked.Decrement(ref _processorsCount);
        }

        public void RemoveLogger(ILogAppender logAppender)
        {
            var list = _loggers.ToList();
            list.Remove(logAppender);
            _loggers = list.ToArray();
        }

        public static void Trace(string message)
        {
            System.Diagnostics.Trace.WriteLine(message);
        }

        public void Close()
        {
            foreach (var logger in _loggers)
            {
                logger.Close();
            }
        }
    }
}
