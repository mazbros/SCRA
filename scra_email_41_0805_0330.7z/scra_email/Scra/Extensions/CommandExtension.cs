﻿using System.Windows.Input;

namespace Scra.Extensions
{
    public static class CommandExtension
    {
        public static void Execute(this ICommand command)
        {
            command.Execute(null);
        }
    }
}
