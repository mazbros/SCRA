﻿using System;
using System.Globalization;

namespace Scra.Extensions
{
    public class DateExtension
    {
        public static DateTime FirstDayOfWeek(DateTime date)
        {
            var firstDayOfWeek = CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
            var offset = firstDayOfWeek - date.DayOfWeek;
            var firstDayOfWeekDate = date.AddDays(offset);
            return firstDayOfWeekDate;
        }

        public static DateTime LastDayOfWeek(DateTime date)
        {
            var lastDayOfWeekDate = FirstDayOfWeek(date).AddDays(6);
            return lastDayOfWeekDate;
        }
    }
}
