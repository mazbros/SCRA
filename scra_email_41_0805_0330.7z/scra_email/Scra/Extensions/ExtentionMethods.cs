﻿using System;
using System.IO;
using System.Reflection;

using System.Windows;
using System.Windows.Forms;
using System.Windows.Interop;
using System.Windows.Threading;

namespace Scra.Extensions
{
    /// <summary>
    ///     Extension methods
    /// </summary>
    public static class ExtensionMethods
    {
        /// <summary>
        ///     Empty delegate
        /// </summary>
        private static readonly Action EmptyDelegate = delegate { };

        /// <summary>
        ///     Forces UI element to re-render
        /// </summary>
        /// <param name="uiElement">UI element to refresh</param>
        public static void Refresh(DispatcherObject uiElement)
        {
            uiElement.Dispatcher.Invoke(DispatcherPriority.Render, EmptyDelegate);
        }

        /// <summary>
        ///     Gets current screen dimensions
        /// </summary>
        /// <param name="window">Current window</param>
        /// <returns></returns>
        public static Screen GetScreen(Window window)
        {
            return Screen.FromHandle(new WindowInteropHelper(window).Handle);
        }

        public static string AssemblyDirectory
        {
            get
            {
                var codeBase = Assembly.GetExecutingAssembly().CodeBase;
                var uri = new UriBuilder(codeBase);
                var path = Uri.UnescapeDataString(uri.Path);
                return Path.GetDirectoryName(path);
            }
        }
    }
}
