﻿using System;
using System.Threading.Tasks;
using Scra.Model.DomainEvents;
using Scra.Model.Inquiries;

namespace Scra.DomainHandlers
{
    public class InquiryAcknowledgeEventHandler : IDomainEventHandler
    {
        private readonly IInquiryRepository _repository;

        public InquiryAcknowledgeEventHandler(IInquiryRepository repository)
        {
            _repository = repository;
        }

        public Task HandleAsync(IDomainEvent domainEvent)
        {
            return HandleAsync((InquiryAcknowledgeEvent)domainEvent);
        }

        public async Task HandleAsync(InquiryAcknowledgeEvent domainEvent)
        {
            await _repository.SetAcknowledge(domainEvent.InquiryId, DateTime.Now);
        }
    }
}