﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Controls.Modules;
using Scra.Model.BranchOfServices;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Views.Shell;

namespace Scra.Views.ServiceMembers
{
    public class ActiveDutyEditViewModel : BaseViewModel
    {
        private readonly IServiceMemberRepository _serviceMemberRepository;
        private readonly IMessageDialog _messageDialog;
        private readonly ShellViewModel _shellViewModel;
        private PersonId _personId;
        private int _activeDutyId;
        private DateTime? _startDate;
        private DateTime? _endDate;        
        private DateTime? _noticeDate;
        private BranchOfService _branchOfService;
        private Visibility _editVisibility;
        private Visibility _viewVisibility;
        private Action _startEditCallback;
        private Action<ActiveDuty> _stopEditCallback;
        private bool _isReserved;
        private readonly IDispatcher _dispatcher;

        public ActiveDutyEditViewModel()
        {
            if (InDesignMode())
            {
                return;
            }
            SubTaskIdentifier = SubTaskType.MilitaryInformation;

            _serviceMemberRepository = Di.Get<IServiceMemberRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();

            OnViewLoaded = Load;

            StartEditCommand = new Command(StartEdit);
            BranchOfServices = new ObservableCollection<BranchOfService>();
            EditVisibility = Visibility.Hidden;
            ViewVisibility = Visibility.Visible;
            IsReserved = false;
        }

        private async void Load()
        {
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
        }

        public ObservableCollection<BranchOfService> BranchOfServices { get; private set; }
        public ICommand StartEditCommand { get; set; }        
        public SubTaskType SubTaskIdentifier { get; private set; }
        public SaveCancelModuleViewModel SaveCancel { get; set; }

        public DateTime? StartDate
        {
            get { return _startDate; }
            set { SetProperty(ref _startDate, value); }
        }
        public DateTime? EndDate
        {
            get { return _endDate; }
            set { SetProperty(ref _endDate, value); }
        }
        public DateTime? NoticeDate
        {
            get { return _noticeDate; }
            set { SetProperty(ref _noticeDate, value); }
        }
        public BranchOfService BranchOfService
        {
            get {return _branchOfService;}
            set
            {
                SetProperty(ref _branchOfService, value);
                EditCheckBox();
            }
        }

        private void EditCheckBox()
        {
            if (BranchOfService == null) return;
            var n = BranchOfService.Name;
            var x = BranchOfService.IsReserve;
            var y = _branchOfService.IsReserve;
            IsReserved = x;
        }

        public Visibility EditVisibility
        {
            get { return _editVisibility; }
            set { SetProperty(ref _editVisibility, value); }
        }
        public Visibility ViewVisibility
        {
            get { return _viewVisibility; }
            set { SetProperty(ref _viewVisibility, value); }
        }

        public bool IsReserved
        {
            get { return _isReserved; }
            set { SetProperty(ref _isReserved, value);}
        }

        public bool IsEditVisible { get; set; }
        public ActiveDuty ActiveDuty { get; private set; }
        public ActiveDuty StoredActiveDuty { get; set; }

        public async Task Load(PersonId personId, int activeDutyId, Action startEditCallback, Action<ActiveDuty> stopEditCallback)
        {
            SaveCancel.Load(Save, Cancel);

            _startEditCallback = startEditCallback;
            _stopEditCallback = stopEditCallback;
            _personId = personId;
            _activeDutyId = activeDutyId;

            if (activeDutyId == 0)
            {
                StartEdit();
            }

            await Reload();
        }

        private async Task Reload()
        {
            await GetModel();

            await FillView();

        }

        private void StartEdit()
        {
            EditVisibility = Visibility.Visible;
            ViewVisibility = Visibility.Hidden;
            _startEditCallback();
        }

        private void StopEdit(ActiveDuty activeDuty)
        {
            EditVisibility = Visibility.Hidden;
            ViewVisibility = Visibility.Visible;
            _stopEditCallback(activeDuty);
        }

        private void Cancel()
        {
            StopEdit(null);
        }

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                await GetModel();
                FillModel();
                Validate();

                if(ActiveDuty.Changed(StoredActiveDuty))
                    await _serviceMemberRepository.Save(ActiveDuty);

                StopEdit(ActiveDuty);
                _shellViewModel.IsUiBusy = false;
                await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private void Validate()
        {
            //if (ActiveDuty.StartDate == null)
            //{
            //    throw new UserException("Please enter a Start Date.");
            //}
            if (ActiveDuty.BranchOfService == null)
            {
                throw new UserException("Please enter a Branch of Service.");
            }
        }

        private async Task FillView()
        {
            var branchOfService = await BranchOfServiceList.GetInstance();
            BranchOfServices.Update(branchOfService.All());

            StartDate = ActiveDuty.StartDate;
            EndDate = ActiveDuty.EndDate;
            NoticeDate = ActiveDuty.NoticeDate;
            BranchOfService = ActiveDuty.BranchOfService;

            UpdateAll();
        }

        private void FillModel()
        {
            ActiveDuty.StartDate = StartDate;
            ActiveDuty.EndDate = EndDate;
            ActiveDuty.NoticeDate = NoticeDate;
            ActiveDuty.BranchOfService = BranchOfService;
        }

        private async Task GetModel()
        {
            if (_activeDutyId == 0)
            {
                ActiveDuty = ActiveDuty.Create(_personId);
                return;
            }
            var sm = await _serviceMemberRepository.Get(_personId);
            ActiveDuty = sm.ActiveDuties.First(x => x.Id == _activeDutyId);
            StoredActiveDuty = ActiveDuty.Copy(ActiveDuty);
        }        
    }
}
