﻿using Scra.Model.Persons;

namespace Scra.Views.ServiceMembers
{
    public class ServiceMemberEditArgs
    {
        public PersonId PersonId { get; set; }
    }
}
