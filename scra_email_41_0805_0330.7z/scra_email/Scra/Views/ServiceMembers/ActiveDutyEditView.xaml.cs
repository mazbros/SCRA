﻿namespace Scra.Views.ServiceMembers
{
    public partial class ActiveDutyEditView
    {
        public ActiveDutyEditView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.SaveCancel = SaveCancelModule.GetViewModel();
        }

        public ActiveDutyEditViewModel GetViewModel()
        {
            return (ActiveDutyEditViewModel)DataContext;
        }
    }
}
