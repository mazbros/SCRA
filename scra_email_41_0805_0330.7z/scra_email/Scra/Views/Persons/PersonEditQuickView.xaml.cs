﻿using System.Windows.Controls;

namespace Scra.Views.Persons
{
    /// <summary>
    /// Interaction logic for PersonEditQuickView.xaml
    /// </summary>
    public partial class PersonEditQuickView : UserControl
    {
        public PersonEditQuickView()
        {
            InitializeComponent();
        }
    }
}
