﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Scra.Views.Persons
{
    /// <inheritdoc cref="UserControl" />
    /// 
    public partial class PersonListView
    {
        public PersonListView()
        {
            AddHandler(System.Windows.Controls.Primitives.ButtonBase.ClickEvent, new RoutedEventHandler(ColumnHeaderClick));
            InitializeComponent();
            
        }

        private void OnItemDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectPersonCommand.Execute(null);
        }

        private PersonListViewModel GetViewModel()
        {
            return (PersonListViewModel) DataContext;
        }

        public async void ColumnHeaderClick(object sender, RoutedEventArgs args)
        {
            var vm = GetViewModel();
            var columnHeader = args.OriginalSource as GridViewColumnHeader;
            if (columnHeader != null)
            {
                await vm.SortListAsync(columnHeader.Column.Header.ToString());
            }
            
        }

        private async void PageSize_Changed(object sender, SelectionChangedEventArgs e)
        {
            await GetViewModel().ReloadList(null);
        }
    }
}
