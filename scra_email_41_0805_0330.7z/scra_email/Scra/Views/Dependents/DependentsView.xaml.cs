﻿namespace Scra.Views.Dependents
{
    public partial class DependentsView
    {
        public DependentsView()
        {
            InitializeComponent();
        }
    }
}
