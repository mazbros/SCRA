﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Dependents;
using Scra.Model.Persons;

namespace Scra.Views.Dependents
{
    public class DependentVm : BaseViewModel
    {
        private Action _onEdit;

        public static DependentVm Create(DependentLink link, Person dependent, Action<DependentLink> onEdit)
        {
            return new DependentVm
            {
                Name = dependent.Name.FullName, Address = dependent.Address.GetFull(), DependentType = link.Type.Name,
                StartDate = link.StartDate,
                EndDate = link.EndDate,
                _onEdit = () => onEdit(link)
            };
        }

        public DateTime? EndDate { get; set; }

        public DateTime? StartDate { get; set; }

        public string DependentType { get; set; }

        public string Address { get; set; }

        public string Name { get; set; }

        public ICommand EditCommand { get; set; }

        private DependentVm()
        {
            if (InDesignMode())
            {
                return;
            }

            EditCommand = new Command(Edit);            
        }

        private void Edit()
        {
            _onEdit();
        }
    }
}
