﻿namespace Scra.Views.StartUp
{
    public partial class StartUpView
    {
        public StartUpView()
        {
            InitializeComponent();
        }
    }
}
