﻿using System.Windows.Controls;

namespace Scra.Views.Benefits
{
    /// <summary>
    /// Interaction logic for ActiveDutySelectionView.xaml
    /// </summary>
    public partial class ActiveDutySelectionView : UserControl
    {
        public ActiveDutySelectionView()
        {
            InitializeComponent();
        }
    }
}
