﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Logs;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class BenefitsViewModel : BaseViewModel
    {
        private readonly IPersonRepository _personRepository;
        private readonly IContractRepository _contractRepository;
        private readonly ILogger _logger;
        private int _personId;
        private readonly AppNavigator _navigator;
        private List<BenefitEventListVm> _contractVms;
        private readonly ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;
        private readonly IMessageDialog _messageDialog;
        private readonly IBenefitRepository _benefitRepository;
        private IAppStore _store;
        private IUiThread _uiThread;


        public ICommand AddContractCommand { get; set; }
        public ICommand DenyRequestCommand { get; set; }
        public SubTaskType SubTaskIdentifier { get; set; }
        public ObservableCollection<BenefitEventListVm> BenefitEventList { get; set; }
        public ObservableCollection<BenefitEventListVm> DependentBenefitEventList { get; set; }
        public string Title { get; set; }
        public ServicememberInformationViewModel ServicememberInformation { get; set; }
        public bool DenyRequestVisible { get; set; }
        public Person Person { get; private set; }
        public IList<Benefit> BenefitList { get; set; }
        public ActiveDuty SelectedActiveDuty { get; set; }
        public BenefitEvent SelectedBenefitEvent { get; set; }

        public BenefitsViewModel()
        {
            _personRepository = Di.Get<IPersonRepository>();
            _contractRepository = Di.Get<IContractRepository>();
            _store = Di.Get<IAppStore>();
            _navigator = Di.Get<AppNavigator>();
            BenefitEventList = new ObservableCollection<BenefitEventListVm>();
            DependentBenefitEventList = new ObservableCollection<BenefitEventListVm>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();
            _messageDialog = Di.Get<IMessageDialog>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _logger = Di.Get<ILogger>();
            _uiThread = Di.Get<IUiThread>();
            SubTaskIdentifier = SubTaskType.ProductInformation;

            _store.SubscribeCommand(Act.TASK_STATUS_CHANGED, ReloadAct);

            AddContractCommand = new Command(AddContract);
            DenyRequestCommand = new Command(DenyRequest);
            
            OnViewLoaded = Load;
        }

        private void ReloadAct(IAct obj)
        {
            _uiThread.Execute(async () => await Reload());
        }

        private void Select(BenefitEvent benefitEvent)
        {
            SelectedBenefitEvent = benefitEvent;
            _navigator.Task(benefitEvent.TaskId);
        }

        public void Select()
        {
            NavigateBenefitDetail.Navigate(SelectedBenefitEvent);
        }

        private void AddContract()
        {
            var contract = Contract.Create(new PersonId(_personId));            
            _navigator.AddContract(contract);
        }

        private async void EditContract(BenefitEvent benefitEvent)
        {
            var contract = await _contractRepository.Get(new ContractId(benefitEvent.ContractId));
            _navigator.AddContract(contract);
        }

        private async void Load()
        {
            _shellViewModel.IsUiBusy = true;            
            var args = (IdArgs) Arguments;
            _personId = args.Id;
            await ServicememberInformation.Load(new PersonId(_personId));
            await Reload();
            _shellViewModel.IsUiBusy = false;
        }

        private async Task Reload()
        {
            Person = await _personRepository.Get(new PersonId(_personId));
            BenefitList = await _benefitRepository.LoadByPerson(_personId);
            var contractList = await _contractRepository.Load(new PersonId(_personId));
            var benefitEvents = await _benefitRepository.LoadEvent(new PersonId(_personId));
            var contractIds = benefitEvents.OrderByDescending(x=>x.OpenDate).Select(x => x.ContractId).Distinct().ToList();
            DenyRequestVisible = contractList.Count == 0;

            _contractVms = new List<BenefitEventListVm>();

            if (contractList.Count == 0)
            {
                foreach (var benefit in BenefitList)
                {
                    var contract = await _contractRepository.Get(benefit.ContractId);
                    if (contract == null)
                    {
                        var v = BenefitEventListVm.Create(benefit, () => _navigator.Task(benefit.TaskId));
                        _contractVms.Add(v);
                    }
                }
            }

            foreach (var id in contractIds)
            {
                var events = benefitEvents.Where(c => c.ContractId == id).ToList();
                var vm = BenefitEventListVm.Create(events, Select, AddBenefit, EditBenefit, ContactCustomer, ExtendBenefit, RemoveBenefit, DenyBenefit, EditContract);
                _contractVms.Add(vm);               
            }

            FillView(_contractVms);
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));            
        }
        
        private async void AddBenefit(BenefitEvent lastEvent)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                GetSelectedActiveDuty();
                CheckEligibility();
                var newBenefit = Benefit.Create(lastEvent.ContractId, SelectedActiveDuty.Id, _personId, BenefitStatus.Applying, 0);
                await CheckBenefitStatus(lastEvent);
                await newBenefit.AddBenefit();
                _navigator.Task(newBenefit.TaskId);    
                await Reload();
            }
            catch(BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void EditBenefit(BenefitEvent lastEvent, TaskType taskType)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                CheckEligibility();
                var newBenefit = Benefit.Create(lastEvent.ContractId, lastEvent.ActiveDutyId, _personId, lastEvent.BenefitStatus, 0);
                await CheckBenefitStatus(lastEvent);
                await newBenefit.EditBenefit(taskType);
                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void ContactCustomer(BenefitEvent lastEvent)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var newBenefit = Benefit.Create(lastEvent.ContractId, lastEvent.ActiveDutyId, _personId, lastEvent.BenefitStatus, 0);
                await CheckBenefitStatus(lastEvent);
                await newBenefit.ContactCustomer();
                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void ExtendBenefit(BenefitEvent lastEvent)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                GetSelectedActiveDuty();
                CheckEligibility();
                var newBenefit = Benefit.Create(lastEvent.ContractId, SelectedActiveDuty.Id, _personId, BenefitStatus.Extending, 0);
                await CheckBenefitStatus(lastEvent);
                await newBenefit.ExtendBenefit();
                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void RemoveBenefit(BenefitEvent lastEvent)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var newBenefit = Benefit.Create(lastEvent.ContractId, lastEvent.ActiveDutyId, _personId, BenefitStatus.Removing, 0);
                await CheckBenefitStatus(lastEvent);
                await newBenefit.RemoveBenefit();
                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void DenyBenefit(BenefitEvent lastEvent)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                GetSelectedActiveDuty();
                var newBenefit = Benefit.Create(lastEvent.ContractId, SelectedActiveDuty.Id, _personId, BenefitStatus.Denying, 0);
                await CheckBenefitStatus(lastEvent);

                _navigator.EnterDenialReason(newBenefit);
                if (newBenefit.DenialReason == null)
                    throw new UserException("Denial Reason is required");
                
                await newBenefit.DenyBenefit();
                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (BreakException e)
            {
                _logger.Warning(e.Message);
            }
            catch (UserException e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private async void DenyRequest()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var activeDuty = await Person.GetLastActiveDuty();
                var newBenefit = Benefit.CreateBenefitWithNoProduct(Person.Id, activeDuty, "No Product", 0);
                
                var tascFactory = Di.Get<ITascFactory>();
                var task = await tascFactory.DenyBenefit(newBenefit.PersonId);

                newBenefit.TaskId = task.Id;
                await _benefitRepository.Save(newBenefit);

                _navigator.Task(newBenefit.TaskId);
                await Reload();
            }
            catch (Exception e)
            {
                _logger.Warning(e.Message);
                _messageDialog.Warning(e.Message);
            }
            finally
            {                
                _shellViewModel.IsUiBusy = false;
            }            
        }

        private void GetSelectedActiveDuty()
        {
            if (ServicememberInformation.HasActiveDuty && ServicememberInformation.ActiveDutyList.Count > 1)
            {
                var na = new NavigatorArguments();
                
                na.NavigatorArgumentList.Add(new PersonId(_personId));
                na.NavigatorArgumentList.Add(SelectedActiveDuty);
                _navigator.ActiveDutySelection(na);

                if (na.NavigatorArgumentList[1] == null)
                    throw new BreakException("User canceled");
                SelectedActiveDuty = (ActiveDuty)na.NavigatorArgumentList[1];
            }
            else if(ServicememberInformation.HasActiveDuty)
            {
                SelectedActiveDuty = ServicememberInformation.SelectedActiveDuty.ActiveDuty;
            }
            else
            {
                SelectedActiveDuty = ActiveDuty.NoActiveDuty();
            }
           
        }

        private void CheckEligibility()
        {
            if (!ServicememberInformation.HasActiveDuty)
            {
                var msg = "Not eligible for benefit! There is no active duty";
                throw new UserException(msg);
            }            
        }

        private async Task CheckBenefitStatus(BenefitEvent lastEvent)
        {
            if (lastEvent.TaskStatus != TascStatus.Empty && lastEvent.TaskStatus != TascStatus.QaCompleted)
            {
                var msg = "The current workflow is still in process, by clicking Yes, it will be marked as Misdirected, and " +
                          "a new workflow will be created." +
                          "\nAre you sure about this action?";
                var r = _messageDialog.ConfirmationBinary(msg);
                if (r == MessageBoxResult.No)
                {
                    throw new BreakException("User clicked No");
                }

                await MisdirecteCurrentTask(lastEvent.TaskId);
                await Task.Run(() =>
                {
                    Thread.Sleep(1000);
                    _navigator.Task(0);
                });
            }
        }

        private async Task MisdirecteCurrentTask(int taskId)
        {
            var taskRepository = Di.Get<ITaskRepository>();
            await taskRepository.DumpTask(taskId);
            _navigator.Task(taskId);
        }

        private void FillView(IList<BenefitEventListVm> contracts)
        {
            BenefitEventList.Update(contracts);
            
            UpdateAll();
        }
    }

    public class NavigateBenefitDetail
    {
        public static void Navigate(BenefitEvent benefitEvent)
        {
            if(benefitEvent == null || benefitEvent.BenefitId == 0)
                return;

            var navigator = Di.Get<AppNavigator>();

            navigator.Task(benefitEvent.TaskId);

            var type = ContractCategory.Parse(benefitEvent.SCRA_Code);
            if (type == ContractCategory.Commercial)
            {
                navigator.CommercialLoan(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.ConsumerLoan)
            {
                navigator.ConsumerLoan(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.CreditCard)
            {
                navigator.CreditCardDetails(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.Mortgage)
            {
                navigator.MortgageDetails(benefitEvent.BenefitId);
            }
            else if (type == ContractCategory.HomeEquity)
            {
                navigator.HomeEquity(benefitEvent.BenefitId);
            }
        }
    }
}
