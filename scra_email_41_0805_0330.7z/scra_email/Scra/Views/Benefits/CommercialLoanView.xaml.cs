﻿namespace Scra.Views.Benefits
{
    public partial class CommercialLoanView
    {
        public CommercialLoanView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ContractSnapshot = ContractSnapshotView.GetViewModel();
        }

        public CommercialLoanViewModel GetViewModel()
        {
            return (CommercialLoanViewModel)DataContext;
        }    
    }
}
