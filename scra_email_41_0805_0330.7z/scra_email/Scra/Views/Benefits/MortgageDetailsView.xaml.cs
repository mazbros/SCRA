﻿namespace Scra.Views.Benefits
{
    public partial class MortgageDetailsView
    {
        public MortgageDetailsView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ContractSnapshot = ContractSnapshotView.GetViewModel();
        }

        public MortgageDetailsViewModel GetViewModel()
        {
            return (MortgageDetailsViewModel)DataContext;
        }
    }
}
