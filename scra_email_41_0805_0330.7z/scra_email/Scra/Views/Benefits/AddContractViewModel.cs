using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class AddContractViewModel : BaseViewModel
    {
        private readonly IContractRepository _contractRepository;
        private readonly IMessageDialog _messageDialog;

        private PersonId _personId;
        private readonly AppNavigator _navigator;
        private readonly ShellViewModel _shellViewModel;

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        
        public ObservableCollection<ContractCategory> Categories { get; set; }
        public ObservableCollection<ContractSubCategory> SubCategories { get; set; }

        private ContractCategory _contractCategory;
        private ContractCategoryList _contractCategories;

        private ContractSubCategory _contractSubCategory;
        private ContractSubCategoryList _contractSubCategories;

        private ContractId _contractId = new ContractId(0);
        private Visibility _isLegacyNoVisible;
        private Visibility _isCardNoVisible;
        private Contract CurrentContract  { get; set; }

        public DateTime? ClosedDate { get; set; }
        public DateTime? OpenDate { get; set; }
        public string LegacyNo { get; set; }
        public string ContractNo { get; set; }
        public int? Product { get; set; }
        public int? Center { get; set; }
        public string CardNo { get; set; }
        public ContractType Type { get; set; }
        public string ProductName { get; set; }

        public bool IsDeleted { get; set; }
        public bool IsDeleteButtonVisible { get; set; }

        private Dictionary<string, ContractSubCategory> Map;

        public Visibility IsLegacyNoVisible
        {
            get { return _isLegacyNoVisible; }
            set { SetProperty(ref _isLegacyNoVisible, value); }
        }

        public Visibility IsCardNoVisible
        {
            get { return _isCardNoVisible; }
            set { SetProperty(ref _isCardNoVisible, value); }
        }
 
        public AddContractViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _contractRepository = Di.Get<IContractRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _navigator = Di.Get<AppNavigator>();
            _shellViewModel = Di.Get<ShellViewModel>();

            Categories = new ObservableCollection<ContractCategory>();
            SubCategories = new ObservableCollection<ContractSubCategory>();

            OnViewLoaded = OnLoaded;
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
            DeleteCommand = new Command(Delete);
        }

        private void Delete()
        {
            var result = _messageDialog.ConfirmationBinary("Are you sure you want to delete contract from servicemember portfolio?");
            
            if (result == MessageBoxResult.Yes)
            {
                IsDeleted = true;
                Save();
            }                
        }

        public ContractSubCategory SubCategory
        {
            get { return _contractSubCategory; }
            set
            {
                SetProperty(ref _contractSubCategory, value);
                ProductName = _contractSubCategory.Name;
            }
        }

        public ContractCategory Category
        {
            get { return _contractCategory; }
            set
            {
                SetProperty(ref _contractCategory, value);

                if (value == ContractCategory.CreditCard)
                {
                    IsLegacyNoVisible = Visibility.Collapsed;
                    IsCardNoVisible = Visibility.Visible;
                    Product = 500;
                    Type = new ContractType(995, value, "Credit Card");
                    Map = ContractSubCategory.CreditCardMap;
                    _contractSubCategories =  ContractSubCategoryList.Create(Map);
                    
                }
                else
                {
                    IsLegacyNoVisible = Visibility.Visible;
                    IsCardNoVisible = Visibility.Collapsed;

                    if (value == ContractCategory.Auto)
                    { 
                        Product = 143;
                        Type = new ContractType(990, value, "Auto");
                        Map = ContractSubCategory.AutoMap;
                        _contractSubCategories = ContractSubCategoryList.Create(Map);
                    }
                    else if (value == ContractCategory.Mortgage)
                    {
                        Product = 113;
                        Type = new ContractType(991, value, "Mortgage");
                        Map = ContractSubCategory.MortgageMap;
                        _contractSubCategories = ContractSubCategoryList.Create(Map);
                    }
                    else if (value == ContractCategory.SafeDepositBox)
                    {

                        Product = 609;
                        Type = new ContractType(992, value, "Safe Deposit Box");
                        Map = ContractSubCategory.SafeDepositBoxMap;
                        _contractSubCategories = ContractSubCategoryList.Create(Map);
                    }
                    else
                    {
                        if (value == ContractCategory.Commercial)
                        {
                            Product = 993;
                            Type = new ContractType(993, value, "Commercial Loan");
                            Map = ContractSubCategory.CommercialMap;
                            _contractSubCategories = ContractSubCategoryList.Create(Map);
                        }
                        else if (value == ContractCategory.ConsumerLoan)
                        {
                            Product = 994;
                            Type = new ContractType(994, value, "Consumer Loan");
                            Map = ContractSubCategory.ConsumerLoanMap;
                            _contractSubCategories = ContractSubCategoryList.Create(Map);
                        }
                        else if (value == ContractCategory.Other)
                        {
                            Product = 996;
                            Type = new ContractType(996, value, "Other");
                            Map = ContractSubCategory.OtherMap;
                            _contractSubCategories = ContractSubCategoryList.Create(Map);
                        }
                        else if (value == ContractCategory.HomeEquity)
                        {
                            Product = 998;
                            Type = new ContractType(999, value, "Home Equity");
                            Map = ContractSubCategory.HomeEquityMap;
                            _contractSubCategories = ContractSubCategoryList.Create(Map);
                        }
                        else
                        {
                            Product = 997;
                            Type = new ContractType(998, value, "");
                            Map = ContractSubCategory.OtherMap;
                            _contractSubCategories = ContractSubCategoryList.Create(Map);
                        }
                    }
                }

                SubCategories.Update(_contractSubCategories.All());

                Center = 0;
            }
        }

        private async Task<string> FormatContractNo()
        {
            var code = await GetNextUniqueCode();
            return GetContractNo(0, Product.ToString(), code);
        }

        private async Task<string> GetNextUniqueCode()
        {
            try
            {
                var b = await _contractRepository.GetCurrent();
                var a = b;
                b = CalculateNextPrime(b);
                var c = b;
                var currentCode = (Math.Abs(b * c) % a) + a;

                if (currentCode > 9999999)
                {
                    currentCode = currentCode % 100000;
                }

                await SaveSequence(currentCode);

                return currentCode.ToString();
            }
            catch (Exception ex)
            {
                _messageDialog.Warning(ex.Message);
            }

            return string.Empty;
        }

        private async Task SaveSequence(int currentCode)
        {
            await _contractRepository.SaveCurrent(currentCode);
        }

        private static int CalculateNextPrime(int number)
        {    
            while(true)
            {
                var isPrime = true;
                number = number + 1;

                var squaredNumber = (int)Math.Sqrt(number);

                for (var i = 2; i <= squaredNumber; i++)
                {
                    if (number % i != 0) continue;
                    isPrime = false;
                    break;
                }

                if (isPrime)
                {
                    return number;
                }
            }
        }

        private void Save()
        {
            if (Validate())
            {
                if (_contractId.IsEmpty())
                {
                    SaveData();
                }
                else
                {
                    UpdateData();
                }
            }
        }

        private bool Validate()
        {
            var message = string.Empty;
            
            if (Category.Code == null || Category == ContractCategory.Empty)
            {
                message += "Please select product category.\n";
            }

            if (ProductName.IsEmpty())
            {
                message += "Please select product name.\n";
            }
            if (Category == ContractCategory.CreditCard)
            {
                if (CardNo.IsEmpty())
                {
                    message += "Please enter credit card number.\n";
                }
            }
            else
            {
                if (LegacyNo.IsEmpty())
                {
                    message += "Please enter legacy account number.\n";
                }
            }
            if (string.IsNullOrEmpty(OpenDate.ToString()))
            {
                message += "Please select product open date.";
            }

            if (message.IsNotEmpty())
            {
                _messageDialog.Warning(message);
                return false;
            }

            return true;
        }

        private async void  SaveData()
        {
            _shellViewModel.IsUiBusy = true;
            var contract = GetModel().Result;
            FillModel(contract);
            contract.ContractNo = await FormatContractNo();
            await _contractRepository.Save(contract);
            CloseView();
            _navigator.Benefits(_personId);
            _shellViewModel.IsUiBusy = false;
        }

        private async void UpdateData()
        {
            _shellViewModel.IsUiBusy = true;

            FillModel(CurrentContract);
            CurrentContract.ContractNo = await FormatContractNo();
            await _contractRepository.Save(CurrentContract);
            CloseView();
            _navigator.Benefits(_personId);
            _shellViewModel.IsUiBusy = false;
        }

        private async Task<Contract> GetModel()
        {
            if (_contractId.IsEmpty())
            {
                return Contract.Create(_personId);
            }
            return await _contractRepository.Get(_contractId);
        }

        private void Cancel()
        {
            CloseView();
        }

        private void OnLoaded()
        {
            _shellViewModel.IsUiBusy = true;
            CurrentContract = (Contract)Arguments;
            _personId = CurrentContract.PersonId;
            _contractId = CurrentContract.Id;
            //var contract = Contract.Parse(_personId);

            IsLegacyNoVisible = Visibility.Visible;
            IsCardNoVisible = Visibility.Collapsed;

            Map = new Dictionary<string, ContractSubCategory>();

            FillView(/*contract*/);
        }

        private void FillView(/*Contract model*/)
        {
            _contractCategories = ContractCategoryList.Create(ContractCategoryList.ITEMS);
            Categories.Update(_contractCategories.All());

            Category = CurrentContract.Category;

            Product = CurrentContract.Product;
            ContractNo = CurrentContract.ContractNo;
            LegacyNo = CurrentContract.LegacyNo;
            OpenDate = CurrentContract.OpenDate;
            ClosedDate = CurrentContract.CloseDate;
            CardNo = CurrentContract.CardNo;
            Type = CurrentContract.Type;
            ProductName = CurrentContract.ContractProductName;
            SubCategory = ContractSubCategory.Parse(CurrentContract.ContractProductName.ToLower().Replace(' ','_'), Map);

            IsDeleteButtonVisible = Category.ToString().IsNotEmpty() &&
                                    SubCategory.ToString().IsNotEmpty() &&
                                    Category.Equals(ContractCategory.CreditCard) && CardNo.IsNotEmpty() ||
                                    !Category.Equals(ContractCategory.CreditCard) && LegacyNo.IsNotEmpty() &&
                                    OpenDate.ToString().IsNotEmpty();
            _shellViewModel.IsUiBusy = false;

            UpdateAll();
        }

        private void FillModel(Contract model)
        {
            model.PersonId = _personId;
            model.Category = Category;
            model.Center = Center;
            model.Product = Product;
            model.ContractNo = ContractNo;
            model.LegacyNo = LegacyNo;
            model.OpenDate = OpenDate;
            model.CloseDate = ClosedDate;
            model.CardNo = CardNo;
            model.Type = Type;
            model.IsDeleted = IsDeleted;
            model.ContractProductName = SubCategory.Name;
        }
        
        private static string GetContractNo(int center, string product, string contractNo)
        {
            if (contractNo.IsEmpty()) return string.Empty;
            if (contractNo.Length == 14) return contractNo;
            
            return center.ToString().PadLeft(4, '0') + product.PadLeft(3, '0') + contractNo.PadLeft(7, '0');
        }

    }
}