﻿namespace Scra.Views.Shell
{
    /// <summary>
    /// Interaction logic for Toolbar.xaml
    /// </summary>
    public partial class MainToolbar
    {
        public MainToolbar()
        {
            InitializeComponent();
        }
    }
}
