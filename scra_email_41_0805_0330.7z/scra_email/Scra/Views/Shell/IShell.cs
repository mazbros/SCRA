﻿using System.Windows.Controls;

namespace Scra.Views.Shell
{
    public interface IShell
    {
        void ShowChild(UserControl control);
    }
}
