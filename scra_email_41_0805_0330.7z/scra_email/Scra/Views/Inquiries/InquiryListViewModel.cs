using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
//using System.IO;
using System.Linq;
//using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Inquiries;
using Scra.Model.Tools;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Inquiries
{
    public class InquiryListViewModel : BaseViewModel
    {
        private readonly IInquiryRepository _repository;
        private readonly AppNavigator _navigator;
        private InquiryListItem _selectedItem;
        private IList<InquiryListItem> _items;
        private readonly IMessageDialog _messageDialog;
        private string _searchText;
        private string _direction;
        private readonly ShellViewModel _shellViewModel;
        private readonly IUiThread _uiThread;
        private IList<InquiryListItem> _pagedItems;
        private int _pageIndex;
        private int _pageSize;
        private int _itemLow;
        private int _itemHigh;
        private bool _isPreviousEnabled;
        private bool _isNextEnabled;
        private string _pagingStats;
        private int _page;

        public InquiryListViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            _repository = Di.Get<IInquiryRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _uiThread = Di.Get<IUiThread>();
            _direction = "Ascending";

            OnViewLoaded = OnLoaded;

            SelectCommand = new Command(Select);
            AddNewCommand = new Command(AddNew);
            //ExportCommand = new Command(Export);
            SearchCommand = new Command(Search);
            ClearCommand = new Command(ClearSearch);

            PreviousCommand = new Command(Previous);
            NextCommand = new Command(Next);

            Pages = new ObservableCollection<int> {5, 10, 15, 20, 25};
        }

        private async void Next()
        {
            await ReloadList(NextCommand);
        }

        private async void Previous()
        {
            await ReloadList(PreviousCommand);
        }

        private void ClearSearch()
        {
            SearchText = string.Empty;
            //Page = 15;
            Search();
        }

        //public ICommand ExportCommand { get; set; }
        public ICommand AddNewCommand { get; set; }
        public ICommand SelectCommand { get; set; }
        public ICommand SearchCommand { get; set; }
        public ICommand ClearCommand { get; set; }

        public ICommand PreviousCommand { get; set; }
        public ICommand NextCommand { get; set; }
        public ObservableCollection<int> Pages { get; set; }

        public int Page
        {
            get { return _page; } 
            set { SetProperty(ref _page, value); }
        }

        public string SearchText
        {
            get { return _searchText; }
            set { SetProperty(ref _searchText, value); }
        }
        public InquiryListItem SelectedItem
        {
            get { return _selectedItem; }
            set { SetProperty(ref _selectedItem, value); }
        }
        public IList<InquiryListItem> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public IList<InquiryListItem> PagedItems
        {
            get { return _pagedItems; }
            set { SetProperty(ref _pagedItems, value); }
        }

        //private void Export()
        //{
        //    var exportData = ExportToString();
        //    CallExportDialog(exportData);
        //}

        //private void CallExportDialog(string exportData)
        //{
        //    var dialog = new Microsoft.Win32.SaveFileDialog
        //    {
        //        FileName = "Inquiries",
        //        DefaultExt = ".csv",
        //        Filter = "CSV Text File|*.csv"
        //    };
        //    if (dialog.ShowDialog() != true)
        //    {
        //        return;
        //    }

        //    var filePath = dialog.FileName;
        //    if (FileHelper.IsFileLocked(filePath))
        //    {
        //        var message = string.Format("File {0} is locked. Please, close the file and repeat export.", filePath);
        //        _messageDialog.Warning(message);
        //    }
        //    else
        //    {
        //        File.WriteAllText(filePath, exportData);
        //        FileHelper.Open(filePath);
        //    }
        //}

        //private string ExportToString()
        //{
        //    var builder = new StringBuilder();
        //    var header = "NewInquiry Date,Acknowledgement Date,Response Date,NewInquiry Type,Person Inquiring,Servicemember,Contact Method,Agent,Status";
        //    builder.AppendLine(header);
        //    foreach (var item in Items)
        //    {
        //        var status = item.IsComplete ? "Complete" : "In progress";
        //        var row = item.RequestDate + "," + item.AcknowledgeDate + "," + item.ResponseDate + "," +
        //                  item.InquiryType + "," + item.PersonInquiring + "," + item.Servicemember + "," +
        //                  item.ContactMethod + "," + item.Agent + "," + status;
        //        builder.AppendLine(row);
        //    }

        //    return builder.ToString();
        //}

        private void AddNew()
        {
            _navigator.Task(0);
            _navigator.NewInquiry();
        }

        private async void Select()
        {
            if (SelectedItem == null)
            {
                return;
            }
            var taskId = await _repository.GetTaskByInquiry(SelectedItem.Id);
            _navigator.Inquiry(SelectedItem.Id);
            _navigator.Task(taskId);
        }

        public bool IsPreviousEnabled
        {
            get { return _isPreviousEnabled; }
            set { SetProperty(ref _isPreviousEnabled, value); }
        }

        public bool IsNextEnabled
        {
            get { return _isNextEnabled; }
            set { SetProperty(ref _isNextEnabled, value); }
        }

        public string PagingStats
        {
            get { return _pagingStats; }
            set { SetProperty(ref _pagingStats, value); }
        }

        private async void OnLoaded()
        {
            _pageIndex = -1;
            await ReloadList(null);
            
            UpdatePages();
            Page = Items.Count;
            _navigator.CloseLeftPanel();
        }

        private async void Search()
        {
            await ReloadList(null);

            UpdatePages();

            Page = Items.Count; 
        }

        private void UpdatePages()
        {
            _uiThread.Execute(() =>
            {
                Pages.Clear();

                var i = 5;

                if (i < Items.Count)
                {
                    Pages.Add(i);

                    while (i <= Items.Count)
                    {
                        i = +i <= 25 ? i + 5 :
                            i == 50 ? i + 50 :
                            i == 100 ? i + 100 :
                            i == 200 ? i + 300 :
                            i >= 500 ? i + 500 :
                            i + 10;

                        if (i >= Items.Count) break;

                        Pages.Add(i);
                    }

                    Pages.Add(Items.Count);
                    //Page = Pages.Count >= 3 ? Pages[2] : Pages[0];
                }
                else
                {
                    Pages.Add(Items.Count);
                    //Page = Items.Count;
                }

                UpdateAll();
            });
        }

        public async Task ReloadList(ICommand command)
        {
            try
            {
                _shellViewModel.IsUiBusy = true;

                var models = await _repository.Load(SearchText);
                Items = models.Select(InquiryListItem.Create).ToList();

                _pageSize = Items.Count;//Page;

                if (command == null)
                {
                    _pageIndex = 0;
                }

                if (command == NextCommand)
                {
                    _pageIndex++;
                }

                if (command == PreviousCommand)
                {
                    _pageIndex--;
                }

                _pagedItems = _items.Count >= _pageSize ? _items.Skip(_pageIndex * _pageSize).Take(_pageSize).ToList() : _items;

                if (_pageIndex < 1)
                {
                    _itemLow = 1;
                    _itemHigh = _items.Count <= _pageSize ? _items.Count : _pageSize;
                    _isPreviousEnabled = false;
                    _isNextEnabled = _itemHigh != _items.Count;
                }
                else
                {
                    _itemLow = _pageIndex * (_items.Count <= _pageSize ? 0 : _pageSize) + 1;

                    _itemHigh = _items.Count <= _pageSize ? _items.Count :
                        _itemLow + _pageSize - 1 >= _items.Count ? _items.Count : _itemLow + _pageSize - 1;

                    _isPreviousEnabled = true;
                    _isNextEnabled = _itemHigh != _items.Count;
                }

                //_pagingStats = _itemLow + " - " + _itemHigh + " of " + Items.Count;
                _pagingStats = "" + Items.Count + (Items.Count.ToString().EndsWith("1") ? " record" :" records");
                PagingStats = _pagingStats;
                if (PreviousCommand != null) PreviousCommand.CanExecute(_isPreviousEnabled);
                if (NextCommand != null) NextCommand.CanExecute(_isNextEnabled);

                PagedItems = _pagedItems.ToList();

            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during loading.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
                UpdateAll();
            }
        }

        public async Task SortListAsync(string selectedHeaderName)
        {
            _shellViewModel.IsUiBusy = true;

            _direction = _direction == "Descending" ? "Ascending" : "Descending";
            var sortedModel = await _repository.Sort(SearchText, selectedHeaderName, _direction);
            PagedItems = sortedModel.Select(InquiryListItem.Create).ToList();

            _pageSize = Items.Count;//Page;

            _pagedItems = _items.Count >= _pageSize ? _items.Skip(_pageIndex * _pageSize).Take(_pageSize).ToList() : _items;

            _itemLow = _pageIndex * (_items.Count <= _pageSize ? 0 : _pageSize) + 1;
            _itemHigh = _items.Count <= _pageSize ? _items.Count : _pageSize;
            
            _isPreviousEnabled = _itemLow == 1;
            _isNextEnabled = _itemHigh != _items.Count;
            
            _pagingStats = _itemLow + " - " + _itemHigh + " of " + Items.Count;

            PagedItems = _pagedItems.ToList();

            UpdatePages();

            IsBusy = false;
            _shellViewModel.IsUiBusy = false;
        }

    }
}