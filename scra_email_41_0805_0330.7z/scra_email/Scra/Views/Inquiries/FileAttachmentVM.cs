﻿using System;
using Scra.AppCore;
using Scra.Controls.Buttons;
using Scra.Model.Inquiries;

namespace Scra.Views.Inquiries
{
    public class FileAttachmentVm : BaseViewModel
    {       
        private MultiButtonProps _actionProps;

        public string FileName { get; set; }

        public MultiButtonProps ActionProps
        {
            get { return _actionProps; }
            set { SetProperty(ref _actionProps, value); }
        }

        public FileAttachmentVm Create(FileAttachmentSnapshot attachment, Action view, Action download, Action delete)
        {
            return new FileAttachmentVm
            {
                FileName = attachment.FileName,
                ActionProps = new MultiButtonProps(new[]
                {
                    new MultiButtonProps.Item("View", view),
                    new MultiButtonProps.Item("Download", download),
                    new MultiButtonProps.Item("Delete", delete),
                })

            };
        }
    }
}