﻿namespace Scra.Views.ViewHistory
{
    /// <summary>
    /// Interaction logic for ViewHistory.xaml
    /// </summary>
    public partial class HistoryView
    {
        public HistoryView()
        {
            InitializeComponent();
        }
    }
}
