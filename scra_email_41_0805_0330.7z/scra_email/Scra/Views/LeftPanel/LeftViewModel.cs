﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Tools;
using Scra.State;

namespace Scra.Views.LeftPanel
{
    public class LeftViewModel : BaseViewModel
    {
        private BaseViewModel _currentModel;
        private int _currentTaskId;
        private Visibility _frameVisibility;
        private Visibility _deleteVisiblility;

        //private AppNavigator _navigator;
        public ICommand CloseCommand { get; set; }
        public ICommand RefreshCommand { get; set; }
        public ICommand DeleteCommand { get; set; }


        public LeftViewModel()
        {
            //_navigator = Di.Get<AppNavigator>();
            RefreshCommand = new Command(RefreshPanel);
            CloseCommand = new Command(CloseLeftPanel);
            DeleteCommand = new Command(DeleteTask);

            FrameVisibility = Visibility.Collapsed;
        }

        private void DeleteTask()
        {
            ((TaskItemsViewModel)CurrentModel).Delete();
        }

        private void RefreshPanel()
        {            
            ((TaskItemsViewModel)CurrentModel).ReloadTask();
        }

        private void CloseLeftPanel()
        {
            FrameVisibility = Visibility.Collapsed;
        }

        public BaseViewModel CurrentModel
        {
            get { return _currentModel; }
            set { SetProperty(ref _currentModel, value); }
        }

        public Visibility FrameVisibility
        {
            get { return _frameVisibility; }
            set { SetProperty(ref _frameVisibility, value); }
        }

        public Visibility DeleteVisiblility
        {
            get { return _deleteVisiblility; }
            set { SetProperty(ref _deleteVisiblility, value); }
        }

        public void Load()
        {
            var store = Di.Get<IAppStore>();
            store.SubscribeCommand(Act.CLOSE_LEFT_PANEL, CloseLeftPanel);
            store.SubscribeCommand(Act.SHOW_PERSON, ShowPerson);
            store.SubscribeCommand(Act.SHOW_TASK, ShowTask);
        }

        private void CloseLeftPanel(IAct obj)
        {
            FrameVisibility = Visibility.Collapsed;            
        }

        private async void ShowPerson(IAct obj)
        {
            //var act = (ModifiedPersonAct)obj;

            FrameVisibility = Visibility.Visible;
            DeleteVisiblility = Visibility.Collapsed;
            var vm = new PersonHistoryListViewModel();
            CurrentModel = vm;
            await vm.Load();
        }

        private async void ShowTask(IAct obj)
        {
            var act = (ShowTaskAct)obj;
            _currentTaskId = act.TaskId;
            DeleteVisiblility = Visibility.Visible;

            if (_currentTaskId == 0)
            {
                FrameVisibility = Visibility.Collapsed;
                return;
            }

            FrameVisibility = Visibility.Visible;
            var vm = new TaskItemsViewModel();
            CurrentModel = vm;
            await vm.Load(act.TaskId);
        }        
    }
}
