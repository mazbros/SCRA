﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Scra.Model.Contracts;
using Scra.Model.Persons;

namespace Scra.Views.PersonDashboard
{
    public class ContractsGroupVm
    {
        public bool IsMain { get; set; }
        public string PersonName { get; set; }
        public IList<ContractItem> Items { get; set; }
        public Visibility IsHeaderVisible { get; set; }
        public bool IsOdd { get; set; }

        public static ContractsGroupVm Create(IEnumerable<ContractSnapshot> contracts, PersonId personId)
        {
            var list = contracts.ToList();
            var first = list.First();
            var isMain = personId == first.PersonId;
            var personName = isMain ? first.PersonName.FullName : first.PersonName.FullName + " — " + first.DependentType;

            return new ContractsGroupVm
            {
                IsMain = isMain,
                PersonName = personName,
                Items = list.Select(ContractItem.Create).ToList()
            };
        }
    }
}