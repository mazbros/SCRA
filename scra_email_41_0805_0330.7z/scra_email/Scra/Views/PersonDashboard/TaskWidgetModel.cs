﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Views.PersonDashboard
{
    public class TaskWidgetModel : BaseViewModel
    {
        private readonly ITaskRepository _repository;
        private readonly AppNavigator _navigator;
        private TaskListItem _taskItem;

        public TaskWidgetModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _repository = Di.Get<ITaskRepository>();
            _navigator = Di.Get<AppNavigator>();
            Tasks = new ObservableCollection<TaskListItem>();
            SelectCommand = new Command(Select);
        }

        private void Select()
        {
            if (TaskItem == null)
            {
                return;
            }
            _navigator.Task(TaskItem.Id);
        }

        private void ShowTask(int id )
        {
            _navigator.Task(id);
        }

        public ObservableCollection<TaskListItem> Tasks { get; set; }
        public ICommand SelectCommand { get; set; }

        public async Task Load(Person person)
        {
            var tasks = await _repository.Load(new LoadTasksFilter {PersonId = person.Id}, string.Empty);
            var sortedTasks = tasks.OrderByDescending(x => x.CreateDate).ToList();

            var vms = new List<TaskListItem>();
            foreach (var task in sortedTasks)
            {                
                vms.Add(TaskListItem.Create(task, ShowTask));
            }

            Tasks.Update(vms);
        }

        public class TaskListItem
        {
            public static TaskListItem Create(TaskSnapshot task, Action<int> showTask)
            {
                return new TaskListItem
                {
                    Title = task.Title,
                    Status = task.Status.Name,
                    Id = task.Id,
                    CreateDate = Formatter.Date(task.CreateDate),
                    DoubleClickCommand = new Command(() => showTask(task.Id))
                };
            }

            public ICommand DoubleClickCommand { get; set; }
            public string Status { get; set; }
            public string Title { get; set; }
            public int Id { get; set; }
            public string CreateDate { get; set; }
        }

        public TaskListItem TaskItem
        {
            get { return _taskItem; }
            set { SetProperty(ref _taskItem, value); }
        }
    }
}
