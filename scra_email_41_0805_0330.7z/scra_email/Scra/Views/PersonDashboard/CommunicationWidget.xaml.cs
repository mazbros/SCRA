﻿namespace Scra.Views.PersonDashboard
{
    public partial class CommunicationWidget
    {
        public CommunicationWidget()
        {
            InitializeComponent();
        }

        public CommunicationWidgetModel GetViewModel()
        {
            return (CommunicationWidgetModel)DataContext;
        }
    }
}
