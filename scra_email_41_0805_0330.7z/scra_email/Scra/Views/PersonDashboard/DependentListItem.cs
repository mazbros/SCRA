﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Dependents;
using Scra.Model.Persons;

namespace Scra.Views.PersonDashboard
{
    public class DependentListItem
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Dates { get; set; }
        public ICommand DoubleClickDependent { get; set; }

        public static DependentListItem Create(DependentLink link, Person dependent, Action<PersonId> selectDependent)
        {
            var dates = Formatter.Date(link.StartDate) + " - " + Formatter.Date(link.EndDate);
            var name = dependent.Name.FullName;
            var type = link.Type.Name;
            return new DependentListItem
            {
                Dates = dates,
                Name = name, Type = type,
                DoubleClickDependent = new Command(() => selectDependent(dependent.Id))
            };
        }
    }
}