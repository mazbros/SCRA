﻿using Scra.Controls;
using Scra.Model.Contracts;
using Scra.Model.Extensions;

namespace Scra.Views.PersonDashboard
{
    public class ContractItem
    {
        public static ContractItem Create(ContractSnapshot contract)
        {
            return new ContractItem
            {
                Category = contract.Type.Category.Name,
                ProductName = contract.Type.Name,
                LegacyNo = contract.LegacyNo,
                CardNo = contract.CardNo,
                OpenCloseDates = Formatter.Range(contract.OpenDate, contract.CloseDate),
                ShowLegacyNo = contract.LegacyNo.IsNotEmpty(),
                ShowCardNo = contract.CardNo.IsNotEmpty()
            };
        }

        public string OpenCloseDates { get; set; }

        public string LegacyNo { get; set; }

        public string CardNo { get; set; }

        public string ProductName { get; set; }

        public string Category { get; set; }

        public bool ShowLegacyNo { get; set; }

        public bool ShowCardNo { get; set; }
    }
}