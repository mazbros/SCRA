﻿using System.Windows.Controls;

namespace Scra.Views.Tasks
{
    public partial class TaskAssigneeAdminControl
    {
        private bool _loaded;

        public TaskAssigneeAdminControl()
        {
            InitializeComponent();
            Loaded += ControlLoaded;
        }

        private void ControlLoaded(object sender, System.Windows.RoutedEventArgs e)
        {
            _loaded = true;
        }

        private void UserSelected(object sender, SelectionChangedEventArgs e)
        {
            if (!_loaded)
            {
                return;
            }
            var vm = GetViewModel();            
            vm.AssignCommand.Execute(null);
        }

        private TaskAssigneeAdminControlModel GetViewModel()
        {
            return (TaskAssigneeAdminControlModel) DataContext;
        }
    }
}
