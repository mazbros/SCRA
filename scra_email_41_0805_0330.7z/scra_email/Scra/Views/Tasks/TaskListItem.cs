﻿using System;
using Scra.AppCore;
using Scra.Model.Tasks;
using Scra.Model.Users;

namespace Scra.Views.Tasks
{
    public class TaskListItem
    {
        //public string CreateDate { get; set; }
        public static TaskListItem Create(TaskSnapshot tasc, TaskAssigneeControlModelFactory factory, UserList userList, Action done, Action qaSelectedAction)
        {
            var t = tasc.TaskType;
            return new TaskListItem
            {
                Id = tasc.Id, Title = tasc.Title, Status = tasc.Status.Name,
                TaskAssignee = factory.Create(tasc, userList, done),
                TaskAssigneeName = tasc.Assignee.DisplayName,
                QaAssignee = factory.CreateQa(tasc,  userList, reload: qaSelectedAction),
                QaAssigneeName = tasc.QaAssignee.DisplayName,
                CreateDate = tasc.CreateDate,/* tasc.CreateDate == null ? null : Formatter.Date(tasc.CreateDate),*/
                ContactDate = tasc.ContactDate,
                IsQaComplete = tasc.IsQaComplete,
                ServicememberName = tasc.ServicememberName,
                RequestType = tasc.TaskType.Name,
            };
        }

        public bool IsQaComplete { get; set; }
        public DateTime? ContactDate { get; set; }
        public DateTime CreateDate { get; set; }
        public string ServicememberName { get; set; }
        public BaseControlModel TaskAssignee { get; set; }
        public BaseControlModel QaAssignee { get; set; }
        public string Status { get; set; }
        public string Title { get; set; }
        public int Id { get; set; }
        public string RequestType { get; set; }
        public string TaskAssigneeName { get; set; }
        public string QaAssigneeName { get; set; }

    }
}