﻿//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Reflection;
using System.Threading.Tasks;
using Scra.Configs;
using Scra.Model.Exceptions;
using Scra.Model.Tools;
using Scra.Model.Version;

namespace Scra.Services
{
    public class VersionControlService
    {
        public async Task CheckVersion()
        {
            var repository = Di.Get<IVersionRepository>();
            var dbVersion = await repository.GetDbVersion();
            var dbName = await repository.GetDbName();

            AppConfig.DbName = dbName;

            if (AppConfig.Version < dbVersion.Version)
            {
                //var directories = Directory.GetDirectories(AppConfig.FileShare, "scra_*_*", SearchOption.AllDirectories);
                //var latest = directories.ToList().OrderByDescending(x => x).ElementAt(0);
                //var files = Directory.GetFiles(latest);
                //var directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                //if (directoryName != null)
                //{
                //    var destinationPath = Path.Combine(directoryName, "Update");

                //    foreach (var file in files)
                //    {
                //        if (!Directory.Exists(destinationPath)) Directory.CreateDirectory(destinationPath);
                //        File.Copy(file, Path.Combine(destinationPath, Path.GetFileName(file)), true);
                //    }
                //}

                var message = "The current application version does not match with the database, please upgrade the application and restart";
                //Process.Start("updateApp.bat");
                throw new UserException(message);

                
            }
            else if (AppConfig.Version > dbVersion.Version)
            {
                var message = "The current application version does not match with the database, please upgrade database and restart the application";
                throw new UserException(message);
            }
        }
    }
}