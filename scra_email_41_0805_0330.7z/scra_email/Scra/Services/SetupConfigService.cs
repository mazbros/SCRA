﻿using Scra.Configs;
using Scra.DataAccess.Configs;
using Scra.Model.Tools;

namespace Scra.Services
{
    public class SetupConfigService
    {
        public void Setup()
        {
            var configReader = new AppConfigFileReader();
            var connectionName = configReader.Get("connectionName");
            var connectionString = configReader.GetConnectionString(connectionName);
            Di.Set<IDbConfig>(new DbConfig { ConnectionString = connectionString });

            //var fileShare = connectionName == "remote" ? configReader.Get("remoteShare") : configReader.Get("sanShare");
            //AppConfig.FileShare = fileShare;
        }
    }
}
