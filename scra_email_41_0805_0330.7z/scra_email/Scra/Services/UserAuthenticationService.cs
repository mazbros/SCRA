﻿using System;
using System.Threading.Tasks;
using Scra.Model.Exceptions;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Services
{
    public class UserAuthenticationService
    {
        public async Task Authenticate()
        {
            var repo = Di.Get<IUserRepository>();
            var userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            var slashIndex = userName.IndexOf(@"\", StringComparison.Ordinal);
            var parsedUserName = userName.Substring(slashIndex + 1, userName.Length - (slashIndex + 1));
            //var parsedUserName = "unknown";
            var user = await repo.Get(parsedUserName);
            if (!user.IsActive)
            {
                var message = string.Format("User {0} doesn't have permissions for SCRA application. Please contact the SCRA manager for support.", parsedUserName);
                throw new UserException(message);
            }
             Di.Set<IUser>(user);
        }
    }
}