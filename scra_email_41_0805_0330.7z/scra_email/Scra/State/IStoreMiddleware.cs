﻿using System.Collections.Generic;

namespace Scra.State
{
    public interface IStoreMiddleware<TState>
    {
        void Execute(IList<IAct> acts, TState state);
    }
}