﻿namespace Scra.State
{
    public class AppReducer : IReducer<AppState>
    {
        public AppState GetInitial()
        {
            return new AppState();
        }

        public AppState Reduce(AppState old, IAct act)
        {
            return old;
        }

        public bool IsApplicable(IAct act)
        {
            return false;
        }
    }
}
