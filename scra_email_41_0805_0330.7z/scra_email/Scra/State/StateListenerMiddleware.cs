﻿using System;
using System.Collections.Generic;

namespace Scra.State
{
    public class StateListenerMiddleware : IStoreMiddleware<AppState>, IStateListenerSubscriber
    {
        private readonly List<Action<AppState>> _executors;
        private AppState _lastState;

        public StateListenerMiddleware()
        {
            _executors = new List<Action<AppState>>();
        }

        public void SubscribeStateListener(Action<AppState> executor)
        {
            _executors.Add(executor);
        }

        public void Execute(IList<IAct> acts, AppState state)
        {
            if (_lastState.StateId >= state.StateId)
            {
                return;
            }

            _lastState = state;
            foreach (var executor in _executors)
            {
                executor(state);
            }
        }
    }
}