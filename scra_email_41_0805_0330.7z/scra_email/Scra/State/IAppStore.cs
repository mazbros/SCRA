﻿namespace Scra.State
{
    public interface IAppStore : ICommandSubscriber, IStateListenerSubscriber, IStore<AppState>
    {
    }
}