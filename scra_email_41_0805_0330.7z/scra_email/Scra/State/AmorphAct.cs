﻿using System;

namespace Scra.State
{
    internal class AmorphAct : IAct, IEquatable<string>
    {
        public string Code { get; private set; }
        public object Argument { get; private set; }

        public AmorphAct(string code)
        {
            Code = code;
        }

        public AmorphAct(string code, object argument)
        {
            Code = code;
            Argument = argument;
        }

        public override string ToString()
        {
            return Code;
        }

        public bool Equals(IAct other)
        {
            return string.Equals(Code, other.Code);
        }

        public bool Is(string other)
        {
            return Equals(other);
        }

        public bool Equals(string other)
        {
            return Code == other;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is IAct && Equals((IAct)obj);
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public static implicit operator AmorphAct(string code)
        {
            return new AmorphAct(code);
        }
    }
}