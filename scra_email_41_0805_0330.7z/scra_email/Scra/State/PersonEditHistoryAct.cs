﻿using System;

namespace Scra.State
{
    public class PersonEditHistoryAct : IAct
    {
        public int Id { get; set; }
        public DateTime? Timestamp{ get; set; }
        public string Code
        {
            get { return Act.LOAD_PERSON_HISTORY; }
        }

        public object Argument { get; set; }

        public PersonEditHistoryAct(int id, DateTime? timestamp)
        {
            Id = id;
            Timestamp = timestamp;
        }
    }
}
