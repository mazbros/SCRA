﻿using System;

namespace Scra.State
{
    public struct Act : IAct, IEquatable<string>
    {
        private readonly string _code;
        private readonly object _argument;
        //public const string TASK_QA_CHANGED = "TASK_QA_CHANGED";
        public const string TASK_DONE_UNLOCK = "TASK_DONE_UNLOCK";
        public const string TASK_DONE_LOCK = "TASK_DONE_LOCK";
        public const string SHOW_TASK = "SHOW_TASK";
        public const string TASK_STATUS_CHANGED = "TASK_STATUS_CHANGED";

        public const string RELOAD_TASK = "RELOAD_TASK";

        public const string SHOW_PERSON = "SHOW_PERSON";
        public const string LOAD_PERSON_HISTORY = "LOAD_PERSON_HISTORY";
        public const string CLOSE_LEFT_PANEL = "CLOSE_LEFT_PANEL";

        public string Code
        {
            get { return _code; }
        }

        public Act(string code)
        {
            _code = code;
            _argument = null;
        }

        public Act(string code, object argument)
        {
            _code = code;
            _argument = argument;
        }
        
        public object Argument
        {
            get { return _argument; }
        }

        public override string ToString()
        {
            return Code;
        }

        public bool Equals(Act other)
        {
            return string.Equals(Code, other.Code);
        }

        public bool Is(string other)
        {
            return Equals(other);
        }

        public bool Equals(string other)
        {
            return Code == other;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is Act && Equals((Act)obj);
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public static implicit operator Act(string code)
        {
            return new Act(code);
        }
    }
}