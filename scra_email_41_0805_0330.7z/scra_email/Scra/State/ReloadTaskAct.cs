﻿namespace Scra.State
{
    public class ReloadTaskAct : IAct
    {
        public int TaskId { get; private set; }
        public string Code
        {
            get { return Act.RELOAD_TASK; }
        }

        public object Argument { get; set; }

        public ReloadTaskAct(int taskId)
        {
            TaskId = taskId;
        }
    }
}