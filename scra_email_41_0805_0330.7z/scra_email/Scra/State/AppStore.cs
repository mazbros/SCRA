﻿using System;
using Scra.Model.Tools;

namespace Scra.State
{
    public class AppStore : Store<AppState>, IAppStore
    {
        private readonly AppCommandMiddleWare _commandMiddleware;
        private readonly StateListenerMiddleware _stateListenerMiddleware;

        public AppStore(IReducer<AppState> reducer)
            : base(reducer)
        {
            _commandMiddleware = Di.Get<AppCommandMiddleWare>();
            Subscribe(_commandMiddleware);

            _stateListenerMiddleware = new StateListenerMiddleware();
            Subscribe(_stateListenerMiddleware);
        }

        public Action SubscribeCommand(string act, Action<IAct> actExecutor)
        {
            return _commandMiddleware.SubscribeCommand(act, actExecutor);
        }

        public void UnSubscribeCommand(string act, Action<IAct> actExecutor)
        {
            _commandMiddleware.UnSubscribeCommand(act, actExecutor);
        }

        public void SubscribeStateListener(Action<AppState> executor)
        {
            _stateListenerMiddleware.SubscribeStateListener(executor);
        }
    }
}
