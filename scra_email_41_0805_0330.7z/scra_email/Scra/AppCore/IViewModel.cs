﻿namespace Scra.AppCore
{
    public interface IViewModel
    {
    }
}