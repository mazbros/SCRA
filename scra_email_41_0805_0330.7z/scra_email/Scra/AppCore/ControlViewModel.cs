﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Scra.AppCore
{
    public class ControlViewModel : INotifyPropertyChanged, IViewModel
    {
        public object View { get; set; }
        public object Arguments { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public void SetProperty<T>(ref T member, T val, [CallerMemberName] string propertyName = null)
        {
            if (Equals(member, val)) return;

            member = val;
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        [NotifyPropertyChangedInvocator]
        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        protected bool InDesignMode()
        {
            return !(System.Windows.Application.Current is App);
        }
    }
}