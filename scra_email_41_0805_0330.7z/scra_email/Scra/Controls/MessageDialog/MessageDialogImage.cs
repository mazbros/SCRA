﻿namespace Scra.Controls.MessageDialog
{
    public enum MessageDialogImage
    {
        Warning = 0,
        Question,
        Information,
        Error,
        Ok
    }
}