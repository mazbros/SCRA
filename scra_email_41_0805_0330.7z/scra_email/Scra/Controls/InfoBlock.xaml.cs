﻿using System.Windows;

namespace Scra.Controls
{
    public partial class InfoBlock
    {
        public InfoBlock()
        {
            InitializeComponent();
        }

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(InfoBlock), new PropertyMetadata(""));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(InfoBlock), new PropertyMetadata("*"));

        public string Value
        {
            get { return (string)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(string), typeof(InfoBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }
}
