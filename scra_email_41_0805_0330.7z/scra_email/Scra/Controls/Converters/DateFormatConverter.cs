﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace Scra.Controls.Converters
{
    public class DateFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || value.ToString().Equals("1/1/0001 12:00:00 AM") || DateTime.Parse(value.ToString()).Equals(DateTime.MinValue))
                return null;

            DateTime dt = DateTime.Parse(value.ToString());
            return dt.ToString("MM/dd/yyyy");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
