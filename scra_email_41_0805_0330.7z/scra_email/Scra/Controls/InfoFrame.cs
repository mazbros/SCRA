﻿using System.Windows.Controls;

namespace Scra.Controls
{
    public class InfoFrame : UserControl
    {
    }
}