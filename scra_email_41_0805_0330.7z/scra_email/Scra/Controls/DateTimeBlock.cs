﻿using System;
using System.Windows;
using System.Windows.Input;

namespace Scra.Controls
{
    public class DateTimeBlock : MaskBlock
    {
        private readonly string _defaultStr = "__/__/____ __:__ AM";

        public DateTimeBlock()
        {
            var skipChars = new[] {'/', ' ', ':'};
            //_defaultStr = "__/__/____ __:__ AM";
            var mask = @"[_01][_0-9]/[_0-3][_0-9]/[_1-2][_8901][_0-9]{2} [_0-1][_0-9]:[_0-5][_0-9] [AaPp]{0,1}[Mm]{1}";
            Setup(mask, _defaultStr, skipChars);
        }

        protected override void Setup(string mask, string defaultText, char[] skipSymbols)
        {
            MaskEditor.Attach(InputTextControl, mask, defaultText, skipSymbols,null,DatePreviewKeyDown);
        }

        private void DatePreviewKeyDown(object sender, KeyEventArgs e)
        {
            var textBox = InputTextControl;
            if (e.Key == Key.Back || e.Key==Key.Delete)
            {
                e.Handled = true;
                var caretIndex = textBox.CaretIndex;
                if (caretIndex == 0)
                {
                    return;
                }

                var text = textBox.Text;
                var removeIndex = caretIndex - 1;
                text = text.Remove(removeIndex, 1);
                text = text.Insert(removeIndex, _defaultStr.Substring(removeIndex, 1));
                textBox.Text = text;
                textBox.CaretIndex = removeIndex;
            }
        }

        public DateTime? Value
        {
            get
            {
                var text = (string)GetValue(TextValueProperty);
                return Formatter.ParseDate(text);
            }
            set
            {
                SetValue(ValueProperty, value);
                if (value == null)
                {
                    SetValue(TextValueProperty, _defaultStr);
                    return;
                }
                var dateStr = Formatter.DateTime(value ?? Formatter.Minimum);
                SetValue(TextValueProperty, dateStr);
            }
        }

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(DateTime?), typeof(DateTimeBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ValueChange));

        private static void ValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var time = (DateTime?)e.NewValue;
            d.SetValue(TextValueProperty, Formatter.DateTime(time ?? Formatter.Minimum));
        }

        protected override void InputTextChanged(string newValue)
        {
            if (newValue == _defaultStr)
            {
                Value = null;
            }

            if (Formatter.IsValidDate(newValue))
            {
                var time = Formatter.ParseDate(newValue);
                Value = time;
            }
        }
    }
}