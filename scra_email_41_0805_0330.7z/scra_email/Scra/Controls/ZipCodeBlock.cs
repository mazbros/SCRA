﻿using System.Windows;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public class ZipCodeBlock : MaskBlock
    {
        public ZipCodeBlock()
        {
            Setup(@"\d{5}-\d{4}", ZipCode.Empty().GetDisplay(), new[] { '-' });

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public ZipCode Value
        {
            get
            {
                var text = (string)GetValue(TextValueProperty);
                return ZipCode.Parse(text);
            }
            set
            {
                SetValue(ValueProperty, value);
                SetValue(TextValueProperty, value.GetDisplay());
            }
        }

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(ZipCode), typeof(ZipCodeBlock), new FrameworkPropertyMetadata(ZipCode.Empty(), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ValueChange));

        private static void ValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var zip = (ZipCode)e.NewValue;
            d.SetValue(TextValueProperty, zip.GetDisplay());
        }

        protected override void InputTextChanged(string newValue)
        {
            var zip = ZipCode.Parse(newValue);
            Value = zip;
        }
    }
}