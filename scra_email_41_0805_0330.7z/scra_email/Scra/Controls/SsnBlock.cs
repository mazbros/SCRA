﻿using System.Windows;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public class SsnBlock : MaskBlock
    {
        public SsnBlock()
        {
            Setup(@"\d{3}-\d{2}-\d{4}", "000-00-0000", new[] { '-' });

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public Ssn Value
        {
            get
            {
                var text = (string) GetValue(TextValueProperty);
                return Ssn.Parse(text);
            }
            set
            {
                SetValue(ValueProperty, value);
                SetValue(TextValueProperty, value.GetDisplay());
            }
        }

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(Ssn), typeof(SsnBlock), new FrameworkPropertyMetadata(Ssn.Empty(), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, ValueChange));

        private static void ValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var ssn = (Ssn) e.NewValue;
            d.SetValue(TextValueProperty, ssn.GetDisplay());
        }

        protected override void InputTextChanged(string newValue)
        {
            var ssn = Ssn.Parse(newValue);
            Value = ssn;
        }
    }
}
