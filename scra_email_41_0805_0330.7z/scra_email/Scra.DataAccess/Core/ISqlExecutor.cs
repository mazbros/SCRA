﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Scra.DataAccess.Core
{
    public interface ISqlExecutor
    {
        Task<TResult> ExecuteOne<TResult>(string query, Func<IRowData, TResult> parser) where TResult: class;
        Task Execute(string query);
        Task<IList<TResult>> Execute<TResult>(string query, Func<IRowData, TResult> parser);
        Task<DataSet> GetDataSet(string query);
        Task<DataTable> GetTable(string query);
        Task<object> GetScalar(string query);
    }
}