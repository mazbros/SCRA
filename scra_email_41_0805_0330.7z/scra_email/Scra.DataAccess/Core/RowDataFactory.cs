﻿using System.Data;

namespace Scra.DataAccess.Core
{
    internal static class RowDataFactory
    {
        public static IRowData Create(DataRow row)
        {
            return new DataRowData(row);
        }

        public static IRowData Create(IDataRecord row)
        {
            return new DataRecordRowData(row);
        }
    }
}
