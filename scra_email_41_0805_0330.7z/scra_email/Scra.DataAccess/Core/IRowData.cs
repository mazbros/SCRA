﻿using System;

namespace Scra.DataAccess.Core
{
    public interface IRowData
    {
        int AsInt(string name);
        decimal AsDecimal(string name);
        string AsString(string name);
        byte[] AsByteArray(string name);
        string AsString(int fieldIndex);
        DateTime? AsDateTime(string name);
        DateTime AsDateTimeStrict(string name);
        bool AsBool(string name);
    }
}