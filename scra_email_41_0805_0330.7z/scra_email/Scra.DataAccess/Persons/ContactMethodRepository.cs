﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.ContactMethods;

namespace Scra.DataAccess.Persons
{
    internal class ContactMethodRepository : IContactMethodRepository
    {
        private readonly SqlExecutor _sqlExecutor;

        public ContactMethodRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<ContactMethodList> GetList()
        {
            var query = "SELECT ID, Name FROM dbo.ContactMethod ORDER BY SortIndex";
            var items = await _sqlExecutor.Execute(query, Convert);
            return ContactMethodList.Create(items);
        }

        private ContactMethod Convert(IRowData record)
        {
            return ContactMethod.Create(record.AsInt(RefColumn.ID), record.AsString(RefColumn.NAME));
        }
    }
}