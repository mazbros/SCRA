﻿namespace Scra.DataAccess.Inquiries
{
    internal static class InquiryColumn
    {
        public const string DMDC_VALIDATION_DATE = "DmdcValidationDate";
        public const string IS_ON_ACTIVE_DUTY = "IsOnActiveDuty";
        public const string INQUIRY_DATE = "InquiryDate";
        public const string AGENT_ID = "AgentId";
        public const string CONTACT_METHOD_ID = "ContactMethodId";
        public const string PERSON_INQUIRING_ID = "PersonInquiringId";
        public const string SERVICEMEMBER_ID = "ServicememberId";
        public const string DEPENDENT_TYPE_ID = "DependentTypeId";
        public const string INQUIRY_TYPE = "inquiryType";
        public const string DESCRIPTION = "Description";
        public const string COMMENT = "Comment";
        public const string IS_COMPLETED = "IsCompleted";
        public const string ACKNOWLEDGE_DATE = "AcknowledgeDate";
        public const string IDENTIFICATION_METHOD = "IdentificationMethod";

        public const string SCUSA_SENT_DATE_1 = "ScusaSentDate1";
        public const string SCUSA_SENT_DATE_2 = "ScusaSentDate2";
        public const string SCUSA_CONFIRMATION_DATE = "ScusaConfirmationDate";
        public const string RESPONSE_TEXT = "ResponseText";
        public const string RESPONSE_DATE = "ResponseDate";
        public const string RESPONSE_METHOD_ID = "ResponseMethodId";
    }
}
