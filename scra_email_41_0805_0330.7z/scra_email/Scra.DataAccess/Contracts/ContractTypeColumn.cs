﻿namespace Scra.DataAccess.Contracts
{
    internal class ContractTypeColumn
    {
        public const string CONTRACT_TYPE_ID = "ContractTypeId";
        public const string CATEGORY_CODE = "SCRA_Code";
        public const string PRODUCT_NAME = "SUB_PRODUCT_NAME";
    }
}