﻿namespace Scra.DataAccess.Contracts
{
    public class ContractColumn
    {
        public const string ID = "Id";
        public const string CONTRACT_TYPE_ID = "ContractTypeId";
        public const string CENTER = "Center";
        public const string PRODUCT = "Product";
        public const string CONTRACT_NO = "ContractNo";
        public const string LEGACY_NO = "LegacyNo";
        public const string CARD_NO = "CardNo";
        public const string OPEN_DATE = "OpenDate";
        public const string CLOSE_DATE = "CloseDate";
        public const string IS_DELETED = "IsDeleted";
        public const string PERSON_ID = "PersonId";
        public const string DEPENDENT_TYPE = "DependentType";
        public const string PRODUCT_NAME_GET = "SUB_PRODUCT_NAME";
        public const string PRODUCT_NAME_SET = "ProductName";
    }
}