﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Contracts;

namespace Scra.DataAccess.Contracts
{
    internal class ContractTypeRepository : IContractTypeRepository
    {
        private const string LOAD_SQL = @"
SELECT	Id AS ContractTypeId, SCRA_Code, SUB_PRODUCT_NAME
FROM	dbo.ContractType

WHERE   {WHERE}";

        private readonly SqlExecutor _sqlExecutor;

        public ContractTypeRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public Task<IList<ContractType>> Load(ContractCategory category)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "SCRA_Code = '" + category.Code + "'");
            return _sqlExecutor.Execute(sql, Convert);
        }

        private ContractType Convert(IRowData row)
        {
            var categoryCode = row.AsString(ContractTypeColumn.CATEGORY_CODE);
            var category = ContractCategory.Parse(categoryCode);

            var typeId = row.AsInt(ContractTypeColumn.CONTRACT_TYPE_ID);
            var productName = row.AsString(ContractTypeColumn.PRODUCT_NAME);
            return new ContractType(typeId, category, productName);
        }
    }
}
