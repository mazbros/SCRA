﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.DataAccess.Persons;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.Logs;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.DataAccess.Contracts
{
    internal class ContractRepository : IContractRepository
    {
        private const string GET_SQL = @"
SELECT	x.Id, x.Center, x.Product, x.ContractNo, x.LegacyNo, x.CardNo, x.OpenDate, x.CloseDate, 
        x.PersonID, x.ContractTypeId, 
        CASE WHEN ISNULL(x.ProductName,'''') = '''' THEN t.Product_SubType ELSE x.ProductName END as [SUB_PRODUCT_NAME], 
        t.SCRA_Code
FROM	dbo.Contract x

INNER	JOIN dbo.ContractType t 
		ON	t.Id	= x.ContractTypeId

WHERE   {WHERE}";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;
        private readonly ILogger _logger;

        public ContractRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
            _logger = Di.Get<ILogger>();
        }

        public async Task<int> GetCurrent()
        {
            var currentNumber = await _sqlExecutor.GetTable("SELECT [Number] FROM [dbo].[Sequence]");
            var num = 0;
            foreach (DataRow row in currentNumber.Rows)
            {
                num = int.Parse(row[0].ToString());
            }

            return num;
        }
    
        public async Task SaveCurrent(int currentNumber)
        {
            var parameters = new[]
            {
                SpParameter.Create("Number", currentNumber)
            };
            await _spExecutor.Execute("dbo.spUpdateSequence", parameters);
        }

        public async Task<int> CheckDuplicate(FNumber fNumber, int personId)
        {
            var parameters = new[]
            {
                SpParameter.Create("FNumber", fNumber.ToString()),
                SpParameter.Create("PersonId", personId),
            };
            var result = await _spExecutor.GetRecord("dbo.spFNumber_CheckDuplicate", parameters, ConvertCheckDuplicate);

            return result;
        }

        private int ConvertCheckDuplicate(IDataRecord arg)
        {
            var record = arg.GetInt32(0);
            return record;
        }

        public async Task<IList<Contract>> RemoteFetch(PersonId personId)
        {
            var peronIdPar = SpParameter.Create(RefColumn.PERSON_ID, personId);
            return await _spExecutor.GetRecords("dbo.spContract_RemoteFetch", peronIdPar, ConvertRemoteToContract);
        }

        public async Task<IList<Contract>> RemoteFetch(string fnumber)
        {
            var peronIdPar = SpParameter.Create("FNumber", fnumber);
            return await _spExecutor.GetRecords("dbo.spContract_RemoteFetch", peronIdPar, ConvertRemoteToContract);
        }

        public async Task Save(Contract contract)
        {
            var id = SpParameter.CreateInOut(contract.Id);
            var parameters = new[]
            {
                SpParameter.Create(ContractColumn.CONTRACT_TYPE_ID, contract.Type.Id),
                SpParameter.Create(ContractColumn.CONTRACT_NO, contract.ContractNo),
                SpParameter.Create(ContractColumn.LEGACY_NO, contract.LegacyNo),
                SpParameter.Create(ContractColumn.CARD_NO, contract.CardNo),
                SpParameter.Create(ContractColumn.CENTER, contract.Center.ToString()),
                SpParameter.Create(ContractColumn.PRODUCT, contract.Product.ToString()),
                SpParameter.Create(ContractColumn.OPEN_DATE, contract.OpenDate),
                SpParameter.Create(ContractColumn.CLOSE_DATE, contract.CloseDate),
                SpParameter.Create(ContractColumn.IS_DELETED, contract.IsDeleted),
                SpParameter.Create(ContractColumn.PERSON_ID, contract.PersonId),
                SpParameter.Create(ContractColumn.PRODUCT_NAME_SET, contract.ContractProductName),
                SpParameter.ModifiedBy(),
                id
            };

            try
            {
                await _spExecutor.Execute("dbo.spContract_Update", parameters);

                contract.Id = new ContractId((int) id.Value);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        public async Task<IList<ContractSnapshot>> Load(PersonId personId)
        {
            var peronIdPar = SpParameter.Create(RefColumn.PERSON_ID, personId);
            return await _spExecutor.GetRecords("dbo.spContract_List", peronIdPar, ConvertToSnapshot);
        }

        public Task<Contract> Get(ContractId id)
        {
            var sql = GET_SQL.Replace("{WHERE}", "x.Id = " + id);
            return _sqlExecutor.ExecuteOne(sql, Convert);
        }

        private Contract Convert(IRowData row)
        {
            var id = new ContractId(row.AsInt(ContractColumn.ID));
            var personId = new PersonId(row.AsInt(ContractColumn.PERSON_ID));
            var contractNo = GetContractNo(row);
            var legacyNo = row.AsString(ContractColumn.LEGACY_NO);
            var cardNo = row.AsString(ContractColumn.CARD_NO);
            var center = row.AsInt(ContractColumn.CENTER);
            var product = row.AsInt(ContractColumn.PRODUCT);
            var openDate = row.AsDateTime(ContractColumn.OPEN_DATE).NotNull();
            var closeDate = row.AsDateTime(ContractColumn.CLOSE_DATE);
            var type = ConvertRemoteToContractType(row);
            var category = ConvertRemoteToContractCategory(row);
            var productName = row.AsString(ContractColumn.PRODUCT_NAME_GET);
            return new Contract(id, personId, type, contractNo, legacyNo, cardNo, center, product, openDate, closeDate, category, productName);
        }

        private ContractSnapshot ConvertToSnapshot(IRowData row)
        {
            var id = new ContractId(row.AsInt(ContractColumn.ID));
            var personId = new PersonId(row.AsInt(ContractColumn.PERSON_ID));
            var name = GetName(row);
            var legacyNo = row.AsString(ContractColumn.LEGACY_NO);
            var contractNo = GetContractNo(row);
            var cardNo = row.AsString(ContractColumn.CARD_NO);
            var center = row.AsInt((ContractColumn.CENTER));
            var product = row.AsInt(ContractColumn.PRODUCT);
            var openDate = row.AsDateTime(ContractColumn.OPEN_DATE).NotNull();
            var closeDate = row.AsDateTime(ContractColumn.CLOSE_DATE);
            var dependentType = row.AsString(ContractColumn.DEPENDENT_TYPE);
            var type = ConvertRemoteToContractType(row);
            return new ContractSnapshot(id, name, type, openDate, closeDate, contractNo, legacyNo, cardNo, center, product,  personId, dependentType);
        }

        private string GetContractNo(IRowData row)
        {
            var center = row.AsInt(ContractColumn.CENTER).ToString();
            var product = row.AsInt(ContractColumn.PRODUCT).ToString();
            var contractNo = row.AsString(ContractColumn.CONTRACT_NO);
            if (contractNo.IsEmpty()) return string.Empty;
            if (contractNo.Length == 14) return contractNo;
            
            return center.PadLeft(4, '0') + product.PadLeft(3, '0') + contractNo.PadLeft(7, '0');
        }

        private PersonName GetName(IRowData record)
        {
            return PersonName.Create(record.AsString(PersonColumn.FIRST_NAME),
                record.AsString(PersonColumn.MIDDLE_INITIAL), record.AsString(PersonColumn.LAST_NAME));
        }

        private Contract ConvertRemoteToContract(IRowData row)
        {
            var contractNo = GetContractNo(row);
            var legacyNo = row.AsString(ContractColumn.LEGACY_NO);
            var cardNo = row.AsString(ContractColumn.CARD_NO);
            var center = row.AsInt(ContractColumn.CENTER);
            var product = row.AsInt(ContractColumn.PRODUCT);
            var openDate = row.AsDateTime(ContractColumn.OPEN_DATE).NotNull();
            var closeDate = row.AsDateTime(ContractColumn.CLOSE_DATE);
            var type = ConvertRemoteToContractType(row);
            var category = ConvertRemoteToContractCategory(row);
            var productName = row.AsString(ContractColumn.PRODUCT_NAME_GET);
            return Contract.CreateRemote(type, contractNo, legacyNo, cardNo, center, product, openDate, closeDate, category, productName);
        }

        private ContractType ConvertRemoteToContractType(IRowData row)
        {
            var categoryCode = row.AsString(ContractTypeColumn.CATEGORY_CODE);
            var category = ContractCategory.Parse(categoryCode);

            var typeId = row.AsInt(ContractTypeColumn.CONTRACT_TYPE_ID);
            var productName = row.AsString(ContractTypeColumn.PRODUCT_NAME);
            return new ContractType(typeId, category, productName);
        }

        private ContractCategory ConvertRemoteToContractCategory(IRowData row)
        {
            var categoryCode = row.AsString(ContractTypeColumn.CATEGORY_CODE);
            var category = ContractCategory.Parse(categoryCode);
            return category;
        }
    }
}
