﻿namespace Scra.DataAccess.Contracts
{
    public class BenefitDetailColumn
    {        
        public const string BENEFIT_ID = "BenefitId";
        public const string CURRENT_RATE = "CurrentRate";
        public const string BLOCK_41 = "Block41";
        public const string DMI_SENT_DATE = "DmiSentDate";
        public const string CONFIRMATION_RECEIVED_DATE = "ConfirmationReceivedDate";
        public const string IS_PROMOTIONAL_OFFER = "IsPromotionalOffer";
        public const string PROMOTION_END_DATE = "PromotionEndDate";
        public const string IS_RATE_CAP_PERFORMED = "IsRateCapPerformed";
        public const string IS_FEE_WAIVED = "IsFeeWaived";
        public const string FEE_REFUNDED_AMOUNT = "FeeRefunded";
        public const string FEE_REFUNDED_DATE = "FeeRefundedDate";
        public const string IS_STATEMENTS_PENDING = "IsStatementsPending";
        public const string STATEMENTS_DATE = "StatementDate";
        public const string IS_INTEREST_ADJUSTMENT_CALCULATED = "IsInterestAdjustmentCalculated";
        public const string INTEREST_REFUNDED_AMOUNT = "InterestRefunded";
        public const string INTEREST_REFUNDED_DATE = "InterestRefundedDate";
        public const string BENEFIT_APPLIED_DATE = "BenefitAppliedDate";
        public const string DATE_BENEFIT_EXPECTED = "BenefitExpectedDate";
        public const string BENEFIT_EFFECTIVE_DATE = "BenefitEffectiveDate";
        public const string EXPECTED_REMOVAL_DATE = "ExpectedRemovalDate";
        public const string BENEFIT_REMOVED_DATE = "BenefitRemovedDate";
    }
}