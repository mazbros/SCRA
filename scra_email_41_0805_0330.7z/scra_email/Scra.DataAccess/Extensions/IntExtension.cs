﻿namespace Scra.DataAccess.Extensions
{
    internal static class IntExtension
    {
        public static bool IsNew(this int id)
        {
            return id < 1;
        }
    }
}