﻿namespace Scra.DataAccess.Users
{
    public static class UserColumn
    {
        public const string ID = "Id";
        public const string USER_NAME = "UserName";
        public const string NAME = "Name";
        public const string ACTIVE = "Active";
        public const string TYPE = "Type";
    }
}