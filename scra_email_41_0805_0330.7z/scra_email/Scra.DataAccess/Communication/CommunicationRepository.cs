﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Communication;
using Scra.Model.Persons;

namespace Scra.DataAccess.Communication
{
    internal class CommunicationRepository : ICommunicationRepository
    {
        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        private const string GET_SQL = @"
SELECT	ID ,PersonID ,BenefitID ,CommunicationDate ,ContactMethodId ,ResponseText ,LetterId, TaskId
FROM	dbo.Communication
WHERE   CommunicationDate IS NOT NULL AND ContactMethodId <> 0 {WHERE} 
Order by Timestamp desc";


        public CommunicationRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }


        public async Task<ProductCommunication> GetById(int id)
        {
            var sql = GET_SQL.Replace("{WHERE}", " AND ID=" + id);
            return await _sqlExecutor.ExecuteOne(sql, Convert);
        }

        public async Task<ProductCommunication> GetByBenefit(int benefitId)
        {
            var sql = GET_SQL.Replace("{WHERE}", "AND BenefitId=" + benefitId);
            return await _sqlExecutor.ExecuteOne(sql, Convert);
        }

        public async Task<ProductCommunication> GetByTask(int taskId)
        {
            var sql = GET_SQL.Replace("{WHERE}", "AND TaskId=" + taskId);
            return await _sqlExecutor.ExecuteOne(sql, Convert);
        }

        public async Task<IList<ProductCommunication>> GetByPerson(int id)
        {
            var sql = GET_SQL.Replace("{WHERE}", "AND PersonId=" + id);
            return await _sqlExecutor.Execute(sql, Convert);
        }

        public async Task Update(ProductCommunication model)
        {
            var id = SpParameter.CreateInOut(model.CommunicationId);
            var parameters = new[]
            {
                id,
                SpParameter.Create(CommunicationColumns.PERSON_ID, model.PersonId),
                SpParameter.Create(CommunicationColumns.BENEFIT_ID, model.BenefitId),
                SpParameter.Create(CommunicationColumns.COMMUNICATION_DATE, model.CommunicationDate),
                SpParameter.Create(CommunicationColumns.CONTACT_METHOD_ID, model.ResponseMethodId),
                SpParameter.Create(CommunicationColumns.RESPONSE_TEXT, model.ResponseText),
                SpParameter.Create(CommunicationColumns.LETTER_ID, model.LetterId),
                SpParameter.Create(CommunicationColumns.TASK_ID, model.TaskId),
                SpParameter.ModifiedBy()
            };

            await _spExecutor.Execute("dbo.spCommunication_Create", parameters);
        }

        private ProductCommunication Convert(IRowData row)
        {
            var communicationId = row.AsInt(CommunicationColumns.ID);
            var personId = row.AsInt(CommunicationColumns.PERSON_ID);
            var benefitId = row.AsInt(CommunicationColumns.BENEFIT_ID);
            var communicationDate = row.AsDateTime(CommunicationColumns.COMMUNICATION_DATE);
            var responseMethodId = row.AsInt(CommunicationColumns.CONTACT_METHOD_ID);
            var responseText = row.AsString(CommunicationColumns.RESPONSE_TEXT);
            var letterId = row.AsInt(CommunicationColumns.LETTER_ID);
            var taskId = row.AsInt(CommunicationColumns.TASK_ID);

            return new ProductCommunication(communicationId, new PersonId(personId), benefitId, communicationDate, responseMethodId, responseText, letterId, taskId);
        }
    }
}