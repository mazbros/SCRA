﻿using System;

namespace Scra.Model.ServiceMembers
{
    public class Dependent : IEntityId
    {
        public static Dependent Create(int personId)
        {
            return new Dependent {PersonId = personId};
        }

        public static Dependent Create(int id, int personId, DateTime? startDate, DateTime? endDate, int dependentTypeId)
        {
            return new Dependent
            {
                PersonId = personId,
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                DependentTypeId = dependentTypeId
            };
        }

        public int DependentTypeId { get; set; }
        public int Id { get; set; }
        public int PersonId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}