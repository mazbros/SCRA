﻿using System.Collections.Generic;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public class ServiceMemberFactory
    {
        public static ServiceMember Create(PersonId personId, PersonName name, IList<ActiveDuty> activeDuties)
        {
            return new ServiceMember(personId, name, activeDuties);
        }
    }
}
