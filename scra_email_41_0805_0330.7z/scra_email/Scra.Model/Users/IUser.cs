﻿namespace Scra.Model.Users
{
    public interface IUser
    {
        UserId Id { get; }
        string UserName { get; }
        bool IsAdmin { get; }
        UserType Type { get; set; }
        string DisplayName { get; }
    }
}