﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.Users
{
    public class UserList
    {
        private IReadOnlyCollection<User> _items;
        private IDictionary<int, User> _idNameMap;

        private UserList()
        {
        }

        public static UserList Create(IList<User> items)
        {
            return new UserList
            {
                _items = items.AsReadOnly(),
                _idNameMap = items.ToDictionary(x => x.Id.Value, x => x)
            };
        }

        public IReadOnlyCollection<User> All()
        {
            return _items.Where(x => x.IsActive).ToList();
        }

        public IReadOnlyCollection<User> AllNotReadOnly()
        {
            return _items.Where(x => x.IsActive && !x.Type.Equals(UserType.Guest)).ToList();
        }

        private static UserList _instance;
        public static async Task<UserList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<IUserRepository>();
                _instance = await repo.GetList();
            }
            return _instance;
        }

        public User Get(UserId userId)
        {
            return _idNameMap[userId.Value];
        }

        public IUser Empty()
        {
            return null;
        }
    }
}