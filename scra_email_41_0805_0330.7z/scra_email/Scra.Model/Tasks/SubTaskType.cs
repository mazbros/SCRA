﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Tasks
{
    public struct SubTaskType : IEquatable<SubTaskType>
    {
        public static readonly SubTaskType Empty = new SubTaskType("", "");
        public static readonly SubTaskType AcknowledgeInquiry = new SubTaskType("acknowledge_inquiry", "Acknowledge Inquiry");
        public static readonly SubTaskType LogRequest = new SubTaskType("log_request", "Log Request");
        public static readonly SubTaskType PersonDetails = new SubTaskType("person_details", "Person Details");
        public static readonly SubTaskType PersonDashboard = new SubTaskType("person_dashboard", "Person Dashboard");
        public static readonly SubTaskType MilitaryInformation = new SubTaskType("military_information", "Military Information");
        public static readonly SubTaskType ProductInformation = new SubTaskType("product_information", "Product Information");
        public static readonly SubTaskType Communication = new SubTaskType("communication", "Communication");

        public static readonly SubTaskType CreditCardDetail = new SubTaskType("creditCardDetail", "CreditCardDetail");
        public static readonly SubTaskType MortgageDetail = new SubTaskType("mortgageDetail", "MortgageDetail");
        public static readonly SubTaskType ConsumerLoanDetail = new SubTaskType("consumerLoanDetail", "ConsumerLoanDetail");
        public static readonly SubTaskType HomeEquityDetail = new SubTaskType("homeEquityDetail", "HomeEquityDetail");
        public static readonly SubTaskType CommercialLoanDetail = new SubTaskType("commercialLoanDetail", "CommercialLoanDetail");
        public static readonly SubTaskType OtherProductsDetail = new SubTaskType("otherProductsnDetail", "OtherProductsDetail");
        public static readonly SubTaskType ProductCommunication = new SubTaskType("productCommunication", "ProductCommunication");

        public static readonly SubTaskType Qa = new SubTaskType("qa", "QA");

        public static readonly IReadOnlyCollection<SubTaskType> List = new List<SubTaskType>
        {
            AcknowledgeInquiry, LogRequest, PersonDetails,PersonDashboard, ProductInformation, Communication, MilitaryInformation,
            CreditCardDetail, MortgageDetail, ConsumerLoanDetail,HomeEquityDetail, CommercialLoanDetail,ProductCommunication,Qa
        };

        private static readonly Dictionary<string, SubTaskType> Map = List.ToDictionary(x => x.Code, x => x);
        private readonly string _code;
        private readonly string _name;

        public string Name
        {
            get { return _name; }
        }
        public string Code
        {
            get { return _code; }
        }

        private SubTaskType(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static SubTaskType Parse(string code)
        {
            if (Map.ContainsKey(code))
            {
                return Map[code];
            }

            return Empty;
        }

        public override int GetHashCode()
        {
            return (_code != null ? _code.GetHashCode() : 0);
        }

        public bool Equals(SubTaskType other)
        {
            return _code == other._code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is SubTaskType))
            {
                return false;
            }
            return Equals((SubTaskType)obj);
        }

        public override string ToString()
        {
            return _code;
        }

        public static bool operator ==(SubTaskType obj1, SubTaskType obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(SubTaskType obj1, SubTaskType obj2)
        {
            return !(obj1 == obj2);
        }
    }
}