﻿using System;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    public class TaskSnapshot
    {
        public TaskSnapshot(int id, string title, TascStatus status, IUser assignee, IUser qaAssignee, DateTime? dueDate,
            DateTime? contactDate, DateTime createDate, bool isQaComplete, TaskType taskType, PersonId personId, string firstName, string lastName)
        {
            Id = id;
            Title = title;
            Status = status;
            Assignee = assignee;
            QaAssignee = qaAssignee;
            DueDate = dueDate;
            ContactDate = contactDate;
            CreateDate = createDate;
            IsQaComplete = isQaComplete;
            TaskType = taskType;
            PersonId = personId;
            ServicememberName = firstName + " " + lastName;
        }

        public int Id { get; private set; }
        public string Title { get; private set; }
        public TascStatus Status { get; private set; }
        public IUser Assignee { get; private set; }
        public IUser QaAssignee { get; private set; }
        public DateTime? DueDate { get; private set; }
        public DateTime? ContactDate { get; private set; }
        public DateTime CreateDate { get; private set; }
        public bool IsQaComplete { get; private set; }
        public TaskType TaskType { get; private set; }
        public PersonId PersonId { get; private set; }
        public string ServicememberName { get; set; }
        
        public Task<Tasc> GetFull()
        {
            var repo = Di.Get<ITaskRepository>();
            return repo.Get(Id);
        }

        public override string ToString()
        {
            return string.Format("{0} {1} {2}", Id, Assignee, QaAssignee);
        }
    }
}