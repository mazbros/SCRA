﻿using Scra.Model.DomainEvents;

namespace Scra.Model.Tasks
{
    public class TaskCompleteEvent : IDomainEvent
    {
        public Tasc Tasc { get; private set; }

        public TaskCompleteEvent(Tasc tasc)
        {
            Tasc = tasc;
        }

        public override string ToString()
        {
            return "TaskCompleteEvent TaskType=" + Tasc.Type.Code;
        }
    }
}
