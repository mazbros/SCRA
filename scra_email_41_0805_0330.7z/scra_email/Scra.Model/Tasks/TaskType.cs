﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Tasks
{
    public struct TaskType : IEquatable<TaskType>
    {
        private readonly string _code;
        private readonly string _name;
        
        public string Code
        {
            get { return _code; }
        }

        public string Name
        {
            get { return _name; }
        }

        public static readonly TaskType Empty = new TaskType("", "");
        public static readonly TaskType ALL = new TaskType("all", "All Request Types");
        public static readonly TaskType REQUEST_DMDC_CHECK = new TaskType("request_dmdc_check", "DMDC Validation");
        public static readonly TaskType REQUEST_AFFILIATE = new TaskType("request_affiliate", "Affiliate or Service By Other");
        public static readonly TaskType REQUEST_INQUIRY = new TaskType("request_inquiry", "Inquiry");
        public static readonly TaskType REQUEST_BENEFITS = new TaskType("request_benefits", "Benefit Intake and Eligibility Determination");

        public static readonly TaskType ADD_BENEFIT = new TaskType("add_benefit", "Add Benefit");
        public static readonly TaskType ADD_PROMOTIONAL_RATE = new TaskType("add_promotional_rate", "Add Promotional Rate");
        public static readonly TaskType REMOVE_PROMOTIONAL_RATE = new TaskType("remove_promotional_rate", "Remove Promotional Rate");
        public static readonly TaskType REMEDIATION_REIMBURSEMENT = new TaskType("remediation_reimbursement", "Remediation Reimbursement");

        public static readonly TaskType REMOVE_BENEFIT = new TaskType("remove_benefit", "Remove Benefit");
        public static readonly TaskType CONTACT_CUSTOMER = new TaskType("contact_customer", "Contact Customer");
        public static readonly TaskType EXTEND_BENEFIT = new TaskType("extend_benefit", "Extend Benefit");
        public static readonly TaskType DENY_BENEFIT = new TaskType("deny_benefit", "Deny Benefit");

        public static IReadOnlyCollection<TaskType> RequestTypeList = new List<TaskType> { Empty, REQUEST_DMDC_CHECK, REQUEST_AFFILIATE, REQUEST_INQUIRY, REQUEST_BENEFITS};

        private static readonly Dictionary<string, TaskType> Map = new[] { Empty, ALL, REQUEST_DMDC_CHECK, REQUEST_AFFILIATE, REQUEST_INQUIRY, REQUEST_BENEFITS, ADD_BENEFIT, ADD_PROMOTIONAL_RATE, REMOVE_PROMOTIONAL_RATE, REMEDIATION_REIMBURSEMENT, REMOVE_BENEFIT, CONTACT_CUSTOMER, EXTEND_BENEFIT, DENY_BENEFIT, }.ToDictionary(x => x.Code, x => x);

        public static TaskType Parse(string code)
        {
            TaskType type;
            if (code == null)
            {
                return Empty;
            }
            if (Map.TryGetValue(code, out type))
            {
                return type;
            }
            return Empty;
        }

        private TaskType(string code)
        {
            _code = code;
            _name = string.Empty;
        }



        private TaskType(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static TaskType Create(string code)
        {
            return new TaskType(code);
        }

        public static TaskType Create(string code, string name)
        {
            return new TaskType(code, name);
        }

        public override int GetHashCode()
        {
            return Code != null ? Code.GetHashCode() : 0;
        }

        public bool Equals(TaskType other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is TaskType))
            {
                return false;
            }
            return Equals((TaskType)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(TaskType obj1, TaskType obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(TaskType obj1, TaskType obj2)
        {
            return !(obj1 == obj2);
        }

        public static IList<TaskType> TaskTypeList()
        {
            return new List<TaskType>
            {
                ALL,
                REQUEST_DMDC_CHECK,
                REQUEST_AFFILIATE,
                REQUEST_INQUIRY,
                REQUEST_BENEFITS,
                ADD_BENEFIT,
                ADD_PROMOTIONAL_RATE,
                REMOVE_PROMOTIONAL_RATE,
                REMEDIATION_REIMBURSEMENT,
                REMOVE_BENEFIT,
                CONTACT_CUSTOMER,
                EXTEND_BENEFIT,
                DENY_BENEFIT
            };
        }
    } 
}