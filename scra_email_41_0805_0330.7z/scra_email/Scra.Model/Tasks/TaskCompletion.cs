﻿using System;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    public class TaskCompletion
    {
        public DateTime Time { get; private set; }
        public IUser User { get; private set; }

        public void Completed()
        {
            Time = DateTime.Now;
            User = Di.Get<IUser>();
        }

        public static TaskCompletion None
        {
            get { return new TaskCompletion(); }
        }

        public static TaskCompletion Create(DateTime time, IUser user)
        {
            return new TaskCompletion { Time = time, User = user};
        }
    }
}