﻿using System;
using Scra.Model.ContactMethods;
using Scra.Model.Persons;

namespace Scra.Model.History
{
    public class PersonEditHistory
    {
        public PersonId Id { get; set; }
        public PersonName Name { get; private set; }
        public Ssn Ssn { get; set; }
        public Address Address { get; set; }
        public PersonContacts Contacts { get; set; }
        public DateTime? Dob { get; set; }        
        public ContactMethod ContactMethod { get; set; }
        public FNumber FNumber { get; private set; }        

        public PersonEditHistory(PersonId id, PersonName name, Ssn ssn, Address address, ContactMethod contactMethod, PersonContacts contacts, DateTime? dob, FNumber fNumber)
        {
            Id = id;
            Name = name;
            Ssn = ssn;
            Address = address;
            ContactMethod = contactMethod;
            Contacts = contacts;
            Dob = dob;
            FNumber = fNumber;
        }
    }
}