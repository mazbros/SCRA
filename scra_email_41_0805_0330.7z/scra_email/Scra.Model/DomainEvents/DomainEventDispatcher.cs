﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Logs;

namespace Scra.Model.DomainEvents
{
    internal class DomainEventDispatcher : IDomainEventDispatcher
    {
        private readonly ILogger _logger;
        private readonly Dictionary<Type, IList<IDomainEventHandler>> _handlers;

        public DomainEventDispatcher(ILogger logger)
        {
            _logger = logger;
            _handlers = new Dictionary<Type, IList<IDomainEventHandler>>();
        }

        public async Task DispatchAsync(IDomainEvent domainEvent)
        {
            if (domainEvent == null)
            {
                return;
            }

            var type = domainEvent.GetType();
            IList<IDomainEventHandler> list;
            if (!_handlers.TryGetValue(type, out list))
            {
                throw new InvalidOperationException("There is no handlers for " + type.FullName);
            }

            foreach (var domainEventHandler in list)
            {
                try
                {
                    await domainEventHandler.HandleAsync(domainEvent);
                }
                catch (Exception ex)
                {
                    var handlerType = domainEventHandler.GetType().FullName;
                    var message = string.Format("Handler {0} failed to execute event {1}.", handlerType, domainEvent);
                    _logger.Error(ex, message);
                }
            }
        }

        public async Task DispatchAsync(IList<IDomainEvent> domainEvents)
        {
            foreach (var domainEvent in domainEvents)
            {
                await DispatchAsync(domainEvent);
            }
        }

        public async Task DispatchAsync(IDomainEventHolder holder)
        {
            var events = holder.DomainEvents.ToArray();
            holder.DomainEvents.Clear();

            await DispatchAsync(events);
        }

        public void Subscribe<T>(IDomainEventHandler handler) where  T : IDomainEvent
        {
            var eventType = typeof(T);

            IList<IDomainEventHandler> list;
            if (!_handlers.TryGetValue(eventType, out list))
            {
                list = new List<IDomainEventHandler>();
                _handlers.Add(eventType, list);
            }
            list.Add(handler);
        }
    }
}
