﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.BranchOfServices
{
    public class BranchOfServiceList
    {
        private IReadOnlyCollection<BranchOfService> _items;
        private IDictionary<int, BranchOfService> _idNameMap;

        private BranchOfServiceList()
        {
        }

        public static BranchOfServiceList Create(IList<BranchOfService> items)
        {
            return new BranchOfServiceList
            {
                _items = items.AsReadOnly(),
                _idNameMap = items.ToDictionary(x => x.Id, x => x)
            };
        }

        public IReadOnlyCollection<BranchOfService> All()
        {
            return _items;
        }

        public string GetName(int branchOfServiceId)
        {
            return _idNameMap[branchOfServiceId].Name;
        }

        private static BranchOfServiceList _instance;
        public static async Task<BranchOfServiceList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<IBranchOfServiceRepository>();
                _instance = await repo.GetList();
            }
            return _instance;
        }

        public BranchOfService Get(int branchOfServiceId)
        {
            return _idNameMap[branchOfServiceId];
        }
    }
}
