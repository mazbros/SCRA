﻿using System.Threading.Tasks;

namespace Scra.Model.BranchOfServices
{
    public interface IBranchOfServiceRepository
    {
        Task<BranchOfServiceList> GetList();
    }
}