﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.Inquiries
{
    public interface IInquiryRepository
    {
        Task<Inquiry> Get(int inquiryId);
        Task Create(Inquiry model);
        Task Update(Inquiry inquiry);
        Task UpdateTitle(Inquiry inquiry);
        Task<IList<InquirySnapshot>> Load(string search);
        Task<int> GetTaskByInquiry(int inquiryId);
        Task SetAcknowledge(int inquiryId, DateTime date);
        Task<IList<InquirySnapshot>> Sort(string searchText, string selectedHeaderName, string direction);
    }
}
