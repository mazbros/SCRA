﻿namespace Scra.Model.Inquiry
{
    internal interface IInquiryRepository
    {
    }
}