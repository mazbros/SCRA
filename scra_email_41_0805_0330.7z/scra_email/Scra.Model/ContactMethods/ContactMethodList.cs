﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.ContactMethods
{
    public class ContactMethodList
    {
        private IReadOnlyCollection<ContactMethod> _items;
        private IDictionary<int, ContactMethod> _idNameMap;
        private static ContactMethodList _instance;

        private ContactMethodList()
        {
        }

        public static ContactMethodList Create(IList<ContactMethod> items)
        {
            items.Insert(0,ContactMethod.Empty);
            return new ContactMethodList
            {
                _items = items.AsReadOnly(),
                _idNameMap = items.ToDictionary(x => x.Id, x => x)
            };
        }

        public IReadOnlyCollection<ContactMethod> All()
        {
            return _items;
        }

        public ContactMethod Get(int contactMethodId)
        {
            if (contactMethodId != 0)
            {
                return _idNameMap[contactMethodId];
            }

            return ContactMethod.Empty;
        }

        

        public static async Task<ContactMethodList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<IContactMethodRepository>();
                _instance = await repo.GetList();
            }
            
            return _instance;
        }

        public ContactMethod Default()
        {
            return _items.First();
        }

        public ContactMethod Empty()
        {
            return ContactMethod.Empty;
        }
    }
}