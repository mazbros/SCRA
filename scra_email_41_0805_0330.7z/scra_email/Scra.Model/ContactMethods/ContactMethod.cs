﻿namespace Scra.Model.ContactMethods
{
    public class ContactMethod
    {
        public int Id { get; set; }
        public string Name { get; set; }

        private ContactMethod()
        {
        }

        public static ContactMethod Create(int id, string name)
        {
            return new ContactMethod { Id = id, Name = name };
        }

        public static ContactMethod Create(string name)
        {
            return new ContactMethod { Name = name };
        }

        public static ContactMethod Empty = new ContactMethod();

        public bool IsEmpty()
        {
            return Id == 0;
        }
    }
}