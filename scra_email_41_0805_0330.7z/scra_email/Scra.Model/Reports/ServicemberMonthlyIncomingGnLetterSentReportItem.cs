﻿using System.ComponentModel;
using System.Data;
using Scra.Model.Persons;

namespace Scra.Model.Reports
{
    public class ServicememberMonthlyIncomingGnLetterSentReportItem
    {
        #region Properties
        [DisplayName("Communication ID")]
        public string CommunicationId { get; set; }

        [DisplayName("Date Of Contact")]
        public string DateOfContact { get; set; }

        [DisplayName("Method Of Notification")]
        public string MethodOfNotification { get; set; }

        [DisplayName("Date DMDC Search Performed")]
        public string DateDmdcSearchPerformed { get; set; }

        [DisplayName("Verify By SCRA Or Military Orders")]
        public string VerifyByScraOrMilOrders { get; set; }

        [DisplayName("Benefit Approved/Denied/Pending")]
        public string BenefitApprovedDeniedPending { get; set; }

        [DisplayName("Status Code")]
        public string StatusCode { get; set; }

        [DisplayName("Not Eligible Reason")]
        public string NotEligibleReason { get; set; }

        [DisplayName("Denial Reason")]
        public string DenialReason { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServiceMemberId { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstname { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Social Security Number")]
        public string SocialSecurityNumber { get; set; }

        [DisplayName("Date Benefits Applied")]
        public string DateBenefitsApplied { get; set; }

        [DisplayName("Benefits Applied Within 60 days of identification")]
        public string BenefitsAppliedWithin60Days { get; set; }

        [DisplayName("Date Benefits Ended")]
        public string DateBenefitsEnded { get; set; }

        [DisplayName("Benefits Effective Date")]
        public string BenefitsEffectiveDate { get; set; }

        [DisplayName("Comments")]
        public string Comments { get; set; }

        [DisplayName("Additional Comments")]
        public string AdditionalComments { get; set; }

        [DisplayName("Product Type")]
        public string ProductType { get; set; }

        [DisplayName("Product SubType")]
        public string SubType { get; set; }

        [DisplayName("Product Start Date")]
        public string StartDate { get; set; }

        [DisplayName("Product End date")]
        public string EndDate { get; set; }

        [DisplayName("FNumber")]
        public string FNumber { get; set; }

        [DisplayName("Branch Of Service")]
        public string BranchOfService { get; set; }

        [DisplayName("Notification Date")]
        public string DateMilitaryOrdersReceived { get; set; }

        [DisplayName("Account Number")]
        public string AccountNum { get; set; }

        [DisplayName("AD Start Date")]
        public string AdStartDate { get; set; }

        [DisplayName("AD End Date")]
        public string AdEndDate { get; set; }

        [DisplayName("Active Account Eligible")]
        public string ActiveAccountEligible { get; set; }

        [DisplayName("Address1")]
        public string Address1 { get; set; }

        [DisplayName("Address2")]
        public string Address2 { get; set; }

        [DisplayName("City")]
        public string City { get; set; }

        [DisplayName("State")]
        public string State { get; set; }

        [DisplayName("Zip")]
        public string Zip { get; set; }

        [DisplayName("Email")]
        public string Email { get; set; }

        [DisplayName("Benefits Received")]
        public string BenefitsReceived { get; set; }

        [DisplayName("Interest Rate Before SCRA")]
        public string InterestRateBeforeScra { get; set; }

        [DisplayName("Interest Adjustment")]
        public string InterestAdjustment { get; set; }

        [DisplayName("Refund Amount")]
        public string RefundAmount { get; set; }

        [DisplayName("Refund Date")]
        public string RefundDate { get; set; }

        [DisplayName("Letter ID")]
        public string LetterId { get; set; }

        [DisplayName("Date Sent")]
        public string DateSent { get; set; }

        [DisplayName("Returned")]
        public string Returned { get; set; }

        [DisplayName("Account")]
        public string Account { get; set; }

        [DisplayName("Letter Code")]
        public string LetterCode { get; set; }

        [DisplayName("Letter Name")]
        public string LetterName { get; set; }
        #endregion
        public static ServicememberMonthlyIncomingGnLetterSentReportItem Create(DataRow dr)
        {
            var item = new ServicememberMonthlyIncomingGnLetterSentReportItem
            {
                CommunicationId = dr["CommunicationID"].ToString(),
                DateOfContact = string.Format("{0:MM/dd/yyyy}", dr["DateOfContact"]),
                MethodOfNotification = dr["MethodOfNotification"].ToString(),
                DateDmdcSearchPerformed = string.Format("{0:MM/dd/yyyy}", dr["DateDMDCSearchPerformed"]),
                VerifyByScraOrMilOrders = dr["VerifyBySCRAOrMilOrders"].ToString(),
                BenefitApprovedDeniedPending = dr["BenefitApprovedDeniedPending"].ToString(),
                StatusCode = dr["StatusCode"].ToString(),
                NotEligibleReason = dr["NotEligReason"].ToString(),
                DenialReason = dr["DenialReason"].ToString(),
                ServiceMemberId = dr["ServiceMemberID"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                ServicememberFirstname = dr["ServicememberFirstname"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                SocialSecurityNumber = dr["SocialSecurityNumber"].ToString().Length > 0
                    ? dr["SocialSecurityNumber"].ToString() != Ssn.Empty().ToString() 
                        ? Ssn.Parse(dr["SocialSecurityNumber"].ToString()).GetDisplay()
                        : string.Empty
                    : dr["SocialSecurityNumber"].ToString(),
                DateBenefitsApplied = string.Format("{0:MM/dd/yyy}", dr["DateBenefitsApplied"]),
                BenefitsAppliedWithin60Days = dr["BenefitsAppliedWithin60Days"].ToString(),
                DateBenefitsEnded = string.Format("{0:MM/dd/yyy}", dr["DateBenefitsEnded"]),
                BenefitsEffectiveDate = string.Format("{0:MM/dd/yyy}", dr["Benefits Effective (as of) Date"]),
                Comments = dr["Comments"].ToString(),
                AdditionalComments = dr["AdditionalComments"].ToString(),
                ProductType = dr["ProductType"].ToString(),
                SubType = dr["SubType"].ToString(),
                AccountNum = dr["AccountNum"].ToString().Length > 0
                    ?  dr["AccountNum"].ToString().Length == 16
                        ? dr["AccountNum"].ToString().Substring(0, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(4, 4) + " " +
                          dr["AccountNum"].ToString().Substring(7, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(12, 4)
                        : dr["AccountNum"].ToString().Length >= 19
                            ? dr["AccountNum"].ToString().Substring(0, 9) + " " + 
                              dr["AccountNum"].ToString().Substring(9, 10)
                            : " " + dr["AccountNum"] + " "
                    : string.Empty,
                StartDate = string.Format("{0:MM/dd/yyy}", dr["StartDate"]),
                EndDate = string.Format("{0:MM/dd/yyy}", dr["EndDate"]),
                FNumber = dr["FNumber"].ToString(),
                BranchOfService = dr["BranchOfService"].ToString(),
                DateMilitaryOrdersReceived = string.Format("{0:MM/dd/yyyy}", dr["DateMilitaryOrdersReceived"]),
                AdStartDate = string.Format("{0:MM/dd/yyyy}", dr["ADStartDate"]),
                AdEndDate = string.Format("{0:MM/dd/yyy}", dr["ADEndDate"]),
                ActiveAccountEligible = dr["ActiveAccountEligible"].ToString(),
                Address1 = dr["Address1"].ToString(),
                Address2 = dr["Address2"].ToString(),
                City = dr["City"].ToString(),
                State = dr["State"].ToString(),
                Zip = dr["Zip"].ToString(),
                Email = dr["Email"].ToString(),
                BenefitsReceived = dr["BenefitsRecvd"].ToString(),

                InterestRateBeforeScra = dr["InterestRateBeforeScra"].ToString(),
                InterestAdjustment = dr["InterestAdjustment"].ToString(),
                RefundAmount = dr["RefundAmount"].ToString(),
                RefundDate = string.Format("{0:MM/dd/yyy}", dr["RefundDate"]),

                LetterId = dr["LetterID"].ToString(),
                DateSent = string.Format("{0:MM/dd/yyy}", dr["DateSent"]),
                Returned = dr["Returned"].ToString(),
                Account = dr["Account"].ToString(),
                LetterCode = dr["LetterCode"].ToString(),
                LetterName = dr["LetterName"].ToString()
            };

            return item;
        }
    }
}