﻿using System.ComponentModel;
using System.Data;
using Scra.Model.Persons;

namespace Scra.Model.Reports
{
    public class InquiriesReportItem
    {
        #region Properties
        [DisplayName("Status")]
        public string Status { get; set; }

        [DisplayName("Person Requesting First Name")]
        public string PersonRequestingFirstName { get; set; }

        [DisplayName("Person Requesting Last Name")]
        public string PersonRequestingLastName { get; set; }

        [DisplayName("Person Requesting Email")]
        public string PersonRequestingEmail { get; set; }

        [DisplayName("Person Requesting Phone")]
        public string PersonRequestingPhone { get; set; }

        [DisplayName("Person Requesting Address")]
        public string PersonRequestingAddress { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServicememberId { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstName { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Servicemember Email")]
        public string ServicememberEmail { get; set; }

        [DisplayName("Servicemember Phone")]
        public string ServicememberPhone { get; set; }

        [DisplayName("Servicemember Address")]
        public string ServicememberAddress { get; set; }

        [DisplayName("Servicemember If Different")]
        public string ServicememberIfDifferent { get; set; }

        [DisplayName("Relationship")]
        public string Relationship { get; set; }

        [DisplayName("Request Date")]
        public string RequestDate { get; set; }

        [DisplayName("Log Request Done")]
        public string LogRequestDone { get; set; }

        [DisplayName("Log Request Completed By")]
        public string LogRequestCompletedBy { get; set; }

        [DisplayName("Completed")]
        public string Completed { get; set; }

        [DisplayName("Response Date")]
        public string ResponseDate { get; set; }

        [DisplayName("Response Method")]
        public string ResponseMethod { get; set; }

        [DisplayName("Response Text")]
        public string ResponseText { get; set; }

         [DisplayName("Description")]
        public string Description { get; set; }

        [DisplayName("Comment")]
        public string Comment { get; set; }
        #endregion
        public static InquiriesReportItem Create(DataRow dr)
        {
            var item = new InquiriesReportItem
            {
                Status = dr["Status"].ToString(),

                PersonRequestingFirstName = dr["PersonRequestingFirstName"].ToString(),
                PersonRequestingLastName = dr["PersonRequestingLastName"].ToString(),
                PersonRequestingEmail = dr["PersonRequestingEmail"].ToString().ToLower(),
                PersonRequestingPhone = PhoneNumber.Parse(dr["PersonRequestingPhone"].ToString()).GetDisplay().Replace("000-000-0000", ""),
                PersonRequestingAddress = Address.Create(dr["PersonRequestingAddress1"].ToString(),
                    dr["PersonrequestingAddress2"].ToString(),
                    dr["PersonRequestingCity"].ToString(),
                    AddressState.Parse(dr["PersonRequestingState"].ToString()),
                    ZipCode.Parse(dr["PersonRequestingZip"].ToString())).GetFullOneLine(),

                ServicememberId = dr["ServicememberId"].ToString(),
                ServicememberFirstName = dr["ServicememberFirstName"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                ServicememberEmail = dr["ServicememberEmail"].ToString().ToLower(),
                ServicememberPhone = PhoneNumber.Parse(dr["ServicememberPhone"].ToString()).GetDisplay().Replace("000-000-0000",""),
                ServicememberAddress = Address.Create(dr["ServicememberAddress1"].ToString(),
                    dr["ServicememberAddress2"].ToString(),
                    dr["ServicememberCity"].ToString(),
                    AddressState.Parse(dr["ServicememberState"].ToString()),
                    ZipCode.Parse(dr["ServicememberZip"].ToString())).GetFullOneLine(),

                ServicememberIfDifferent = dr["ServicememberIfDifferent"].ToString(),
                Relationship = dr["Relationship"].ToString(),

                RequestDate = string.Format("{0:MM/dd/yyyy}", dr["RequestDate"]),
                LogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["LogRequestDone"]),
                LogRequestCompletedBy = dr["LogRequestCompletedBy"].ToString(),

                Description = dr["Description"].ToString(),
                Comment = dr["Comment"].ToString(),
                ResponseText = dr["ResponseText"].ToString(),
                ResponseDate = string.Format("{0:MM/dd/yyyy}", dr["ResponseDate"]),
                ResponseMethod = dr["ResponseMethod"].ToString(),
                
                Completed = dr["Completed"].ToString()

            };

            return item;
        }
    }
}