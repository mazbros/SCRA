﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class TaskStatusReportItem
    {
        #region Properties
        [DisplayName("Date")]
        public string Date { get; set; }

        [DisplayName("Task Type")]
        public string TaskType { get; set; }

        [DisplayName("In Process")]
        public string InProcess { get; set; }

        [DisplayName("Completed")]
        public string Completed { get; set; }

        [DisplayName("QA Completed")]
        public string QaCompleted { get; set; }

        [DisplayName("Rejected")]
        public string Rejected { get; set; }

        [DisplayName("Misdirected")]
        public string Misdirected { get; set; }

        [DisplayName("Total")]
        public string Total { get; set; }
        #endregion
        public static TaskStatusReportItem Create(DataRow dr)
        {
            var item = new TaskStatusReportItem
            {
                Date = string.Format("{0:MM/dd/yyyy}", dr["Date"]),
                TaskType = dr["Task Type"].ToString(),
                InProcess = dr["In Process"].ToString(),
                Completed = dr["Completed"].ToString(),
                QaCompleted = dr["QA Completed"].ToString(),
                Rejected = dr["Rejected"].ToString(),
                Misdirected = dr["Misdirected"].ToString(),
                Total = dr["Total"].ToString()
            };

            return item;
        }
    }
}