﻿using System.Threading.Tasks;

namespace Scra.Model.Contracts
{
    public interface IBenefitDetailRepository
    {
        Task<BenefitDetail> Get(int benefitId);
        Task<BenefitDetail> GetLastDetail(int benefitId);

        Task Save(BenefitDetail model);
    }
}