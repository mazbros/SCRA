﻿using System.Collections.Generic;
using System.Linq;
using Scra.Model.Extensions;

namespace Scra.Model.Contracts
{
    public class ContractSubCategoryList
    {
        private IReadOnlyCollection<ContractSubCategory> _items;


        private static IList<ContractSubCategory> ITEMS;

        private ContractSubCategoryList()
        {
        }

        public static ContractSubCategoryList Create(Dictionary<string, ContractSubCategory> map)
        {
            ITEMS = new List<ContractSubCategory>();
            foreach (var it in map.Values)
            {
                ITEMS.Add(new ContractSubCategory(it.Code, it.Name));
            }

            return new ContractSubCategoryList
            {
                _items = ITEMS.AsReadOnly()
            };
        }

        public IReadOnlyCollection<ContractSubCategory> All()
        {
            return _items;
        }
    }
}
