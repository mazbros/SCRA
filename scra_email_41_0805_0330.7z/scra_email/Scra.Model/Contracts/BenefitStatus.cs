﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Contracts
{
    public struct BenefitStatus : IEquatable<BenefitStatus>
    {
        private readonly string _code;
        private readonly string _name;

        public string Code
        {
            get { return _code; }
        }
        public string Name
        {
            get { return _name; }
        }
        public string Display
        {
            get { return Name; }
        }

        public static readonly BenefitStatus Empty = new BenefitStatus("", "");
        public static readonly BenefitStatus No = new BenefitStatus("no", "No Benefit");
        public static readonly BenefitStatus Applying = new BenefitStatus("applying", "Applying");
        public static readonly BenefitStatus Applied = new BenefitStatus("applied", "Applied");
        public static readonly BenefitStatus Extending = new BenefitStatus("extending", "Extending");
        public static readonly BenefitStatus Extended = new BenefitStatus("extended", "Extended");
        public static readonly BenefitStatus Removing = new BenefitStatus("removing", "Removing");
        public static readonly BenefitStatus Removed = new BenefitStatus("removed", "Removed");
        public static readonly BenefitStatus Denying = new BenefitStatus("denying", "Denying");
        public static readonly BenefitStatus Denied = new BenefitStatus("denied", "Denied");

        private static readonly Dictionary<string, BenefitStatus> Map = new[] {No, Applying, Applied, Extending, Extended, Removing, Removed, Denying, Denied }.ToDictionary(x => x.Code, x => x);

        private BenefitStatus(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static BenefitStatus Parse(string code)
        {
            BenefitStatus status;
            if (code == null)
            {
                return Empty;
            }
            if (Map.TryGetValue(code, out status))
            {
                return status;
            }            
            return Empty;
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public bool Equals(BenefitStatus other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is BenefitStatus))
            {
                return false;
            }
            return Equals((BenefitStatus)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(BenefitStatus obj1, BenefitStatus obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(BenefitStatus obj1, BenefitStatus obj2)
        {
            return !(obj1 == obj2);
        }
    }
}