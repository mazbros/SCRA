﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.Contracts
{
    public class ContractType
    {
        public int Id { get; private set; }
        public ContractCategory Category { get; private set; }
        public string Name { get; private set; }

        public ContractType(int id, ContractCategory category, string name)
        {
            Id = id;
            Category = category;
            Name = name;
        }
    }

    public interface IContractTypeRepository
    {
        Task<IList<ContractType>> Load(ContractCategory category);
    }
}