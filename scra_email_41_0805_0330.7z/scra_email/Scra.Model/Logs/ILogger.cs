﻿using System;

namespace Scra.Model.Logs
{
    public interface ILogger
    {
        void Error(Exception e);
        void Error(Exception e, string message);
        void Error(string message);

        void Warning(string message);
        void Warning(Exception e, string message);

        void Debug(string message);

        void Close();
    }
}
