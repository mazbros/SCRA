﻿using System;

namespace Scra.Model.Files
{
    public class FileAttachmentSnapshot
    {
        public FileAttachmentSnapshot(int id, string fileName, DateTime? modifiedDate)
        {
            Id = id;
            FileName = fileName;
            ModifiedDate = modifiedDate;
        }

        public int Id { get; private set; }
        public string FileName { get; private set; }
        public DateTime? ModifiedDate { get; private set; }
    }
}