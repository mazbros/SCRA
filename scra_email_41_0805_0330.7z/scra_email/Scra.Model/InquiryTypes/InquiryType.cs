﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Extensions;
using Scra.Model.Tasks;

namespace Scra.Model.InquiryTypes
{
    public struct InquiryType : IEquatable<InquiryType>
    {
        public static readonly InquiryType EMPTY = new InquiryType("", "");
        public static readonly InquiryType DMDC_CHECK = new InquiryType("dmdc_check", "DMDC Validation");
        public static readonly InquiryType AFFILIATE = new InquiryType("affiliate", "Affiliate or Service By Other");
        public static readonly InquiryType INQUIRY = new InquiryType("inquiry", "Inquiries");
        public static readonly InquiryType BENEFIT_REQUEST = new InquiryType("benefit_request", "Benefit Intake and eligibility determination");
        public static IReadOnlyCollection<InquiryType> InquiryTypeList = new List<InquiryType> { DMDC_CHECK, AFFILIATE, INQUIRY, BENEFIT_REQUEST };

        //public static readonly IReadOnlyCollection<TaskType> TaskTypeList = new List<TaskType>
        //{
        //    TaskType.REQUEST_DMDC_CHECK,
        //    TaskType.REQUEST_AFFILIATE,
        //    TaskType.REQUEST_INQUIRY,
        //    TaskType.REQUEST_BENEFITS
        //};

        private static readonly Dictionary<string, InquiryType> Map = InquiryTypeList.ToDictionary(x => x.Code, x => x);
        //private static Dictionary<InquiryType, TaskType> _requestTaskPare = new Dictionary<InquiryType, TaskType>();

        private readonly string _code;
        private readonly string _name;

        public string Name
        {
            get { return _name; }
        }
        public string Code
        {
            get { return _code; }
        }

        private InquiryType(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static TaskType ToTaskType(InquiryType type)
        {
            var inquiryTypeList = new List<InquiryType> { DMDC_CHECK, AFFILIATE, INQUIRY, BENEFIT_REQUEST };
            var taskTypeList = new List<TaskType>{TaskType.REQUEST_DMDC_CHECK,TaskType.REQUEST_AFFILIATE,TaskType.REQUEST_INQUIRY,TaskType.REQUEST_BENEFITS};

            var requestTaskPair = new Dictionary<InquiryType, TaskType>();

            for (var i = 0; i < inquiryTypeList.Count; i++)
            {
                requestTaskPair.Add(inquiryTypeList[i], taskTypeList[i]);
            }

            return requestTaskPair[type];
        }

        public static InquiryType Parse(string code)
        {
            if (Map.ContainsKey(code))
            {
                return Map[code];
            }
            
            return EMPTY;
        }

        public bool IsEmpty()
        {
            return _code.IsEmpty();
        }

        public override int GetHashCode()
        {
            return (_code != null ? _code.GetHashCode() : 0);
        }

        public bool Equals(InquiryType other)
        {
            return _code == other._code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is InquiryType))
            {
                return false;
            }
            return Equals((InquiryType)obj);
        }

        public override string ToString()
        {
            return _code;
        }

        public static bool operator ==(InquiryType obj1, InquiryType obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(InquiryType obj1, InquiryType obj2)
        {
            return !(obj1 == obj2);
        }
    }
}
