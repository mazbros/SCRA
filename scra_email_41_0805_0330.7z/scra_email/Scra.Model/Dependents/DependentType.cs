﻿namespace Scra.Model.Dependents
{
    public class DependentType
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public static readonly DependentType Empty = new DependentType();

        private DependentType()
        {
        }

        public static DependentType Create(int id, string name)
        {
            return new DependentType { Id = id, Name = name };
        }
    }
}