﻿using System.Threading.Tasks;

namespace Scra.Model.Letters
{
    public interface ILetterTemplate
    {
        Task LoadTemplate(int letterNumber);
        Task<Letter> Generate(Letter letter, object argument);
        string Content { get; set; }
    }
}