﻿using System.Threading.Tasks;
using Scra.Model.Communication;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Model.Letters
{
    public class IneligibleTemplate : ILetterTemplate
    {
        private readonly ILetterRepository _letterRepository;
        public PersonId PersonId { get; set; }
        public string Content { get; set; }

        public IneligibleTemplate()
        {
            _letterRepository = Di.Get<ILetterRepository>();
        }

        public static IneligibleTemplate Create()
        {
            return new IneligibleTemplate();
        }

        public async Task LoadTemplate(int letterNumber)
        {
            Content = await _letterRepository.LoadTemplate(letterNumber);
        }

        public async Task<Letter> Generate(Letter letter, object argument)
        {
            var personId = ((ProductCommunication)argument).PersonId;
            Content = await LetterUtilities.ParsePersonalInformation(personId, Content);
            return letter;
        }
    }
}