﻿using System;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Model.Letters
{
    public class LetterUtilities
    {
        public static async Task<string> ParsePersonalInformation(PersonId id, string content)
        {
            var personRepository = Di.Get<IPersonRepository>();
            var user = Di.Get<IUser>();

            var username = user.DisplayName;
            var model = await personRepository.Get(id);

            var address1 = model.Address.Address1;
            var address2 = model.Address.Address2.IsEmpty() ? model.Address.City + ", " + model.Address.State + " " + model.Address.ZipCode.GetDisplay() : model.Address.Address2;
            var address3 = model.Address.Address2.IsNotEmpty() ? model.Address.City + ", " + model.Address.State + " " + model.Address.ZipCode.GetDisplay() : null;


            var date = DateTime.Now.ToString("MMMM dd, yyyy");
            return content
                .Replace("__Name", model.Name.FullName)                
                .Replace("__Address1", address1)
                .Replace("__Address2", address2)
                .Replace("__Address3", address3)
                .Replace("__Date", date)                
                .Replace("__SCRAAgent", username);
        }
    }
}