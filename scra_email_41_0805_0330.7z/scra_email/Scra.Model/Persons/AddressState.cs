﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public struct AddressState : IEquatable<AddressState>
    {
        public static readonly AddressState Empty = new AddressState("", "");
        public static readonly IReadOnlyCollection<AddressState> List = new List<AddressState> 
        { 
            new AddressState("AL", "Alabama"),
            new AddressState("AK", "Alaska"),
            new AddressState("AZ", "Arizona"),
            new AddressState("AR", "Arkansas"),
            new AddressState("CA", "California"),
            new AddressState("CO", "Colorado"),
            new AddressState("CT", "Connecticut"),
            new AddressState("DE", "Delaware"),
            new AddressState("DC", "District Of Columbia"),
            new AddressState("FL", "Florida"),
            new AddressState("GA", "Georgia"),
            new AddressState("HI", "Hawaii"),
            new AddressState("ID", "Idaho"),
            new AddressState("IL", "Illinois"),
            new AddressState("IN", "Indiana"),
            new AddressState("IA", "Iowa"),
            new AddressState("KS", "Kansas"),
            new AddressState("KY", "Kentucky"),
            new AddressState("LA", "Louisiana"),
            new AddressState("ME", "Maine"),
            new AddressState("MD", "Maryland"),
            new AddressState("MA", "Massachusetts"),
            new AddressState("MI", "Michigan"),
            new AddressState("MN", "Minnesota"),
            new AddressState("MS", "Mississippi"),
            new AddressState("MO", "Missouri"),
            new AddressState("MT", "Montana"),
            new AddressState("NE", "Nebraska"),
            new AddressState("NV", "Nevada"),
            new AddressState("NH", "New Hampshire"),
            new AddressState("NJ", "New Jersey"),
            new AddressState("NM", "New Mexico"),
            new AddressState("NY", "New York"),
            new AddressState("NC", "North Carolina"),
            new AddressState("ND", "North Dakota"),
            new AddressState("OH", "Ohio"),
            new AddressState("OK", "Oklahoma"),
            new AddressState("OR", "Oregon"),
            new AddressState("PA", "Pennsylvania"),
            new AddressState("RI", "Rhode Island"),
            new AddressState("SC", "South Carolina"),
            new AddressState("SD", "South Dakota"),
            new AddressState("TN", "Tennessee"),
            new AddressState("TX", "Texas"),
            new AddressState("UT", "Utah"),
            new AddressState("VT", "Vermont"),
            new AddressState("VA", "Virginia"),
            new AddressState("WA", "Washington"),
            new AddressState("WV", "West Virginia"),
            new AddressState("WI", "Wisconsin"),
            new AddressState("WY", "Wyoming"),
        };

        private static readonly Dictionary<string, AddressState> Map = List.ToDictionary(x => x.Abbreviation, x => x);
        private readonly string _abbreviation;
        private readonly string _name;

        public string Name
        {
            get { return _name; }
        }
        public string Abbreviation
        {
            get { return _abbreviation; }
        }

        public AddressState(string abbreviation, string name)
        {
            _abbreviation = abbreviation;
            _name = name;
        }

        public static AddressState Parse(string abbreviation)
        {
            if (abbreviation == null) return Empty;
            if (Map.ContainsKey(abbreviation))
            {
                return Map[abbreviation];
            }

            return Empty;
        }

        public bool IsEmpty()
        {
            return _abbreviation.IsEmpty();
        }

        public override int GetHashCode()
        {
            return (_abbreviation != null ? _abbreviation.GetHashCode() : 0);
        }

        public bool Equals(AddressState other)
        {
            return _abbreviation == other._abbreviation;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is AddressState))
            {
                return false;
            }
            return Equals((AddressState)obj);
        }

        public override string ToString()
        {
            return _abbreviation;
        }

        public static bool operator ==(AddressState obj1, AddressState obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(AddressState obj1, AddressState obj2)
        {
            return !(obj1 == obj2);
        }
        
        
    }
}
