﻿using System;
using Scra.Model.InquiryTypes;


namespace Scra.Model.Persons
{
    public class PersonSnapshot
    {
        public PersonId Id { get; set; }
        public PersonName Name { get; set; }
        public Address Address { get; set; }
        public Ssn Ssn { get; set; }
        public FNumber FNumber { get; private set; }
        public InquiryType Origin { get; set; }
        public DateTime? Timestamp { get; set; }

        public string FullName { get; set; }

        public PersonSnapshot(PersonId id, FNumber fNumber)
        {
            Id = id;
            FNumber = fNumber;
        }

        public PersonSnapshot(PersonId id, PersonName name)
        {
            Id = id;
            Name = name;
            FullName = name.FullName;
        }

        public PersonSnapshot(PersonId id, PersonName name, InquiryType origin)
        {
            Id = id;
            Name = name;
            Origin = origin;
        }

        public PersonSnapshot(PersonId id, PersonName name, DateTime timestamp)
        {
            Id = id;
            Name = name;
            Timestamp = timestamp;
        }
    }
}