﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Dependents;

namespace Scra.Model.Persons
{
    public interface IPersonRepository
    {
        Task Save(Person person, bool updateContracts=false );
        Task<Person> SavePerson(Person person, bool updateContracts = false);
        Task<Person> Get(PersonId personId);
        Task<IList<PersonSnapshot>> Load(string search);
        Task<IList<PersonSnapshot>> LoadAll(string search);
        Task<IList<Person>> LoadWithParameter(Person person);

        Task Save(DependentLink link);

        Task<Person> RemoteGet(Ssn ssn, FNumber fNumber);
        Task<IList<PersonSnapshot>> Sort(string search, string selectedHeaderName, string direction);

        Task<IList<Person>> LoadEditHistoryByPerson(int id, DateTime? timestamp);
    }
}
