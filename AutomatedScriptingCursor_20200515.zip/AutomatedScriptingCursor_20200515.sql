DECLARE Scripting CURSOR
READ_ONLY
FOR 
SELECT DISTINCT sysobjects.ID
FROM sysobjects,syscomments 
WHERE sysobjects.id = syscomments.id and sysobjects.type IN ('P') AND sysobjects.category = 0
--AND sysobjects.ID NOT IN (1634208972,1666209086,1682209143,1618208915,1602208858,1586208801,1570208744,1907641989,1827641704,1584164839,1600164896)
AND sysobjects.name NOT IN ('sp_upgraddiagrams','sp_helpdiagrams','sp_helpdiagramdefinition','sp_creatediagram','p_renamediagram','sp_alterdiagram','sp_dropdiagram')
AND sysobjects.name NOT LIKE '%Servicemember%'
AND sysobjects.name NOT LIKE '%_obsolete%'
AND sysobjects.name NOT like '%_old%'
AND sysobjects.name NOT like '%Weekly%Report%'
AND sysobjects.name NOT like '%v21%'
AND sysobjects.name NOT IN ('spTaskStatus_Report','spViewLetterHistory_Report','sp30DaysList_Report')
--AND sysobjects.ID  IN (693577509,661577395,709577566,645577338,629577281,677577452,533576939)
--ORDER BY sysobjects.name,syscomments.colid

DECLARE @ID as bigint
OPEN Scripting

CREATE TABLE Temp 
(
 [Name] varchar(255),
 [ID] INT,
 [Text] varchar(max)
)

FETCH NEXT FROM Scripting INTO @ID
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN

		DECLARE Scripting2 CURSOR
		READ_ONLY
		FOR 
		SELECT DISTINCT syscomments.colid,sysobjects.name,syscomments.[text]
		FROM sysobjects,syscomments 
		WHERE sysobjects.id = syscomments.id and sysobjects.type IN ('P') AND sysobjects.category = 0 and sysobjects.ID = @ID
		ORDER BY sysobjects.name,syscomments.colid

		DECLARE @colid int,@name varchar(255),@text varchar(max)

		--DECLARE @objFileSystem int, @objTextStream int, @PathAndFile varchar(255),@objErrorObject int,@strErrorMessage varchar(1000),@hr int
		--SET @PathAndFile = 'F:\WizData\Projects\SCRA\SQL\Reports\TEST\'+@name
		--SET @PathAndFile = 'H:\SCRA\Reports\TEST\'+@name
		--SET @PathAndFile = '\\CpkUsr01\x381108$\SCRA\Reports\TEST\'+@name
		--SET @PathAndFile = '\\DataSet1\CBL\WizData\Projects\SCRA\SQL\Reports\TEST\'+@name

		--EXEC sp_configure 'show advanced options', 1;
		--RECONFIGURE
		--EXEC sp_configure 'Ole Automation Procedures',1;
		--RECONFIGURE

		OPEN Scripting2
		
		FETCH NEXT FROM Scripting2 INTO  @colid,@name,@text

		--PRINT @name
		
		--EXECUTE @hr = sp_OACreate 'Scripting.FileSystemObject', @objFileSystem OUT
		--IF @hr = 0 SELECT @objErrorObject = @objFileSystem, @strErrorMessage = 'Creating file: "' + @PathAndFile + '"'
		--IF @hr = 0 EXECUTE sp_OAMethod @objFileSystem, 'CreateTextFile', @objTextStream OUT,@PathAndFile,2,True

		WHILE (@@fetch_status <> -1)
		BEGIN

			IF (@@fetch_status <> -2)
			BEGIN
				--SELECT @name, @colid, @text
				--PRINT CAST(@colid as varchar(3)) + char(9) +@name

				SET NOCOUNT ON;

				INSERT INTO Temp ([name],[ID],[Text]) VALUES (@name,@colid,@text)

				--IF LEN(@text) > 0 BEGIN
				--	IF @hr = 0 SELECT @objErrorObject = @objTextStream, @strErrorMessage = 'Writing to a file: "' + @PathAndFile + '"'
				--	IF @hr = 0 EXECUTE sp_OAMethod @objTextStream, 'Write', NULL, @text
				--END
			END

		FETCH NEXT FROM Scripting2 INTO  @colid,@name,@text
		END
		
		--IF @hr = 0 SELECT @objErrorObject = @objTextStream, @strErrorMessage = 'Closing the file: "' + @PathAndFile + '"'
		--IF @hr = 0 EXECUTE sp_OAMethod	@objTextStream, 'Close'
		
		--IF @hr <> 0 BEGIN
		--	DECLARE @Source varchar(255),@Description varchar(255),@Helpfile varchar(255),@Helpid int
		--	EXECUTE sp_OAGetErrorInfo @objErrorObject, @Source	OUTPUT, @Description OUTPUT, @Helpid OUTPUT
		--	SELECT @strErrorMessage = 'Error while ' + coalesce(@strErrorMessage, 'doing something') + ', ' + coalesce(@Description,'')
		--	RAISERROR	(@strErrorMessage,16,1)
		--END
		
		--EXECUTE sp_OADestroy @objTextStream
		--EXECUTE sp_OADestroy @objFileSystem

		CLOSE Scripting2

		--EXEC sp_configure 'Ole Automation Procedures',0;
		--RECONFIGURE
		--EXEC sp_configure 'show advanced options', 0;
		--RECONFIGURE

		DEALLOCATE Scripting2
	
	FETCH NEXT FROM Scripting INTO @ID
	END
END

CLOSE Scripting
DEALLOCATE Scripting

--SELECT * FROM Temp ORDER BY [Name],[ID]

--/*SELECT STUFF((*/SELECT '' + cast([Text] as varchar(max)) FROM Temp WHERE [Name] = 'spAffiliate_EXL_Report'  ORDER BY [ID] for xml path('')/*),1,2)*/ 

CREATE TABLE Temp2
(
 [Name] varchar(255),
 [Text] text
)

INSERT INTO Temp2 ([Name],[Text]) SELECT DISTINCT [Name],(SELECT REPLACE(STUFF((SELECT '' + cast([Text] as varchar(max)) FROM Temp WHERE [Name] = t.[Name] ORDER BY [ID] for xml path('')),1,0,''),'&#x0D;','') ) FROM Temp t

DROP TABLE Temp

SELECT * FROM Temp2

DROP TABLE Temp2


