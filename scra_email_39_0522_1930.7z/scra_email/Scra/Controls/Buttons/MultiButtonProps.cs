﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Extensions;

namespace Scra.Controls.Buttons
{
    public class MultiButtonProps : ControlViewModel
    {
        private ObservableCollection<Item> _items;

        public MultiButtonProps()
        {
            Items = new ObservableCollection<Item>();
        }

        public MultiButtonProps(IEnumerable<Item> items)
        {
            Items = new ObservableCollection<Item>();
            Items.Update(items);
        }

        public ObservableCollection<Item> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public class Item
        {
            public Item(string name, Action action)
            {
                Name = name;
                Command = new Command(action);
            }

            public string Name { get; private set; }

            public ICommand Command { get; private set; }
        }
    }
}
