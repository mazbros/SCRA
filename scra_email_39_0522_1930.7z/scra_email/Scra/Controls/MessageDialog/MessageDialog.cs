﻿using System;
using System.ComponentModel;
using System.Windows;
using Scra.Localization;
using Scra.Model.Exceptions;
using Scra.Model.Logs;
using Scra.Tools;

namespace Scra.Controls.MessageDialog
{
    public class MessageDialog : IMessageDialog
    {
        private readonly IUiThread _uiThread;
        private readonly ILogger _logger;

        public MessageDialog(IUiThread uiThread, ILogger logger)
        {
            _uiThread = uiThread;
            _logger = logger;
        }

        public void Error(Exception ex, MessageDialogImage image)
        {
            _logger.Error(ex);
            var message = GetMessageFromException(ex);
            _uiThread.Execute(() => MessageDialogView.Show(message, MessageBoxButton.OK, image));
        }

        public void Error(Exception ex, string message)
        {
            _logger.Error(ex);
            message = GetMessageFromException(ex, message);
            _uiThread.Execute(() => MessageDialogView.Show(message, MessageBoxButton.OK, MessageDialogImage.Error));
        }

        public void Warning(string message)
        {
            Warning(message, false);
        }

        public void Warning(string message, bool skipLogging)
        {
            if (!skipLogging)
            {
                _logger.Warning(message);
            }

            _uiThread.Execute(() => MessageDialogView.Show(message, MessageBoxButton.OK, MessageDialogImage.Warning));
        }

        public void Warning(UserException ex)
        {
            _uiThread.Execute(() => MessageDialogView.Show(ex.Message, MessageBoxButton.OK, MessageDialogImage.Warning));
        }

        public MessageBoxResult Confirmation(string message)
        {
            //_uiThread.Execute(() => MessageDialogView.Show(message, MessageBoxButton.YesNo, MessageDialogImage.Question));
            var x = MessageDialogView.Show(message, MessageBoxButton.YesNoCancel, MessageDialogImage.Question);
            return x ;
        }

        public MessageBoxResult ConfirmationBinary(string message)
        {
            var x = MessageDialogView.Show(message, MessageBoxButton.YesNo, MessageDialogImage.Question);
            return x;
        }

        private string GetMessageFromException(Exception e, string message = null)
        {
            message = message ?? Lang.Error.UnexpectedError;

            if (e == null)
            {
                return message;
            }

            while (e is AggregateException && e.InnerException != null)
            {
                e = e.InnerException;
            }
            if (e is WarningException || e is UserException || e is AppException)
            {
                return e.Message;
            }
            return message;
        }
    }
}