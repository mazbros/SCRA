﻿using System.ComponentModel;
using System.Configuration;

namespace Scra.Configs
{
    public class AppConfigFileReader
    {
        public string Get(string name)
        {
            var value = ConfigurationManager.AppSettings[name];
            if (value == null)
            {
                var message = string.Format("Parameter '{0}' is absent. Open *.exe.config file and add following: '<add key=\"{0}\" value=\"\" />' in section 'appSettings'.", name);
                throw new WarningException(message);
            }
            return value;
        }

        public string GetConnectionString(string name)
        {
            var item = ConfigurationManager.ConnectionStrings[name];
            if (item == null)
            {
                var message = string.Format("Connection string '{0}' is absent. Add '{0}' connection string into *.exe.config file.", name);
                throw new WarningException(message);
            }
            return item.ConnectionString;
        }
    }
}
