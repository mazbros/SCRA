﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scra.State
{
    public class ModifiedPersonAct : IAct
    {
        public string Code
        {
            get { return Act.SHOW_PERSON; }
        }

        public object Argument { get; set; }

        public ModifiedPersonAct()
        {
            
        }

    }
}
