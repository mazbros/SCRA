﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scra.State
{
    public class CloseLeftPanelAct: IAct
    {

        public string Code
        {
            get { return Act.CLOSE_LEFT_PANEL; }
        }

        public object Argument { get; set; }

        public CloseLeftPanelAct()
        {

        }
    }
}
