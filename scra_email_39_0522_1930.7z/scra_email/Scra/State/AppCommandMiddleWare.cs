﻿using Scra.Model.Logs;
using Scra.Tools.Logs;

namespace Scra.State
{
    public class AppCommandMiddleWare : CommandMiddleware<AppState>
    {
        public AppCommandMiddleWare(ILogger logger) : 
            base(logger)
        {
        }
    }
}