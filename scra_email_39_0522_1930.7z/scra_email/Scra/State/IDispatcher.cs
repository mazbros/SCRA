﻿using System.Threading.Tasks;

namespace Scra.State
{
    public interface IDispatcher
    {
        void Dispatch(string act);
        void Dispatch(IAct act);
        Task DispatchAsync(string act);
        Task DispatchAsync(IAct act);
    }
}
