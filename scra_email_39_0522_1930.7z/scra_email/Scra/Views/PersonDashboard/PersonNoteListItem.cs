﻿using Scra.Controls;
using Scra.Model.Persons;

namespace Scra.Views.PersonDashboard
{
    public class PersonNoteListItem
    {
        public static PersonNoteListItem Create(PersonNote note)
        {
            return new PersonNoteListItem
            {
                Text = note.Text,
                ModifiedTime = Formatter.Date(note.ModifiedTime),
                ModifiedByName = note.ModifiedByName
            };
        }

        public string ModifiedByName { get; set; }
        public string ModifiedTime { get; set; }
        public string Text { get; set; }
    }
}