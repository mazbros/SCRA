﻿namespace Scra.Views.PersonDashboard
{
    public partial class DependentsWidget
    {
        public DependentsWidget()
        {
            InitializeComponent();
        }

        public DependentsWidgetModel GetViewModel()
        {
            return (DependentsWidgetModel)DataContext;
        }
    }
}
