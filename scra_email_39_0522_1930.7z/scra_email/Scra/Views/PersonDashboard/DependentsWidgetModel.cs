﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.PersonDashboard
{
    public class DependentsWidgetModel : BaseViewModel
    {
        private readonly AppNavigator _navigator;
        private Person _person;

        public DependentsWidgetModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            AddOrEditCommand = new Command(AddOrEdit);
            
            Dependents = new ObservableCollection<DependentListItem>();
        }

        private void GotoSelectedDependent(PersonId dependent)
        {
            _navigator.PersonDashboard(dependent);
        }

        public ICommand DoubleClickDependent { get; set; }
        public ICommand AddOrEditCommand { get; set; }
        public ObservableCollection<DependentListItem> Dependents { get; set; }

        public async Task Load(Person person)
        {
            _person = person;

            var vms = new List<DependentListItem>();

            foreach (var link in person.DependentLinks)
            {
                var dependent = await link.GetDependent();
                var psrsonId = dependent.Id;
                
                vms.Add(DependentListItem.Create(link, dependent, GotoSelectedDependent));
            }

            Dependents.Update(vms);
        }

        private void AddOrEdit()
        {
            _navigator.Dependents(_person.Id);
        }
    }
}
