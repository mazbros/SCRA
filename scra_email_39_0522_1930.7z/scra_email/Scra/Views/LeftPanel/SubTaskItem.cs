﻿using Scra.Model.Tasks;

namespace Scra.Views.LeftPanel
{
    public class SubTaskItem
    {
        public string Title { get; set; }
        public bool IsVisible { get; set; }
        public bool IsRejected { get; set; }
        public SubTaskType SubTaskType { get; set; }

        public static SubTaskItem Create(SubTask item)
        {
            return new SubTaskItem
            {
                Title = item.ItemId + ". " + item.Title,
                IsRejected = item.Status == SubTaskStatus.Rejected
            };
        }

        public static SubTaskItem CreateCurrent(SubTask item)
        {
            if (item == null)
            {
                return new SubTaskItem {IsVisible = false};
            }

            return new SubTaskItem
            {
                Title = item.ItemId + ". " + item.Title,
                IsVisible = true,
                SubTaskType = item.Type,
                IsRejected = item.Status == SubTaskStatus.Rejected
            };
        }
    }
}
