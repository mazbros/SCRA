﻿using System.Windows.Forms.VisualStyles;
using System.Windows.Input;

namespace Scra.Views.LeftPanel
{
    public partial class LeftView
    {
        public LeftView()
        {
            InitializeComponent();
        }
    }
}
