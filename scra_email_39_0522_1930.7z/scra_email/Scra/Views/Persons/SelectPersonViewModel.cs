﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.Persons
{
    public class SelectPersonViewModel : BaseViewModel
    {
        private readonly IPersonRepository _repository;
        private IList<PersonListItem> _items;
        private PersonListItem _selectedPerson;
        private string _searchText;
        private Action _successAction;
        private AppNavigator _navigator;

        public SelectPersonViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            _repository = Di.Get<IPersonRepository>();
            OnViewLoaded = OnLoaded;
            AddCommand = new Command(AddPerson);
            SelectPersonCommand = new Command(SelectPerson);
            SearchCommand = new Command(Search);
            CancelCommand = new Command(Cancel);
            OnViewClosed = OnClosed;
        }

        public ICommand SelectPersonCommand { get; set; }
        public ICommand SearchCommand { get; set; }
        public ICommand AddCommand { set; get; }
        public ICommand CancelCommand { get; set; }

        public string SearchText
        {
            get { return _searchText; }
            set { SetProperty(ref _searchText, value); }
        }

        public IList<PersonListItem> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public PersonListItem SelectedPerson
        {
            get { return _selectedPerson; }
            set { SetProperty(ref _selectedPerson, value); }
        }
        
        private async void Search()
        {
            await ReloadList();
        }

        private void Cancel()
        {
            CloseView();
        }

        private void OnClosed()
        {
            if (_successAction == null)
            {
                return;
            }
            _successAction();
        }

        private async void AddPerson()
        {
            _navigator.AddPerson();
            await ReloadList();
        }

        private void SelectPerson()
        {
            if (_selectedPerson == null)
            {
                return;
            }

            var args = (SelectPersonArgs) Arguments;
            _successAction = () => args.OnSuccess(_selectedPerson.Id);

            CloseView();
        }

        private async void OnLoaded()
        {
            await ReloadList();
        }

        private async Task ReloadList()
        {
            var models = await _repository.Load(SearchText);
            Items = models.Select(PersonListItem.Create).ToList();
        }
    }
}
