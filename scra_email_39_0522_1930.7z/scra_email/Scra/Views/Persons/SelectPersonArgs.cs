﻿using System;
using Scra.Model.Persons;

namespace Scra.Views.Persons
{
    public class SelectPersonArgs
    {
        public Action<PersonId> OnSuccess { get; set; }
    }
}