﻿using System.Windows.Controls;

namespace Scra.Views.Persons
{
    /// <inheritdoc cref="UserControl" />
    /// <summary>
    /// Interaction logic for PersonConflictView.xaml
    /// </summary>
    public partial class PersonConflictView
    {
        public PersonConflictView()
        {
            InitializeComponent();
        }
    }
}
