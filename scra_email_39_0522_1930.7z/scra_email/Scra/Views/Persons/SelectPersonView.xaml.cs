﻿using System.Windows.Input;

namespace Scra.Views.Persons
{
    public partial class SelectPersonView
    {
        public SelectPersonView()
        {
            InitializeComponent();
        }

        private void OnItemDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectPersonCommand.Execute(null);
        }

        private SelectPersonViewModel GetViewModel()
        {
            return (SelectPersonViewModel)DataContext;
        }
    }
}
