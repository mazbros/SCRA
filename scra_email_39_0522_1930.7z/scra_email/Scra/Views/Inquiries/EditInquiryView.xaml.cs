﻿namespace Scra.Views.Inquiries
{
    public partial class EditInquiryView
    {
        public EditInquiryView()
        {
            InitializeComponent();

            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.Attachments = AttachmentsControl.GetViewModel();
        }

        public EditInquiryViewModel GetViewModel()
        {
            return (EditInquiryViewModel)DataContext;
        }
    }
}
