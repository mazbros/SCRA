﻿using Scra.Model.Inquiries;

namespace Scra.Views.Inquiries
{
    public class Attachment : IAttachment
    {
        public string FileName { get; set; }
        public byte[] Content { get; set; }
    }
}