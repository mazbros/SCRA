﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class ConsumerLoanDetailsViewModel:BaseViewModel
    {
        private readonly IBenefitDetailRepository _benefitDetailRepository;
        private readonly AppNavigator _navigator;
        private readonly IMessageDialog _messageDialog;
        private int _benefitId;
        private BenefitDetail _detail;
        private Benefit _benefit;
        private readonly IBenefitRepository _benefitRepository;
        private ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;

        public ConsumerLoanDetailsViewModel()
        {
            SubTaskIdentifier = SubTaskType.ConsumerLoanDetail;

            _benefitDetailRepository = Di.Get<IBenefitDetailRepository>();
            _navigator = Di.Get<AppNavigator>();
            _messageDialog = Di.Get<IMessageDialog>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();

            OnViewLoaded = Load;
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
        }

        private void Cancel()
        {
            Load();
        }

        public decimal CurrentRate { get; set; }
        public bool IsRateCapPerformed { get; set; }
        public bool Block41 { get; set; }
        public bool IsFeeWaived { get; set; }
        public decimal FeeRefundAmount { get; set; }
        public DateTime? DateFeesRefunded { get; set; }
        public bool IsInterestAdjustmentCalculated { get; set; }
        public decimal InterestAdjustmentAmount { get; set; }
        public DateTime? DateInterestAdjustmentApplied { get; set; }
        public DateTime? BenefitAppliedDate { get; set; }
        public DateTime? DateBenefitExpected { get; set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public DateTime? ExpectedRemovalDate { get; set; }
        public DateTime? DateBenefitRemoved { get; set; }
        public SubTaskType SubTaskIdentifier { get; private set; }

        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ContractSnapshotViewModel ContractSnapshot { get; set; }

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var model = FillModel();

                if (model != BenefitDetail.Empty)
                    await _benefitDetailRepository.Save(model);

                _shellViewModel.IsUiBusy = false;
                await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
                await Reload();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private BenefitDetail FillModel()
        {
            var model = GetModel();
            model.CurrentRate = CurrentRate;
            model.Block41 = Block41;
            model.IsRateCapPerformed = IsRateCapPerformed;
            model.IsFeeWaived = IsFeeWaived;
            model.FeeRefundAmount = FeeRefundAmount;
            model.DateFeesRefunded = DateFeesRefunded;
            model.IsInterestAdjustmentCalculated = IsInterestAdjustmentCalculated;
            model.InterestRefunded = InterestAdjustmentAmount;
            model.RefundDate = DateInterestAdjustmentApplied;
            model.BenefitAppliedDate = BenefitAppliedDate;
            model.DateBenefitExpected = DateBenefitExpected;
            model.BenefitEffectiveDate = BenefitEffectiveDate;
            model.ExpectedRemovalDate = ExpectedRemovalDate;
            model.BenefitRemovedDate = DateBenefitRemoved;

            if (model.UnChanged(_detail))
                return BenefitDetail.Empty;

            return model;
        }

        private BenefitDetail GetModel()
        {
            if (_detail != null)
            {
                return BenefitDetail.CopyAll(_detail);
            }
            return BenefitDetail.ConsumerLoan(_benefitId);
        }

        private async void Load()
        {
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
            _shellViewModel.IsUiBusy = true;
            _benefitId = ((IdArgs)Arguments).Id;           
            await Reload();
            _shellViewModel.IsUiBusy = false;
        }

        private async Task Reload()
        {
            _benefit = await _benefitRepository.LoadById(_benefitId);
            _detail = await _benefitDetailRepository.Get(_benefitId);
            await ContractSnapshot.Load(_benefit.ContractId, _benefit.PersonId, _benefitId);
            FillView(_detail);                        
        }

        private void FillView(BenefitDetail model)
        {
            if (model == null)
            {
                return;
            }

            CurrentRate = Formatter.Percent(model.CurrentRate);
            IsRateCapPerformed = model.IsRateCapPerformed;
            Block41 = model.Block41;
            IsFeeWaived = model.IsFeeWaived;
            FeeRefundAmount = Formatter.Money(model.FeeRefundAmount);
            DateFeesRefunded = model.DateFeesRefunded;
            IsInterestAdjustmentCalculated = model.IsInterestAdjustmentCalculated;
            InterestAdjustmentAmount = Formatter.Money(model.InterestRefunded);
            DateInterestAdjustmentApplied = model.RefundDate;
            BenefitAppliedDate = model.BenefitAppliedDate;
            DateBenefitExpected = model.DateBenefitExpected;
            BenefitEffectiveDate = model.BenefitEffectiveDate;
            ExpectedRemovalDate = model.ExpectedRemovalDate;
            DateBenefitRemoved = model.BenefitRemovedDate;

            UpdateAll();
        }
    }
}
