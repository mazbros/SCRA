﻿using Scra.Controls;
using Scra.Model.ServiceMembers;

namespace Scra.Views.Benefits
{
    public class ActiveDutyListItem
    {
        public string ActiveDutyPeriod { get; set; }
        public string ActiveDutyBranch { get; set; }
        public string ActiveDutyNotificationDate { get; set; }
        public bool IsReserve { get; set; }
        public ActiveDuty ActiveDuty { get; set; }

        public static ActiveDutyListItem Create(ActiveDuty activeDuty)
        {
            return new ActiveDutyListItem()
            {
                ActiveDutyPeriod = Formatter.Date(activeDuty.StartDate) + " - " + Formatter.Date(activeDuty.EndDate),
                ActiveDutyNotificationDate = Formatter.Date(activeDuty.NoticeDate),
                ActiveDutyBranch = activeDuty.BranchOfService.Name,
                IsReserve = activeDuty.BranchOfService.IsReserve,
                ActiveDuty = activeDuty
            };
        }
    }
}