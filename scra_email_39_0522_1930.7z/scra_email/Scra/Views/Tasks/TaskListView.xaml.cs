﻿using System.Windows.Controls;
using System.Windows.Input;

namespace Scra.Views.Tasks
{
    ///<inheritdoc cref="UserControl"/>

    public partial class TaskListView
    {
        public TaskListView()
        {
           //AddHandler(System.Windows.Controls.Primitives.ButtonBase.ClickEvent, new RoutedEventHandler(ColumnHeaderClick));
            InitializeComponent();
        }

        private void OnItemDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectCommand.Execute(null);
        }

        private TaskListViewModel GetViewModel()
        {
            return (TaskListViewModel)DataContext;
        }

        private async void PageSize_Changed(object sender, SelectionChangedEventArgs e)
        {
            await GetViewModel().ReloadList(null);
        }

        private void RequestType_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var vm = GetViewModel();
            vm.ApplyTypeFilter();
        }

        private void Status_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var vm = GetViewModel();
            vm.ApplyStatusFilter();
        }

        private void TaskAgentFilter_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var vm = GetViewModel();
            vm.ApplyTaskAssigneeFilter();
        }

        private void QaAgentFilter_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var vm = GetViewModel();
            vm.ApplyQaAssigneeFilter();
        }
    }
}
