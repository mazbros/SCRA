﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class ViewLetterHistoryReportItem
    {
        [DisplayName("Letter History ID")]
        public string LetterHistId { get; set; }

        [DisplayName("Letter Code")]
        public string LetterCode { get; set; }

        [DisplayName("Date Sent")]
        public string DateSent { get; set; }

        [DisplayName("Returned")]
        public string Returned { get; set; }

        [DisplayName("Account")]
        public string Account { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServiceMemberId { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServiceMemberFirstName { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServiceMemberLastName { get; set; }

        [DisplayName("FNumber")]
        public string FNumber { get; set; }

        public static ViewLetterHistoryReportItem Create(DataRow dr)
        {
            var item = new ViewLetterHistoryReportItem
            {
                LetterHistId = dr["LetterHistID"].ToString(),
                LetterCode = dr["LetterCode"].ToString(),
                DateSent = string.Format("{0:MM/dd/yyyy}", dr["DateSent"]),
                Returned = dr["Returned"].ToString(),
                Account = dr["Account"].ToString(),
                ServiceMemberId = dr["ServiceMemberID"].ToString(),
                ServiceMemberFirstName = dr["ServicememberFirstName"].ToString(),
                ServiceMemberLastName = dr["ServicememberLastName"].ToString(),
                FNumber = dr["FNumber"].ToString()
            };

            return item;
        }
    }
}