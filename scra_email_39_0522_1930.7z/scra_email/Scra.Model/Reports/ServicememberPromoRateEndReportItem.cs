﻿using System.ComponentModel;
using System.Data;
using Scra.Model.Persons;

namespace Scra.Model.Reports
{
    public class ServicememberPromoRateEndReportItem
    {
        [DisplayName("Date Of Contact")]
        public string DateOfContact { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServiceMemberId { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstname { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("FNumber")]
        public string FNumber { get; set; }

        [DisplayName("Social Security Number")]
        public string SocialSecurityNumber { get; set; }

        [DisplayName("Date Of Birth")]
        public string DateOfBirth { get; set; }

        [DisplayName("Branch Of Service")]
        public string BranchOfService { get; set; }

        [DisplayName("AD Start Date")]
        public string AdStartDate { get; set; }

        [DisplayName("AD End Date")]
        public string AdEndDate { get; set; }

        [DisplayName("Benefit Approved/Denied/Pending")]
        public string BenefitApprovedDeniedPending { get; set; }

        [DisplayName("Date Benefit Applied")]
        public string DateBenefitsApplied { get; set; }

        [DisplayName("Date Benefits Ended")]
        public string DateBenefitsEnded { get; set; }

        [DisplayName("Product Type")]
        public string ProductType { get; set; }

        [DisplayName("Product SubType")]
        public string SubType { get; set; }

        [DisplayName("Account Number")]
        public string AccountNum { get; set; }

        [DisplayName("Product Start Date")]
        public string StartDate { get; set; }

        [DisplayName("Product End Date")]
        public string EndDate { get; set; }

        [DisplayName("Active Account Eligible")]
        public string ActiveAccountEligible { get; set; }

        [DisplayName("Comments")]
        public string Comments { get; set; }

        [DisplayName("Additional Comments")]
        public string AdditionalComments { get; set; }

        [DisplayName("Promo Rate End Date")]
        public string PromoRateEndDate { get; set; }

        public static ServicememberPromoRateEndReportItem Create(DataRow dr)
        {
            var item = new ServicememberPromoRateEndReportItem
            {
                DateOfContact = string.Format("{0:MM/dd/yyyy}", dr["DateOfContact"]),
                ServiceMemberId = dr["ServiceMemberID"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                ServicememberFirstname = dr["ServicememberFirstname"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                FNumber = dr["FNumber"].ToString(),
                SocialSecurityNumber = dr["SocialSecurityNumber"].ToString().Length > 0
                    ? dr["SocialSecurityNumber"].ToString() != Ssn.Empty().ToString() 
                        ? Ssn.Parse(dr["SocialSecurityNumber"].ToString()).GetDisplay()
                        : string.Empty
                    : dr["SocialSecurityNumber"].ToString(),
                DateOfBirth = string.Format("{0:MM/dd/yyyy}", dr["DateOfBirth"]),
                BranchOfService = dr["BranchOfService"].ToString(),
                AdStartDate = string.Format("{0:MM/dd/yyyy}", dr["ADStartDate"]),
                AdEndDate = string.Format("{0:MM/dd/yyy}", dr["ADEndDate"]),
                BenefitApprovedDeniedPending = dr["BenefitApprovedDeniedPending"].ToString(),
                DateBenefitsApplied = string.Format("{0:MM/dd/yyy}", dr["DateBenefitsApplied"]),
                DateBenefitsEnded = string.Format("{0:MM/dd/yyy}", dr["DateBenefitsEnded"]),
                ProductType = dr["ProductType"].ToString(),
                SubType = dr["SubType"].ToString(),
                AccountNum = dr["AccountNum"].ToString().Length > 0
                    ?  dr["AccountNum"].ToString().Length == 16
                        ? dr["AccountNum"].ToString().Substring(0, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(4, 4) + " " +
                          dr["AccountNum"].ToString().Substring(7, 4) + " " + 
                          dr["AccountNum"].ToString().Substring(12, 4)
                        : dr["AccountNum"].ToString().Length >= 19
                            ? dr["AccountNum"].ToString().Substring(0, 9) + " " + 
                              dr["AccountNum"].ToString().Substring(9, 10)
                            : " " + dr["AccountNum"] + " "
                    : string.Empty,
                StartDate = string.Format("{0:MM/dd/yyy}", dr["StartDate"]),
                EndDate = string.Format("{0:MM/dd/yyy}", dr["EndDate"]),
                ActiveAccountEligible = dr["ActiveAccountEligible"].ToString(),
                Comments = dr["Comments"].ToString(),
                AdditionalComments = dr["AdditionalComments"].ToString(),
                PromoRateEndDate = string.Format("{0:MM/dd/yyy}", dr["Promo Rate End Date"])
            };

            return item;
        }
    }
}