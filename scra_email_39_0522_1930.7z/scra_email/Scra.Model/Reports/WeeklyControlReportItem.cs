﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class WeeklyControlReportItem
    {
        [DisplayName("Request Date")]
        public string RequestDate { get; set; }

        [DisplayName("Status")]
        public string Status { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServiceMemberId { get; set; }

        [DisplayName("Origin")]
        public string Origin { get; set; }

        [DisplayName("Servicemember First Name")]
        public string FirstName { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string MiddleInitial { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string LastName { get; set; }
         
        [DisplayName("FNumber")]
        public string CustomerNumber { get; set; }

        [DisplayName("Branch Of Service")]
        public string BranchOfService { get; set; }

        [DisplayName("Reservist")]
        public string IsReserve { get; set; }

        [DisplayName("AD Start Date")]
        public string AdStartDate { get; set; }

        [DisplayName("AD End Date")]
        public string AdEndDate { get; set; }

        [DisplayName("Notification Date")]
        public string NotificationDate { get; set; }

        [DisplayName("Account Number")]
        public string AccountNumber { get; set; }
        
        [DisplayName("Contract Number")]
        public string ContractNo { get; set; }

        [DisplayName("Product Type")]
        public string ProductType { get; set; }

        [DisplayName("Product Open Date")]
        public string ProductOpenDate { get; set; }

        [DisplayName("Product Close Date")]
        public string ProductCloseDate { get; set; }

        [DisplayName("Benefit Approved/Denied/Pending")]
        public string BenefitStatus { get; set; }

        [DisplayName("Benefit Denial Reason")]
        public string BenefitDenialReason { get; set; }

        [DisplayName("Benefit Start Date")]
        public string BenefitStartDate { get; set; }

        [DisplayName("Benefit End Date")]
        public string BenefitEndDate { get; set; }

        [DisplayName("Benefit Effective (as of) Date")]
        public string BenefitEffectiveDate { get; set; }

        [DisplayName("Log Request Done")]
        public string LogRequestDone { get; set; }

        [DisplayName("Enter Details Done")]
        public string EnterDetailsDone { get; set; }

        [DisplayName("Military Info Done")]
        public string MilitaryInfoDone { get; set; }

        [DisplayName("Product Eligibility Done")]
        public string ProductEligibilityDone { get; set; }

        [DisplayName("Respond To Requester Done")]
        public string RespondToRequesterDone { get; set; }

        [DisplayName("Save All Records Done")]
        public string SaveAllRecordsDone { get; set; }

        [DisplayName("Completed By")]
        public string CompletedBy { get; set; }

        [DisplayName("Log Request Rejected")]
        public string LogRequestRejected { get; set; }

        [DisplayName("Enter Details Rejected")]
        public string EnterDetailsRejected { get; set; }

        [DisplayName("Military Info Rejected")]
        public string MilitaryInfoRejected { get; set; }

        [DisplayName("Product Eligibility Rejected")]
        public string ProductEligibilityRejected { get; set; }

        [DisplayName("Respond To Requester Rejected")]
        public string RespondToRequesterRejected { get; set; }

        [DisplayName("Save All Records Rejected")]
        public string SaveAllRecordsRejected { get; set; }

        [DisplayName("Rejected By")]
        public string RejectedBy { get; set; }

        [DisplayName("QA Log Request Done")]
        public string QaLogRequestDone { get; set; }

        [DisplayName("QA Enter Details Done")]
        public string QaEnterDetailsDone { get; set; }

        [DisplayName("QA Military Info Done")]
        public string QaMilitaryInfoDone { get; set; }

        [DisplayName("QA Product Eligibility Done")]
        public string QaProductEligibilityDone { get; set; }

        [DisplayName("QA Respond To Requester Done")]
        public string QaRespondToRequesterDone { get; set; }

        [DisplayName("QA Save All Records Done")]
        public string QaSaveAllRecordsDone { get; set; }

        [DisplayName("QA Completed By")]
        public string QaCompletedBy { get; set; }

        [DisplayName("Completed")]
        public string Completed { get; set; }

        public static WeeklyControlReportItem Create(DataRow dr)
        {
            var item = new WeeklyControlReportItem
            {
                RequestDate = string.Format("{0:MM/dd/yyyy}", dr["Date"]),
                Status = dr["Status"].ToString(),
                ServiceMemberId = dr["ServiceMemberID"].ToString(),
                Origin = dr["RequestTypeOrOrigin"].ToString(),
                FirstName = dr["ServicememberFirstName"].ToString(),
                MiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                LastName = dr["ServicememberLastName"].ToString(),
                
                CustomerNumber = dr["FNumber"].ToString(),
                
                BranchOfService = dr["Branch"].ToString(),
                IsReserve = dr["isReserve"].ToString(),
                AdStartDate = string.Format("{0:MM/dd/yyyy}", dr["ADStartDate"]),
                AdEndDate = string.Format("{0:MM/dd/yyyy}", dr["ADEndDate"]),
                NotificationDate = string.Format("{0:MM/dd/yyyy}", dr["NoticeDate"]),

                ContractNo = dr["ContractNo"].ToString().Length > 0
                    ? dr["ContractNo"].ToString().Substring(0, 4) + " " + 
                      dr["ContractNo"].ToString().Substring(4, 3) + " " +
                      dr["ContractNo"].ToString().Substring(7, 7)
                    : string.Empty,
                AccountNumber = dr["AccountNumber"].ToString().Length > 0
                    ?  dr["AccountNumber"].ToString().Length == 16
                        ? dr["AccountNumber"].ToString().Substring(0, 4) + " " + 
                          dr["AccountNumber"].ToString().Substring(4, 4) + " " +
                          dr["AccountNumber"].ToString().Substring(7, 4) + " " + 
                          dr["AccountNumber"].ToString().Substring(12, 4)
                        : dr["AccountNumber"].ToString().Length >= 19
                            ? dr["AccountNumber"].ToString().Substring(0, 9) + " " + 
                              dr["AccountNumber"].ToString().Substring(9, 10)
                            : " " + dr["AccountNumber"] + " "
                    : string.Empty,
                ProductType = dr["ProductType"].ToString(),
                ProductOpenDate = string.Format("{0:MM/dd/yyyy}", dr["ProductOpenDate"]),
                ProductCloseDate = string.Format("{0:MM/dd/yyyy}", dr["ProductCloseDate"]),
                
                
                BenefitStatus = dr["BenefitStatus"].ToString(),
                BenefitDenialReason = dr["DenialReason"].ToString(),
                BenefitStartDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitStartDate"]),
                BenefitEndDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitEndDate"]),
                BenefitEffectiveDate = string.Format("{0:MM/dd/yyyy}", dr["BenefitEffectiveDate"]),
                
                LogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["LogRequestDONE"]),
                EnterDetailsDone = string.Format("{0:MM/dd/yyyy}", dr["EnterDetailsDONE"]),
                MilitaryInfoDone = string.Format("{0:MM/dd/yyyy}", dr["MilitaryinfoDONE"]),
                ProductEligibilityDone = string.Format("{0:MM/dd/yyyy}", dr["ProductEligibilityDONE"]),
                RespondToRequesterDone = string.Format("{0:MM/dd/yyyy}", dr["RespondToRequesterDONE"]),
                SaveAllRecordsDone = string.Format("{0:MM/dd/yyyy}", dr["SaveAllrecordsDONE"]),
                CompletedBy = dr["CompletedBy"].ToString(),

                LogRequestRejected = string.Format("{0:MM/dd/yyyy}", dr["LogRequestREJECTED"]),
                EnterDetailsRejected = string.Format("{0:MM/dd/yyyy}", dr["EnterDetailsREJECTED"]),
                MilitaryInfoRejected = string.Format("{0:MM/dd/yyyy}", dr["MilitaryinfoREJECTED"]),
                ProductEligibilityRejected = string.Format("{0:MM/dd/yyyy}", dr["ProductEligibilityREJECTED"]),
                RespondToRequesterRejected = string.Format("{0:MM/dd/yyyy}", dr["RespondToRequesterREJECTED"]),
                SaveAllRecordsRejected = string.Format("{0:MM/dd/yyyy}", dr["SaveAllrecordsREJECTED"]),
                RejectedBy = dr["RejectedBy"].ToString(),

                QaLogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["QaLogRequestDONE"]),
                QaEnterDetailsDone = string.Format("{0:MM/dd/yyyy}", dr["QaEnterDetailsDONE"]),
                QaMilitaryInfoDone = string.Format("{0:MM/dd/yyyy}", dr["QAMilitaryinfoDONE"]),
                QaProductEligibilityDone = string.Format("{0:MM/dd/yyyy}", dr["QAProductEligibilityDONE"]),
                QaRespondToRequesterDone = string.Format("{0:MM/dd/yyyy}", dr["QARespondToRequesterDONE"]),
                QaSaveAllRecordsDone = string.Format("{0:MM/dd/yyyy}", dr["QASaveAllrecordsDONE"]),
                QaCompletedBy = dr["CompletedBy"].ToString(),

                Completed = dr["Completed"].ToString()
            };

            return item;
        }

    }
}