﻿using System;
using Scra.Model.Communication;
using Scra.Model.Persons;
using Scra.Model.Tools;
using System.Threading.Tasks;
using Scra.Model.Exceptions;

namespace Scra.Model.Letters
{
    public class ExpiringTemplate : ILetterTemplate
    {
        private readonly ILetterRepository _letterRepository;
        public PersonId PersonId { get; set; }
        public string Content { get; set; }
        
        public ExpiringTemplate()
        {
            _letterRepository = Di.Get<ILetterRepository>();
        }

        public static ExpiringTemplate Create()
        {
            return new ExpiringTemplate();
        }

        public async Task LoadTemplate(int letterNumber)
        {
            Content = await _letterRepository.LoadTemplate(letterNumber);
        }

        public async Task<Letter> Generate(Letter letter, object argument)
        {
            var personId = ((ProductCommunication)argument).PersonId;
            var benefitId = ((ProductCommunication)argument).BenefitId;
            Content = await LetterUtilities.ParsePersonalInformation(personId, Content);
            Content = await ParseBenefitInformation(benefitId);
            return letter;
        }

        private async Task<string> ParseBenefitInformation(int benefitId)
        {
            try
            {
                var benefitInfor = await _letterRepository.GetBenefitInformation(benefitId);
                var productType = benefitInfor.SUB_PRODUCT_NAME;

                var accountNumber = benefitInfor.AccountNumber.Substring(benefitInfor.AccountNumber.Length - 4);
                return Content.Replace("ActiveDutyEndDate", string.Format("{0:MM/dd/yyyy}", benefitInfor.AceiveDutyEndDate))
                    .Replace("BenefitEndDate", string.Format("{0:MM/dd/yyyy}", benefitInfor.BenefitExpectedRemovalDate))
                    .Replace("ProductType", productType)
                    .Replace("AccountNum", accountNumber);
            }
            catch (Exception)
            {

                throw new UserException("Fail to generate letter, benefit information is not available!");
            }

        }
    }
}