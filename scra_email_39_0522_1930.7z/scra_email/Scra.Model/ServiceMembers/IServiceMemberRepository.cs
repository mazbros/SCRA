﻿using System.Threading.Tasks;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public interface IServiceMemberRepository
    {
        Task<ServiceMember> Get(PersonId personId);

        Task Save(ActiveDuty model);
    }
}