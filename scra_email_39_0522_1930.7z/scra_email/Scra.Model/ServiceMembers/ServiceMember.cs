﻿using System.Collections.Generic;
using System.Linq;
using Scra.Model.Extensions;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public class ServiceMember
    {
        public PersonId PersonId { get; set; }
        public PersonName Name { get; set; }
        public IReadOnlyCollection<ActiveDuty> ActiveDuties { get; set; }

        public ServiceMember(PersonId personId, PersonName name, IList<ActiveDuty> activeDuties)
        {
            PersonId = personId;
            Name = name;
            ActiveDuties = activeDuties.AsReadOnly();
            foreach (var activeDuty in ActiveDuties)
            {
                activeDuty.ServiceMember = this;
            }
        }

        public ActiveDuty GetLastActiveDuty()
        {
            return ActiveDuties
                .OrderByDescending(x => x.StartDate)
                .FirstOrDefault();
        }
    }
}
