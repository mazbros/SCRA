﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    public interface ITaskRepository
    {
        Task<int> Create(Tasc model);
        Task<IList<TaskSnapshot>> Load(LoadTasksFilter filter, string searchText);
        Task<Tasc> Get(int taskId);
        Task SaveCompletion(SubTask subTask);
        Task SaveQaCompletion(SubTask subTask);
        Task UpdateAssignee(int taskId, IUser assignee);
        Task UpdateQaAssignee(int taskId, IUser assignee);
        Task DumpTask(int taskId);
        Task AppendSubTask(SubTask subTask);
    }
}