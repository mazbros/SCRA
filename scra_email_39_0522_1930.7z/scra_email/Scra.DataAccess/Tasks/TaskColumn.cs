﻿namespace Scra.DataAccess.Tasks
{
    public static class TaskColumn
    {
        public const string CONTRACT_ID = "ContractId";
        public const string PERSON_ID = "PersonId";
        public const string INQUIRY_ID = "InquiryId";
        public const string TYPE = "TaskType";
        public const string DUE_DATE = "DueDate";
        public const string CREATE_DATE = "CreateDate";
        public const string TITLE = "Title";
        public const string STATUS = "Status";
        public const string IS_QA_COMPLETE = "QaComplete";
        public const string ASSIGNEE_ID = "AssigneeID";
        public const string QA_ASSIGNEE_ID = "QaAssigneeID";
        public const string ASSIGNEE_USER_NAME = "AssigneeUserName";
        public const string ASSIGNEE_NAME = "AssigneeName";
    }
}