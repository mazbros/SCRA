﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.DataAccess.Persons
{
    internal class PersonNoteRepository : IPersonNoteRepository
    {
        private readonly SpExecutor _spExecutor;        

        public PersonNoteRepository(SpExecutor spExecutor)
        {
            _spExecutor = spExecutor;
        }

        public async Task Create(PersonNote note, IUser user)
        {
            var id = SpParameter.CreateInOut(note.Id);
            var parameters = new[]
            {
                SpParameter.Create(PersonNoteColumn.PERSON_ID, note.PersonId),
                SpParameter.Create(PersonNoteColumn.TEXT, note.Text),                
                id,
                SpParameter.ModifiedBy(user)
            };
            await _spExecutor.Execute("dbo.spNote_Update", parameters);
        }

        public async Task<IList<PersonNote>> Load(PersonId personId)
        {
            var id = SpParameter.Create(PersonNoteColumn.PERSON_ID, personId);
            Func<IRowData, PersonNote> convert = row => ToPersonNote(row, personId);
            return await _spExecutor.GetRecords("dbo.spNote_Get", id, convert);
        }

        private PersonNote ToPersonNote(IRowData row, PersonId personId)
        {
            var modifiedTime = row.AsDateTimeStrict(PersonNoteColumn.TIMESTAMP);
            var text = row.AsString(PersonNoteColumn.TEXT);
            var modifiedByName = row.AsString(PersonNoteColumn.MODIFIED_BY_NAME);

            return new PersonNote(text, personId, modifiedTime, modifiedByName);
        }
    }
}
