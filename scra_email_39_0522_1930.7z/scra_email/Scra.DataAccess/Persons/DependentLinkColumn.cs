﻿namespace Scra.DataAccess.Persons
{
    internal static class DependentLinkColumn
    {
        public const string FROM_ID = "FromId";
        public const string TO_ID = "ToId";
        public const string START_DATE = "StartDate";
        public const string END_DATE = "EndDate";
        public const string DEPENDENT_TYPE_ID = "DependentTypeId";
        public const string ID = "Id";

        public const string PERSON_ID = "PersonId";
    }
}