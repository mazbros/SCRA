﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.DataAccess.Persons;
using Scra.Model.BranchOfServices;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;

namespace Scra.DataAccess.Servicemembers
{
    public class ServiceMemberRepository : IServiceMemberRepository
    {
        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public ServiceMemberRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public async Task<ServiceMember> Get(PersonId personId)
        {
            var id = SpParameter.Create(RefColumn.PERSON_ID, personId);
            var dataSet = await _spExecutor.GetDataSet("dbo.spServiceMember_Get", id);
            var model = await ConvertSm(personId, dataSet);
            return model;
        }

        public async Task Save(ActiveDuty model)
        {
            var id = SpParameter.CreateInOut(RefColumn.ACTIVE_DUTY_ID, model.Id);
            var parameters = new[]
            {
                SpParameter.Create(ActiveDutyColumn.BRANCH_OF_SERVICE_ID, model.BranchOfService.Id),
                SpParameter.Create(RefColumn.PERSON_ID, model.PersonId),
                SpParameter.Create(ActiveDutyColumn.START_DATE, model.StartDate),
                SpParameter.Create(ActiveDutyColumn.END_DATE, model.EndDate),
                SpParameter.Create(ActiveDutyColumn.NOTICE_DATE, model.NoticeDate),                
                id,
                SpParameter.ModifiedBy()
            };

            await _spExecutor.Execute("dbo.spActiveDuty_Update", parameters);

            model.Id = (int)id.Value;
        }

        private async Task<ServiceMember> ConvertSm(PersonId personId, DataSet dataSet)
        {
            var row = dataSet.GetFirstTableRow();
            var name = PersonName.Create(row.AsString(PersonColumn.FIRST_NAME),
                row.AsString(PersonColumn.MIDDLE_INITIAL), row.AsString(PersonColumn.LAST_NAME));

            var activeDutyRows = dataSet.Tables[1].ToRows();
            var activeDuties = await ConvertActiveDuties(personId, activeDutyRows);

            return ServiceMemberFactory.Create(personId, name, activeDuties);
        }

        private async Task<IList<ActiveDuty>> ConvertActiveDuties(PersonId personId, IEnumerable<IRowData> rows)
        {
            var branchOfServices = await BranchOfServiceList.GetInstance();
            return rows.Select(x => ConvertActiveDuty(personId, x, branchOfServices)).ToList();
        }

        private ActiveDuty ConvertActiveDuty(PersonId personId, IRowData row, BranchOfServiceList branchOfServices)
        {
            var id = row.AsInt(RefColumn.ID);
            var branchOfServiceId = row.AsInt(ActiveDutyColumn.BRANCH_OF_SERVICE_ID);
            var branchOfService = branchOfServices.Get(branchOfServiceId);
            var startDate = row.AsDateTime(ActiveDutyColumn.START_DATE);
            var endDate = row.AsDateTime(ActiveDutyColumn.END_DATE);
            var noticeDate = row.AsDateTime(ActiveDutyColumn.NOTICE_DATE);
            return ActiveDuty.Create(id, personId, startDate, endDate, noticeDate, branchOfService);
        }
    }
}
