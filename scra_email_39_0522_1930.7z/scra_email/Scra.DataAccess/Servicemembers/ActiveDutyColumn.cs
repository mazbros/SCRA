﻿namespace Scra.DataAccess.Servicemembers
{
    public static class ActiveDutyColumn
    {
        public const string BRANCH_OF_SERVICE_ID = "BranchOfServiceId";
        public const string START_DATE = "StartDate";
        public const string END_DATE = "EndDate";
        public const string NOTICE_DATE = "NoticeDate";
    }
}