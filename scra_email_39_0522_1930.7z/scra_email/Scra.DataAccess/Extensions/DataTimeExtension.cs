﻿using System;

namespace Scra.DataAccess.Extensions
{
    internal static class DataTimeExtension
    {
        public static DateTime NotNull(this DateTime? date)
        {
            if (date == null)
            {
                throw new InvalidOperationException("Date is null.");
            }
            return date.Value;
        }
    }
}