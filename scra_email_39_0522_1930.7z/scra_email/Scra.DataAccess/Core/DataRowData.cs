﻿using System;
using System.Data;

namespace Scra.DataAccess.Core
{
    internal class DataRowData : IRowData
    {
        private readonly DataRow _row;

        public DataRowData(DataRow row)
        {
            _row = row;
        }

        public int AsInt(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return 0;
            }
            return (int)ordinal;
        }

        public decimal AsDecimal(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return 0;
            }
            return (decimal)ordinal;
        }

        public string AsString(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return null;
            }
            return (string)ordinal;
        }

        public byte[] AsByteArray(string name)
        {
            var data = (byte[])_row[name];
            return data;
        }

        public string AsString(int fieldIndex)
        {
            return (string)_row[fieldIndex];
        }

        public DateTime? AsDateTime(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return null;
            }
            return (DateTime?)ordinal;
        }

        public DateTime AsDateTimeStrict(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return new DateTime();
            }
            return (DateTime)ordinal;
        }

        public bool AsBool(string name)
        {
            var ordinal = _row[name];
            if (ordinal is DBNull)
            {
                return false;
            }
            return (bool)ordinal;
        }
    }
}