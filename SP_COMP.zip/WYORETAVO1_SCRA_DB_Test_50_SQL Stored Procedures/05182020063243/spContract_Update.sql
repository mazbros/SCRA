
CREATE PROCEDURE [dbo].[spContract_Update]
	@ID					INT OUT,
	@PersonID			INT,
	@ContractTypeId		INT,
	@ContractNo			VARCHAR(14),
    @LegacyNo			VARCHAR(24),
    @CardNo				VARCHAR(16),
    @Center				INT = NULL,
    @Product			INT = NULL,
    @OpenDate			DATE,
	@CloseDate			DATE = NULL,
	@ProductName		VARCHAR(50) = NULL,
	@IsDeleted			BIT,
	@Charge_Off			BIT = NULL,
	@Charge_Off_Note	VARCHAR(MAX)= NULL,
	@ModifiedBy			INT
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   NVARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION   

	
				IF @ID = 0 BEGIN SET @ID = NULL END
	
				IF @ID IS NULL BEGIN
	
				--IF (SELECT COUNT(*) FROM [dbo].[Contract] WHERE [ContractNo] = @ContractNo AND ISNULL([ContractNo],'') &lt;&gt; '') = 0 BEGIN
				
					INSERT INTO [dbo].[Contract]
						   ([PersonID]
						   ,[ContractTypeId]
						   ,[ContractNo]
						   ,[LegacyNo]
						   ,[CardNo]
						   ,[Center]
						   ,[Product]
						   ,[OpenDate]
						   ,[CloseDate]
						   ,[ProductName]
						   ,[Timestamp]
						   ,[ModifiedBy])
					 VALUES
						   (@PersonID
						   ,@ContractTypeId
						   ,@ContractNo
						   ,@LegacyNo
						   ,@CardNo
						   ,@Center
						   ,@Product
						   ,@OpenDate
						   ,@CloseDate
						   ,@ProductName
						   ,GETDATE()
						   ,@ModifiedBy)
						   
				SET @ID = SCOPE_IDENTITY()
			
			--END ELSE BEGIN
				
			--	SET @ID = (SELECT Top 1 ID FROM [dbo].[Contract] WHERE [ContractNo] = @ContractNo)
			
			--END
	
				END ELSE BEGIN
	
						INSERT INTO [hist].[Contract]
							([ID]
							,[PersonID]
							,[ContractTypeId]
							,[ContractNo]
							,[LegacyNo]
							,[CardNo]
							,[Center]
							,[Product]
							,[OpenDate]
							,[CloseDate]
							,[ProductName]
							,[IsDeleted]
							,[Timestamp]
							,[ModifiedBy]
							,[Charge_Off]
							,[Charge_Off_Note])
						SELECT
							 [ID]
							,[PersonID]
							,[ContractTypeId]
							,[ContractNo]
							,[LegacyNo]
							,[CardNo]
							,[Center]
							,[Product]
							,[OpenDate]
							,[CloseDate]
							,[ProductName]
							,[IsDeleted]
							,[Timestamp]
							,[ModifiedBy]
							,[Charge_Off]
							,[Charge_Off_Note]
						FROM [dbo].[Contract]
						WHERE [ID] = @ID
	
						UPDATE [dbo].[Contract]
							SET [ContractTypeId] = @ContractTypeId
							   ,[ContractNo] = @ContractNo
							   ,[LegacyNo] = @LegacyNo
							   ,[CardNo] = @CardNo
							   ,[ProductName] = CASE WHEN @ContractTypeId &gt;= 900 THEN @ProductName ELSE [ProductName] END
							   ,[OpenDate] = @OpenDate
							   ,[CloseDate] = @CloseDate
							   ,[IsDeleted] = @IsDeleted
							   ,[Timestamp] = GETDATE()
							   ,[ModifiedBy] = @ModifiedBy
							   ,[Charge_Off] = @Charge_Off
							   ,[Charge_Off_Note] = @Charge_Off_Note
						WHERE [ID] = @ID
	
				END
	
			COMMIT TRANSACTION
	
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = Convert(NVARCHAR(2048),SUBSTRING(ERROR_MESSAGE(),1,2047));
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
	
END

