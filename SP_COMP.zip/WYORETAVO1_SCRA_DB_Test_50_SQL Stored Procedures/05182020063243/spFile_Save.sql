

CREATE PROCEDURE [dbo].[spFile_Save]
	@EntityId		INT,
	@Entity			VARCHAR(255),
	@FileContent	VARBINARY(MAX),
	@FileName		VARCHAR(255),
	@FileID			INT = NULL
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
		
				IF @FileID = 0 OR @FileID IS NULL BEGIN

					INSERT INTO dbo.[File] ([FileName],[FileContent], [Timestamp]) VALUES (@FileName, @FileContent, GETDATE())		
					SET @FileID = SCOPE_IDENTITY()		
					INSERT INTO dbo.DocumentLink ([EntityId], [Entity], [FileId], [Timestamp])
						VALUES  (@EntityId, @Entity, @FileID, GETDATE())
				
				END ELSE BEGIN

					IF @FileID != 0 AND @FileID IS NOT NULL BEGIN

						--insert into hist.[File] ([ID],[FileName],[FileContent], [Timestamp]) VALUES (@FileID, @FileName, @FileContent, GETDATE())
						INSERT INTO hist.[File]  ([ID],[FileName],[FileContent], [Timestamp])
							SELECT [ID],[FileName],[FileContent] , [Timestamp] FROM dbo.[File]
						WHERE ID = @FileID

						UPDATE [dbo].[File] 
							SET [FileName] = @FileName, 
								[FileContent] = @FileContent,
							[Timestamp] = GETDATE() 
						WHERE [ID] = @FileID
					
					END
				
				END

			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			
	
END

