
CREATE PROCEDURE [dbo].[spThirtyDaysList_Report]
WITH RECOMPILE
AS
	SET NOCOUNT ON;
	SELECT DISTINCT 
		  p.ID
		 ,p.LastName
		 ,p.FirstName
		 ,cus.FNumber
		 --,bd.ExpectedRemovalDate,bd.BenefitRemovedDate
		 ,COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate) as BenefitRemovedDate
		 ,DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)) AS DaysLeft
		 ,dbo.fnProductName(c.ContractTypeId) + CASE WHEN LEN(dbo.fnProductSubName(c.ID)) = 0 THEN '' ELSE ' - ' + dbo.fnProductSubName(c.ID) END as SUB_PRODUCT_NAME
		 ,ISNULL(COALESCE(CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN NULL 
								ELSE dbo.LegacyNo_Format(c.LegacyNo) END,
						  CASE WHEN ISNULL(c.CardNo,'') = '' THEN NULL 
								ELSE dbo.CardNo_Format(c.CardNo) END),'') as [AccountNo]
	FROM dbo.Person p 
		INNER JOIN dbo.Customer cus 
			ON p.ID = cus.PersonID
		INNER JOIN dbo.[Contract] c 
			ON p.ID  = c.PersonID
		INNER JOIN dbo.ContractType ct 
			ON c.ContractTypeId = ct.ID
		INNER JOIN dbo.Benefit b 
			ON c.ID = b.ContractID
		INNER JOIN dbo.BenefitDetail bd 
			ON b.ID = bd.BenefitId 
	WHERE (((DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate))) BETWEEN 0 AND 30))
		ORDER BY (DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)))

/*
EXEC [dbo].[spThirtyDaysList_Report]
*/