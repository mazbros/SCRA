
CREATE PROCEDURE [dbo].[spInquiry_SortedList]
	@Search VARCHAR(MAX) = '',
	@SortBy VARCHAR(50),
	@SortDir VARCHAR(50),
	@PersonId int = null
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @Search IS NULL BEGIN
					SET @Search = ISNULL(@Search,'')
				END ELSE BEGIN
					SET @Search = REPLACE(@Search,' ','%')
				END
				
				SET @Search = REPLACE(@Search,'''','''''');
				
				DECLARE @sql VARCHAR(MAX)
				SET @sql = '
	SELECT	x.Id, 
		x.PersonInquiringId AS PE_ID, pe.FirstName AS PE_FirstName, pe.LastName AS PE_LastName, pe.MiddleInitial AS PE_MiddleInitial,
		x.ServicememberId AS SM_ID, sm.FirstName AS SM_FirstName, sm.LastName AS SM_LastName, sm.MiddleInitial AS SM_MiddleInitial,
        x.InquiryDate, x.Description, x.InquiryType,
        x.AcknowledgeDate, x.IsCompleted, x.ResponseDate, x.IdentificationMethod,
		x.ContactMethodID, m.Name AS ContactMethodName,
		x.AgentID, e.UserName AS AgentUserName, e.Name AS AgentName,
        x.DependentTypeId, d.Type AS DependentTypeName
FROM	dbo.Inquiry x
INNER	JOIN dbo.ContactMethod m
		ON m.ID = x.ContactMethodID
LEFT	JOIN dbo.Employee e
		ON e.ID = x.AgentID
LEFT	JOIN dbo.DependentType d
		ON	d.ID = x.DependentTypeId
LEFT	JOIN dbo.Person pe
		ON	pe.ID = x.PersonInquiringId
LEFT	JOIN dbo.Person sm
		ON	sm.ID = x.ServicememberId

	  WHERE (
			 pe.FirstName+'' ''+pe.LastName	LIKE ''%' + @Search + '%''
		 OR pe.FirstName					LIKE ''%' + @Search + '%''
		 OR pe.LastName						LIKE ''%' + @Search + '%''
		 OR sm.FirstName+'' ''+sm.LastName	LIKE ''%' + @Search + '%''
		 OR sm.FirstName					LIKE ''%' + @Search + '%''
		 OR sm.LastName						LIKE ''%' + @Search + '%''
		 OR	x.[Description]					LIKE ''%' + @Search + '%''
		 OR	x.[Comment]						LIKE ''%' + @Search + '%''
		 OR	m.[Name]						LIKE ''%' + @Search + '%''
		 OR	e.[UserName]					LIKE ''%' + @Search + '%''
		 OR	e.[Name]						LIKE ''%' + @Search + '%''
		 OR	d.[Type]						LIKE ''%' + @Search + '%''
		 OR	x.[ResponseText]				LIKE ''%' + @Search + '%''
		 OR  (CASE WHEN x.InquiryType = ''dmdc_check'' THEN ''DMDC Validation''
							 WHEN x.InquiryType = ''affiliate'' THEN ''Affiliate or Service By Other''
							 WHEN x.InquiryType = ''inquiry'' THEN ''Inquiries''
							 WHEN x.InquiryType = ''benefit_request'' THEN ''Benefit Intake and eligibility determination''
							 ELSE ''''
						END)				LIKE ''%' + @Search + '%''
		 )'
				 IF (@PersonId IS NOT NULL) BEGIN
					SET @sql = @sql + '
		 AND ((x.PersonInquiringId = ' + CAST(@PersonId as VARCHAR(32)) + ' OR x.ServicememberId = ' + CAST(@PersonId as VARCHAR(32)) + ') AND x.InquiryType = ''benefit_request'')'
				 END	
		  
					 SET @sql = @sql + '
	ORDER BY '
				  IF @SortBy = '' BEGIN 
					SET @sql = @sql + 'x.[InquiryDate] '	
				  END 
				  IF @SortBy = 'Inquired' BEGIN
					SET @sql = @sql + 'x.[InquiryDate] '
				  END
				  IF @SortBy = 'Responded' BEGIN
					SET @sql = @sql + 'x.[ResponseDate] '	
				  END 
				  IF @SortBy = 'Acknowledged' BEGIN
					SET @sql = @sql + 'x.[AcknowledgeDate] '	
				  END 
				  IF @SortBy = 'Type' BEGIN
					SET @sql = @sql + 'x.[InquiryType] '	
				  END 
				  IF @SortBy = 'Description' BEGIN
					SET @sql = @sql + 'x.[Description] '	
				  END
				  IF @SortBy = 'Person Requesting' BEGIN
					SET @sql = @sql + 'pe.FirstName+'' ''+pe.LastName '	
				  END 
				  IF @SortBy = 'Servicemember' BEGIN
					SET @sql = @sql + 'sm.FirstName+'' ''+sm.LastName '	
				  END 
				  IF @SortBy = 'Contact' BEGIN
					SET @sql = @sql + 'm.[Name] '	
				  END 
				  IF @SortBy = 'Agent' BEGIN
					SET @sql = @sql + 'e.[Name] '	
				  END 
				   IF @SortBy = 'Status' BEGIN
					SET @sql = @sql + 'x.[IsCompleted] '	
				  END
				  
				 IF @SortDir = 'Ascending' BEGIN
					SET @sql = @sql + ' ASC'
				 END ELSE BEGIN
					SET @sql = @sql + ' DESC'
				 END
  
			  PRINT len(@sql);
			  PRINT @sql;
			  EXEC(@sql);
			  
		COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

--EXEC [spInquiry_SortedList] '','Person Requesting', 'Descending'

	--SELECT	DISTINCT
	--		x.[Id], x.[PersonInquiringId], p.FirstName+'' ''+p.LastName as [PersonInquiring], 
	--		x.[ServicememberId], smt.FirstName+'' ''+smt.LastName as [ServiceMember],
	--           x.[InquiryDate], x.[Description], x.[InquiryType],
	 --           x.[AcknowledgeDate], x.[IsCompleted], x.[ResponseDate],
	--	    x.[ContactMethodID], m.[Name] AS ContactMethodName,
	--	    x.[AgentID], e.[UserName] AS AgentUserName, e.[Name] AS AgentName,
	 --           x.[DependentTypeId], d.[Type] AS DependentTypeName
	 --       FROM dbo.Inquiry x
	 --           INNER JOIN dbo.ContactMethod m
	--            ON m.[ID] = x.[ContactMethodID]
	--           LEFT JOIN dbo.Employee e
	--            ON e.[ID] = x.[AgentID]
	--           LEFT JOIN dbo.DependentType d
	--            ON d.[ID] = x.[DependentTypeId]
	--        LEFT JOIN dbo.Person p 
	--			ON x.PersonInquiringId = p.ID
	--		 LEFT JOIN (SELECT sm.ID, sm.PersonID, pt.Firstname, pt.LastName from dbo.Person pt 
	--			JOIN dbo.ServiceMember sm 
	--			ON pt.Id = sm.PersonID) smt
	--				ON x.ServiceMemberId = smt.ID