
CREATE PROCEDURE [dbo].[spGetCommunication] 
	@TaskId		INT = NULL,
	@PersonId	INT = NULL
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				IF @TaskId = 0 BEGIN SET @TaskId = NULL END;
				IF @PersonId = 0 BEGIN SET @PersonId = NULL END;
	
				SELECT	c.ID
					, c.PersonID
					, c.BenefitID
					, c.CommunicationDate
					, c.ContactMethodId
					, c.ResponseText
					, c.LetterId
					, c.TaskId
					, t.Status

					FROM [dbo].[Communication] c
					JOIN Task t on t.id = c.TaskId
				WHERE ((@PersonId IS NOT NULL AND c.PersonID = @PersonId)
				OR (@TaskId IS NOT NULL AND c.TaskId = @TaskId))
				AND ISNULL(CommunicationDate,'') &lt;&gt; '' AND ContactMethodId &lt;&gt; 0 AND LetterId &lt;&gt; 0
				AND t.[Status] &lt;&gt; 'misdirected' /* 05/14/2020 - AM - hiding misdirected task communications */

			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

	--DECLARE @SQL varchar(max)
	--SET @SQL = '
	--SELECT	[ID],[PersonID],[BenefitID],[CommunicationDate],[ContactMethodId],[ResponseText],[LetterId],[TaskId]
	--	FROM	[dbo].[Communication]
	--		WHERE   1 = 1 ' 
			
	--		IF LEN(@taskId) &gt; 0 BEGIN 
	--			SET @SQL = @SQL + ' AND TaskId = ' + CAST(@taskId as varchar(16))
	--		END
	--		IF LEN(@PersonID) &gt; 0 BEGIN
	--			SET @SQL = @SQL + ' AND PersonId= ' + CAST(@PersonId as varchar(16)) 
	--		END
	
	--SET @SQL = @SQL + '
	--		ORDER BY [Timestamp] DESC;'

	--EXEC(@SQL)        
            
END

/*
EXEC [dbo].[spGetCommunication]  @PersonID = 2433

SELECT	c.ID
		, c.PersonID
		, c.BenefitID
		, c.CommunicationDate
		, c.ContactMethodId
		, c.ResponseText
		, c.LetterId
		, c.TaskId
		, t.Status

		FROM [dbo].[Communication] c
		JOIN Task t on t.id = c.TaskId
	WHERE ((2433 IS NOT NULL AND c.PersonID = 2433)
	OR (5746 IS NOT NULL AND c.TaskId = 5746))
	AND ISNULL(CommunicationDate,'') &lt;&gt; '' AND ContactMethodId &lt;&gt; 0 AND LetterId &lt;&gt; 0
	AND t.[Status] &lt;&gt; 'misdirected'
*/

