
CREATE PROCEDURE [dbo].[spSubTask_QaComplete]
	@Id					INT, 
	@Status				VARCHAR(255), 
	@ModifiedBy			INT
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine		INT,
			@ErrorSource    SYSNAME,
			@ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				DECLARE @Date DATETIME SET @Date = GETDATE();
				
				UPDATE dbo.[SubTask]
					SET [QaCompletionDate] = @Date,
						[Status] = @Status,
						[QaCompletedBy] = @ModifiedBy,
						[Timestamp] = @Date
				WHERE [ID] = @Id;
				
				--DECLARE @QaComplete BIT
				--DECLARE @TaskId INT
				--SET @TaskId = (SELECT TaskId FROM [dbo].[SubTask] WHERE [ID] = @Id)
							
				--SET @QaComplete = CASE 
				--					WHEN (
				--							(SELECT COUNT(*) FROM [dbo].[SubTask] WHERE [TaskID] = @TaskId)
				--							 - 
				--							(SELECT COUNT(*) FROM [dbo].[SubTask] WHERE [TaskID] = @TaskId AND [QaCompletionDate] IS NOT NULL)
				--						 ) = 0
				--					THEN 1
				--					ELSE 0
				--				  END
				
				--IF @QaComplete = 1 BEGIN
					
				--	UPDATE [dbo].[Task]
				--		SET [QaComplete] = @QaComplete
				--		WHERE [ID] = @TaskId;
					
				--END
				
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

