

CREATE PROCEDURE [dbo].[spBenefitDetail_Update]
	@BenefitId						INT,
    @CurrentRate					DECIMAL(18,4),
    @Block41						BIT = NULL,
    @DmiSentDate					DATE = NULL,
    @ConfirmationReceivedDate		DATE = NULL,
    @IsPromotionalOffer				BIT = NULL,
    @PromotionEndDate				DATE = NULL,
    @IsRateCapPerformed				BIT = NULL,
    @IsFeeWaived					BIT = NULL,
    @FeeRefunded					MONEY = NULL,
    @FeeRefundedDate				DATE = NULL,
    @IsStatementsPending			BIT = NULL,
    @StatementDate					DATE = NULL,
    @IsInterestAdjustmentCalculated BIT = NULL,
    @InterestRefunded				MONEY = NULL,
    @InterestRefundedDate			DATE = NULL,
    @BenefitAppliedDate				DATE = NULL,
    @BenefitExpectedDate			DATE = NULL,
    @BenefitEffectiveDate			DATE = NULL,
    @ExpectedRemovalDate			DATE = NULL,
    @ExtendDate						DATE = NULL,
    @BenefitRemovedDate				DATE = NULL,
    @ModifiedBy						INT,
    @ID								INT OUT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN
	
	    BEGIN TRY
	
	        BEGIN TRANSACTION   
	
				IF @ID = 0 BEGIN SET @ID = NULL END;
				
				IF @Block41 IS NULL BEGIN SET @Block41 = 0 END ELSE BEGIN SET @Block41 = @Block41 END
				IF @IsPromotionalOffer IS NULL BEGIN SET @IsPromotionalOffer = 0 END ELSE BEGIN SET @IsPromotionalOffer = @IsPromotionalOffer END
				IF @IsRateCapPerformed IS NULL BEGIN SET @IsRateCapPerformed = 0 END ELSE BEGIN SET @IsRateCapPerformed = @IsRateCapPerformed END
				IF @IsFeeWaived IS NULL BEGIN SET @IsFeeWaived = 0 END ELSE BEGIN SET @IsFeeWaived = @IsFeeWaived END
				IF @IsStatementsPending IS NULL BEGIN SET @IsStatementsPending = 0 END ELSE BEGIN SET @IsStatementsPending = @IsStatementsPending END
				IF @IsInterestAdjustmentCalculated IS NULL BEGIN SET @IsInterestAdjustmentCalculated = 0 END ELSE BEGIN SET @IsInterestAdjustmentCalculated = @IsInterestAdjustmentCalculated END
				
				IF @ID IS NULL BEGIN
			
					INSERT INTO [dbo].[BenefitDetail]
			           ([BenefitId]
			           ,[CurrentRate]
			           ,[Block41]
			           ,[DmiSentDate]
			           ,[ConfirmationReceivedDate]
			           ,[IsPromotionalOffer]
			           ,[PromotionEndDate]
			           ,[IsRateCapPerformed]
			           ,[IsFeeWaived]
			           ,[FeeRefunded]
			           ,[FeeRefundedDate]
			           ,[IsStatementsPending]
			           ,[StatementDate]
			           ,[IsInterestAdjustmentCalculated]
			           ,[InterestRefunded]
			           ,[InterestRefundedDate]
			           ,[BenefitAppliedDate]
			           ,[BenefitExpectedDate]
			           ,[BenefitEffectiveDate]
			           ,[ExpectedRemovalDate]
			           ,[BenefitRemovedDate]
			           ,[ExtendDate]
			           ,[ModifiedBy]
			           ,[Timestamp])
			    VALUES
					   (@BenefitId
						,@CurrentRate
						,@Block41
						,@DmiSentDate
						,@ConfirmationReceivedDate
						,@IsPromotionalOffer
						,@PromotionEndDate
						,@IsRateCapPerformed
						,@IsFeeWaived
						,@FeeRefunded
						,@FeeRefundedDate
						,@IsStatementsPending
						,@StatementDate
						,@IsInterestAdjustmentCalculated
						,@InterestRefunded
						,@InterestRefundedDate
						,@BenefitAppliedDate
						,@BenefitExpectedDate
						,@BenefitEffectiveDate
						,@ExpectedRemovalDate
						,@BenefitRemovedDate
						,@ExtendDate
						,@ModifiedBy	
					    ,GETDATE())
				           
						   SET @ID = SCOPE_IDENTITY();
						 
				END ELSE BEGIN
				
					INSERT INTO [hist].[BenefitDetail]
			           ([BenefitDetailId]
			           ,[BenefitId]
			           ,[CurrentRate]
			           ,[Block41]
			           ,[DmiSentDate]
			           ,[ConfirmationReceivedDate]
			           ,[IsPromotionalOffer]
			           ,[PromotionEndDate]
			           ,[IsRateCapPerformed]
			           ,[IsFeeWaived]
			           ,[FeeRefunded]
			           ,[FeeRefundedDate]
			           ,[IsStatementsPending]
			           ,[StatementDate]
			           ,[IsInterestAdjustmentCalculated]
			           ,[InterestRefunded]
			           ,[InterestRefundedDate]
			           ,[BenefitAppliedDate]
			           ,[BenefitEffectiveDate]
			           ,[ExpectedRemovalDate]
			           ,[BenefitRemovedDate]
			           ,[ExtendDate]
			           ,[ModifiedBy]
			           ,[Timestamp]
			           ,[BenefitExpectedDate])
					 SELECT [ID]
					  ,[BenefitId]
					  ,[CurrentRate]
					  ,[Block41]
					  ,[DmiSentDate]
					  ,[ConfirmationReceivedDate]
					  ,[IsPromotionalOffer]
					  ,[PromotionEndDate]
					  ,[IsRateCapPerformed]
					  ,[IsFeeWaived]
					  ,[FeeRefunded]
					  ,[FeeRefundedDate]
					  ,[IsStatementsPending]
					  ,[StatementDate]
					  ,[IsInterestAdjustmentCalculated]
					  ,[InterestRefunded]
					  ,[InterestRefundedDate]
					  ,[BenefitAppliedDate]
					  ,[BenefitEffectiveDate]
					  ,[ExpectedRemovalDate]
					  ,[BenefitRemovedDate]
					  ,[ExtendDate]
					  ,[ModifiedBy]
					  ,[Timestamp]
					  ,[BenefitExpectedDate]
				  FROM [dbo].[BenefitDetail]
					WHERE [ID] = @ID
			
						
					UPDATE [dbo].[BenefitDetail]
					   SET [BenefitId] = @BenefitId
						  ,[CurrentRate] = @CurrentRate
						  ,[Block41] = @Block41
						  ,[DmiSentDate] = @DmiSentDate
						  ,[ConfirmationReceivedDate] = @ConfirmationReceivedDate
						  ,[IsPromotionalOffer] = @IsPromotionalOffer
						  ,[PromotionEndDate] = @PromotionEndDate
						  ,[IsRateCapPerformed] = @IsRateCapPerformed
						  ,[IsFeeWaived] = @IsFeeWaived
						  ,[FeeRefunded] = @FeeRefunded
						  ,[FeeRefundedDate] = @FeeRefundedDate
						  ,[IsStatementsPending] = @IsStatementsPending
						  ,[StatementDate] = @StatementDate
						  ,[IsInterestAdjustmentCalculated] = @IsInterestAdjustmentCalculated
						  ,[InterestRefunded] = @InterestRefunded
						  ,[InterestRefundedDate] = @InterestRefundedDate
						  ,[BenefitAppliedDate] = @BenefitAppliedDate
						  ,[BenefitExpectedDate] = @BenefitExpectedDate
						  ,[BenefitEffectiveDate] = @BenefitEffectiveDate
						  ,[ExpectedRemovalDate] = @ExpectedRemovalDate
						  ,[BenefitRemovedDate] = @BenefitRemovedDate
						  ,[ExtendDate] = @ExtendDate
						  ,[ModifiedBy] = @ModifiedBy
						  ,[Timestamp] = GETDATE()
					 WHERE [ID] = @ID
			
				END

			 COMMIT TRANSACTION
	    
	    END TRY
	    BEGIN CATCH
	        ROLLBACK TRANSACTION        
	        SET @ErrorMessage = ERROR_MESSAGE();
	        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
	        SET @ErrorLine    = ERROR_LINE();
	        SET @ErrorSeverity= ERROR_SEVERITY();
	        SET @ErrorState   = ERROR_STATE();
	        GOTO ErrorHandler;
	    END CATCH
	    RETURN;
	    
	    ErrorHandler:
	        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
	                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  
	
	END			

END


