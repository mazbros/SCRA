
CREATE PROCEDURE [dbo].[spInquiry_UpdateTitle]
	@InquiryId int
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
	
				DECLARE @Title			VARCHAR(max)
				DECLARE @FName			VARCHAR(255)
				DECLARE @LName			VARCHAR(255)
				DECLARE @OldFName		VARCHAR(255)
				DECLARE @oldLName		VARCHAR(255)
				DECLARE @PersonId		INT
	
				SELECT @Title = Title 
					FROM dbo.Task t 
						INNER JOIN dbo.Person p 
							ON p.ID = t.PersonID
					WHERE InquiryID = @InquiryId	

				SELECT @FName = p.FirstName, @LName = p.LastName, @PersonId = p.ID 
					FROM dbo.Inquiry inq 
						INNER JOIN dbo.Person p
							ON inq.ServicememberId = p.ID
					WHERE inq.ID = @InquiryId
					
				SELECT TOP 1 @OldFName = p.FirstName, @OldLName = p.LastName, @PersonId = p.ID 
					FROM dbo.Inquiry inq 
						INNER JOIN hist.Person p
							ON inq.ServicememberId = p.ID OR inq.PersonInquiringId = p.ID
					WHERE inq.ID = @InquiryId
						ORDER BY p.[Timestamp] DESC
	
				--DECLARE @name NVARCHAR(255)
				--DECLARE @pos INT	

				--DECLARE @Values Table(Id int IDENTITY(1,1) NOT NULL ,Text varchar(max))
	
				-- WHILE CHARINDEX(' ', @Title) &gt; 0 BEGIN
				--	SELECT @pos  = CHARINDEX(' ', @Title)  
				--	SELECT @name = SUBSTRING(@Title, 1, @pos-1)  

				--	INSERT INTO @Values (Text)
				--		SELECT @name

				--	SELECT @Title = SUBSTRING(@Title, @pos+1, LEN(@Title)-@pos)
				-- END

				-- INSERT INTO @Values
				--	SELECT @Title

				-- DECLARE @CNT int
				--	 SELECT @CNT = Count(*) from @Values
				 
				-- UPDATE @Values
				--	SET [Text] = @FName
				-- WHERE Id = @CNT-1

				-- UPDATE @Values
				--	SET [Text] = @LName + '.'
				-- WHERE Id = @CNT

				-- SET @Title = ''

				-- SELECT @Title = @Title
				--			 + CASE len(@Title)
				--				 WHEN 0 THEN ''
				--				 ELSE        ' '
				--			   END
				--			 + [Text]
				--	FROM @Values 

				SET @Title = REPLACE(@Title, @OldFName+' '+@OldLName, @Fname+' '+@LName)
				
				UPDATE dbo.Task
					SET Title = @Title, PersonID = @PersonId
				WHERE InquiryID = @InquiryId
	
				
			COMMIT TRANSACTION
    
		END TRY
    
		BEGIN CATCH
    
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
    
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			
	
END


