
CREATE PROCEDURE [dbo].[spPerson_List]
	@Search VARCHAR(MAX)
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				IF @Search IS NULL BEGIN
					SET @Search = ISNULL(@Search,'')
				END ELSE BEGIN
					SET @Search = @Search
				END

				SELECT t1.[ID]
				  ,t1.[FirstName]
				  ,t1.[LastName]
				  ,t1.[MiddleInitial]
				  ,t1.[SSN]
				  ,t1.[DOB]
				  ,t1.[Address1]
				  ,t1.[Address2]
				  ,t1.[City]
				  ,t1.[State]
				  ,t1.[Zip]
				  ,t1.[Phone]
				  ,t1.[Email]
				  ,t1.[ContactMethodID]
				  ,t1.[Timestamp]
				  ,t1.[ModifiedBy]
				  ,t2.[FNumber]
				  ,t1.[Origin]
			  FROM [dbo].[Person] t1 
				LEFT JOIN [dbo].[Customer] t2 ON t1.[ID] = t2.[PersonID]
					JOIN [dbo].[PersonSearch] ps ON t1.ID = ps.ID
			  WHERE 1 = 1  AND ISNULL(ps.[Search],'') LIKE '%'+RTRIM(LTRIM(@Search))+'%|'
			  AND ISNULL(t1.[Origin],'') NOT IN ('dmdc_check','inquiry') /* 'affiliate', as per request */
			  ORDER BY [LastName], [FirstName]
			  
		COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
    
END

/*

EXECUTE [dbo].[spPerson_List] @Search = '07083'

*/
