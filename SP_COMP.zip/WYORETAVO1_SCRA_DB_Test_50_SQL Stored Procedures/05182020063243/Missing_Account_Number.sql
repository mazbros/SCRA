
CREATE PROCEDURE [dbo].[Missing_Account_Number]

AS
BEGIN

	SET NOCOUNT ON;


SELECT Firstname,LastName,c.FNumber,t.ContractNo,t.OpenDate,t.CloseDate,t.LegacyNo,t.CardNo,t.[Timestamp] 
,ct.SCRA_Code,ct.ID
,CASE WHEN ct.SCRA_Code = 'auto' THEN 'Auto'
			  WHEN ct.SCRA_Code = 'commercial' THEN 'Commercial Loan'
			  WHEN ct.SCRA_Code = 'consumer_loan' THEN 'Consumer Loan'
			  WHEN ct.SCRA_Code = 'credit_card' THEN 'Credit Card'
			  WHEN ct.SCRA_Code = 'mortgage' THEN 'Mortgage'
			  WHEN ct.SCRA_Code = 'safe_dep_box' THEN 'Safe Deposit Box'
			  WHEN ISNULL(ct.SCRA_Code,'') = '' THEN ''
			  ELSE 'Other' END
											AS ProductType
		,ct.SUB_PRODUCT_NAME				AS SubType
		,t.Productname
FROM [dbo].[Person] p JOIN  [dbo].[Contract] t ON p.ID = t.PersonID
JOIN [dbo].[Customer] c ON p.ID = c.PersonID
  JOIN [dbo].[ContractType] ct ON t.ContractTypeId = ct.ID
  WHERE ISNULL(LegacyNo,'') = '' and ISNULL(cardno,'') = ''
    
END

/*
EXEC dbo.[Missing_Account_Number]
*/
