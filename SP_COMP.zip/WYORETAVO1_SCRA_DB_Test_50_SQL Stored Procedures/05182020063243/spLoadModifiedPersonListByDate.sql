
CREATE PROCEDURE [dbo].[spLoadModifiedPersonListByDate]
	@Timestamp datetime
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT DISTINCT p.[ID], p.[FirstName], p.[MiddleInitial], p.[LastName], th.[Timestamp], th.[Category]
				FROM [dbo].[Person] p
					JOIN (SELECT [PersonID], [Timestamp], [Category] FROM (
							SELECT [ID] as PersonID, [Timestamp], 'PERS' as Category FROM [dbo].[Person] WHERE [Timestamp] &gt; @Timestamp
							UNION
							SELECT [PersonID], [Timestamp], 'AD' as Category FROM [dbo].[ActiveDuty] WHERE [Timestamp] &gt; @Timestamp
							UNION
							SELECT [PersonID], [Timestamp], 'CONTR' as Category FROM [dbo].[Contract] WHERE [Timestamp] &gt; @Timestamp
					) u
				GROUP BY [PersonID], [Timestamp], [Category]
				HAVING [Timestamp] = (SELECT MAX([Timestamp]) 
										FROM (
											SELECT [ID] as PersonID, [Timestamp] FROM [dbo].[Person] p WHERE [Timestamp] &gt; @Timestamp AND p.[ID] = u.[PersonID]
											UNION
											SELECT [PersonID], [Timestamp] FROM [dbo].[ActiveDuty] a WHERE [Timestamp] &gt; @Timestamp AND a.[ID] = u.[PersonID]
											UNION
											SELECT [PersonID], [Timestamp] FROM [dbo].[Contract] c WHERE [Timestamp] &gt; @Timestamp AND c.[ID] = u.[PersonID]) uu )
				) th 
					ON p.[ID] = th.[PersonID]
						WHERE p.[Origin] NOT IN ('dmdc_check','inquiry')
					ORDER BY [Timestamp] DESC
			
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
        
END

