

CREATE PROCEDURE [dbo].[spBenefit_Update]
	@Id				INT,
	@Status			VARCHAR(50),
	@DenialReason	VARCHAR(MAX),
	@StartDate		DATE = NULL,
	@EndDate		DATE = NULL,
	@TaskID			INT = NULL,
	@ModifiedBy		INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	Declare 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

BEGIN

    BEGIN TRY

        BEGIN TRANSACTION   
	
	
	INSERT INTO [hist].[Benefit]
           ([BenefitID]
           ,[ContractID]
           ,[Timestamp]
           ,[ModifiedBy]
           ,[PersonID]
           ,[ActiveDutyID]
           ,[IsPromo]
           ,[StartDate]
           ,[EndDate]
           ,[Status]
           ,[DenialReason]
           ,[TaskID])
		SELECT [ID]
		  ,[ContractID]
		  ,[Timestamp]
		  ,[ModifiedBy]
		  ,[PersonID]
		  ,[ActiveDutyID]
		  ,[IsPromo]
		  ,[StartDate]
		  ,[EndDate]
		  ,[Status]
		  ,[DenialReason]
		  ,[TaskID]
	  FROM [dbo].[Benefit]
		WHERE ID = @ID
		
	UPDATE [dbo].[Benefit]
	   SET [Timestamp] = GETDATE(),
		   [ModifiedBy] = @ModifiedBy,
		   [StartDate] = @StartDate,
		   [EndDate] = @EndDate,
		   [Status] = @Status,
		   [DenialReason] = @DenialReason,
		   [TaskID] = @TaskID
	 WHERE [ID] = @Id
	 
	 COMMIT TRANSACTION
    
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION        
        SET @ErrorMessage = ERROR_MESSAGE();
        SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
        SET @ErrorLine    = ERROR_LINE();
        SET @ErrorSeverity= ERROR_SEVERITY();
        SET @ErrorState   = ERROR_STATE();
        GOTO ErrorHandler;
    END CATCH
    RETURN;
    
    ErrorHandler:
        RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
                    @ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

END			

END

