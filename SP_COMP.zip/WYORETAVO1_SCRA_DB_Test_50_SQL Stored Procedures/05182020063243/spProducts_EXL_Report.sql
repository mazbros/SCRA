
CREATE PROCEDURE [dbo].[spProducts_EXL_Report] 
	@ProductCategory varchar(50)
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine		INT,
        @ErrorSource    SYSNAME,
        @ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 

				SELECT   t.[Contract No],t.[Account No],t.[Product Type],t.[Product SubType],t.[Contract Open Date],t.[Contract Close Date]
					    ,t.[Customer ID],t.[FNumber],t.[Customer First Name],t.[Customer Middle Initial],t.[Customer Last Name],t.[Origin]
					    ,t.[ContractTypeId]
						,sm.[ID] as [Servicemember ID]
						,sm.[FirstName] as [Servicemember First Name]
						,sm.[MiddleInitial] as [Servicemember Middle Initial]
						,sm.[LastName] as [Servicemember Last Name]
						,sm.[Origin] as [Servicemember Origin] 
						,th.Branch,th.Reserv
						,ISNULL(CONVERT(VARCHAR(10),th.NoticeDate,121),'') as [Notification Date]
						,ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') as [Active Duty Start Date]
						,CASE WHEN CONVERT(varchar(10),ISNULL(th.EndDate,'9999-12-31'),121) = '9999-12-31' AND ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') &lt;&gt; '' THEN '' 
							ELSE CASE WHEN ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') &lt;&gt; '' THEN ISNULL(CONVERT(VARCHAR(10),ISNULL(th.EndDate,'9999-12-31'),121),'') ELSE '' END END as [Active Duty End Date]
				FROM 
					(
						SELECT u.ID,u.LinkedId,ad.ID as ActiveDutyID,ad.NoticeDate,ad.StartDate,ad.EndDate
						,[dbo].[fnServiceBranchByID](ad.[BranchOfServiceID]) as Branch
						,[dbo].[fnIsReservistByBranchID](ad.[BranchOfServiceID]) as Reserv
						,ROW_NUMBER() OVER (PARTITION BY u.ID ORDER BY COALESCE(ad.StartDate,ad.NoticeDate) DESC) RN FROM
							(SELECT FromID as ID, ToID as LinkedID FROM [PersonToPersonLink]-- WHERE DependentTypeId &lt;&gt; 4
							UNION
							SELECT ToID as ID, FromID as LinkedID FROM [PersonToPersonLink]--  WHERE DependentTypeId &lt;&gt; 4
							UNION
							SELECT ID, ID as LinkedID FROM [Person]
							) u
						JOIN [ActiveDuty] ad ON u.LinkedID = ad.PersonID
					) th
					RIGHT JOIN 
						(SELECT
								dbo.Partenon_Format(c.[ContractNo]) as [Contract No]
							,CASE WHEN ISNULL(c.CardNo,'') = '' THEN dbo.LegacyNo_Format(c.LegacyNo) ELSE dbo.CardNo_Format(c.CardNo) END as [Account No]
							,dbo.fnProductName(c.ContractTypeID) as [Product Type]
							,dbo.fnProductSubName(c.ID) as [Product SubType]
							,c.[OpenDate] as [Contract Open Date]
							,ISNULL(CONVERT(VARCHAR(10),c.[CloseDate],121),'') as [Contract Close Date]
							,p.[ID] as [Customer ID]
							,cust.[FNumber] as [FNumber]
							,p.[FirstName] as [Customer First Name]
							,p.[MiddleInitial] as [Customer Middle Initial]
							,p.[LastName] as [Customer Last Name]
							,p.[Origin]
							,c.ContractTypeId
						FROM [Contract] c 
							JOIN [Person] p ON p.ID = c.PersonID 
								JOIN [Customer] cust ON p.ID = cust.PersonID
						WHERE c.IsDeleted = 0
						) t ON th.ID = t.[Customer ID]
					JOIN [Person] sm ON th.LinkedId = sm.ID	 
				WHERE th.RN = 1
					--AND ISNULL(th.NoticeDate,'') = '' AND ISNULL(th.StartDate,'') = '' AND ISNULL(th.EndDate,'') = ''

					AND ((@ProductCategory = 'Consumer Loan + Home Equity' AND dbo.fnProductName(t.ContractTypeId) IN ('Consumer Loan','Home Equity'))
					OR @ProductCategory =  dbo.fnProductName(t.ContractTypeId)
					OR @ProductCategory = 'All' )

				ORDER BY t.[Product Type], th.ID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='All'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Commercial Loan'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Credit Card'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Consumer Loan'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Home Equity'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Consumer Loan + Home Equity'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Mortgage'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Safe Deposit Box'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Serviced by SCUSA'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Other'
*/



