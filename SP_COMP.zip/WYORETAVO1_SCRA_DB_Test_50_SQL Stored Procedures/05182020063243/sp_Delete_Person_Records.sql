
CREATE PROCEDURE [dbo].[sp_Delete_Person_Records]
	@PersonID INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	SELECT 'ActiveDuty',* from [dbo].[ActiveDuty] WHERE PersonID = @PersonID
	SELECT 'BenefitDetail',* from [dbo].[BenefitDetail] WHERE BenefitId IN (SELECT ID from dbo.Benefit WHERE PersonID = @PersonID)
	SELECT 'Benefit',* from [dbo].[Benefit] WHERE PersonID = @PersonID
	SELECT 'Communication',* from [dbo].[Communication] WHERE PersonID = @PersonID
	SELECT 'SubTask',* from [dbo].[SubTask] WHERE TaskID IN (SELECT ID from dbo.Task WHERE PersonID = @PersonID)
	SELECT 'Task',* from [dbo].[Task] WHERE PersonID = @PersonID
	SELECT 'Contract',* from [dbo].[Contract] WHERE PersonID = @PersonID OR PersonID = (select ToID FROM [dbo].[PersonToPersonLink] WHERE FromID = @PersonID OR ToID = @PersonID)
	SELECT 'Customer',* from [dbo].[Customer] WHERE PersonID = @PersonID
	SELECT 'File',* from [dbo].[File] WHERE ID IN (SELECT FileID from [dbo].[DocumentLink] WHERE EntityId = @PersonID)
	SELECT 'DocumentLink',* from [dbo].[DocumentLink] WHERE EntityId = @PersonID
	SELECT 'Inquiry',* from [dbo].[Inquiry] WHERE PersonInquiringId = @PersonID OR ServicememberId = @PersonID
	SELECT 'Note',* from [dbo].[Note] WHERE PersonID = @PersonID
	SELECT 'PersonToPersonLink',* from [dbo].[PersonToPersonLink] WHERE FromID = @PersonID OR ToID = @PersonID
	SELECT 'Person',* from [dbo].[Person] WHERE ID = @PersonID
   
/*
    DELETE from [dbo].[ActiveDuty] WHERE PersonID = @PersonID
	DELETE from [dbo].[BenefitDetail] WHERE BenefitId IN (SELECT ID from dbo.Benefit WHERE PersonID = @PersonID)
	DELETE from [dbo].[Benefit] WHERE PersonID = @PersonID
	DELETE from [dbo].[Communication] WHERE PersonID = @PersonID
	DELETE from [dbo].[SubTask] WHERE TaskID IN (SELECT ID from dbo.Task WHERE PersonID = @PersonID)
	DELETE from [dbo].[Task] WHERE PersonID = @PersonID
	DELETE from [dbo].[Contract] WHERE PersonID = @PersonID
	DELETE from [dbo].[Customer] WHERE PersonID = @PersonID
	DELETE from [dbo].[File] WHERE ID IN (SELECT FileID from [dbo].[DocumentLink] WHERE EntityId = @PersonID)
	DELETE from [dbo].[DocumentLink] WHERE EntityId = @PersonID
	DELETE from [dbo].[Inquiry] WHERE PersonInquiringId = @PersonID OR ServicememberId = @PersonID
	DELETE from [dbo].[Note] WHERE PersonID = @PersonID
	DELETE from [dbo].[PersonToPersonLink] WHERE FromID = @PersonID OR ToID = @PersonID
	DELETE from [dbo].[Person] WHERE ID = @PersonID
*/
/*
	SELECT * from [dbo].[ActiveDuty] WHERE PersonID = @PersonID
	SELECT * from [dbo].[BenefitDetail] WHERE BenefitId IN (SELECT ID from dbo.Benefit WHERE PersonID = @PersonID)
	SELECT * from [dbo].[Benefit] WHERE PersonID = @PersonID
	SELECT * from [dbo].[Communication] WHERE PersonID = @PersonID
	SELECT * from [dbo].[SubTask] WHERE TaskID IN (SELECT ID from dbo.Task WHERE PersonID = @PersonID)
	SELECT * from [dbo].[Task] WHERE PersonID = @PersonID
	SELECT * from [dbo].[Contract] WHERE PersonID = @PersonID
	SELECT * from [dbo].[Customer] WHERE PersonID = @PersonID
	SELECT * from [dbo].[File] WHERE ID IN (SELECT FileID from [dbo].[DocumentLink] WHERE EntityId = @PersonID)
	SELECT * from [dbo].[DocumentLink] WHERE EntityId = @PersonID
	SELECT * from [dbo].[Inquiry] WHERE PersonInquiringId = @PersonID OR ServicememberId = @PersonID
	SELECT * from [dbo].[Note] WHERE PersonID = @PersonID
	SELECT * from [dbo].[PersonToPersonLink] WHERE FromID = @PersonID OR ToID = @PersonID
	SELECT * from [dbo].[Person] WHERE ID = @PersonID
--*/  	
END

/* 
EXEC [dbo].[sp_Delete_Person_Records] 2524  
*/
