
CREATE PROCEDURE [dbo].[spGetModifiedActiveDutyByDate]
	@PersonID INT,
	@Timestamp datetime
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
			
				IF @Timestamp &lt; (SELECT MAX([Timestamp]) FROM [ActiveDuty] WHERE PersonID = @PersonId) BEGIN

					SELECT	AD.[ID], BS.[ID] As BranchOfServiceID, 
							BS.[Branch], BS.[IsReserve], AD.[StartDate], 
							AD.[EndDate], AD.[NoticeDate], AD.[Timestamp], 
							E.[Name] As ModifiedBy, AD.[PersonID]
					FROM
						(SELECT [ID], [BranchOfServiceID], [StartDate], [EndDate], 
								[NoticeDate], [Timestamp], [ModifiedBy], [PersonID] 
							FROM [ActiveDuty] WHERE [PersonID] = @PersonId
						UNION 
						SELECT TOP 1 [ID], [BranchOfServiceID], [StartDate], [EndDate], 
								[NoticeDate], [Timestamp], [ModifiedBy], [PersonID] 
							FROM [hist].[ActiveDuty] WHERE [PersonID] = @PersonId ORDER BY [Timestamp] DESC) AD
					LEFT JOIN [Employee] E on E.[ID] = AD.[ModifiedBy]
					LEFT JOIN [BranchOfService] BS on BS.[ID] = AD.[BranchOfServiceID]
					ORDER BY [Timestamp] DESC
				
				END
				
			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

