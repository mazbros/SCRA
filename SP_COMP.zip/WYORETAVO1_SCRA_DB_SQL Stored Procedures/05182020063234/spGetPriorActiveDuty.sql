CREATE PROCEDURE [dbo].[spGetPriorActiveDuty] 
	@ActiveDutyId INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  	INT,
			@ErrorSource    SYSNAME,
			@ErrorState 	INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				;WITH CTE AS 
				(SELECT [ID]
					   ,[BranchOfServiceID]
					   ,[StartDate]
					   ,[EndDate]
					   ,[NoticeDate]
					   ,[Timestamp]
					   ,[ModifiedBy]
					   ,[PersonID]
					   ,ROW_NUMBER() OVER (ORDER BY [StartDate]) AS [Row_Counter]
				 FROM [ActiveDuty]
					WHERE [PersonId] IN (SELECT [PersonID] FROM [ActiveDuty] WHERE [ID] = @ActiveDutyId)
				)
                  
				SELECT * FROM CTE WHERE [Row_Counter] IN (SELECT [Row_Counter] - 1 FROM CTE WHERE ID = @ActiveDutyId)

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END
