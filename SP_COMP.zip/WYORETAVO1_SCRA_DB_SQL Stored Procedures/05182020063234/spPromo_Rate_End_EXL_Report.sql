CREATE PROCEDURE [dbo].[spPromo_Rate_End_EXL_Report]
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine		INT,
			@ErrorSource    SYSNAME,
			@ErrorState		INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				;WITH CTE as (
				SELECT DISTINCT b.ID,b.BenefitIntervalId,ContractID,PersonID,ActiveDutyID,PromotionEndDate,TaskID from Benefit b LEFT JOIN BenefitDetail bd ON b.ID = bd.BenefitId where bd.PromotionEndDate IS NOT NULL AND ActiveDutyID &lt;&gt; 0)

				SELECT DISTINCT 
					ISNULL(CONVERT(VARCHAR(10),COALESCE(mh.DateOfContact,i.InquiryDate),121),'')	as [Date Of Contact],
					p.ID																			as [Servicemember ID],
					p.FirstName																		as [Servicemember First Name],
					p.MiddleInitial																	as [Servicemember Middle Initial],
					p.LastName																		as [Servicemember Last Name],
					cust.FNumber																	as [FNumber],
					dbo.SSN_Format(p.SSN)															as [Social Security Number],
					p.DOB																			as [Date Of Birth],
					dbo.fnServiceBranchByID(ad.BranchOfServiceID)									as [Branch Of Service],
					dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)								as [Reserv],
					ISNULL(CONVERT(VARCHAR(10),ad.StartDate,121),'')								as [Active Duty Start Date],
					ISNULL(CASE WHEN CONVERT(varchar(10),ad.EndDate,121) = '9999-12-31' 
						AND ISNULL(ad.StartDate,'') &lt;&gt; '' THEN '' ELSE 
							CASE WHEN ISNULL(ad.StartDate,'') &lt;&gt; '' THEN 
								CONVERT(VARCHAR(10),ad.EndDate,121) ELSE '' END END,'')				as [Active Duty End Date],
					CASE ISNULL((SELECT TOP 1 CASE WHEN ISNULL(b1.[Status],'') &lt;&gt; '' 
									THEN UPPER(SUBSTRING(b1.[Status],1,1))+
										SUBSTRING(b1.[Status],2,LEN(b1.[Status]) - 1) ELSE '' END
										FROM [Benefit] b1 
										WHERE b1.BenefitIntervalId = b.BenefitIntervalId AND 
										ISNULL(b1.[Status],'') &lt;&gt; '' 
										ORDER BY b1.[Timestamp] DESC),'')
									WHEN 'Denied' THEN 'Denied' 
									WHEN  '' THEN 'Pending'
									ELSE 'Approved' END												as [Benefit Approved/Denied/Pending],
					ISNULL((SELECT TOP 1 CASE WHEN ISNULL(b1.[Status],'') &lt;&gt; '' 
							THEN UPPER(SUBSTRING(b1.[Status],1,1))+
								SUBSTRING(b1.[Status],2,LEN(b1.[Status]) - 1) ELSE '' END 
										FROM [Benefit] b1 
										WHERE b1.BenefitIntervalId = b.BenefitIntervalId 
										AND ISNULL(b1.[Status],'') &lt;&gt; '' 
										ORDER BY b1.[Timestamp] DESC),'')							as [Benefit Status],
					ISNULL(CONVERT(varchar(10),bd.BenefitAppliedDate,121),'')						as [Date Benefits Applied],
					ISNULL(CONVERT(varchar(10),bd.BenefitEffectiveDate,121),'')						as [Benefit Effective Date],
					ISNULL(CONVERT(varchar(10),bd.ExpectedRemovalDate,121),'')						as [Expected Removal Date],
					ISNULL(CONVERT(varchar(10),bd.BenefitRemovedDate,121),'')						as [Date Benefits Ended],
					ISNULL(CONVERT(varchar(10),bd.ExtendDate,121),'')								as [Extend Date],
					dbo.fnProductName(c.ContractTypeId)												as [Product Type],
					dbo.fnProductSubName(cte.ContractID)											as [Product SubType],
					dbo.PARTENON_Format(c.ContractNo)												as [Contract #],
					ISNULL(COALESCE(CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN NULL 
						ELSE dbo.LegacyNo_Format(c.LegacyNo) END,
							CASE WHEN ISNULL(c.CardNo,'') = '' THEN NULL 
								ELSE dbo.CardNo_Format(c.CardNo) END),'')							as [Account #],
					ISNULL(CONVERT(varchar(10),c.OpenDate,121),'')									as [Product Open Date],
					ISNULL(CONVERT(varchar(10),c.CloseDate,121),'')									as [Product Close Date],
					'Yes'																			as [Active Account Eligible],
					cte.PromotionEndDate															as [Promo Rate End Date],
					ISNULL(REPLACE(REPLACE(REPLACE(REPLACE(STUFF((SELECT ',' + note.Comment FROM dbo.Note note 
						WHERE PersonID = p.ID ORDER BY note.[Timestamp] DESC 
							FOR XML PATH('')),1,1,''),',',
							CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)),CHAR(34),CHAR(39)+CHAR(39)),CHAR(226)+CHAR(128)+CHAR(147),'-'),'"',''''''),'') as [Comments]
						
					FROM CTE cte 
						JOIN Person p ON cte.PersonID = p.ID 
							LEFT JOIN ActiveDuty ad ON cte.ActiveDutyID = ad.ID
								LEFT JOIN Task t ON cte.TaskID = t.ID
									LEFT JOIN Inquiry i on t.InquiryID = i.ID
										LEFT JOIN Customer cust ON cte.PersonID = cust.PersonID
											JOIN Benefit b ON cte.ID = b.ID
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON cte.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Contract] c ON cte.ContractID = c.ID
														LEFT JOIN (SELECT DateOfContact,p.ID FROM Migration_History mh JOIN Servicemember sm ON mh.ServiceMemberID = sm.ServicememberID JOIN Person p On sm.PersonID = p.ID) mh ON cte.PersonID = mh.ID
					ORDER BY cte.PromotionEndDate
					
				COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END																							

END
/*
EXEC [dbo].[spPromo_Rate_End_EXL_Report]
*/
