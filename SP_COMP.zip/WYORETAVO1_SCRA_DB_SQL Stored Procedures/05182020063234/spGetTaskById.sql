CREATE PROCEDURE [dbo].[spGetTaskById]
	@taskId INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  	INT,
			@ErrorSource    SYSNAME,
			@ErrorState 	INT;        
	
	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				SELECT	T.Id
					, T.Title
					, T.DueDate
					, I.InquiryDate as ContactDate
					, I.ResponseDate
					, T.CreateDate
					, T.Status
					, T.TaskType
					, T.InquiryId
					, T.PersonId
					, P.FirstName
					, P.LastName
					, CASE WHEN ISNULL(C.LegacyNo, '') &lt;&gt; '' THEN C.LegacyNo
					  WHEN ISNULL(C.CardNo, '') &lt;&gt; '' THEN C.CardNo END AS AccountNum
					, T.ContractId
					, T.QaComplete
					, T.ModifiedBy
					, m.UserName AS ModifiedByUserName
					, m.Name as ModifiedByName
					, T.AssigneeID
					, e.UserName AS AssigneeUserName
					, e.Name as AssigneeName
					, T.QaAssigneeID
					, qae.UserName AS QaAssigneeUserName
					, qae.Name as QaAssigneeName
			

				FROM	dbo.Task T
				JOIN 	dbo.Person P On P.ID = T.PersonID
				LEFT JOIN dbo.Employee m ON m.ID = T.ModifiedBy
				LEFT JOIN dbo.Employee e ON e.ID = T.AssigneeID
				LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
				LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
				left join Contract C On C.ID = T.ContractID
				WHERE   T.Id = @taskId;

				SELECT  x.Id, 
					x.Title
					, x.Code
					, x.Status
					, x.SortNo
					, x.IsComplete
					, x.CompletionDate
					, x.CompletedBy
					, e.UserName AS CompletedByUserName
					, e.Name as CompletedByName
					, x.IsQaComplete
					, x.QaCompletionDate
					, x.QaCompletedBy
					, eq.UserName AS QaCompletedByUserName
					, eq.Name as QaCompletedByName
					, r.RejectionReason
				FROM	dbo.SubTask x
				LEFT JOIN dbo.Employee e ON e.ID = x.CompletedBy
				LEFT JOIN dbo.Employee eq ON eq.ID = x.QaCompletedBy
				LEFT JOIN dbo.RejectionReason r ON r.SubTaskID = x.ID
				WHERE   x.TaskID = @taskId
				ORDER BY x.ID;

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END
        
END
