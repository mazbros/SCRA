DECLARE @DateStart date,@DateEnd date

SET @DateStart = '2019-12-01'
SET @DateEnd = '2020-01-31'

--/*
--SELECT SMID,COUNT(*) FROM (
SELECT DISTINCT 
	ISNULL(CONVERT(VARCHAR(10),b.BenefitIntervalId),'') as BenefitIntervalId,
	ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate,
	CASE ISNULL(i.IdentificationMethod,'') 
		WHEN 'internal' THEN 'Proactive'
		WHEN 'line_business' THEN 'Line of Business'
		WHEN 'customer' THEN 'Customer Originated'
		WHEN '' THEN ''
		ELSE ''
	END as IdentificationMethod,
	ISNULL(CONVERT(varchar(10),ad.PersonID),'') as SMID,
	ISNULL(CONVERT(varchar(10),sm.FNumber),'') as FNumber,
	ISNULL(CONVERT(varchar(50),p.FirstName),'') as SMFirstName,
	ISNULL(CONVERT(varchar(50),p.MiddleInitial),'') as SMMiddleInitial,
	ISNULL(CONVERT(varchar(50),p.LastName),'') as SMLastName,--p.Origin,
	--ad.ID as ActiveDutyID,
	ISNULL(dbo.fnServiceBranchByID(ad.BranchOfServiceID),'') as Branch,
	ISNULL(dbo.fnIsReservistByBranchID(ad.BranchOfServiceId),'') as Reserv,
	ISNULL(CONVERT(VARCHAR(10),ad.StartDate,121),'') as ADSD,
	ISNULL(CONVERT(VARCHAR(10),ad.EndDate,121),'') as ADED,
	ISNULL(CONVERT(VARCHAR(10),ad.NoticeDate,121),'') as NotificationDate,
	'' as [Status],
	'' as TaskStatus,
	'' as BenefitAppliedDate,'' as BenefitEffectiveDate,'' as ExpectedRemovalDate,'' as BenefitRemovedDate,'' as ExtendDate,
	ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,
	ISNULL(CONVERT(VARCHAR(10),cust.FNumber),'') as CustFNumber,
	ISNULL(CONVERT(VARCHAR(50),p.FirstName),'') as CustFirstName,
	ISNULL(CONVERT(VARCHAR(50),p.MiddleInitial),'') as CustMiddleInitial,
	ISNULL(CONVERT(VARCHAR(50),p.LastName),'') as CustLastName,
	ISNULL(CONVERT(VARCHAR(10),c.ID),'') as ContractID,
	dbo.PARTENON_Format(c.ContractNo) as ContractNo,
	CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo,
	ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType,
	ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType,
	ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate,
	ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate,
	'' as DueDate	
	
	--,t.ID as TaskID,t.TaskType
	
FROM  [ActiveDuty] ad 
		FULL OUTER JOIN [Contract] c ON ISNULL(ad.PersonID,'') = ISNULL(c.PersonID,'')
			LEFT JOIN [Person] pc ON ISNULL(c.PersonID,'') = ISNULL(pc.ID,'')
				LEFT JOIN [Benefit] b ON ISNULL(ad.ID,'') = ISNULL(b.ActiveDutyID,'') AND ISNULL(c.ID,'') = ISNULL(b.ContractID,'')
					LEFT JOIN [Person] p ON ISNULL(ad.PersonID,'') = ISNULL(p.ID,'')
						LEFT JOIN [Customer] sm ON ISNULL(p.ID,'') = ISNULL(sm.PersonID,'')
							LEFT JOIN [Customer] cust ON ISNULL(c.PersonID,'') = ISNULL(cust.PersonID,'')
								LEFT JOIN [Inquiry] i ON ISNULL(ad.PersonID,'') = ISNULL(i.ServicememberId,'')
									LEFT JOIN [Task] t ON ISNULL(i.ID,'') = ISNULL(t.InquiryID,'')
WHERE 1=1 AND b.ID IS NULL
	--OR b.ID IS NOT NULL AND c.ID IS NULL) --OR ad.ID IS NULL
	AND ISNULL(c.IsDeleted,'') = 0
--AND ad.PersonID NOT IN (SELECT PersonID FROM Servicemember sm JOIN Migration_History mh ON sm.ServicememberID = mh.ServiceMemberID)
	AND (((ISNULL(ad.StartDate,'1900-01-01') > ISNULL(c.OpenDate,'1900-01-01'))
	AND (ISNULL(c.CloseDate,'9999-12-31') > ISNULL(ad.StartDate,'9999-12-31'))
		OR ad.StartDate IS NULL AND ad.EndDate IS NULL OR c.OpenDate IS NULL OR c.CloseDate IS NULL))
--AND (ISNULL(i.InquiryType,'') = 'benefit_request')
--AND (ISNULL(t.TaskType,'') IN ('add_benefit','deny_benefit'))

--AND ad.PersonID NOT IN (SELECT DISTINCT PersonID FROM Benefit WHERE ContractId = 0 OR DenialReason LIKE '%no product%')
--) th GROUP BY SMID
--ORDER BY ISNULL(ad.PersonID,'')
--SELECT * FROM Benefit WHERE DenialReason LIKE '%no product%' OrRDER BY PersonID
UNION
--*/
--/*
SELECT DISTINCT	CONVERT(VARCHAR(10),ISNULL(b.BenefitIntervalId,'')) as BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					--,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,ISNULL(CONVERT(varchar(10),b.PersonID),'') as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv,ISNULL(CONVERT(varchar(10),adr.NotificationDate,121),'') as NotificationDate
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID
					,ISNULL(CONVERT(VARCHAR(10),cust.FNumber),'') as CustFNumber
					,ISNULL(CONVERT(VARCHAR(50),p.FirstName),'') as CustFirstName
					,ISNULL(CONVERT(VARCHAR(50),p.MiddleInitial),'') as CustMiddleInitial
					,ISNULL(CONVERT(VARCHAR(50),p.LastName),'') as CustLastName
					,c.ID as ContractID
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate 
					,CASE WHEN b.[Status] = 'applying' THEN ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate) ,121),'')
						WHEN b.[Status] = 'denying' THEN ''
						WHEN b.[Status] = 'removing' THEN 
							CASE WHEN dbo.fnProductName(c.ContractTypeId) IN ('Credit card','Consumer Loan') THEN ISNULL(CONVERT(varchar(10),DATEADD(day, 90, adr.ADED) ,121),'')
							ELSE ''
							END
					END as DueDate
				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,ISNULL(CONVERT(VARCHAR(10),MIN(ad.StartDate),121),'') as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv,
													   MAX(ad.Noticedate) as NotificationDate 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND (t.TaskType IN ('add_benefit','deny_benefit','remove_benefit'))
							AND ((b.[Status] IN ('applying') AND bd.BenefitAppliedDate IS NULL) OR
								 (b.[Status] IN ('denying')) OR
								 (b.[Status] IN ('removing') and bd.BenefitRemovedDate IS NULL))
							AND c.IsDeleted = 0
							AND t.CreateDate < @DateEnd
						--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate < @DateEnd
				--ORDER BY b.PersonID
--*/