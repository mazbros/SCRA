DECLARE @DateStart date,@DateEnd date

SET @DateStart = '2019-12-01'
SET @DateEnd = '2019-12-31'

SELECT ContactDate,IdentificationMethod,OriginalMethodOfContact,SMID,FNumber,SMFirstName,SMMiddleInitial,SMLastName,DueDate,CommunicationDate,[SLA Met],[Days Since Contact]--,DATENAME(weekday,ContactDate) as ContactDay,DATENAME(weekday,DueDate) as DueDay,DATENAME(weekday,CommunicationDate) as CommDate 
FROM (
SELECT DISTINCT --b.BenefitIntervalId,
					ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,p.ID as SMID,ISNULL(COALESCE(cust.FNumber,sm.FNumber),'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					--,ISNULL(dbo.fnServiceBranchByID(ad.BranchOfServiceID),'') as Branch,ISNULL(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID),'') as Reserv
					--,ISNULL(CONVERT(VARCHAR(10),ad.StartDate,121),'') as ADSD
					--,CASE WHEN CONVERT(varchar(10),ad.EndDate,121) = '9999-12-31' AND ISNULL(ad.StartDate,'') <> '' THEN '' ELSE CASE WHEN ISNULL(ad.StartDate,'') <> '' THEN CONVERT(VARCHAR(10),ad.EndDate,121) ELSE '' END END as ADED 
					--,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					--,ISNULL(b.DenialReason,'') as DenialReason
					--,t.[Status] as TaskStatus
					--,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate
					--,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					--,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate
					--,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					--,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,ISNULL(cust.FNumber,'') as CustFNumber,ISNULL(p.FirstName,'') as CustFirstName
					--,ISNULL(p.MiddleInitial,'') as CustMiddleInitial,ISNULL(p.LastName,'') as CustLastName
					--,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					--,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					--,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					--,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					--,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					--,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,dbo.fnGetNextBusinessDay(ISNULL(CONVERT(VARCHAR(10),DATEADD(day, 15, i.InquiryDate),121),'')) as DueDate

					,ISNULL(CONVERT(VARCHAR(10),com.LetterID),'') as LetterID
					,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as Date1
					,ISNULL(CONVERT(VARCHAR(10),i.ResponseDate,121),'') as Date2
					,ISNULL(CONVERT(VARCHAR(10),COALESCE(com.CommunicationDate,i.ResponseDate),121),'') as CommunicationDate
					,ISNULL(i.ResponseMethodID,'') as InquiryResponseMethod
					,CASE WHEN  COALESCE(com.CommunicationDate,i.ResponseDate) <= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 15, i.InquiryDate),121),'')) THEN 'Yes' 
						   ELSE CASE WHEN COALESCE(com.CommunicationDate,i.ResponseDate) IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,isnull(COALESCE(com.CommunicationDate,i.ResponseDate),getdate())) as [Days Since Contact]
					 FROM [Inquiry] i 
							JOIN [Task] t ON i.ID = t.InquiryID
								JOIN [Person] p ON i.ServicememberId = p.ID
									LEFT JOIN [Contract] c ON (p.ID = c.PersonID)
										LEFT JOIN [Customer] cust on p.ID = cust.PersonID
											LEFT JOIN [ActiveDuty] ad ON p.ID = ad.PersonID
												LEFT JOIN [Communication] com ON p.ID = com.PersonID AND ISNULL(com.TaskID,'') = t.ID
													--LEFT JOIN [Benefit] b ON p.ID = b.PersonID
													--	LEFT JOIN (SELECT bb.BenefitIntervalID
													--		,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
													--		,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
													--		,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
													--		,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
													--		,MAX(bd1.ExtendDate) as ExtendDate 
													--		FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
															LEFT JOIN [Customer] sm on sm.PersonID = ad.PersonID
																LEFT JOIN [Person] smn on smn.ID = ad.PersonID
					WHERE 1=1
						
						AND (i.InquiryType = 'benefit_request'
						AND t.TaskType = 'request_benefits'
						AND ISNULL(i.IdentificationMethod,'') <> 'internal' 
						AND ((ISNULL(com.LetterId,'') = 2 OR com.LetterId IS NULL))
							OR (i.ResponseMethodId = 3 AND i.ResponseText LIKE '%request received%'))
						AND ISNULL(COALESCE(com.CommunicationDate,i.ResponseDate),'1900-01-01') BETWEEN @DateStart and @DateEnd

) th WHERE (LetterID = 2 OR LetterID = '') AND IdentificationMethod <> '' AND (InquiryResponseMethod = 3 OR InquiryResponseMethod = '')