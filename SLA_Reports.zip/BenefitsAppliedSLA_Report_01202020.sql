DECLARE @DateStart date,@DateEnd date

SET @DateStart = '2019-12-01'
SET @DateEnd = '2019-12-31'

			SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					--,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') as DueDate
					,ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') as DueDateNBD
					,CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as DATE) <= CAST(ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') as DATE) THEN 'Yes' ELSE 'No' END as SLA
					,ISNULL(CONVERT(VARCHAR(10),
							DATEDIFF(day,ISNULL(i.InquiryDate,getdate()),bd.BenefitAppliedDate)),'') as [Days Since Contact Date]
					,CASE WHEN ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') <> ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
							AND ISNULL(bd.BenefitAppliedDate,getdate()) = ISNULL(CONVERT(varchar(10),dbo.fnGetNextbusinessDay(DATEADD(day, 60, i.InquiryDate)),121),'') 
						THEN 'Yes' ELSE '' END as NextBusinessDay
				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND (t.TaskType = 'add_benefit' OR t.TaskType IS NULL)
							
							AND (
									(
										(ISNULL(bd.BenefitAppliedDate,'') >= @DateStart AND ISNULL(bd.BenefitAppliedDate,'') <= @DateEnd)
									) 
									AND bd.BenefitAppliedDate IS NOT NULL
								)
							AND c.IsDeleted = 0
						--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate < @DateEnd
						AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity')
				ORDER BY b.PersonID