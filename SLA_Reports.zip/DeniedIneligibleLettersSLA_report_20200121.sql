DECLARE @DateStart date,@DateEnd date

SET @DateStart = '2019-12-01'
SET @DateEnd = '2019-12-31'

			SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN CASE WHEN LEN(p.Origin) > 0 THEN UPPER(SUBSTRING(p.Origin,1,1))+SUBSTRING(p.Origin,2,LEN(p.Origin) - 1) ELSE '' END
						ELSE ''
					END as IdentificationMethod
					--,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,ISNULL(sm.FNumber,'') as FNumber,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial,COALESCE(smn.LastName,p.LastName) as SMLastName
					,ISNULL(adr.Branch,'') as Branch,ISNULL(adr.Reserv,'') as Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE '' END END as ADED 
					--,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,ISNULL(b.DenialReason,'') as DenialReason
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,ISNULL(cust.FNumber,'') as CustFNumber,ISNULL(cp.FirstName,'') as CustFirstName
					,ISNULL(cp.MiddleInitial,'') as CustMiddleInitial,ISNULL(cp.LastName,'') as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'')) as DueDate
					--,CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as DATE) <= ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'') 
					--		THEN 'Yes' ELSE 'No' END as AppliedWithinSLA
					--,CASE WHEN adr.Reserv = 'Yes' THEN
					--	CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') <> '1900-01-01' THEN
					--		CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = CAST(adr.NoticeDate as DATE) THEN 'Yes' ELSE 'No' END 
					--	ELSE 'No'
					--	END 
					-- ELSE ''
					-- END as NotificationDateStandard
					--,CASE WHEN adr.Reserv = 'Yes' THEN
					--	CASE WHEN ISNULL(adr.NoticeDate,'1900-01-01') = '1900-01-01' THEN			
					--		CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as DATE) = DATEADD(day,-45,adr.ADSD) THEN 'Yes' ELSE 'No' END
					--	ELSE 'No'
					--	END	
					-- ELSE ''							
					-- END as ADSDStandard
					--,ISNULL(CONVERT(VARCHAR(10),com.LetterID),'') as LetterID
					,ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),'') as CommunicationDate
					,CASE WHEN com.CommunicationDate <= dbo.fnGetNextBusinessDay(ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate),121),'')) THEN 'Yes' 
						   ELSE CASE WHEN com.CommunicationDate IS NOT NULL THEN 'No' ELSE '' END END as [SLA Met]
					 ,DATEDIFF(day,i.InquiryDate,ISNULL(com.CommunicationDate,getdate())) as [Days Since Contact]						   
					 FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON b.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											LEFT JOIN 
													(SELECT b.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b.ActiveDutyID) as ADCount, 
														   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
													FROM ActiveDuty ad JOIN Benefit b on b.ActiveDutyID = ad.ID WHERE b.BenefitIntervalId IS NOT NULL GROUP BY b.BenefitIntervalID,ad.PersonID) adr
													ON b.BenefitIntervalId = adr.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 RIGHT JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													LEFT JOIN [Customer] cust on c.PersonID = cust.PersonID
														LEFT JOIN [Person] cp ON cust.PersonID = cp.ID
															LEFT JOIN [Customer] sm on sm.PersonID = adr.PersonID
																LEFT JOIN [Person] smn on smn.ID = adr.PersonID
																	LEFT JOIN [Communication] com ON (b.PersonID = ISNULL(com.PersonID,'') /* DELETE NEXT TWO LINES TO INCLUDE MORE PEOPLE THAT SHOULD BE INCLUDED */
																					AND ISNULL(com.BenefitId,'') IN (SELECT ID FROM Benefit WHERE BenefitIntervalId = b.BenefitIntervalId) 
																					AND ISNULL(com.TaskID,'') = t.ID
																					)
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND b.[Status] IN ('denied','denying')
							AND (t.TaskType = 'deny_benefit')
							--AND i.InquiryDate >= @DateStart 
							--AND i.InquiryDate <= @DateEnd
							AND ((i.InquiryDate BETWEEN @DateStart AND @DateEnd) OR (ISNULL(com.CommunicationDate,'') BETWEEN @DateStart AND @DateEnd))
							AND ISNULL(c.IsDeleted,'') = 0
							--AND (ISNULL(com.CommunicationDate,'') BETWEEN @DateStart AND @DateEnd)
							AND (ISNULL(i.IdentificationMethod,'') <> 'internal' 
							AND ISNULL(com.LetterId,'3') = 3)
						--ORDER BY ISNULL(CONVERT(VARCHAR(10),com.CommunicationDate,121),''),b.PersonID							
						ORDER BY ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),''),b.PersonID							