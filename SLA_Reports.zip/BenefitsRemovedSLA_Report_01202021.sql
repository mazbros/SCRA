DECLARE @DateStart date,@DateEnd date

SET @DateStart = '2019-12-01'
SET @DateEnd = '2019-12-31'

SELECT	BenefitIntervalId,ContactDate,IdentificationMethod,/*OriginalMethodOfContact,*/SMID,FNumber,SMFirstName,SMMiddleInitial,SMLastName,Branch,Reserv,ADSD,
						ADED,[Status],TaskStatus,BenefitAppliedDate,BenefitEffectiveDate,ExpectedRemovalDate,BenefitRemovedDate,ExtendDate,CustID,
						CustFNumber,CustFirstName,CustMiddleInitial,CustLastName,ContractNo,AccountNo,ProductType,ProductSubType,ProductOpenDate,ProductCloseDate,
						DueDate,[SLA Met],[Days Since Due Date], CASE WHEN [Days Since Due Date] > [Days Since Due Date (Next Business Day)] THEN 'Yes' ELSE '' END as 'Next Business Day'
				FROM (
				SELECT DISTINCT ROW_NUMBER() OVER (PARTITION BY b.BenefitIntervalID ORDER BY i.inquiryDate DESC) as RN,b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					--,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					--,ISNULL(adr.ADCount,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
					,ISNULL(CONVERT(VARCHAR(10),CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
						ISNULL(CONVERT(VARCHAR(10),COALESCE(bd.ExpectedRemovalDate,dbo.fnGetNextBusinessDay(CASE WHEN adr.ADED = '9999-12-31' THEN NULL ELSE DATEADD(day, 90, adr.ADED) END)),121),'') 
						ELSE ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'')
					 END,121),'') as DueDate
					,CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
						CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN
							CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as DATE) <= 
								COALESCE(dbo.fnGetNextBusinessDay(DATEADD(day, 90, adr.ADED)),dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate)) THEN 'Yes' ELSE 'No' END
						ELSE '' END
					 ELSE 
						CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								CASE WHEN CAST(ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as DATE) <= dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate) THEN 'Yes' ELSE 'No' END
							ELSE '' 
						END
					 END as [SLA Met]
					 ,ISNULL(CONVERT(VARCHAR(10),
							CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								DATEDIFF(day,
									CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
										ISNULL(COALESCE(bd.ExpectedRemovalDate,dbo.fnGetNextBusinessDay(CASE WHEN adr.ADED = '9999-12-31' THEN NULL ELSE dbo.fnGetNextBusinessDay(DATEADD(day,90,adr.ADED)) END)),'') 
									ELSE ISNULL(bd.ExpectedRemovalDate,GETDATE())
									END,ISNULL(bd.BenefitRemovedDate,GETDATE()))
							ELSE NULL END),'') as [Days Since Due Date]
					 ,ISNULL(CONVERT(VARCHAR(10),
							CASE WHEN ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') = '' THEN 
								DATEDIFF(day,
									CASE WHEN CAST(adr.ADED as DATE) <> '9999-12-31' THEN 
										ISNULL(COALESCE(dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate),dbo.fnGetNextBusinessDay(DATEADD(day,90,adr.ADED))),'')
									ELSE ISNULL(dbo.fnGetNextBusinessDay(bd.ExpectedRemovalDate),GETDATE()) 
									END,ISNULL(bd.BenefitRemovedDate,GETDATE()))
							ELSE NULL END),'') as [Days Since Due Date (Next Business Day)]
				FROM [Benefit] b 
							JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														JOIN [Customer] sm on   sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND t.TaskType IN ('remove_benefit')
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND b.[Status] IN ('removed','removing')
							AND c.IsDeleted = 0
							AND ISNULL(bd.BenefitRemovedDate,'') >= @DateStart AND ISNULL(bd.BenefitRemovedDate,'') <= @DateEnd
							AND	ISNULL(bd.ExtendDate,'1900-01-01') < ISNULL(bd.BenefitRemovedDate,'9999-12-31') 
							--AND ISNULL(bd.BenefitAppliedDate,'') <> ISNULL(bd.BenefitRemovedDate,'')
							AND ISNULL(dbo.fnProductName(c.ContractTypeId),'') IN ('Consumer Loan','Credit card','Home Equity')
					) th
				WHERE RN = 1
				ORDER BY BenefitRemovedDate
				
--SELECT dbo.fnGetNextBusinessDay(DATEADD(day, 90, NULL))
--SELECT CONVERT(varchar(10),EndDate,121),CAST(EndDate as DATE)	 FROM ACtiveDuty ORDER BY CAST(EndDate as DATE) DESC
--SELECT DATEDIFF(day,GETDATE(),ISNULL('2019-03-18',GETDATE()))

