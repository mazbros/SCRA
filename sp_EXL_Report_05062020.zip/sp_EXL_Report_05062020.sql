USE [SCRA_DB_TEST_50]
GO

/****** Object:  StoredProcedure [dbo].[spDeniedAccounts_EXL_Report]    Script Date: 5/6/2020 4:03:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =====================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Denied Accounts Report with parameters>
-- Version:		<1.0>
-- =====================================================
CREATE PROCEDURE [dbo].[spDeniedAccounts_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[DenialReason] as [Denial Reason],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,ISNULL(sm.FNumber,'') as FNumber
					/* [START] SERVICEMEMBER NAME RETRIEVED FROM WHERE AVAILABLE WHEN EITHER PRODUCT OR ACTIVE DUTY IS MISSING - BENEFIT JOIN TO PERSON */
					,COALESCE(smn.FirstName,p.Firstname) as SMFirstName
					,COALESCE(smn.MiddleInitial,p.MiddleInitial) as SMMiddleInitial
					,COALESCE(smn.LastName,p.LastName) as SMLastName
					/* [END] SERVICEMEMBER NAME RETRIEVED FROM WHERE AVAILABLE WHEN EITHER PRODUCT OR ACTIVE DUTY IS MISSING - BENEFIT JOIN TO PERSON */
					,ISNULL(adr.Branch,'') as Branch,ISNULL(adr.Reserv,'') as Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE '' END END as ADED 
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,ISNULL(b.DenialReason,'') as DenialReason
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID,ISNULL(cust.FNumber,'') as CustFNumber,ISNULL(cp.FirstName,'') as CustFirstName
					,ISNULL(cp.MiddleInitial,'') as CustMiddleInitial,ISNULL(cp.LastName,'') as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON b.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											LEFT JOIN 
													(SELECT b.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b.ActiveDutyID) as ADCount, 
														   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
													FROM ActiveDuty ad JOIN Benefit b on b.ActiveDutyID = ad.ID WHERE b.BenefitIntervalId IS NOT NULL GROUP BY b.BenefitIntervalID,ad.PersonID) adr
													ON b.BenefitIntervalId = adr.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 RIGHT JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													LEFT JOIN [Customer] cust on c.PersonID = cust.PersonID
														LEFT JOIN [Person] cp ON cust.PersonID = cp.ID
															LEFT JOIN [Customer] sm on sm.PersonID = adr.PersonID
																LEFT JOIN [Person] smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							--AND b.[Status] IN ('denied','denying')
							AND (t.TaskType = 'deny_benefit')
							--AND ((i.InquiryDate >= @DateStart AND i.InquiryDate <= @DateEnd) OR i.InquiryDate IS NULL)
							AND ((i.InquiryDate >= @DateStart AND i.InquiryDate <= @DateEnd) AND i.InquiryDate IS NOT NULL)
							AND ISNULL(c.IsDeleted,'') = 0
							--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
							--AND i.InquiryDate <= @DateEnd

					) th
				ORDER BY SMID
			
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spDeniedAccounts_EXL_Report] @DateStart='2019-04-01',@DateEnd='2020-04-30'
*/


GO

/****** Object:  StoredProcedure [dbo].[spLoadTaskList]    Script Date: 5/6/2020 4:03:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <02/25/2020>
-- Description:	<Getting filtered task list>
-- =============================================
CREATE PROCEDURE [dbo].[spLoadTaskList] 
	@filterPersonID		INT = NULL,
	@filterContractID	INT = NULL,
	@filterTypes		VARCHAR(255),
	@filterStatuses		VARCHAR(255), 
	@filterAssigneeId	INT = NULL,
	@filterQaAssigneeId INT = NULL,
	@filterTaskId		INT = NULL,
	@filterInquiryId	INT = NULL,
	@filterHideAssigned BIT = 0,
	@searchText			VARCHAR(255)
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				DECLARE @SQL VARCHAR(MAX)
				SET @SQL = 'SELECT	T.Id
								, T.Title
								, T.DueDate
								, I.InquiryDate as ContactDate
								, I.ResponseDate
								, T.CreateDate
								, T.Status
								, T.TaskType
								, T.InquiryId
								, T.ContractId
								, T.PersonId
								, P.FirstName
								, P.LastName
								, T.QaComplete
								, T.AssigneeID
								, E.UserName AS AssigneeUserName
								, E.Name as AssigneeName
								, T.QaAssigneeID
								, qae.UserName AS QaAssigneeUserName
								, qae.Name as QaAssigneeName
								, CASE WHEN ISNULL(C.LegacyNo, '''') <> '''' THEN C.LegacyNo
								  WHEN ISNULL(C.CardNo, '''') <> '''' THEN C.CardNo END AS AccountNum
						FROM	dbo.Task T
						JOIN 	dbo.Person P On P.ID = T.PersonID
						LEFT JOIN dbo.Employee E ON E.ID = T.AssigneeID
						LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
						LEFT JOIN dbo.Inquiry I ON T.InquiryID = I.ID
						left join (Select distinct TaskId, ContractID from Benefit) B On B.TaskID = T.ID
						left join Contract C On C.ID = B.ContractID
						WHERE   1=1 '
			            
						IF @filterPersonId > 0 BEGIN
							SET @SQL = @SQL + ' AND T.PersonID = ' + CAST(@filterPersonId as varchar(16))
						END
						IF @filterContractId > 0 BEGIN
							SET @SQL = @SQL + ' AND T.ContractID = ' + CAST(@filterContractId as varchar(16))
						END
						IF LEN(@filterTypes) > 0 BEGIN
							SET @SQL = @SQL + ' AND T.TaskType IN (' + @filterTypes + ') '
						END
						IF LEN(@filterStatuses) > 0 BEGIN
							SET @SQL = @SQL + ' AND T.Status IN (' + @filterStatuses + ') '
						END
						IF @filterAssigneeId > 0 BEGIN
							SET @SQL = @SQL + ' AND (T.AssigneeID = ' + CAST(@filterAssigneeId as varchar(16)) + ') '
						END
						IF @filterQaAssigneeId > 0 BEGIN
							SET @SQL = @SQL + ' AND (T.QaAssigneeID = ' + CAST(@filterQaAssigneeId as varchar(16)) + ') '
						END
						IF @filterHideAssigned > 0 BEGIN
							SET @SQL = @SQL + ' AND T.AssigneeID is NULL '
						END
						IF @filterTaskId > 0 BEGIN
							SET @SQL = @SQL + ' AND T.Id = ' + CAST(@filterTaskId as varchar(16))
						END
						IF @filterInquiryId > 0 BEGIN
							SET @SQL = @SQL + ' AND T.InquiryId = ' + CAST(@filterInquiryId as varchar(16))
						END
						if LEN(@searchText) > 0 BEGIN
			            
							SET @searchText = REPLACE(@searchText,'''', '''''');

							SET @SQL = @SQL + ' AND (T.[Title] LIKE ''%' + @searchText + '%'' OR ' + CHAR(10) + CHAR(9) +
								   '   [AssigneeID] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') OR ' + CHAR(10) + CHAR(9) +
								   '   [QaAssigneeId] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'') /*OR ' + CHAR(10) + CHAR(9) +
								   '   [ModifiedBy] IN (SELECT [ID] FROM [dbo].[Employee] WHERE [Name] LIKE ''%' + @searchText + '%'')*/ ' + CHAR(10) + CHAR(9) +
								   '   ) '
						END
			            
						SET @SQL = @SQL + '
						ORDER BY T.CreateDate DESC;'
            
					PRINT @SQL            
            		EXEC (@SQL)
					
				COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

/*

EXEC [dbo].[spLoadTaskList]  
	@filterPersonID = NULL,
	@filterTypes = '',
	@filterStatuses	= '',
	@filterAssigneeId = NULL,
	@filterQaAssigneeId = NULL,
	@filterTaskId = 5242,
	@filterInquiryId = NULL,
	@filterHideAssigned  = 0,
	@searchText = ''
*/


GO

/****** Object:  StoredProcedure [dbo].[spProducts_EXL_Report]    Script Date: 5/6/2020 4:03:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =================================================================
-- Author:		<Aleksey Mazur>
-- Create date: <04/20/2020>
-- Modified:	<04/20/2020>
-- Description:	<Products Report with parameters>
-- Version:		<1.0>
-- =================================================================
CREATE PROCEDURE [dbo].[spProducts_EXL_Report] 
	@ProductCategory varchar(50)
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 

				SELECT   t.[Contract No],t.[Account No],t.[Product Type],t.[Product SubType],t.[Contract Open Date],t.[Contract Close Date]
					    ,t.[Customer ID],t.[FNumber],t.[Customer First Name],t.[Customer Middle Initial],t.[Customer Last Name],t.[Origin]
					    ,t.[ContractTypeId]
						,sm.[ID] as [Servicemember ID]
						,sm.[FirstName] as [Servicemember First Name]
						,sm.[MiddleInitial] as [Servicemember Middle Initial]
						,sm.[LastName] as [Servicemember Last Name]
						,sm.[Origin] as [Servicemember Origin] 
						,th.Branch,th.Reserv
						,ISNULL(CONVERT(VARCHAR(10),th.NoticeDate,121),'') as [Notification Date]
						,ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') as [Active Duty Start Date]
						,CASE WHEN CONVERT(varchar(10),ISNULL(th.EndDate,'9999-12-31'),121) = '9999-12-31' AND ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') <> '' THEN '' 
							ELSE CASE WHEN ISNULL(CONVERT(VARCHAR(10),th.StartDate,121),'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),ISNULL(th.EndDate,'9999-12-31'),121),'') ELSE '' END END as [Active Duty End Date]
				FROM 
					(
						SELECT u.ID,u.LinkedId,ad.ID as ActiveDutyID,ad.NoticeDate,ad.StartDate,ad.EndDate
						,[dbo].[fnServiceBranchByID](ad.[BranchOfServiceID]) as Branch
						,[dbo].[fnIsReservistByBranchID](ad.[BranchOfServiceID]) as Reserv
						,ROW_NUMBER() OVER (PARTITION BY u.ID ORDER BY COALESCE(ad.StartDate,ad.NoticeDate) DESC) RN FROM
							(SELECT FromID as ID, ToID as LinkedID FROM [PersonToPersonLink]-- WHERE DependentTypeId <> 4
							UNION
							SELECT ToID as ID, FromID as LinkedID FROM [PersonToPersonLink]--  WHERE DependentTypeId <> 4
							UNION
							SELECT ID, ID as LinkedID FROM [Person]
							) u
						JOIN [ActiveDuty] ad ON u.LinkedID = ad.PersonID
					) th
					RIGHT JOIN 
						(SELECT
								dbo.Partenon_Format(c.[ContractNo]) as [Contract No]
							,CASE WHEN ISNULL(c.CardNo,'') = '' THEN dbo.LegacyNo_Format(c.LegacyNo) ELSE dbo.CardNo_Format(c.CardNo) END as [Account No]
							,dbo.fnProductName(c.ContractTypeID) as [Product Type]
							,dbo.fnProductSubName(c.ID) as [Product SubType]
							,c.[OpenDate] as [Contract Open Date]
							,ISNULL(CONVERT(VARCHAR(10),c.[CloseDate],121),'') as [Contract Close Date]
							,p.[ID] as [Customer ID]
							,cust.[FNumber] as [FNumber]
							,p.[FirstName] as [Customer First Name]
							,p.[MiddleInitial] as [Customer Middle Initial]
							,p.[LastName] as [Customer Last Name]
							,p.[Origin]
							,c.ContractTypeId
						FROM [Contract] c 
							JOIN [Person] p ON p.ID = c.PersonID 
								JOIN [Customer] cust ON p.ID = cust.PersonID
						WHERE c.IsDeleted = 0
						) t ON th.ID = t.[Customer ID]
					JOIN [Person] sm ON th.LinkedId = sm.ID	 
				WHERE th.RN = 1
					--AND ISNULL(th.NoticeDate,'') = '' AND ISNULL(th.StartDate,'') = '' AND ISNULL(th.EndDate,'') = ''
 					
					AND ((@ProductCategory = 'Consumer Loan + Home Equity' AND dbo.fnProductName(t.ContractTypeId) IN ('Consumer Loan','Home Equity'))
					OR @ProductCategory =  dbo.fnProductName(t.ContractTypeId)
					OR @ProductCategory = 'All' )
				
				ORDER BY t.[Product Type], th.ID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='All'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Commercial Loan'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Credit Card'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Consumer Loan'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Home Equity'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Consumer Loan + Home Equity'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Mortgage'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Safe Deposit Box'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Serviced by SCUSA'
EXEC [dbo].[spProducts_EXL_Report] @ProductCategory='Other'
*/




GO

/****** Object:  StoredProcedure [dbo].[spExpiredAccounts_EXL_Report]    Script Date: 5/6/2020 4:03:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- ===============================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<Expired Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===============================================================
CREATE PROCEDURE [dbo].[spExpiredAccounts_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (
				SELECT	BenefitIntervalId,ContactDate,IdentificationMethod,OriginalMethodofContact,SMID,FNumber,SMFirstName,SMMiddleInitial,SMLastName,Branch,Reserv,ADSD,
						ADED,ADCount,[Status],TaskStatus,BenefitAppliedDate,BenefitEffectiveDate,ExpectedRemovalDate,BenefitRemovedDate,ExtendDate,CustID,
						CustFNumber,CustFirstName,CustMiddleInitial,CustLastName,ContractNo,AccountNo,ProductType,ProductSubType,ProductOpenDate,ProductCloseDate
				FROM (
				SELECT DISTINCT ROW_NUMBER() OVER (PARTITION BY b.BenefitIntervalID ORDER BY i.inquiryDate DESC) as RN,b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,ISNULL(adr.ADCount,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														LEFT JOIN [Customer] sm on   sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND t.TaskType IN ('remove_benefit')
							--AND b.[Status] IN ('removed','removing')
							AND c.IsDeleted = 0
							--AND (ISNULL(c.CloseDate,'') >= CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) OR c.CloseDate IS NULL)
							AND ISNULL(bd.BenefitRemovedDate,'') >= @DateStart AND ISNULL(bd.BenefitRemovedDate,'') <= @DateEnd
							AND	ISNULL(bd.ExtendDate,'1900-01-01') < ISNULL(bd.BenefitRemovedDate,'9999-12-31') 
							--AND ISNULL(bd.BenefitAppliedDate,'') <> ISNULL(bd.BenefitRemovedDate,'')
					) th
				WHERE RN = 1
				) th
				ORDER BY BenefitRemovedDate
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spExpiredAccounts_EXL_Report] @DateStart='2020-04-01',@DateEnd='2020-04-30'
*/


GO

/****** Object:  StoredProcedure [dbo].[spNewAccounts_EXL_Report]    Script Date: 5/6/2020 4:03:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- ===========================================================
-- Author:		<Aleksey Mazur>
-- Create date: <01/07/2020>
-- Modified:	<01/16/2019>
-- Description:	<New Accounts Benefits Report with parameters>
-- Version:		<1.0>
-- ===========================================================
CREATE PROCEDURE [dbo].[spNewAccounts_EXL_Report] 
	@DateStart date,
	@DateEnd date
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (			
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,CONVERT(VARCHAR(10),adr.ADSD,121) as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,ISNULL(adr.ADCount ,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
												ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
												JOIN [Customer] cust on cust.PersonID = c.PersonID
													LEFT JOIN [Customer] sm on   sm.PersonID = adr.PersonID
														JOIN Person smn on smn.ID = adr.PersonID
						WHERE 1 = 1
							AND ISNULL(t.[Status],'') <> 'misdirected'
							AND (t.TaskType = 'add_benefit'/* OR t.TaskType IS NULL*/)
							
							AND (
									(
										(ISNULL(bd.BenefitAppliedDate,'') >= @DateStart AND ISNULL(bd.BenefitAppliedDate,'') <= @DateEnd)
										--OR 
										--(ISNULL(bd.BenefitEffectiveDate,'') >= @DateStart AND ISNULL(bd.BenefitEffectiveDate,'') <= @DateEnd)
									) 
									AND bd.BenefitAppliedDate IS NOT NULL
								)
							AND c.IsDeleted = 0
						--AND (ISNULL(bd.BenefitRemovedDate,'') > @DateEnd OR bd.BenefitRemovedDate IS NULL)
						--AND i.InquiryDate < @DateEnd
					) th
				ORDER BY SMID
		
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spNewAccounts_EXL_Report] @DateStart='2020-04-01',@DateEnd='2020-04-30'
*/


GO

/****** Object:  StoredProcedure [dbo].[spThirtyDaysList_EXL_Report]    Script Date: 5/6/2020 4:03:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[spThirtyDaysList_EXL_Report]
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;
	
	DECLARE 
			@ErrorNumber    INT,
			@ErrorMessage   VARCHAR(2048),
			@ErrorSeverity  INT,
			@ErrorLine  INT,
			@ErrorSource    SYSNAME,
			@ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION
	
				SELECT DISTINCT 
					  p.ID as [Servicemember ID]
					 ,p.FirstName as [Servicemember First Name]
					 ,p.MiddleInitial as [Servicemember Middle Initial]
					 ,p.LastName as [Servicemember Last Name]
					 ,cus.FNumber as [FNumber]
					 --,bd.ExpectedRemovalDate,bd.BenefitRemovedDate
					 ,COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate) as [Expected Removal Date]
					 ,DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)) as [Days Left]
					 ,dbo.fnProductName(c.ContractTypeId) + CASE WHEN LEN(dbo.fnProductSubName(c.ID)) = 0 THEN '' ELSE ' - ' + dbo.fnProductSubName(c.ID) END as [Product Name]
					 ,ISNULL(COALESCE(CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN NULL 
											ELSE dbo.LegacyNo_Format(c.LegacyNo) END,
									  CASE WHEN ISNULL(c.CardNo,'') = '' THEN NULL 
											ELSE dbo.CardNo_Format(c.CardNo) END),'') as [Product Account #]
				FROM dbo.Person p 
					INNER JOIN dbo.Customer cus 
						ON p.ID = cus.PersonID
					INNER JOIN dbo.[Contract] c 
						ON p.ID  = c.PersonID
					INNER JOIN dbo.ContractType ct 
						ON c.ContractTypeId = ct.ID
					INNER JOIN dbo.Benefit b 
						ON c.ID = b.ContractID
					INNER JOIN dbo.BenefitDetail bd 
						ON b.ID = bd.BenefitId 
				WHERE (((DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate))) BETWEEN 0 AND 30))
					ORDER BY (DateDiff(DAY,CAST(GETDATE() as DATE),COALESCE(bd.ExpectedRemovalDate,bd.BenefitRemovedDate)))

			COMMIT TRANSACTION
	    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
	    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END
/*
EXEC [dbo].[spThirtyDaysList_EXL_Report]
*/
GO

/****** Object:  StoredProcedure [dbo].[spCurrentlyReceivingBenefits_EXL_Report]    Script Date: 5/6/2020 4:03:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =================================================================
-- Author:		<Aleksey Mazur>
-- Create date: <12/26/2019>
-- Modified:	<01/16/2019>
-- Description:	<Curently Receiving Benefits Report with parameters>
-- Version:		<1.0>
-- =================================================================
CREATE PROCEDURE [dbo].[spCurrentlyReceivingBenefits_EXL_Report] 
	@DateStart date,
	@DateEnd date,
	@ProductCategory varchar(50)
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 

				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (
				SELECT DISTINCT b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN CONVERT(VARCHAR(10),adr.ADED,121) ELSE NULL END END as ADED 
					,ISNULL(adr.ADCount,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														LEFT JOIN [Customer] sm on   sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
																	WHERE b.BenefitIntervalId
						IN		
						(
							SELECT ISNULL(b.BenefitIntervalId,0) as BenefitIntervalId
								FROM [Benefit] b 
									JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 ,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 --,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 --,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 --,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 --,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
								WHERE 1 = 1
									AND ISNULL(t.[Status],'') <> 'misdirected'
									AND (t.TaskType = 'add_benefit' OR t.TaskType = 'continue_benefit') 
									--AND (ISNULL(bd0.BenefitAppliedDate,'') <= CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR bd0.BenefitAppliedDate IS NULL)
									AND (ISNULL(bd0.BenefitAppliedDate,'9999-12-31') <= CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR bd0.BenefitAppliedDate IS NULL)
						) 
						AND b.BenefitIntervalId NOT IN 
						(	
							SELECT ISNULL(b.BenefitIntervalId,0)
								FROM [Benefit] b 
									JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 --,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 --,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 ,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 --,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 ,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
									WHERE 1 = 1
										AND ISNULL(t.[Status],'') <> 'misdirected'
										AND t.TaskType = 'remove_benefit' 
										AND (ISNULL(bd0.BenefitRemovedDate,'9999-12-31') > (ISNULL(bd0.ExtendDate,'1900-01-01')))
										AND (ISNULL(bd0.BenefitRemovedDate,'1900-01-01') < CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) OR bd0.BenefitRemovedDate IS NULL)
										--AND (ISNULL(bd0.BenefitRemovedDate,'1900-01-01') <= CONVERT(VARCHAR(10),@DateEnd,121) OR bd0.BenefitRemovedDate IS NULL)
										--GROUP BY b.BenefitIntervalId
						)
						AND 
						(
						      (TaskType = 'add_benefit'			AND  ISNULL(bd.BenefitRemovedDate,'9999-12-31') >= CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) AND bd.ExtendDate IS NULL)
						  OR  (TaskType = 'continue_benefit'	AND (ISNULL(bd.BenefitRemovedDate,'9999-12-31') >= CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) OR ISNULL(bd.BenefitRemovedDate,'9999-12-31') <  ISNULL(bd.ExtendDate,'1900-01-01')) ) 
						  OR  (TaskType = 'extend_benefit'		AND (ISNULL(bd.BenefitRemovedDate,'9999-12-31') >= CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) OR ISNULL(bd.BenefitRemovedDate,'9999-12-31') <  ISNULL(bd.ExtendDate,'1900-01-01') ))
						)
						AND ISNULL(t.[Status],'') <> 'misdirected'
						AND ISNULL(b.[Status],'') <> ''
						AND c.IsDeleted = 0 
						AND (ISNULL(c.CloseDate,'') >= CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE) OR c.CloseDate IS NULL)
						
						--AND NOT (ISNULL(b.[Status],'') IN ('applying','extending') AND bd.BenefitAppliedDate IS NULL) 

						/* INCLUDING TASK IN PROCESS WITH APPLY OR EXTEND DATE PRESENT */
						AND NOT (ISNULL(b.[Status],'') IN ('applying') AND bd.BenefitAppliedDate IS NULL)
						AND NOT (ISNULL(b.[Status],'') IN ('extending') AND bd.ExtendDate IS NULL)
						/* ONLY THE ONES THAT NEED TO BE REMOVED AS MISSING APPLY DATE OR EXTEND DATE FOR TASK IN PROCES */
						--AND ((ISNULL(b.[Status],'') IN ('applying') AND bd.BenefitAppliedDate IS NULL)
						--	OR (ISNULL(b.[Status],'') IN ('extending') AND bd.ExtendDate IS NULL))

						AND ((@ProductCategory = 'Consumer Loan + Home Equity' AND dbo.fnProductName(c.ContractTypeId) IN ('Consumer Loan','Home Equity'))
						OR @ProductCategory =  dbo.fnProductName(c.ContractTypeId)
						OR @ProductCategory = 'All' )
					) th

				ORDER BY SMID,ISNULL(CONVERT(VARCHAR(10),BenefitAppliedDate,121),'')
			
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='All'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Auto'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Commercial Loan'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Credit Card'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Consumer Loan'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Home Equity'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2020-02-01',@DateEnd='2020-02-29',@ProductCategory='Consumer Loan + Home Equity'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Mortgage'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Safe Deposit Box'
EXEC [dbo].[spCurrentlyReceivingBenefits_EXL_Report] @DateStart='2019-12-01',@DateEnd='2019-12-31',@ProductCategory='Other'
*/


GO

/****** Object:  StoredProcedure [dbo].[spOpenActiveBenefits_EXL_Report]    Script Date: 5/6/2020 4:03:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =========================================================
-- Author:		<Aleksey Mazur>
-- Create date: <12/26/2019>
-- Modified:	<01/16/2019>
-- Description:	<Open Active Benefits Report with parameters>
-- Version:		<1.0>
-- ==========================================================
CREATE PROCEDURE [dbo].[spOpenActiveBenefits_EXL_Report] 
	@DateStart date,
	@DateEnd date	
WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION 
			
				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date]
				FROM (
				SELECT DISTINCT   b.BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
						WHEN 'internal' THEN 'Proactive'
						WHEN 'line_business' THEN 'Line of Business'
						WHEN 'customer' THEN 'Customer Originated'
						WHEN 'third_party' THEN 'Third Party Service Provider'
						WHEN '' THEN ''
						ELSE ''
					END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					,b.PersonID as SMID,sm.FNumber,smn.FirstName as SMFirstName,smn.MiddleInitial as SMMiddleInitial,smn.LastName as SMLastName
					,adr.Branch,adr.Reserv
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					,ISNULL(adr.ADCount,0) as ADCount
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,t.[Status] as TaskStatus
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					,c.PersonID as CustID,cust.FNumber as CustFNumber,p.FirstName as CustFirstName,p.MiddleInitial as CustMiddleInitial,p.LastName as CustLastName
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate
				FROM [Benefit] b 
							LEFT JOIN [Contract] c ON (b.ContractID = c.ID)
								JOIN [Person] p ON c.PersonID = p.ID
									JOIN [Task] t on b.TaskID = t.ID
										JOIN Inquiry i on t.InquiryID = i.ID
											JOIN 
												(SELECT b1.BenefitIntervalId,MIN(ad.StartDate) as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
													   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv 
												FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
													ON adr.BenefitIntervalId = b.BenefitIntervalId
												LEFT JOIN (SELECT bb.BenefitIntervalID
															,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
															,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
															,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
															,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
															,MAX(bd1.ExtendDate) as ExtendDate 
															FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
													JOIN [Customer] cust on cust.PersonID = c.PersonID
														LEFT JOIN [Customer] sm on sm.PersonID = adr.PersonID
															JOIN Person smn on smn.ID = adr.PersonID
																	WHERE b.BenefitIntervalId
						IN		
						(
							SELECT ISNULL(b.BenefitIntervalId,0) as BenefitIntervalId
								FROM [Benefit] b 
									JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 ,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 --,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 --,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 --,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 --,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
								WHERE 1 = 1
									AND ISNULL(t.[Status],'') <> 'misdirected'
									AND (t.TaskType = 'add_benefit' OR t.TaskType = 'continue_benefit') 
									AND (ISNULL(bd0.BenefitAppliedDate,'1900-01-01') < CAST(CONVERT(VARCHAR(10),@DateStart,121) as DATE))
						)	
						AND b.BenefitIntervalId NOT IN 
						(	
								SELECT ISNULL(b.BenefitIntervalId,0)
									FROM [Benefit] b 
										JOIN [Task] t on b.TaskID = t.ID
										JOIN (SELECT bb.BenefitIntervalID
											 ,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
											 --,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
											 ,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
											 --,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
											 ,MAX(bd1.ExtendDate) as ExtendDate 
											FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd0 ON b.BenefitIntervalId = bd0.BenefitIntervalId
									WHERE 1 = 1
										AND ISNULL(t.[Status],'') <> 'misdirected'
										AND t.TaskType IN ('remove_benefit') 
										AND (ISNULL(bd0.BenefitRemovedDate,'9999-12-31') > (ISNULL(bd0.ExtendDate,'1900-01-01')))
										AND (ISNULL(bd0.BenefitRemovedDate,'1900-01-01') <= CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR bd0.BenefitRemovedDate IS NULL) 
									--GROUP BY b.BenefitIntervalId
						)
						AND 
						(
						      (TaskType = 'add_benefit'		 AND  ISNULL(bd.BenefitRemovedDate,'9999-12-31') > CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) AND bd.ExtendDate IS NULL)
						  OR  (TaskType = 'continue_benefit' AND (ISNULL(bd.BenefitRemovedDate,'9999-12-31') > CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR ISNULL(bd.BenefitRemovedDate,'9999-12-31') <  ISNULL(bd.ExtendDate,'1900-01-01'))) 
						  OR  (TaskType = 'extend_benefit'	 AND (ISNULL(bd.BenefitRemovedDate,'9999-12-31') > CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR ISNULL(bd.BenefitRemovedDate,'9999-12-31') <  ISNULL(bd.ExtendDate,'1900-01-01')))
		                )
						AND ISNULL(t.[Status],'') <> 'misdirected'
						AND ISNULL(b.[Status],'') <> ''
						AND c.IsDeleted = 0 
						AND (ISNULL(c.CloseDate,'') > CAST(CONVERT(VARCHAR(10),@DateEnd,121) as DATE) OR c.CloseDate IS NULL) 	
						
						--AND NOT (ISNULL(b.[Status],'') IN ('applying','extending') AND bd.BenefitAppliedDate IS NULL)

						/* INCLUDING TASK IN PROCESS WITH APPLY OR EXTEND DATE PRESENT */
						AND NOT (ISNULL(b.[Status],'') IN ('applying') AND bd.BenefitAppliedDate IS NULL)
						AND NOT (ISNULL(b.[Status],'') IN ('extending') AND bd.ExtendDate IS NULL)
						/* ONLY THE ONES THAT NEED TO BE REMOVED AS MISSING APPLY DATE OR EXTEND DATE FOR TASK IN PROCES */
						--AND ((ISNULL(b.[Status],'') IN ('applying') AND bd.BenefitAppliedDate IS NULL)
						--	OR (ISNULL(b.[Status],'') IN ('extending') AND bd.ExtendDate IS NULL))

					) th

				ORDER BY SMID,ISNULL(CONVERT(VARCHAR(10),BenefitAppliedDate,121),'')
			
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END			

END

/*

EXEC [dbo].[spOpenActiveBenefits_EXL_Report] @DateStart='2020-02-01',@DateEnd='2020-02-29'

*/


GO

