USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spBenefits_To_Review_SLA_EXL_Report]    Script Date: 03/23/2020 13:59:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/19/2020>
-- Modified:	<03/19/2020>
-- Description:	<Benefit to be reviewed>
-- =============================================
CREATE PROCEDURE [dbo].[spBenefits_To_Review_SLA_EXL_Report]
	@DateStart date,
	@DateEnd date
WITH RECOMPILE	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE 
        @ErrorNumber    INT,
        @ErrorMessage   VARCHAR(2048),
        @ErrorSeverity  INT,
        @ErrorLine  INT,
        @ErrorSource    SYSNAME,
        @ErrorState INT;        

	BEGIN

		BEGIN TRY

			BEGIN TRANSACTION

				SELECT	[ContactDate] as [Contact Date],
						[IdentificationMethod] as [Identification Method],
						[OriginalMethodOfContact] as [Original Contact Method],
						[SMID] as [Servicemember ID],
						[FNumber] as [Servicemember FNumber],
						[SMFirstName] as [Servicemember First Name],
						[SMMiddleInitial] as [Servicemember Middle Initial],
						[SMLastName] as [Servicemember Last Name],
						[Branch] as [Branch],
						[Reserv] as [Reserv],
						[ADSD] as [Active Duty Start Date],
						[ADED] as [Active Duty End Date],
						[Status] as [Benefit Status],
						[BenefitAppliedDate] as [Benefit Applied Date],
						[BenefitEffectiveDate] as [Benefit Effective Date],
						[ExpectedRemovalDate] as [Expected Removal Date],
						[BenefitRemovedDate] as [Benefit Removed Date],
						[ExtendDate] as [Extend Date],
						[CustID] as [Customer ID],
						[CustFNumber] as [Customer FNumber],
						[CustFirstName] as [Customer First Name],
						[CustMiddleInitial] as [Customer Middle Initial],
						[CustLastName] as [Customer Last Name],
						[ContractNo] as [Contract #],
						[AccountNo] as [Account #],
						[ProductType] as [Product Type],
						[ProductSubType] as [Product SubType],
						[ProductOpenDate] as [Product Open Date],
						[ProductCloseDate] as [Product Close Date],
						[DueDate] as [Due Date]
				FROM (
				SELECT CONVERT(VARCHAR(10),ISNULL(b.BenefitIntervalId,'')) as BenefitIntervalId
					,ISNULL(CONVERT(VARCHAR(10),cast(i.InquiryDate as DATE),121),'') as ContactDate
					,CASE ISNULL(i.IdentificationMethod,'') 
										WHEN 'internal' THEN 'Proactive'
										WHEN 'line_business' THEN 'Line of Business'
										WHEN 'customer' THEN 'Customer Originated'
										WHEN '' THEN ''
										ELSE ''
									END as IdentificationMethod
					,ISNULL(dbo.fnResponseMethodName(i.ContactMethodID),'') as OriginalMethodOfContact
					
					,ISNULL(CONVERT(varchar(10),b.PersonID),'') as SMID
					,ISNULL(CONVERT(varchar(10),sm.FNumber),'') as FNumber
					,ISNULL(CONVERT(VARCHAR(50),COALESCE(smn.FirstName,bp.FirstName)),'') as SMFirstName
					,ISNULL(CONVERT(VARCHAR(50),COALESCE(smn.MiddleInitial,bp.MiddleInitial)),'') as SMMiddleInitial
					,ISNULL(CONVERT(VARCHAR(50),COALESCE(smn.LastName,bp.LastName)),'') as SMLastName	
					,ISNULL(adr.Branch,'') as Branch,ISNULL(adr.Reserv,'') as Reserv,ISNULL(CONVERT(varchar(10),adr.NotificationDate,121),'') as NotificationDate
					,ISNULL(CONVERT(VARCHAR(10),adr.ADSD,121),'') as ADSD
					,CASE WHEN CONVERT(varchar(10),adr.ADED,121) = '9999-12-31' AND ISNULL(adr.ADSD,'') <> '' THEN '' ELSE CASE WHEN ISNULL(adr.ADSD,'') <> '' THEN ISNULL(CONVERT(VARCHAR(10),adr.ADED,121),'') ELSE '' END END as ADED 
					
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END as [Status]
					,CASE WHEN CASE WHEN ISNULL(b.[Status],'') != '' THEN UPPER(SUBSTRING(b.[Status],1,1))+SUBSTRING(b.[Status],2,LEN(b.[Status]) - 1) ELSE '' END = 'denying' THEN b.DenialReason ELSE '' END as DenialReason
					,CASE WHEN ISNULL(b.[Status],'') != '' THEN CASE WHEN RIGHT(ISNULL(b.[Status],''),3) = 'ing' THEN REPLACE(t.[Status],'qa_','') ELSE t.[Status] END END as TaskStatus
					
					,ISNULL(CONVERT(VARCHAR(10),bd.BenefitAppliedDate,121),'') as BenefitAppliedDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitEffectiveDate,121),'') as BenefitEffectiveDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExpectedRemovalDate,121),'') as ExpectedRemovalDate,ISNULL(CONVERT(VARCHAR(10),bd.BenefitRemovedDate,121),'') as BenefitRemovedDate
					,ISNULL(CONVERT(VARCHAR(10),bd.ExtendDate,121),'') as ExtendDate
					
					,ISNULL(CONVERT(VARCHAR(10),c.PersonID),'') as CustID
					,ISNULL(CONVERT(VARCHAR(10),cust.FNumber),'') as CustFNumber
					,ISNULL(CONVERT(VARCHAR(50),p.FirstName),'') as CustFirstName
					,ISNULL(CONVERT(VARCHAR(50),p.MiddleInitial),'') as CustMiddleInitial
					,ISNULL(CONVERT(VARCHAR(50),p.LastName),'') as CustLastName
					
					,ISNULL(CONVERT(VARCHAR(50),c.ID),'') as ContractID
					,dbo.PARTENON_Format(c.ContractNo) as ContractNo
					,CASE WHEN ISNULL(c.LegacyNo,'') = '' THEN dbo.CardNo_Format(c.CardNo) ELSE dbo.LegacyNo_Format(c.LegacyNo) END as AccountNo
					,ISNULL(dbo.fnProductName(c.ContractTypeId),'') as ProductType
					,ISNULL(dbo.fnProductSubName(c.ID),'') as ProductSubType
					,ISNULL(CONVERT(VARCHAR(10),c.OpenDate,121),'') as ProductOpenDate
					,ISNULL(CONVERT(VARCHAR(10),c.CloseDate,121),'') as ProductCloseDate 

					,CASE WHEN b.[Status] = 'applying' THEN ISNULL(CONVERT(varchar(10),DATEADD(day, 60, i.InquiryDate) ,121),'')
						  WHEN b.[Status] = 'denying' THEN ''
						  WHEN b.[Status] = 'removing' THEN 
							CASE WHEN dbo.fnProductName(c.ContractTypeId) IN ('Credit card','Consumer Loan','Home Equity') 
									THEN CASE WHEN adr.ADED <> '9999-12-31' THEN ISNULL(CONVERT(varchar(10),DATEADD(day, 90, adr.ADED) ,121),'') ELSE '' END
								 WHEN dbo.fnProductName(c.ContractTypeId) IN ('Mortgage') 
									THEN CASE WHEN adr.ADED <> '9999-12-31' THEN ISNULL(CONVERT(varchar(10),DATEADD(day, 365, adr.ADED) ,121),'') ELSE  '' END
								 ELSE ''
							END

					 END as DueDate										
				  FROM [Benefit] b 
					LEFT JOIN [Task] t ON ISNULL(b.TaskID,'') = ISNULL(t.ID,'')
						LEFT JOIN [Inquiry] i ON ISNULL(t.InquiryID,'') = ISNULL(i.ID,'')
							LEFT JOIN [Contract] c ON ISNULL(b.ContractID,'') = ISNULL(c.ID,'')
								LEFT JOIN [Person] p ON ISNULL(c.PersonID,'') = ISNULL(p.ID,'')
							LEFT JOIN 
									(SELECT b1.BenefitIntervalId,ISNULL(CONVERT(VARCHAR(10),MIN(ad.StartDate),121),'') as ADSD,MAX(ISNULL(ad.EndDate,'9999-12-31')) as ADED,ad.PersonID, COUNT(b1.ActiveDutyID) as ADCount, 
										   MAX(dbo.fnServiceBranchByID(ad.BranchOfServiceID)) as Branch, MAX(dbo.fnIsReservistByBranchID(ad.BranchOfServiceID)) as Reserv,
										   MAX(ad.NoticeDate) as NotificationDate 
									FROM ActiveDuty ad JOIN Benefit b1 on b1.ActiveDutyID = ad.ID WHERE b1.BenefitIntervalId IS NOT NULL GROUP BY b1.BenefitIntervalID,ad.PersonID) adr
									ON b.BenefitIntervalId = adr.BenefitIntervalId
								LEFT JOIN (SELECT bb.BenefitIntervalID
												,MAX(bd1.BenefitAppliedDate) as BenefitAppliedDate
												,MAX(bd1.BenefitEffectiveDate) as BenefitEffectiveDate
												,MAX(bd1.BenefitRemovedDate) as BenefitRemovedDate
												,MAX(bd1.ExpectedRemovalDate) as ExpectedRemovalDate 
												,MAX(bd1.ExtendDate) as ExtendDate 
												FROM [BenefitDetail] bd1 JOIN Benefit bb ON bd1.BenefitId = bb.ID GROUP BY bb.BenefitIntervalID) bd ON b.BenefitIntervalId = bd.BenefitIntervalId
									LEFT JOIN [Customer] cust on ISNULL(c.PersonID,'') = ISNULL(cust.PersonID,'')
										LEFT JOIN [Customer] sm on ISNULL(adr.PersonID,'') = ISNULL(sm.PersonID,'')
											LEFT JOIN [Person] smn on ISNULL(adr.PersonID,'') = ISNULL(smn.ID,'')
												LEFT JOIN [Person] bp ON b.PersonID = bp.ID
				  WHERE b.[Status] IN ('applying','denying','removing') and t.[Status] <> 'misdirected'
						AND (t.TaskType IN ('add_benefit','deny_benefit','remove_benefit'))
						AND ((b.[Status] IN ('applying') AND bd.BenefitAppliedDate IS NULL) OR
							(b.[Status] IN ('denying')) OR
							(b.[Status] IN ('removing') AND bd.BenefitRemovedDate IS NULL))
						AND ISNULL(c.IsDeleted,0) = 0
						AND ISNULL(i.InquiryDate,'9999-12-31') <= @DateEnd
				) th
				ORDER BY SMID
				
			COMMIT TRANSACTION
    
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION        
			SET @ErrorMessage = ERROR_MESSAGE();
			SET @ErrorSource  = ISNULL(ERROR_PROCEDURE(), 'Unknown');
			SET @ErrorLine    = ERROR_LINE();
			SET @ErrorSeverity= ERROR_SEVERITY();
			SET @ErrorState   = ERROR_STATE();
			GOTO ErrorHandler;
		END CATCH
		RETURN;
    
		ErrorHandler:
			RAISERROR('The following error has occured in the object [%s]: Error Number %d on line %d with message [%s]',
						@ErrorSeverity, @ErrorState, @ErrorSource, @ErrorNumber, @ErrorLine, @ErrorMessage)  

	END

END

/*
EXEC [dbo].[spBenefits_To_Review_SLA_EXL_Report] @DateStart = '2020-01-01',@DateEnd = '2020-03-19'
*/


GO


