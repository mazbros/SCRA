﻿namespace Scra.Model.Persons
{
    public class Address
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public ZipCode ZipCode { get; set; }

        public static Address Empty()
        {
            return new Address();
        }

        public static Address Create(string address1, string address2, string city, AddressState state, ZipCode zipCode)
        {
            return new Address
            {
                Address1 = address1,
                Address2 = address2,
                City = city,
                State = state.Abbreviation,
                ZipCode = zipCode
            };
        }

        public string GetFull()
        {
            var text = string.Format("{0}, {1}, \n{2}, {3} {4}", Address1, Address2, City, State, ZipCode.GetDisplay());
            return text.Trim(',', ' ');
        }

        public string GetFullOneLine()
        {
            var text = string.Format("{0}, {1}, {2}, {3} {4}", Address1, Address2, City, State, ZipCode.GetDisplayNoZeros());
            return text.Trim(',', ' ');
        }

        public string GetStreetAndApartment()
        {
            var text = string.Format("{0}, {1}", Address1, Address2);
            return text.Trim(',', ' ');
        }

        public string GetCityZipState()
        {
            var text = string.Format("{0}, {1}, {2}", City, State, ZipCode.GetDisplay());
            return text.Trim(',', ' ');
        }

        public bool Equals(Address address)
        {
            if (Address1 == address.Address1 && Address2 == address.Address2 && City == address.City &&
                State == address.State && ZipCode.ToString() == address.ZipCode.ToString())
            {
                return true;
            }

            return false;
        }
    }
}