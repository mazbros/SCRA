﻿using Scra.Model.DomainEvents;

namespace Scra.Model.Persons
{
    public class FNumberChangedEvent : IDomainEvent
    {
        public Person Person { get; private set; }

        public FNumberChangedEvent(Person person)
        {
            Person = person;
        }
    }
}
