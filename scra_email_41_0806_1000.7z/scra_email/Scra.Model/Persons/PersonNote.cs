﻿using System;

namespace Scra.Model.Persons
{
    public class PersonNote
    {
        public PersonNote(string text, PersonId personId)
        {
            Text = text;
            PersonId = personId;
        }

        public PersonNote(string text, PersonId personId, DateTime modifiedTime, string modifiedByName)
        {
            Text = text;
            PersonId = personId;
            ModifiedByName = modifiedByName;
            ModifiedTime = modifiedTime;
        }

        public int Id { get; set; }
        public string Text { get; private set; }
        public PersonId PersonId { get; private set; }
        public string ModifiedByName { get; private set; }
        public DateTime ModifiedTime { get; private set; }
    }
}