﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Scra.Model.Extensions
{
    public static class ListExtension
    {
        public static IReadOnlyCollection<T> AsReadOnly<T>(this IList<T> list)
        {
            return new ReadOnlyCollection<T>(list);
        }

        public static bool IsNotEmpty<T>(this IList<T> list)
        {
            return list != null && list.Count > 0;
        }

        public static ObservableCollection<T> AddRange<T>(this ObservableCollection<T> collection, IEnumerable<T> newItems)
        {
            foreach (var newItem in newItems)
            {
                collection.Add(newItem);
            }
            return collection;
        }

        public static ObservableCollection<T> Update<T>(this ObservableCollection<T> collection, IEnumerable<T> newItems)
        {
            collection.Clear();
            AddRange(collection, newItems);
            return collection;
        }

        public static ObservableCollection<T> Refresh<T>(this ObservableCollection<T> collection)
        {
            Update(collection, collection.ToList());
            return collection;
        }
    }
}