﻿using System;
using Scra.Model.ContactMethods;

namespace Scra.Model.Inquiries
{
    public class InquiryResponse
    {
        public ContactMethod Method { get; set; }
        public DateTime? Date { get; set; }
        public string Text { get; set; }
    }
}