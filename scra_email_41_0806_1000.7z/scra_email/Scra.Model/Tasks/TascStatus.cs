﻿using System;
using System.Collections.Generic;

namespace Scra.Model.Tasks
{
    public struct TascStatus : IEquatable<TascStatus>
    {
        private readonly string _code;
        private readonly string _name;

        public string Code
        {
            get { return _code; }
        }
        public string Name
        {
            get { return _name; }
        }

        public static readonly TascStatus Empty = new TascStatus("", "");
        public static readonly TascStatus Created = new TascStatus("created", "Created");
        public static readonly TascStatus Completed = new TascStatus("completed", "Completed");
        public static readonly TascStatus InProcess = new TascStatus("in_process", "In Process");
        public static readonly TascStatus Rejected = new TascStatus("rejected", "Rejected");
        public static readonly TascStatus QaCompleted = new TascStatus("qa_completed", "QA Completed");
        public static readonly TascStatus Misdirected = new TascStatus("misdirected", "Misdirected");

        public static IReadOnlyCollection<TascStatus> TascStatusList = new List<TascStatus> { Empty, InProcess, Rejected, Completed, QaCompleted, Misdirected};

        private TascStatus(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static TascStatus Parse(string code)
        {
            if (code == Created.Code)
            {
                return Created;
            }
            if (code == Completed.Code)
            {
                return Completed;
            }
            if (code == InProcess.Code)
            {
                return InProcess;
            }
            if (code == Rejected.Code)
            {
                return Rejected;
            }
            if (code == QaCompleted.Code)
            {
                return QaCompleted;
            }
            if (code == Misdirected.Code)
            {
                return Misdirected;
            }

            return Empty;
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public bool Equals(TascStatus other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is TascStatus))
            {
                return false;
            }
            return Equals((TascStatus)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(TascStatus obj1, TascStatus obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(TascStatus obj1, TascStatus obj2)
        {
            return !(obj1 == obj2);
        }
    }
}
