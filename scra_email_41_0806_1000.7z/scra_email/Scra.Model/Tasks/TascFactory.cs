﻿using System;
using System.Threading.Tasks;
using Scra.Model.Contracts;
using Scra.Model.Inquiries;
using Scra.Model.InquiryTypes;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    internal class TascFactory : ITascFactory
    {
        private readonly ITaskRepository _repository;
        private readonly BenefitsSubTascFactory _benefitsSubTascFactory;
        private readonly InquirySubTascFactory _inquirySubTascFactory;

        public TascFactory(ITaskRepository repository, InquirySubTascFactory inquirySubTascFactory)
        {
            _repository = repository;
            _benefitsSubTascFactory = new BenefitsSubTascFactory();
            _inquirySubTascFactory = inquirySubTascFactory;
        }

        public async Task<Tasc> CreateRequest(Inquiry inquiry)
        {
            var type = inquiry.InquiryType;
            var serviceMember = await inquiry.GetServiceMember();
            var name = string.Format("Request - {0}. Servicemember {1}.", type.Name, serviceMember);
            var createTime = DateTime.Now;
            var dueTime = SetDueDate(type);
           
            var subTasks = _inquirySubTascFactory.Create(type);
            var user = Di.Get<IUser>();
            var assignee = type == InquiryType.BENEFIT_REQUEST ? User.Empty : user;

            var taskType = InquiryType.ToTaskType(type);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, taskType, subTasks,
                assignee, User.Empty, inquiry.Id, inquiry.ServicememberId, ContractId.Empty, false);

            await _repository.Create(task);

            //var firstSub = task.SubTasks.First();
            //if (firstSub.Type == SubTaskType.LogRequest)
            //{
            //    await firstSub.Complete();
            //}

            return task;
        }

       

        public DateTime SetDueDate(InquiryType inquiryType)
        {
            var createTime = DateTime.Now;
            var switchTime = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 15, 0, 0);
            DateTime dueDate;

            if(inquiryType == InquiryType.DMDC_CHECK || inquiryType == InquiryType.AFFILIATE || inquiryType == InquiryType.INQUIRY)
            {
                dueDate = createTime.AddDays(DateTime.Compare(createTime, switchTime) < 0 ? 0 : 1);
            }
            else
            {
                dueDate = createTime.AddDays(60);
            }

            return dueDate;
        }

        public async Task<Tasc> AddBenefit(ContractId contractId)
        {           
            var createTime = DateTime.Now;
            var dueTime = SetDueDate(InquiryType.BENEFIT_REQUEST);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);
            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = "Add " + contract.Type.Category.Name + " benefits for " + person.Name + ", contract #" + contract.ContractNo;
            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.AddBenefit);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.ADD_BENEFIT, subTasks,
                User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> EditBenefit(ContractId contractId, TaskType taskType)
        {
            var createTime = DateTime.Now;
            var dueTime = SetDueDate(InquiryType.BENEFIT_REQUEST);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);
            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = taskType.Name + " for "+ contract.Type.Category.Name + " benefits for " + person.Name + ", contract #" + contract.ContractNo;
            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.EditBenefit);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, taskType, subTasks,
                User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> ContactCustomer(ContractId contractId)
        {
            var createTime = DateTime.Now;
            var dueTime = createTime.AddDays(10);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);

            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = "Contact " + person.Name + " for contract #" + contract.ContractNo;

            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.ContactCustomer);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.CONTACT_CUSTOMER, subTasks, User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> ExtendBenefit(ContractId contractId)
        {
            var createTime = DateTime.Now;
            var dueTime = createTime.AddDays(10);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);

            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = "Extend " + contract.Type.Category.Name + " benefits for " + person.Name + ", contract #" + contract.ContractNo;

            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.ContactCustomer);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.EXTEND_BENEFIT, subTasks, User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> RemoveBenefit(ContractId contractId)
        {
            var createTime = DateTime.Now;
            var dueTime = createTime.AddDays(10);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);
            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = "Remove " + contract.Type.Category.Name + " benefits for " + person.Name + ", contract #" + contract.ContractNo;

            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.RemoveBenefit);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.REMOVE_BENEFIT, subTasks,
                User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> DenyBenefit(ContractId contractId)
        {
            var createTime = DateTime.Now;
            var dueTime = createTime.AddDays(10);

            var contractRepository = Di.Get<IContractRepository>();
            var contract = await contractRepository.Get(contractId);
            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(contract.PersonId);

            var name = "Deny " + contract.Type.Category.Name + " benefits for " + person.Name + ", contract #" + contract.ContractNo;

            var subTasks = _benefitsSubTascFactory.Create(contract, BenefitsSubTascFactory.DenyBenefit);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.DENY_BENEFIT, subTasks,
                User.Empty, User.Empty, 0, contract.PersonId, contractId, false);
            await _repository.Create(task);

            return task;
        }

        public async Task<Tasc> DenyBenefit(PersonId personId)
        {
            var createTime = DateTime.Now;
            var dueTime = createTime.AddDays(10);

            var personRepository = Di.Get<IPersonRepository>();
            var person = await personRepository.Get(personId);

            var name = "Deny benefit request due to no product for " + person.Name.FullName;

            var subTasks = _benefitsSubTascFactory.Create(Contract.Create(personId), BenefitsSubTascFactory.DenyBenefit);

            var task = new Tasc(0, name, createTime, dueTime, TascStatus.Created, TaskType.DENY_BENEFIT, subTasks,
                User.Empty, User.Empty, 0, personId, new ContractId(0), false);
            await _repository.Create(task);

            return task;
        }
    }
}