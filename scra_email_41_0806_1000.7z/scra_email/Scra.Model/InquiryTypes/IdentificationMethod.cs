﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Extensions;

namespace Scra.Model.InquiryTypes
{
    public struct IdentificationMethod : IEquatable<IdentificationMethod>
    {
        public static readonly IdentificationMethod Empty = new IdentificationMethod("", "");
        public static readonly IdentificationMethod Internal = new IdentificationMethod("internal", "Proactive");
        public static readonly IdentificationMethod Customer = new IdentificationMethod("customer", "Customer Originated");
        public static readonly IdentificationMethod LineOfBusiness = new IdentificationMethod("line_business", "Line of Business");
        public static readonly IReadOnlyCollection<IdentificationMethod> List = new List<IdentificationMethod> { Internal, Customer, LineOfBusiness };

        private static readonly Dictionary<string, IdentificationMethod> Map = List.ToDictionary(x => x.Code, x => x);
        private readonly string _code;
        private readonly string _name;

        public string Name
        {
            get { return _name; }
        }
        public string Code
        {
            get { return _code; }
        }

        private IdentificationMethod(string code, string name)
        {
            _code = code;
            _name = name;
        }

        public static IdentificationMethod Parse(string code)
        {
            if (Map.ContainsKey(code))
            {
                return Map[code];
            }

            return Empty;
        }

        public bool IsEmpty()
        {
            return _code.IsEmpty();
        }

        public override int GetHashCode()
        {
            return (_code != null ? _code.GetHashCode() : 0);
        }

        public bool Equals(IdentificationMethod other)
        {
            return _code == other._code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is IdentificationMethod))
            {
                return false;
            }
            return Equals((IdentificationMethod)obj);
        }

        public override string ToString()
        {
            return _name;
        }

        public static bool operator ==(IdentificationMethod obj1, IdentificationMethod obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(IdentificationMethod obj1, IdentificationMethod obj2)
        {
            return !(obj1 == obj2);
        }
    }
}