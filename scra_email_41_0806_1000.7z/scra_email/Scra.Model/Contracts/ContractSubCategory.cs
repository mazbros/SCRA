﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Contracts
{
    public struct ContractSubCategory : IEquatable<ContractSubCategory>
    {
        private readonly string _code;
        private readonly string _name;
        
        public string Name
        {
            get { return _name; }
        }

        public string Code
        {
            get { return _code; }
        }

        public static readonly ContractSubCategory Auto = new ContractSubCategory("auto", "Auto");
        public static readonly ContractSubCategory Mortgage = new ContractSubCategory("mortgage", "Mortgage");
        public static readonly ContractSubCategory SafeDepositBox = new ContractSubCategory("safe_deposit_box", "Safe Deposit Box");

        public static readonly ContractSubCategory LineOfCredit = new ContractSubCategory("line_of_credit", "Line Of Credit");
        public static readonly ContractSubCategory OverdraftLineOfCredit = new ContractSubCategory("overdraft_line_of_credit", "Overdraft Line Of Credit");

        public static readonly ContractSubCategory PersonalLineOfCredit = new ContractSubCategory("personal_line_of_credit", "Personal Line Of Credit");
        public static readonly ContractSubCategory PersonalLoan = new ContractSubCategory("personal_loan", "Personal Loan");
        
        public static readonly ContractSubCategory Other = new ContractSubCategory("other", "Other");

        public static readonly ContractSubCategory Loan = new ContractSubCategory("loan", "Loan");

        public static readonly ContractSubCategory Bravo = new ContractSubCategory("bravo", "Bravo");
        public static readonly ContractSubCategory Sphere = new ContractSubCategory("sphere", "Sphere");
        public static readonly ContractSubCategory Ultimate = new ContractSubCategory("ultimate", "Ultimate");

        public static readonly ContractSubCategory Empty = new ContractSubCategory("empty","");

        public static readonly Dictionary<string, ContractSubCategory> AutoMap =
            new[] { Auto }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> MortgageMap =
            new[] { Mortgage }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> SafeDepositBoxMap =
            new[] { SafeDepositBox }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> ConsumerLoanMap =
            new[] { Empty, PersonalLoan, PersonalLineOfCredit, OverdraftLineOfCredit, Other }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> CommercialMap =
            new[] { Empty, LineOfCredit, OverdraftLineOfCredit, Other }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> HomeEquityMap =
            new[] { Empty, LineOfCredit, Loan, Other }.ToDictionary(x => x.Code, x => x);

        public static readonly Dictionary<string, ContractSubCategory> CreditCardMap =
            new[] { Empty, Bravo, Sphere, Ultimate }.ToDictionary(x => x.Code, x => x);
        
        public static readonly Dictionary<string, ContractSubCategory> OtherMap =
            new[] { Other }.ToDictionary(x => x.Code, x => x);

        public ContractSubCategory(string code, string name)
        {
            _name = name;
            _code = code;
        }

        public static ContractSubCategory Parse(string code, Dictionary<string,ContractSubCategory> map)
        {
            if (code == null)
            {
                return Other;
            }

            ContractSubCategory category;
            if (map.TryGetValue(code, out category))
            {
                return category;
            }
            
            return new ContractSubCategory(code, code);
        }

        public override int GetHashCode()
        {
            return Code != null ? Code.GetHashCode() : 0;
        }

        public bool Equals(ContractSubCategory other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ContractSubCategory))
            {
                return false;
            }
            return Equals((ContractSubCategory)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(ContractSubCategory obj1, ContractSubCategory obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(ContractSubCategory obj1, ContractSubCategory obj2)
        {
            return !(obj1 == obj2);
        }
    }
}