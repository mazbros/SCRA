﻿using System;
using Scra.Model.Persons;

namespace Scra.Model.Dependents
{
    public class DependentLinkFactory
    {
        public static DependentLink Create(int id, DependentType type, PersonId fromId, PersonId toId, DateTime? startDate, DateTime? endTime)
        {
            return new DependentLink
            {
                Id = id,
                Type = type,
                FromId = fromId,
                ToId = toId,
                StartDate = startDate,
                EndDate = endTime
            };
        }

        public static DependentLink Create(PersonId fromId, PersonId toId)
        {
            return new DependentLink
            {
                FromId = fromId,
                ToId = toId
            };
        }

        public static DependentLink Create(PersonId fromId, PersonId toId, DependentType type)
        {
            return new DependentLink
            {
                FromId = fromId,
                ToId = toId,
                Type = type,
            };
        }
    }
}