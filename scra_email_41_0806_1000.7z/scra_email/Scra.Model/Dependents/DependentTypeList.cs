﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.Dependents
{
    public class DependentTypeList
    {
        private IReadOnlyCollection<DependentType> _items;
        private IDictionary<int, DependentType> _idNameMap;

        private DependentTypeList()
        {
        }

        public static DependentTypeList Create(IList<DependentType> items)
        {
            return new DependentTypeList
            {
                _items = items.AsReadOnly(),
                _idNameMap = items.ToDictionary(x => x.Id, x => x)
            };
        }

        public IReadOnlyCollection<DependentType> All()
        {
            return _items;
        }

        public string GetName(int typeId)
        {
            return _idNameMap[typeId].Name;
        }

        public DependentType Get(int typeId)
        {
            return _idNameMap[typeId];
        }

        private static DependentTypeList _instance;
        public static async Task<DependentTypeList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<IDependentTypeRepository>();
                _instance = await repo.GetList();
            }
            return _instance;
        }

        public DependentType Default()
        {
            return _items.First();
        }

        public DependentType Empty()
        {
            return DependentType.Empty;
        }
    }
}