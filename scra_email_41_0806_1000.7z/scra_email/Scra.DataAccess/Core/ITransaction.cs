﻿using System;
using System.Data.SqlClient;

namespace Scra.DataAccess.Core
{
    public interface ITransaction : IDisposable
    {
        void Commit();
        SqlConnection GetConnection();
        SqlTransaction GetTransaction();
    }
}