﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Version;

namespace Scra.DataAccess.Version
{
    internal class VersionRepository : IVersionRepository
    {
        private readonly SqlExecutor _sqlExecutor;
        private string GET_DB_VERSION = @"SELECT Version FROM dbo.Version";
        private string GET_DB_NAME = @"SELECT DB_NAME() AS DatabaseName";

        public VersionRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<DbVersion> GetDbVersion()
        {
            return await _sqlExecutor.ExecuteOne(GET_DB_VERSION, ToDbVersion);
        }

        public async Task<string> GetDbName()
        {
            return await _sqlExecutor.ExecuteOne(GET_DB_NAME, ToDbName);
        }

        private string ToDbName(IRowData arg)
        {
            return arg.AsString("DatabaseName");
        }

        private DbVersion ToDbVersion(IRowData row)
        {
            return new DbVersion(row.AsInt(VersionColumn.VERSION));
        }
    }
}
