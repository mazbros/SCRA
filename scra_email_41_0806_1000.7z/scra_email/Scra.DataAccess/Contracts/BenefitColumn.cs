﻿namespace Scra.DataAccess.Contracts
{
    public class BenefitColumn
    {
        public const string PERSON_ID = "PersonId";
        public const string CONTRACT_ID = "ContractId";
        public const string ACTIVE_DUTY_ID = "ActiveDutyId";
        public const string STATUS = "Status";
        public const string DENIAL_REASON = "DenialReason";
        public const string IS_PROMO = "IsPromo";
        public const string START_DATE = "StartDate";
        public const string END_DATE = "EndDate";
        public const string TASK_ID = "TaskID";
    }
}