﻿using System;

namespace Scra.Tools
{
    public interface IUiThread
    {
        void Execute(Action action);
    }
}
