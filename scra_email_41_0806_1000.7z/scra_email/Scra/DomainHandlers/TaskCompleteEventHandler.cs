﻿using System.Threading.Tasks;
using Scra.Model.Contracts;
using Scra.Model.DomainEvents;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.DomainHandlers
{
    public class TaskCompleteEventHandler : IDomainEventHandler
    {
        private readonly IBenefitRepository _benefitRepository;

        public TaskCompleteEventHandler()
        {
            _benefitRepository = Di.Get<IBenefitRepository>();
        }

        public Task HandleAsync(IDomainEvent domainEvent)
        {
            return HandleAsync((TaskCompleteEvent)domainEvent);
        }

        public async Task HandleAsync(TaskCompleteEvent domainEvent)
        {
            var task = domainEvent.Tasc;
            if (task.Type == TaskType.ADD_BENEFIT && task.Status == TascStatus.QaCompleted)
            {                
                var benefit = await _benefitRepository.GetBenefitByTask(task.Id);
                await benefit.ChangeStatus(BenefitStatus.Applied);
            }
            else if (task.Type == TaskType.EXTEND_BENEFIT && task.Status == TascStatus.QaCompleted)
            {
                var benefit = await _benefitRepository.GetBenefitByTask(task.Id);
                await benefit.ChangeStatus(BenefitStatus.Extended);
            }
            else if (task.Type == TaskType.REMOVE_BENEFIT && task.Status == TascStatus.QaCompleted)
            {
                var benefit = await _benefitRepository.GetBenefitByTask(task.Id);
                await benefit.ChangeStatus(BenefitStatus.Removed);
            }
            else if (task.Type == TaskType.DENY_BENEFIT && task.Status == TascStatus.QaCompleted)
            {
                var benefit = await _benefitRepository.GetBenefitByTask(task.Id);
                await benefit.ChangeStatus(BenefitStatus.Denied);
            }
        }
    }
}