﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Dependents;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Views.Persons;

namespace Scra.Views.Dependents
{
    public class DependentsViewModel : BaseViewModel
    {
        private readonly IPersonRepository _repository;

        private PersonId _personId;
        private string _name;
        private string _address;
        private Visibility _isAddingNew;
        private Visibility _isExistingVisible;
        private DependentType _selectedDependentType;
        private readonly AppNavigator _navigator;
        private string _dependentName;
        private PersonId _dependentId;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private readonly IMessageDialog _messageDialog;
        private Visibility _isEditing;
        private DependentLink _editLink;
        
        public DependentsViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            _messageDialog = Di.Get<IMessageDialog>();
            _repository = Di.Get<IPersonRepository>();
            OnViewLoaded = OnLoaded;
            AddNewCommand = new Command(AddNewDependent);
            CancelEditCommand = new Command(CancelEdit);
            IsExistingVisible = Visibility.Visible;
            IsAddingNew = Visibility.Collapsed;
            IsEditing = Visibility.Collapsed;
            DependentTypes = new ObservableCollection<DependentType>();
            Dependents = new ObservableCollection<DependentVm>();
            SelectPersonCommand = new Command(SelectPerson);
            SaveCommand = new Command(Save);
        }



        public Command SaveCommand { get; set; }
        public Command AddNewCommand { get; set; }
        public Command CancelEditCommand { get; set; }
        
        public Command SelectPersonCommand { get; set; }

        public ObservableCollection<DependentType> DependentTypes { get; private set; }
        public ObservableCollection<DependentVm> Dependents { get; private set; }

        public DependentType SelectedDependentType
        {
            get { return _selectedDependentType; }
            set { SetProperty(ref _selectedDependentType, value); }
        }
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }
        public string DependentName
        {
            get { return _dependentName; }
            set { SetProperty(ref _dependentName, value); }
        }
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }
        public Visibility IsAddingNew
        {
            get { return _isAddingNew; }
            set { SetProperty(ref _isAddingNew, value); }
        }
        public Visibility IsEditing
        {
            get { return _isEditing; }
            set { SetProperty(ref _isEditing, value); }
        }
        public Visibility IsExistingVisible
        {
            get { return _isExistingVisible; }
            set { SetProperty(ref _isExistingVisible, value); }
        }
        public DateTime? StartDate
        {
            get { return _startDate; }
            set { SetProperty(ref _startDate, value); }
        }
        public DateTime? EndDate
        {
            get { return _endDate; }
            set { SetProperty(ref _endDate, value); }
        }        

        private void SelectPerson()
        {
            var args = new SelectPersonArgs {OnSuccess = OnPersonSelected};
            _navigator.SelectPerson(args);
        }

        private async void Save()
        {
            var link = GetLink();
            try
            {
                FillModel(link);
                Validate(link);
                await _repository.Save(link);                
                _navigator.PersonDashboard(_personId);
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
        }

        private void FillModel(DependentLink link)
        {
            link.StartDate = StartDate;
            link.EndDate = EndDate;
            link.Type = SelectedDependentType;
        }

        private DependentLink GetLink()
        {
            if (_editLink != null)
            {
                return _editLink;
            }
            return DependentLinkFactory.Create(_personId, _dependentId);
        }

        private void Validate(DependentLink model)
        {
            if (model.Type == null)
            {
                throw new UserException("Please select a Dependent Type.");
            }
            if (model.ToId.IsEmpty())
            {
                throw new UserException("Please select a dependent.");
            }
        }

        private async void OnPersonSelected(PersonId personId)
        {
            var person = await _repository.Get(personId);
            DependentName = person.Name.FullName;
            _dependentId = person.Id;
        }

        private void AddNewDependent()
        {
            DependentName = "";
            StartDate = null;
            EndDate = null;
            IsAddingNew = Visibility.Visible;
            IsExistingVisible = Visibility.Collapsed;
        }

        private void CancelEdit()
        {
            _editLink = null;
            IsAddingNew = Visibility.Collapsed;
            IsEditing = Visibility.Collapsed;
            IsExistingVisible = Visibility.Visible;
        }

        private async void OnLoaded()
        {
            var args = (DependentsArgs)Arguments;
            _personId = args.PersonId;
            await Reload();
        }

        private async Task Reload()
        {
            CancelEdit();
            var person = await GetPerson();
            var dependentTypes = await DependentTypeList.GetInstance();
            var dependents = await GetDependents(person);
            FillView(person, dependentTypes, dependents);
        }

        private void FillView(Person person, DependentTypeList dependentTypes, IList<DependentVm> dependents)
        {
            Name = person.Name.FullName;
            Address = person.Address.GetFull();

            Dependents.Update(dependents);

            DependentTypes.Update(dependentTypes.All());
        }

        private async Task<IList<DependentVm>> GetDependents(Person person)
        {
            var res = new List<DependentVm>();
            foreach (var link in person.DependentLinks)
            {
                var dependent = await link.GetDependent();
                res.Add(DependentVm.Create(link, dependent, OnEdit));
            }
            return res;
        }

        private Task<Person> GetPerson()
        {
            return _repository.Get(_personId);
        }

        private async void OnEdit(DependentLink link)
        {
            _editLink = link;
            StartDate = link.StartDate;
            EndDate = link.EndDate;
            SelectedDependentType = link.Type;
            var dependent = await link.GetDependent();
            DependentName = dependent.Name.FullName;

            IsEditing = Visibility.Visible;
            IsExistingVisible = Visibility.Collapsed;
        }
    }
}
