﻿using Scra.Model.Persons;

namespace Scra.Views.Dependents
{
    public class DependentsArgs
    {
        public PersonId PersonId { get; set; }
    }
}
