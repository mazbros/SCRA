﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using Scra.AppCore;
using Scra.Controls;
using Scra.Controls.Buttons;
using Scra.Model.Persons;
using Point = System.Drawing.Point;

namespace Scra.Views.Dashboard
{
    public class DashboardViewModel : BaseViewModel
    {
        private MultiButtonProps _actionProps;
        private Ssn _personSsn;
        private string _personSsnDisplay;
        private DateTime? _sunnyDay;
        private string _sunnyDayDisplay;
        private AddressState _selectedState;

        public DashboardViewModel()
        {
            OnViewLoaded = OnLoaded;
            ButtonCommand = new Command(ButtonAction);
        }

        public Ssn PersonSsn
        {
            get { return _personSsn; }
            set { SetProperty(ref _personSsn, value); }
        }
        public string PersonSsnDisplay
        {
            get { return _personSsnDisplay; }
            set { SetProperty(ref _personSsnDisplay, value); }
        }

        public DateTime? SunnyDay
        {
            get { return _sunnyDay; }
            set { SetProperty(ref _sunnyDay, value); }
        }
        public string SunnyDayDisplay
        {
            get { return _sunnyDayDisplay; }
            set { SetProperty(ref _sunnyDayDisplay, value); }
        }

        private void OnLoaded()
        {
            SunnyDay = DateTime.Now;
            ActionProps = new MultiButtonProps(new []
            {
                new MultiButtonProps.Item("Task 1", Action1),
                new MultiButtonProps.Item("Task 2", Action2),
                new MultiButtonProps.Item("Task 3", Action3),
            });
        }

        public Command ButtonCommand { get; set; }

        private void ButtonAction()
        {
            PersonSsnDisplay = PersonSsn.GetDisplay();
            SunnyDayDisplay = Formatter.DateTime(SunnyDay);
        }

        private void Action1()
        {
            ActionProps.Items.Add(new MultiButtonProps.Item("DateTime.Now:T", Action1));
        }

        private void Action2()
        {
        }

        private void Action3()
        {
        }

        private void SaveScreenShot()
        {
            Rectangle bounds = Screen.GetBounds(Point.Empty);
            using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
                }
                bitmap.Save(@"c:\temp\test.jpg", ImageFormat.Jpeg);
            }
        }

        public MultiButtonProps ActionProps
        {
            get { return _actionProps; }
            set { SetProperty(ref _actionProps, value); }
        }

        public AddressState State
        {
            get { return _selectedState; }
            set { SetProperty(ref _selectedState, value);}
        }
    }
}
