﻿using Scra.AppCore;
using Scra.Controls;
using Scra.Model.ServiceMembers;

namespace Scra.Views.ServiceMembers
{
    public class ActiveDutyItemVm : ControlViewModel
    {
        private string _name;

        public int AdId { get; set; }
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }

        public override string ToString()
        {
            return Name;
        }

        public static ActiveDutyItemVm Create(ActiveDuty model)
        {
            return new ActiveDutyItemVm {AdId = model.Id, Name = GetName(model) };
        }

        public void Update(ActiveDuty activeDuty)
        {
            AdId = activeDuty.Id;
            Name = GetName(activeDuty);
        }

        private static string GetName(ActiveDuty model)
        {
            return Formatter.Date(model.StartDate) + " - " + Formatter.Date(model.EndDate);
        }
    }
}