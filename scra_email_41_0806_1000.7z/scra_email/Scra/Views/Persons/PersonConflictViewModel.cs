﻿using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Persons
{
    public class PersonConflictViewModel : BaseViewModel
    {
        private ShellViewModel _shellViewModel;

        public PersonConflictViewModel()
        {
            _shellViewModel = Di.Get<ShellViewModel>();
            CancelCommand = new Command(Cancel);
            SaveCommand = new Command(Save);
            OnViewLoaded = Load;
        }

        public PersonConflictVm PersonConflict { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public void Load()
        {
            _shellViewModel.IsUiBusy = true;
            PersonConflict = (PersonConflictVm)Arguments;
            Reload();            
            _shellViewModel.IsUiBusy = false;
        }

        private void Reload()
        {
            FillView();
        }

        private void Save()
        {
            _shellViewModel.IsUiBusy = true;
            PersonConflict.SetData();
            CloseView();
            _shellViewModel.IsUiBusy = false;
        }

        private void Cancel()
        {
            _shellViewModel.IsUiBusy = true;
            PersonConflict.ResetData();
            CloseView();
            _shellViewModel.IsUiBusy = false;
        }

        private void FillView()
        {        
            UpdateAll();
        }
    }
}
