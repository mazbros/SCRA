﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.BranchOfServices;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.PersonDashboard
{                 
    public class PersonMilitaryWidgetModel : BaseViewModel
    {
        private readonly AppNavigator _navigator;
        private Person _person;

        public PersonMilitaryWidgetModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _navigator = Di.Get<AppNavigator>();
            ActiveDuties = new ObservableCollection<ActiveDutyListItem>();
            AddNewActiveDutyCommand = new Command(AddNewActiveDuty);
            SelectActiveDutyCommand = new Command(SelectActiveDuty);
        }
                        
        public ICommand AddNewActiveDutyCommand { get; set; }
        public ICommand SelectActiveDutyCommand { get; set; }
        public ObservableCollection<ActiveDutyListItem> ActiveDuties { get; set; }
        
        public async Task Load(Person person)
        {
            _person = person;
            
            var sm = await person.GetServiceMember();
            var branchOfServices = await BranchOfServiceList.GetInstance();
            var activeDuties = sm.ActiveDuties.Select(x => ActiveDutyListItem.Create(x, branchOfServices)).ToList();

            ActiveDuties.Update(activeDuties);
        }

        private void SelectActiveDuty(object selected)
        {
            var vm = (ActiveDutyListItem) selected;
            //_navigator.ActiveDutyEdit(_person.Id, vm.AdId);
        }

        private void AddNewActiveDuty()
        {
            _navigator.ActiveDuty(_person.Id);
        }
    }
}
