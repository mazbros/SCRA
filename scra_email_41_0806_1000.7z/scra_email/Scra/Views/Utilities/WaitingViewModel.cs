﻿using Scra.AppCore;

namespace Scra.Views.Utilities
{
    public class WaitingViewModel : BaseViewModel
    {
        public WaitingViewModel()
        {
            OnViewLoaded = Load;

        }

        private void Load()
        {
            
        }
    }
}