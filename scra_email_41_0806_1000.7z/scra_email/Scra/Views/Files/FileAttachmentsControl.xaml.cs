﻿using System.Windows;

namespace Scra.Views.Files
{
    public partial class FileAttachmentsControl
    {
        public FileAttachmentsControl()
        {
            InitializeComponent();
        }

        public FileAttachmentsControlModel GetViewModel()
        {
            return (FileAttachmentsControlModel) DataContext;
        }

        private void FileAttachmentsControl_OnSizeChanged(object sender, SizeChangedEventArgs e)
        {
            var vm = GetViewModel();
            var listSize = vm.AttachmentList.Count;
            var offset = 28;
            if (listSize <= 5) offset = 8;
            MyDockPanel.Width = (int)ActualWidth;

            var headerWidth = MyDockPanel.Width - ((int)FileDateGridViewColumn.Width + offset);
            if(headerWidth <=0)
                return;

            FileNameGridViewColumn.Width = headerWidth;
        } 
    }
}
