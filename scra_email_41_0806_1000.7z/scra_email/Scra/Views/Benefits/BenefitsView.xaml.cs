﻿using System.Windows.Input;

namespace Scra.Views.Benefits
{
    public partial class BenefitsView
    {
        public BenefitsView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ServicememberInformation = ServiceMemberInforView.GetViewModel();
        }

        public BenefitsViewModel GetViewModel()
        {
            return (BenefitsViewModel)DataContext;
        }

        private void Listview_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.Select();
        }

        private void Listview_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            
        }
    }
}
