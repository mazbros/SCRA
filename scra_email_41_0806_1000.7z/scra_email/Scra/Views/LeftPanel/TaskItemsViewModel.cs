﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Communication;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.LeftPanel
{
    public class TaskItemsViewModel : BaseViewModel
    {
        private readonly ITaskRepository _repository;
        private int _taskId;
        private SubTaskItem _currentItem;
        private string _title;
        private readonly IDispatcher _dispatcher;
        private readonly IUiThread _uiThread;
        private string _viewTitle;
        private ICommand _doneCommand;
        private readonly AppNavigator _navigator;
        private PersonId _personId;
        private readonly IMessageDialog _messageDialog;
        private readonly IUser _currentUser;

        private readonly IBenefitRepository _benefitRepository;
        private readonly ICommunicationRepository _communicationRepository;
        private readonly ShellViewModel _shellViewModel;

        public TaskItemsViewModel()
        {
            ReadOnlyItems = new ObservableCollection<CompleteSubTaskItem>();
            CompleteItems = new ObservableCollection<CompleteSubTaskItem>();
            FutureItems = new ObservableCollection<SubTaskItem>();
            TrashedItems = new ObservableCollection<CompleteSubTaskItem>();
            CurrentItem = new SubTaskItem();
            _repository = Di.Get<ITaskRepository>();
            _dispatcher = Di.Get<IDispatcher>();
            _uiThread = Di.Get<IUiThread>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _communicationRepository = Di.Get<ICommunicationRepository>();

            _navigator = Di.Get<AppNavigator>();
            DoubleClickCommand = new Command(ShowPerson);
            var store = Di.Get<IAppStore>();
            _messageDialog = Di.Get<IMessageDialog>();
            store.SubscribeCommand(Act.RELOAD_TASK, ReloadTask);
            store.SubscribeCommand(Act.TASK_DONE_UNLOCK, TaskDonePerformed);
            store.SubscribeCommand(Act.TASK_DONE_LOCK, TaskDonePerformed);
            store.SubscribeCommand(Act.TASK_STATUS_CHANGED, TaskStatusChanged);
            _currentUser = Di.Get<IUser>();
            _shellViewModel = Di.Get<ShellViewModel>();

            TitleClicked = new Command(Jump);
            IsDoneEnabled = false;
        }

        public bool IsDoneEnabled { get; set; }
        public bool IsModelEmpty { get; set; }
        public ObservableCollection<CompleteSubTaskItem> CompleteItems { get; set; }
        public ObservableCollection<CompleteSubTaskItem> ReadOnlyItems { get; set; }
        public ObservableCollection<SubTaskItem> FutureItems { get; set; }
        public ObservableCollection<CompleteSubTaskItem> TrashedItems { get; set; }
        public ICommand DoubleClickCommand { get; set; }       
        public SubTaskItem CurrentItem
        {
            get { return _currentItem; }
            set { SetProperty(ref _currentItem, value); }
        }
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        public string ViewTitle
        {
            get { return _viewTitle; }
            set { SetProperty(ref _viewTitle, value); }
        }
        public ICommand TitleClicked { get; set; }
        public ICommand DoneCommand
        {
            get { return _doneCommand; }
            set { SetProperty(ref _doneCommand, value); }
        }

        public async void ReloadTask()
        {
            await ReLoad();
        }

        private void ReloadTask(IAct obj)
        {
            var local = (ReloadTaskAct) obj;
            if (local.TaskId != _taskId)
            {
                return;
            }

            _uiThread.Execute(async () => await ReLoad());
        }

        private async void TaskStatusChanged(IAct obj)
        {
            await ReLoad();
        }

        private void ShowPerson()
        {
            _navigator.PersonDashboard(_personId);
        }

        private async void TaskDonePerformed(IAct obj)
        {
            if (CurrentSubTask == null || obj.Argument == null)
                return;

            if (obj.Code == Act.TASK_DONE_LOCK && CurrentSubTask.Type == (SubTaskType)obj.Argument)
                IsDoneEnabled = false;
            else if (obj.Code == Act.TASK_DONE_UNLOCK && CurrentSubTask.Type == (SubTaskType)obj.Argument)
                IsDoneEnabled = true;

            await ReLoad();
            UpdateAll();
        }        

        private async void Done(SubTask subTask)
        {
            await subTask.Complete();

            if (subTask.Type == SubTaskType.Qa)
                await subTask.CompleteQa();

            await ReLoad();
            Jump();
            await _dispatcher.DispatchAsync(Act.TASK_STATUS_CHANGED);
        }

        private async void QaDone(SubTask subTask)
        {
            await subTask.CompleteQa();
            await ReLoad();
            await _dispatcher.DispatchAsync(Act.TASK_STATUS_CHANGED);
        }

        private async void QaReject(SubTask subTask)
        {
            var result = _messageDialog.ConfirmationBinary("Are you sure you want to reject this task?");

            if (result == MessageBoxResult.No)
            {
                return;
            }

            await subTask.RejectQa();
            await ReLoad();
            await _dispatcher.DispatchAsync(Act.TASK_STATUS_CHANGED);
            IsDoneEnabled = false;
            UpdateAll();
        }

        public async void Delete()
        {
            var result = _messageDialog.ConfirmationBinary("Are you sure you want to label this task as Misdirected?");
            if (result == MessageBoxResult.No)
            {
                return;
            }

            var taskRepository = Di.Get<ITaskRepository>();
            await taskRepository.DumpTask(_taskId);
            await _dispatcher.DispatchAsync(Act.TASK_STATUS_CHANGED);
            _navigator.Task(_taskId);
        }

        public async Task Load(int taskId)
        {
            
            if (taskId == 0)
            {
                IsModelEmpty = true;
                return;
            }

            if (_taskId == taskId)
            {
                return;
            }
            _taskId = taskId;
            await ReLoad();
        }

        private SubTask CurrentSubTask { get; set; }
        public SubTask SelectedSubTask { get; set; }
        private Tasc CurrentTasc { get; set; }

        private async Task ReLoad()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                CurrentTasc = await _repository.Get(_taskId);
                if (CurrentTasc == null)
                {
                    _shellViewModel.IsUiBusy = false;
                    return;
                }

                _personId = CurrentTasc.PersonId;
                
                _uiThread.Execute(() => FillView(CurrentTasc, CurrentSubTask));
                _shellViewModel.IsUiBusy = false;
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during opening the task.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private void Jump()
        {
            NavigateRightSide(CurrentSubTask, CurrentTasc);
        }

        private async void NavigateRightSide(SubTask subTask, Tasc tasc)
        {
            if (subTask == null)
            {
                return;
            }
            SelectedSubTask = subTask;

            if (subTask.Type == SubTaskType.PersonDetails)
            {
                _navigator.PersonEdit(tasc.PersonId);
            }
            else if (subTask.Type == SubTaskType.PersonDashboard)
            {
                _navigator.PersonDashboard(tasc.PersonId);
            }
            else if (subTask.Type == SubTaskType.MilitaryInformation)
            {
                _navigator.ActiveDuty(tasc.PersonId);
            }
            else if (subTask.Type == SubTaskType.ProductInformation)
            {
                _navigator.Benefits(tasc.PersonId);
            }
            else if (subTask.Type == SubTaskType.LogRequest)
            {
                _navigator.NewInquiry(tasc.InquiryId);                
            }
            else if (subTask.Type == SubTaskType.Communication)
            {
                if (tasc.InquiryId > 0)
                {
                    _navigator.Inquiry(tasc.InquiryId);
                }
            }
            else if (subTask.Type == SubTaskType.CreditCardDetail)
            {
                int id = await GetBenefitId(subTask);
                _navigator.CreditCardDetails(id);
            }
            else if (subTask.Type == SubTaskType.MortgageDetail)
            {
                int id = await GetBenefitId(subTask);
                _navigator.MortgageDetails(id);
            }
            else if (subTask.Type == SubTaskType.ConsumerLoanDetail)
            {
                int id = await GetBenefitId(subTask);
                _navigator.ConsumerLoan(id);
            }
            else if (subTask.Type == SubTaskType.HomeEquityDetail)
            {
                int id = await GetBenefitId(subTask);
                _navigator.HomeEquity(id);
            }
            else if (subTask.Type == SubTaskType.CommercialLoanDetail)
            {
                int id = await GetBenefitId(subTask);
                _navigator.CommercialLoan(id);
            }

            else if (subTask.Type == SubTaskType.ProductCommunication)
            {
                var benefitId = await GetBenefitId(subTask);
                var personId = tasc.PersonId;
                var communication = await GetCommunicationId(tasc);

                if (communication == null)
                {
                    communication = new ProductCommunication(personId, benefitId);                    
                }
 
                _navigator.ProductCommunication(communication);
            }
            else if (subTask.Type == SubTaskType.Qa)
            {                
                _navigator.TaskList(tasc.Id);
            }
        }

        private async Task<ProductCommunication> GetCommunicationId(Tasc tasc)
        {
            return await _communicationRepository.GetByTask(tasc.Id);
        }

        private async Task<int> GetBenefitId(SubTask subTask)
        {
            var benefit = await _benefitRepository.GetBenefitByTask(subTask.Task.Id);
            var benefitId = benefit == null ? 0 : benefit.Id;
            return benefitId;
        }

        private void FillView(Tasc task, SubTask currentSubTask)
        {
            Title = task.Title;
            ViewTitle = GetViewTitle(task);

            if (task.Status == TascStatus.Misdirected)
            {
                var items = task.SubTasks.Select(x => CompleteSubTaskItem.CreateMisDirected(x, task));
                TrashedItems.Update(items);
                return;
            }

            if (_currentUser.Type.Equals(UserType.Guest))
            {
                var readOnlyItems = task.SubTasks
                    .Select(x => ReadOnlySubTaskItem.Create(x, _currentUser, task, () => NavigateRightSide(x, task)));
                ReadOnlyItems.Update(readOnlyItems);
                return;
            }

            CurrentSubTask = CurrentTasc.SubTasks.FirstOrDefault(x => x.Status == SubTaskStatus.InProcess );
            DoneCommand = new Command(() => Done(CurrentSubTask));

            var completeItems = task.SubTasks
                .Where(x => x.Status == SubTaskStatus.Completed || x.Status == SubTaskStatus.QaCompleted || x.Status == SubTaskStatus.Rejected)
                .Select(x => CompleteSubTaskItem.Create(x, () => QaDone(x), () => QaReject(x), _currentUser, task,
                    () => NavigateRightSide(x, task)));
            CompleteItems.Update(completeItems);

            var futureItems = task.SubTasks
                .Where(x => (x.Status == SubTaskStatus.InProcess) &&
                            x != CurrentSubTask).Select(SubTaskItem.Create);
            FutureItems.Update(futureItems);

            CurrentItem = SubTaskItem.CreateCurrent(CurrentSubTask);
        }

        private string GetViewTitle(Tasc task)
        {
            string assignee = null;
            if (task.Assignee != null)
            {
                assignee = task.Assignee.DisplayName;
            }
            if (assignee.IsEmpty())
            {
                return "Task. Unassigned.";
            }

            return string.Format("Task. TaskAssignee {0}.", assignee);
        }
    }
}
