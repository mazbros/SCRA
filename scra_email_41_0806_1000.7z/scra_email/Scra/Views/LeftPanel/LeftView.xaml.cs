﻿namespace Scra.Views.LeftPanel
{
    public partial class LeftView
    {
        public LeftView()
        {
            InitializeComponent();
        }
    }
}
