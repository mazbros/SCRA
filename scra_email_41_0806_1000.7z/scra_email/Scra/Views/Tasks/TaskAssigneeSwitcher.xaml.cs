﻿using Scra.Tools;

namespace Scra.Views.Tasks
{
    public partial class TaskAssigneeSwitcher
    {
        public TaskAssigneeSwitcher()
        {
            InitializeComponent();
            Loaded += TaskAssigneeSwitcher_Loaded;
        }

        private void TaskAssigneeSwitcher_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            TaskListItem vm;
            if(TryCast.Cast<TaskListItem>(DataContext, out vm))
            { 

                if (vm.TaskAssignee is TaskAssigneeAdminControlModel)
                {
                    var view = new TaskAssigneeAdminControl {DataContext = vm.TaskAssignee};
                    Panel.Children.Add(view);
                }
                else
                {
                    var view = new TaskAssigneeControl { DataContext = vm.TaskAssignee };
                    Panel.Children.Add(view);
                }
            }
        }

        //public static bool TryCast<T>(object obj, out T result)
        //{
        //    if (obj is T)
        //    {
        //        result = (T)obj;
        //        return true;
        //    }

        //    result = default(T);
        //    return false;
        //}
    }
}
