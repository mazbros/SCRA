﻿using System.Windows.Controls;

namespace Scra.Views.Tasks
{
    public partial class TaskAssigneeControl : UserControl
    {
        public TaskAssigneeControl()
        {
            InitializeComponent();
        }
    }
}
