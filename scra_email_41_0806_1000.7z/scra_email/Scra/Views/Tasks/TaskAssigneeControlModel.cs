﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Users;

namespace Scra.Views.Tasks
{
    public class TaskAssigneeControlModel : BaseControlModel
    {
        private readonly IUser _currentUser;
        private readonly Func<int, IUser, Task> _updateAction;
        private bool _isTextMode;
        private string _assigneeName;
        private readonly int _taskId;

        public TaskAssigneeControlModel(int taskId, IUser assignee, IUser currentUser, bool isTextMode, Func<int, IUser, Task> updateAction)
        {
            _taskId = taskId;
            IsTextMode = isTextMode;
            if (assignee != null)
            {
                AssigneeName = assignee.DisplayName;
            }

            _currentUser = currentUser;
            _updateAction = updateAction;
            AssignCommand = new Command(Assign);
        }

        public bool IsTextMode
        {
            get { return _isTextMode; }
            set { SetProperty(ref _isTextMode, value); }
        }

        public string AssigneeName
        {
            get { return _assigneeName; }
            set { SetProperty(ref _assigneeName, value); }
        }

        public ICommand AssignCommand { get; private set; }

        private async void Assign()
        {
            await _updateAction(_taskId, _currentUser);
            AssigneeName = _currentUser.UserName;
            IsTextMode = true;
        }
    }
}