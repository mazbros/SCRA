﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Scra.Controls
{
    public class MaskEditor
    {
        private readonly TextBox _textBox;
        private readonly string _mask;
        private readonly string _defaultText;
        private readonly char[] _skipSymbols;
        private Regex _maskRegex;
        private readonly int _length;

        private readonly TextCompositionEventHandler _previewTextInput;
        private readonly KeyEventHandler _previewKeyDown;

        private MaskEditor(TextBox textBox, string mask, string defaultText, char[] skipSymbols,TextCompositionEventHandler previewTextInput=null,KeyEventHandler previewKeyDown=null)
        {
            _length = defaultText.Length;
            _textBox = textBox;
            _mask = mask;
            _defaultText = defaultText;
            _skipSymbols = skipSymbols;
            _previewKeyDown = previewKeyDown;
            _previewTextInput = previewTextInput;
        }

        public static void Attach(TextBox textBox, string mask, string defaultText, char[] skipSymbols, TextCompositionEventHandler previewTextInput=null,KeyEventHandler previewKeyDown=null)
        {
            var editor = new MaskEditor(textBox, mask, defaultText, skipSymbols,previewTextInput, previewKeyDown);
            editor.Setup();            
        }

        private void Setup()
        {
            _maskRegex = new Regex(_mask);
            _textBox.MaxLength = _length;
            _textBox.Text = _defaultText;
            _textBox.PreviewTextInput += _previewTextInput?? PreviewTextInput;
            _textBox.PreviewKeyDown += _previewKeyDown?? PreviewKeyDown;
            DataObject.AddPastingHandler(_textBox, Pasting);
        }

        private void PreviewKeyDown(object sender, KeyEventArgs e)
        {
            var textBox = _textBox;
            if (e.Key == Key.Back)
            {
                e.Handled = true;
                var caretIndex = textBox.CaretIndex;
                if (caretIndex == 0)
                {
                    return;
                }

                var text = textBox.Text;
                var removeIndex = caretIndex - 1;
                text = text.Remove(removeIndex, 1);
                text = text.Insert(removeIndex, _defaultText.Substring(removeIndex, 1));
                textBox.Text = text;
                textBox.CaretIndex = removeIndex;
            }
        }

        private void PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var textBox = _textBox;
            var caretIndex = textBox.CaretIndex;
            if (caretIndex >= _length)
            {
                e.Handled = true;
            }
            else
            {
                var proposedText = GetProposedText(textBox, e.Text);

                if (!_maskRegex.IsMatch(proposedText))
                {
                    e.Handled = true;
                }
                else
                {
                    textBox.Text = proposedText;
                    textBox.CaretIndex = GetNextCaretIndex(caretIndex);
                }
            }
        }

        private int GetNextCaretIndex(int current)
        {
            current++;
            while (current < _length && _skipSymbols.Contains(_defaultText[current]))
            {
                current++;
            }

            return current;
        }

        private void Pasting(object sender, DataObjectPastingEventArgs e)
        {
            var textBox = _textBox;
            
            if (e.DataObject.GetDataPresent(typeof(string)))
            {
                var pastedText = e.DataObject.GetData(typeof(string)) as string;
                var proposedText = GetProposedText(textBox, pastedText);

                if (!_maskRegex.IsMatch(proposedText))
                {
                    e.CancelCommand();
                }
            }
            else
            {
                e.CancelCommand();
            }
        }

        private static string GetProposedText(TextBox textBox, string newText)
        {
            var text = textBox.Text;
            var index = textBox.CaretIndex;
            text = text.Remove(index, 1);
            text = text.Insert(index, newText);
            return text;
        }
    }
}