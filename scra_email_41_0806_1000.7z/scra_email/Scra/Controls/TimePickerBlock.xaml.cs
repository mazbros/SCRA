﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Scra.Controls
{
    /// <inheritdoc cref="UserControl" />
    /// <summary>
    /// Interaction logic for TimePickerBlock.xaml
    /// </summary>
    public partial class TimePickerBlock
    {
        public static readonly List<string> StrHours = new List<string> {"", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
   
        public List<string> HoursStrings
        {
               get { return (List<string>)GetValue(HoursStringsProperty);}
               set { SetValue(HoursStringsProperty, value);}
        }

        public static readonly DependencyProperty HoursStringsProperty = DependencyProperty.Register(
            "HoursStrings", typeof(List<string>), typeof(TimePickerBlock), new PropertyMetadata(StrHours));

        public static readonly List<string> StrMinutes = new List<string>
        {
            "", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09",
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
            "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31",
            "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42",
            "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53",
            "54", "55", "56", "57", "58", "59"
        };

        public List<string> MinutesStrings
        {
            get { return (List<string>) GetValue(MinutesStringsProperty); }
            set {SetValue(MinutesStringsProperty, value);}
        }

        public static readonly DependencyProperty MinutesStringsProperty = DependencyProperty.Register(
            "MinutesStrings", typeof(List<string>), typeof(TimePickerBlock), new PropertyMetadata(StrMinutes));

        public static readonly List<string> StrAmPm = new List<string> {"", "AM", "PM"};

        public List<string> AmPmStrings
        {
            get { return (List<string>)GetValue(AmPmStringsProperty); }
            set { SetValue(AmPmStringsProperty, value); }
        }

        public static readonly DependencyProperty AmPmStringsProperty = DependencyProperty.Register(
            "AmPmStrings", typeof(List<string>), typeof(TimePickerBlock), new PropertyMetadata(StrAmPm));

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(TimePickerBlock), new PropertyMetadata(""));

        public int EditWidth
        {
            get { return (int)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }

        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(int), typeof(TimePickerBlock), new PropertyMetadata(200));

        public string Hours
        {
            get { return (string)GetValue(HoursProperty); }
            set { SetValue(HoursProperty, value); }
        }
        public static readonly DependencyProperty HoursProperty = DependencyProperty.Register(
            "Hours", typeof(string), typeof(TimePickerBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string Minutes
        {
            get { return (string)GetValue(MinutesProperty); }
            set { SetValue(MinutesProperty, value); }
        }
        public static readonly DependencyProperty MinutesProperty = DependencyProperty.Register(
            "Minutes", typeof(string), typeof(TimePickerBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public string AmPm
        {
            get { return (string) GetValue(AmPmProperty); }
            set { SetValue(AmPmProperty, value); }
        }
        public static readonly DependencyProperty AmPmProperty = DependencyProperty.Register(
            "AmPm", typeof(string), typeof(TimePickerBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public bool? DisplayCurrentTime
        {
            get { return (bool?) GetValue(DisplayCurrentTimeProperty); }
            set { SetValue(DisplayCurrentTimeProperty, value); }
        }
        public static readonly DependencyProperty DisplayCurrentTimeProperty = DependencyProperty.Register(
            "DisplayCurrentTime", typeof(bool?), typeof(TimePickerBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public DateTime? TimeValue
        {
            get { return (DateTime?) GetValue(TimeValueProperty); }
            set { SetValue(TimeValueProperty, value); }
        }

        public static DependencyProperty TimeValueProperty  = DependencyProperty.Register(
            "TimeValue", typeof(DateTime?), typeof(TimePickerBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public TimePickerBlock()
        {
            Loaded += Control_Loaded;
            InitializeComponent();
        }
        
        private void Control_Loaded(object sender, RoutedEventArgs e)
        {
            var defHoursValue = (DateTime.Now.Hour % 12).ToString("00");
            var defMinutesValue = DateTime.Now.Minute.ToString("00");
            var defAmPmValue = DateTime.Now.ToShortTimeString().Contains("AM") ? "AM" : "PM";

            if (TimeValue != null && !string.IsNullOrEmpty(TimeValue.ToString()) && !TimeValue.Equals(DateTime.MinValue))
            {
                Hours = (TimeValue.Value.Hour % 12).ToString("00");
                Minutes = TimeValue.Value.Minute.ToString("00");
                AmPm = TimeValue.Value.ToShortTimeString().Contains("AM") ? "AM" : "PM";
            }
            else
            {
                if (DisplayCurrentTime == true)
                {
                    Hours = defHoursValue;
                    Minutes = defMinutesValue;
                    AmPm = defAmPmValue;
                }
                else
                {
                    Hours = string.Empty;
                    Minutes = string.Empty;
                    AmPm = string.Empty;
                }
            }

            CbHours.SelectedValue = Hours;
            CbMinutes.SelectedValue = Minutes;
            CbAmPm.SelectedValue = AmPm;
        }
        
        private void Cb_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AssignTimeValue();
        }

        private void AssignTimeValue()
        {
            if (!string.IsNullOrEmpty(Hours) && !string.IsNullOrEmpty(Minutes) && !string.IsNullOrEmpty(AmPm))  
            {
                TimeValue = DateTime.Parse(Hours + ":" + Minutes + " " + AmPm);
            }

            if (string.IsNullOrEmpty(Hours) && string.IsNullOrEmpty(Minutes) && string.IsNullOrEmpty(AmPm))
            {
                TimeValue = DateTime.MinValue;
            }
        }
    }
}
