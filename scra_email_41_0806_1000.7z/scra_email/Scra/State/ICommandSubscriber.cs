﻿using System;

namespace Scra.State
{
    public interface ICommandSubscriber
    {
        Action SubscribeCommand(string act, Action<IAct> action);

        void UnSubscribeCommand(string act, Action<IAct> action);
    }
}