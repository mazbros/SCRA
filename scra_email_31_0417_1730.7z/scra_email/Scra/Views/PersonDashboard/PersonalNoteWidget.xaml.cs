﻿using System.Windows;

namespace Scra.Views.PersonDashboard
{
    public partial class PersonalNoteWidget
    {
        public PersonalNoteWidget()
        {
            InitializeComponent();
        }

        public PersonalNoteWidgetModel GetViewModel()
        {
            return (PersonalNoteWidgetModel)DataContext;
        }
    }
}
