﻿using System.Windows.Controls;
using System.Windows.Input;

namespace Scra.Views.Tasks
{
    ///<inheritdoc cref="UserControl"/>

    public partial class TaskListView
    {
        public TaskListView()
        {
           //AddHandler(System.Windows.Controls.Primitives.ButtonBase.ClickEvent, new RoutedEventHandler(ColumnHeaderClick));
            InitializeComponent();
        }

        private void OnItemDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var vm = GetViewModel();
            vm.SelectCommand.Execute(null);
        }

        private TaskListViewModel GetViewModel()
        {
            return (TaskListViewModel)DataContext;
        }

        //public async void ColumnHeaderClick(object sender, RoutedEventArgs args)
        //{
        //    var vm = GetViewModel();
        //    var columnHeader = args.OriginalSource as GridViewColumnHeader;
        //    if (columnHeader != null)
        //    {
        //        await vm.SortListAsync(columnHeader.Column.Header.ToString(), columnHeader);
        //    }
            
        //}
        private async void PageSize_Changed(object sender, SelectionChangedEventArgs e)
        {
            await GetViewModel().ReloadList(null);
        }
    }
}
