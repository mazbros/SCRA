﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Extensions;
using Scra.Model.Files;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Files
{
    public class FileAttachmentsControlModel : BaseViewModel
    {
        private readonly IFileAttachmentRepository _repository;
        private int _entityId;
        private string _category;

        private readonly FileAttachmentVm _fileAttachmentVm;

        private readonly IMessageDialog _messageDialog;
        private string _title;
        private Visibility _visibility;
        private ShellViewModel _shellViewModel;

        public FileAttachmentsControlModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _shellViewModel = Di.Get<ShellViewModel>();
            _messageDialog = Di.Get<IMessageDialog>();
            _repository = Di.Get<IFileAttachmentRepository>();
            AttachFiles = new Command(AttachFileClicked);
            AttachmentList = new ObservableCollection<FileAttachmentVm>();
            _fileAttachmentVm = new FileAttachmentVm();
            ReadOnlyMode = Di.Get<IUser>().Type.Equals(UserType.Guest);

            SetVisibility = Visibility.Collapsed;
        }

        public ObservableCollection<FileAttachmentVm> AttachmentList { get; set; }
        public ICommand AttachFiles { get; set; }

        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        public Visibility SetVisibility
        {
            get { return _visibility; }
            set { SetProperty(ref _visibility, value); }
        }

        public bool ReadOnlyMode { get; set; }

        public async Task Load(int entityId, string category)
        {
            _shellViewModel.IsUiBusy = true;
            _entityId = entityId;
            _category = category;
            await Reload();
            _shellViewModel.IsUiBusy = false;
        }

        public async Task Load(int entityId, string category, string title)
        {
            _shellViewModel.IsUiBusy = true;
            _entityId = entityId;
            _category = category;
            Title = title;
            SetVisibility = Visibility.Visible;
            await Reload();
            _shellViewModel.IsUiBusy = false;
        }

        public async Task Reload()
        {
            await LoadAttachedFileList();
        }

        private async Task LoadAttachedFileList()
        {
            var fileList = await _repository.Load(_entityId, _category);
            AttachmentList.Update(fileList.Select(x => _fileAttachmentVm.Create(x, () => ViewFile(x), () => Download(x), () => Delete(x), ViewFile)));
        }

        private async void ViewFile(FileAttachmentSnapshot snapshot)
        {
            var attachment = await _repository.Get(snapshot.Id);
            var path = Path.GetTempFileName() + "_" + attachment.FileName;

            File.WriteAllBytes(path, attachment.Content);
            FileHelper.Open(path);
        }

        private async void Download(FileAttachmentSnapshot snapshot)
        {
            var attachment = await _repository.Get(snapshot.Id);

            var saveFileDialog = new SaveFileDialog
            {
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                FileName = attachment.FileName,
                Filter = "All files (*.*)|*.*"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                var path = saveFileDialog.FileName;
                File.WriteAllBytes(path, attachment.Content);
            }
        }

        private async void Delete(FileAttachmentSnapshot attachment)
        {
            var result = _messageDialog.Confirmation("Are you sure you wan to delete the selected file?");

            if (result != MessageBoxResult.Yes) return;
            await _repository.Delete(attachment.Id);
            await Reload();
        }

        private async void AttachFileClicked()
        {
            var openFileDialog = new OpenFileDialog
            {
                Multiselect = true,
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            };

            if (openFileDialog.ShowDialog() != true) return;

            _shellViewModel.IsUiBusy = true;
            foreach (var filename in openFileDialog.FileNames)
            {
                var newFile = new FileAttachment(Path.GetFileName(filename), File.ReadAllBytes(filename));
                await UploadAttachedFile(newFile);
            }

            await Reload();
            _shellViewModel.IsUiBusy = false;
        }

        private async Task UploadAttachedFile(FileAttachment newFile)
        {
            await _repository.UploadFile(_entityId, _category, newFile);
        }
    }
}