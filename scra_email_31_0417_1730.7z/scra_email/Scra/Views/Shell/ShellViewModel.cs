﻿using System.Windows;
using Scra.AppCore;
using Scra.Configs;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.Views.LeftPanel;

namespace Scra.Views.Shell
{
    public class ShellViewModel : BaseViewModel
    {
        private bool _isUiBusy;
        private readonly IUser _user;

        public ShellViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            Di.Set(this);
            _user = Di.Get<IUser>();
            OnViewLoaded = Load;
        }

        public bool IsUiBusy
        {
            get { return _isUiBusy;}
            set{ SetProperty(ref _isUiBusy, value);}
        }        

        private void Load()
        {
            SetTitle();
            var navigator = Di.Get<AppNavigator>();

            navigator.TaskList();

            var flowModel = GetFlowViewModel();            
            flowModel.Load();
        }

        private void SetTitle()
        {
            var window = (Window)View;
            
            var type = _user.Type.Display;
            window.Title = "SCRA    " + _user.DisplayName + " - " + type  + "    " + AppConfig.VersionString();
        }

        private LeftViewModel GetFlowViewModel()
        {
            var view = (ShellView) View;
            var flowView = view.FlowView;
            return (LeftViewModel)flowView.DataContext;
        }
    }
}
