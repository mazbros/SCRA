﻿using System.Windows.Controls;

namespace Scra.Views.Benefits
{
    /// <summary>
    /// Interaction logic for AddContractView.xaml
    /// </summary>
    public partial class AddContractView : UserControl
    {
        public AddContractView()
        {
            InitializeComponent();
        }

    }
}
