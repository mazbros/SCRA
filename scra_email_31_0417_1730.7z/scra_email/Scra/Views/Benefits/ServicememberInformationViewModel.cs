﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tools;

namespace Scra.Views.Benefits
{
    public class ServicememberInformationViewModel : BaseViewModel
    {
        private readonly IPersonRepository _personRepository;
        private PersonId _personId;
        private AppNavigator _navigator;

        public string ServiceMemberName { get; set; }
        public bool HasActiveDuty { get; set; }
        public IList<ActiveDutyListItem> ActiveDutyList { get; set; }
        public ActiveDutyListItem SelectedActiveDuty { get; set; }
        public string Title { get; set; }
        public ICommand TitleClicked { get; set; }
        public ICommand SelectedCommand { get; set; }
        public Action UpdateSelection { get; set; }

        public ServicememberInformationViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            _personRepository = Di.Get<IPersonRepository>();            
            TitleClicked = new Command(GotoPersonDashboard);
            SelectedCommand = new Command(Select);
        }

        private void Select()
        {
            //UpdateSelection();
        }

        private void GotoPersonDashboard()
        {
            _navigator.PersonDashboard(_personId);
        }

        public async Task Load(PersonId personId)
        {
            _personId = personId;
            await Reload();
        }

        private async Task Reload()
        {
            var person = await _personRepository.Get(_personId);
            var serviceMember = await person.GetServiceMember();

            FillView(serviceMember);
        }

        private void FillView(ServiceMember serviceMember)
        {
            HasActiveDuty = serviceMember.ActiveDuties.Count > 0;
            if (HasActiveDuty)
            {
                ServiceMemberName = "Servicemember (" + serviceMember.Name.FullName + ")";


                ActiveDutyList = new List<ActiveDutyListItem>();
                foreach (var activeDuty in serviceMember.ActiveDuties)
                {
                    ActiveDutyList.Add(ActiveDutyListItem.Create(activeDuty));
                }

                SelectedActiveDuty = ActiveDutyList.FirstOrDefault();
            }
            UpdateAll();
        }
    }

    public class ActiveDutyListItem
    {
        public string ActiveDutyPeriod { get; set; }
        public string ActiveDutyBranch { get; set; }
        public string ActiveDutyNotificationDate { get; set; }
        public bool IsReserve { get; set; }
        public ActiveDuty ActiveDuty { get; set; }

        public static ActiveDutyListItem Create(ActiveDuty activeDuty)
        {
            return new ActiveDutyListItem()
            {
                ActiveDutyPeriod = Formatter.Date(activeDuty.StartDate) + " - " + Formatter.Date(activeDuty.EndDate),
                ActiveDutyNotificationDate = Formatter.Date(activeDuty.NoticeDate),
                ActiveDutyBranch = activeDuty.BranchOfService.Name,
                IsReserve = activeDuty.BranchOfService.IsReserve,
                ActiveDuty = activeDuty
            };
        }
    }
}
