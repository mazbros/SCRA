﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Scra.Model.Contracts;

namespace Scra.Views.Benefits
{
    public partial class BenefitsView
    {
        public BenefitsView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ServicememberInformation = ServiceMemberInforView.GetViewModel();
        }

        public BenefitsViewModel GetViewModel()
        {
            return (BenefitsViewModel)DataContext;
        }
    }
}
