﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public partial class EditBlock
    {
        public EditBlock()
        {
            InitializeComponent();

            var user = Di.Get<IUser>();
            IsReadOnly = user.Type.Equals(UserType.Guest);
        }

        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyProperty); }
            set { SetValue(IsReadOnlyProperty, value); }
        }
        public static readonly DependencyProperty IsReadOnlyProperty = DependencyProperty.Register(
            "IsReadOnly", typeof(bool), typeof(EditBlock), new PropertyMetadata(false));

        public string LabelName
        {   
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(EditBlock), new PropertyMetadata(""));

        public int LabelWidth
        {
            get { return (int)GetValue(LabelWidthProperty); }
            set { SetValue(LabelWidthProperty, value); }
        }
        public static readonly DependencyProperty LabelWidthProperty = DependencyProperty.Register(
            "LabelWidth", typeof(int), typeof(EditBlock), new PropertyMetadata(200));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(EditBlock), new PropertyMetadata("*"));

        public string EditMaxLength
        {
            get { return (string)GetValue(EditMaxLengthProperty); }
            set { SetValue(EditMaxLengthProperty, value); }
        }
        public static readonly DependencyProperty EditMaxLengthProperty = DependencyProperty.Register(
            "EditMaxLength", typeof(string), typeof(EditBlock), new PropertyMetadata("255"));

        public string Value
        {
            get { return (string)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(string), typeof(EditBlock), new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public ICommand EnterCommand
        {
            get { return (ICommand)GetValue(EnterCommandProperty); }
            set { SetValue(EnterCommandProperty, value); }
        }
        public static readonly DependencyProperty EnterCommandProperty = DependencyProperty.Register(
            "EnterCommand", typeof(ICommand), typeof(EditBlock), new FrameworkPropertyMetadata(new Command(()=>{})));

        public TextBoxInputMode InputMode
        {
            get { return (TextBoxInputMode) GetValue(TextInputModeProperty); }
            set {SetValue(TextInputModeProperty, value);}
        }

        public static readonly DependencyProperty TextInputModeProperty = DependencyProperty.Register(
            "InputMode", typeof(TextBoxInputMode), typeof(EditBlock), new PropertyMetadata(TextBoxInputMode.None));
    }
}
