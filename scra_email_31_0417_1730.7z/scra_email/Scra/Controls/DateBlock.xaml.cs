﻿using System;
using System.Windows;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public partial class DateBlock
    {
        public DateBlock()
        {
            InitializeComponent();

            var user = Di.Get<IUser>();
            var u = user.Type.Equals(UserType.Guest);
            IsDateEnabled = !u;
        }

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(DateBlock), new PropertyMetadata(""));

        public int EditWidth
        {
            get { return (int)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(int), typeof(DateBlock), new PropertyMetadata(200));

        public bool IsDateEnabled
        {
            get { return (bool)GetValue(IsDateEnabledProperty); }
            set { SetValue(IsEnabledProperty, value); }
        }
        public static readonly DependencyProperty IsDateEnabledProperty = DependencyProperty.Register(
            "IsDateEnabled", typeof(bool), typeof(DateBlock), new PropertyMetadata(true));

       public DateTime? Value
        {
            get { return (DateTime?)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(DateTime?), typeof(DateBlock), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }
}
