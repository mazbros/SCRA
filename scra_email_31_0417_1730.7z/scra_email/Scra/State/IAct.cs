﻿namespace Scra.State
{
    public interface IAct
    {
        string Code { get; }
        object Argument { get; }
    }
}