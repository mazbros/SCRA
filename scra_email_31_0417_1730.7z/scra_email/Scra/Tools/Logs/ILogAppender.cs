﻿namespace Scra.Tools.Logs
{
    public interface ILogAppender
    {
        void Log(ILogRecord record);

        void Close();
    }
}