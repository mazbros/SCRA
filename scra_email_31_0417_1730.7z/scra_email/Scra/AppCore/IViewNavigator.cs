﻿using Scra.Views.Shell;

namespace Scra.AppCore
{
    public interface IViewNavigator
    {
        void ShowDialog<T>(object args = null) where T : IViewModel;
        void Show<T>(object args = null) where T : IViewModel;
        
        T CreateControl<T>(object args = null) where T : IViewModel;

        void Back();
        void ShowMainWindow<T>() where T : IViewModel;
        void Setup(IShell shell);
        void ShutDown();
    }
}
