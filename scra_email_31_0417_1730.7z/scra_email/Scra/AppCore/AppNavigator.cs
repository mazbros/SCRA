﻿using System.Threading.Tasks;
using Scra.Model.Communication;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.State;
using Scra.Tools;
using Scra.Views.Benefits;
using Scra.Views.Dashboard;
using Scra.Views.Dependents;
using Scra.Views.Inquiries;
using Scra.Views.PersonDashboard;
using Scra.Views.Persons;
using Scra.Views.Reports;
using Scra.Views.ServiceMembers;
using Scra.Views.Shell;
using Scra.Views.StartUp;
using Scra.Views.Tasks;
using Scra.Views.Utilities;

namespace Scra.AppCore
{
    public class AppNavigator
    {
        private readonly IViewNavigator _navigator;
        private readonly IDispatcher _dispatcher;
        private readonly IUiThread _uiThread;

        public AppNavigator(IViewNavigator navigator, IDispatcher dispatcher, IUiThread uiThread)
        {
            _navigator = navigator;
            _dispatcher = dispatcher;
            _uiThread = uiThread;
        }

        public void PersonDashboard(PersonId personId)
        {
            Show<PersonDashboardViewModel>(new IdArgs(personId));
        }
        public void PersonList()
        {
            Show<PersonListViewModel>();
        }
        public void PersonEdit(PersonId personId)
        {
            Show<PersonEditViewModel>(new IdArgs(personId));
        }
        public void PersonAdd()
        {
            Show<PersonEditViewModel>(new IdArgs(0));
        }

        public void ActiveDuty(PersonId personId)
        {
            Show<ServiceMemberEditViewModel>(new ServiceMemberEditArgs {PersonId = personId});
        }

        public void Dependents(PersonId personId)
        {
            Show<DependentsViewModel>(new DependentsArgs { PersonId = personId});
        }

        public void Shell()
        {
            _navigator.ShowMainWindow<ShellViewModel>();
        }
        public void ShutDown()
        {
            _navigator.ShutDown();
        }
        public void Back()
        {
            _navigator.Back();
        }
        public void StartUp()
        {
            _navigator.ShowDialog<StartUpViewModel>();
        }
        public void SetupShell(IShell shell)
        {
            _navigator.Setup(shell);
        }

        public void AddPerson()
        {
            _navigator.ShowDialog<PersonEditQuickViewModel>();
        }

        public void AddPerson(SelectPersonArgs args)
        {
            _navigator.ShowDialog<PersonEditQuickViewModel>(args);
        }

        public void PersonConflict(PersonConflictVm person)
        {
            _navigator.ShowDialog<PersonConflictViewModel>(person);
        }

        public void AddContract(Contract contract)
        {
            _navigator.ShowDialog<AddContractViewModel>(contract);
        }

        public void EnterDenialReason(Benefit benefit)
        {
            _navigator.ShowDialog<DenialReasonViewModel>(benefit);
        }

        public void SelectPerson(SelectPersonArgs args)
        {
            _navigator.ShowDialog<SelectPersonViewModel>(args);
        }

        public void Dashboard()
        {
            _navigator.Show<DashboardViewModel>();
        }

        public void NewInquiry()
        {
            Show<CreateInquiryViewModel>();
        }
        public void NewInquiry(int id)
        {
            Show<CreateInquiryViewModel>(new IdArgs(id));
        }

        public void Inquiry(int id)
        {
            Show<EditInquiryViewModel>(new IdArgs(id));
        }

        public void InquiryList()
        {
            Show<InquiryListViewModel>();
        }

        public async void Task(int flowId)
        {
            await _dispatcher.DispatchAsync(new ShowTaskAct(flowId));
        }

        public async Task AwaitTask(int flowId)
        {
            await _dispatcher.DispatchAsync(new ShowTaskAct(flowId));
        }

        public void TaskList()
        {
            Show<TaskListViewModel>();
        }

        public void TaskList(int taskId)
        {
            Show<TaskListViewModel>(new IdArgs(taskId));
        }

        public void Benefits(PersonId personId)
        {
            Show<BenefitsViewModel>(new IdArgs(personId));
        }

        public void MortgageDetails(int benefitId)
        {
            Show<MortgageDetailsViewModel>(new IdArgs(benefitId));
        }

        public void CreditCardDetails(int benefitId)
        {
            Show<CreditCardDetailsViewModel>(new IdArgs(benefitId));
        }

        public void ConsumerLoan(int benefitId)
        {
            Show<ConsumerLoanDetailsViewModel>(new IdArgs(benefitId));
        }

        public void CommercialLoan(int benefitId)
        {
            Show<CommercialLoanViewModel>(new IdArgs(benefitId));
        }

        public void ProductCommunication(ProductCommunication communication)
        {
            Show<ProductCommunicationViewModel>(communication);
        }

        public void Loading()
        {
            _navigator.ShowDialog<WaitingViewModel>();
        }

        private void Show<T>(object args = null) where T : IViewModel
        {
            _uiThread.Execute(() => _navigator.Show<T>(args));
        }

        public void ReportsList()
        {
            Show<ReportsListViewModel>();
        }
    }
}
