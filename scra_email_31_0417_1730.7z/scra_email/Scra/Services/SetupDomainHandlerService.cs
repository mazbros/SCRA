﻿using Scra.DomainHandlers;
using Scra.Model.DomainEvents;
using Scra.Model.Inquiries;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Services
{
    public class SetupDomainHandlerService
    {
        public void Setup()
        {
            var dispatcher = Di.Get<IDomainEventDispatcher>();            
            dispatcher.Subscribe<InquiryAcknowledgeEvent>(Di.SetAndCreate<InquiryAcknowledgeEventHandler>());
            dispatcher.Subscribe<TaskCompleteEvent>(Di.SetAndCreate<TaskCompleteEventHandler>());
        }
    }
}
