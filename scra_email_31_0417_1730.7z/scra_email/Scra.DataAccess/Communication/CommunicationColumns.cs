﻿namespace Scra.DataAccess.Communication
{
    public class CommunicationColumns
    {        
        public const string ID = "ID";     
        public const string PERSON_ID = "PersonID";
        public const string BENEFIT_ID = "BenefitID";
        public const string COMMUNICATION_DATE = "CommunicationDate";
        public const string CONTACT_METHOD_ID = "ContactMethodId";
        public const string RESPONSE_TEXT = "ResponseText";
        public const string LETTER_ID = "LetterId";
        public const string TASK_ID = "TaskId";
    }
}