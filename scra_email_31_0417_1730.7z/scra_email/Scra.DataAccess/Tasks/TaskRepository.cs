﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.Model.Contracts;
using Scra.Model.DomainEvents;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tasks;
using Scra.Model.Users;

namespace Scra.DataAccess.Tasks
{
    internal class TaskRepository : ITaskRepository
    {
        private const string LOAD_SQL = @"
            SELECT	T.Id
		            , T.Title
		            , T.DueDate
		            , T.CreateDate
		            , T.Status
		            , T.TaskType
		            , T.InquiryId
		            , T.PersonId
		            , P.FirstName
		            , P.LastName
		            , T.QaComplete
		            , T.AssigneeID
                    , E.UserName AS AssigneeUserName
                    , E.Name as AssigneeName
                    , T.QaAssigneeID
                    , qae.UserName AS QaAssigneeUserName
                    , qae.Name as QaAssigneeName
            FROM	dbo.Task T
            JOIN 	dbo.Person P On P.ID = T.PersonID
            LEFT JOIN dbo.Employee E ON E.ID = T.AssigneeID
            LEFT JOIN dbo.Employee qae ON qae.ID = T.QaAssigneeID
            WHERE   1=1 {WHERE}
            ORDER BY T.CreateDate DESC";

        private const string GET_SQL = @"
            SELECT	x.Id, x.Title, x.DueDate, x.CreateDate, x.Status, x.TaskType, x.InquiryId, x.PersonId, x.ContractId, x.QaComplete,
		            x.AssigneeID, e.UserName AS AssigneeUserName, e.Name as AssigneeName,
                    x.QaAssigneeID, qae.UserName AS QaAssigneeUserName, qae.Name as QaAssigneeName
            FROM	dbo.Task x
            LEFT JOIN dbo.Employee e
	            ON e.ID = x.AssigneeID
            LEFT JOIN dbo.Employee qae
	            ON qae.ID = x.QaAssigneeID
            WHERE   x.Id = {taskId}

            SELECT  x.Id, x.Title, x.Code, x.Status, x.SortNo,
		            x.IsComplete, x.CompletionDate, x.CompletedBy, e.UserName AS CompletedByUserName, e.Name as CompletedByName,
                    x.IsQaComplete, x.QaCompletionDate, x.QaCompletedBy, eq.UserName AS QaCompletedByUserName, eq.Name as QaCompletedByName
            FROM	dbo.SubTask x
            LEFT JOIN dbo.Employee e
	            ON e.ID = x.CompletedBy
            LEFT JOIN dbo.Employee eq
	            ON eq.ID = x.QaCompletedBy
            WHERE   x.TaskID = {taskId}
            ORDER BY x.ID";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;
        private readonly IDomainEventDispatcher _domainEventDispatcher;

        public TaskRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor, IDomainEventDispatcher domainEventDispatcher)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
            _domainEventDispatcher = domainEventDispatcher;
        }

        public async Task<int> Create(Tasc model)
        {
            
            using (var transaction = await Transaction.Start())
            {
                var id = SpParameter.CreateInOut(model.Id);
                var parameters = new[]
                {
                    SpParameter.Create(TaskColumn.TITLE, model.Title),
                    SpParameter.Create(TaskColumn.DUE_DATE, model.DueDate),
                    SpParameter.Create(TaskColumn.CREATE_DATE, model.CreateDate),
                    SpParameter.Create(TaskColumn.TYPE, model.Type.Code),
                    SpParameter.Create(TaskColumn.PERSON_ID, model.PersonId),
                    SpParameter.Create(TaskColumn.INQUIRY_ID, model.InquiryId),
                    SpParameter.Create(TaskColumn.CONTRACT_ID, model.ContractId),
                    id,
                    SpParameter.ModifiedBy()
                };
                await _spExecutor.Execute("dbo.spTask_Create", parameters, transaction);
                
                model.Id = (int)id.Value;

                var sortNo = 0;
                foreach (var subTask in model.SubTasks)
                {
                    sortNo++;
                    var subTaskId = SpParameter.CreateInOut(subTask.Id);
                    parameters = new[]
                    {
                        SpParameter.Create(SubTaskColumn.TITLE, subTask.Title),
                        SpParameter.Create(SubTaskColumn.CODE, subTask.Type.Code),
                        SpParameter.Create(SubTaskColumn.SORT_NO, sortNo),
                        SpParameter.Create(SubTaskColumn.TASK_ID, model.Id),
                        subTaskId,
                        SpParameter.ModifiedBy()
                    };
                    await _spExecutor.Execute("dbo.spSubTask_Create", parameters, transaction);
                    subTask.Id = (int)subTaskId.Value;
                }

                transaction.Commit();
            }

            if (model.Assignee.Id.IsNotEmpty())
            {
                await UpdateAssignee(model.Id, model.Assignee);
            }

            return model.Id;
        }

        public async Task<IList<TaskSnapshot>> Load(LoadTasksFilter filter, string searchText)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", GetWhere(filter, searchText));
            var items = await _sqlExecutor.Execute(sql, ConvertToTaskSnapshot);
            return items;
        }

        private string GetWhere(LoadTasksFilter filter, string searchText)
        {
            var sql = "";

            if (filter.PersonId.IsNotEmpty())
            {
                sql += " AND T.PersonID=" + filter.PersonId;
            }
            if (filter.ContractId.IsNotEmpty())
            {
                sql += " AND T.ContractID=" + filter.ContractId;
            }
            if (filter.Statuses.IsNotEmpty())
            {
                var statusNames = string.Join(", ", filter.Statuses.Select(x => "'" + x.Code + "'"));
                sql += string.Format(" AND T.Status IN ({0})", statusNames);
            }
            if (filter.AssigneeId.IsNotEmpty())
            {
                sql += " AND (T.AssigneeID=" + filter.AssigneeId + " OR T.QaAssigneeID=" + filter.QaAssigneeId + ")";
            }
            if (filter.HideAssigned)
            {
                sql += " AND T.AssigneeID is NULL";
            }
            if (filter.TaskId != 0)
            {
                sql += " AND T.Id = " + filter.TaskId;
            }

            if (searchText.IsNotEmpty())
            {
                searchText = searchText.Replace("'", "''");

                sql += " AND (T.[Title] LIKE '%" + searchText + "%' OR " +
                       "   [AssigneeID] IN (SELECT [ID] FROM [SCRA_DB].[dbo].[Employee] WHERE [Name] LIKE '%" + searchText + "%') OR " +
                       "   [QaAssigneeId] IN (SELECT [ID] FROM [SCRA_DB].[dbo].[Employee] WHERE [Name] LIKE '%" + searchText + "%') /*OR " +
                       "   [ModifiedBy] IN (SELECT [ID] FROM [SCRA_DB].[dbo].[Employee] WHERE [Name] LIKE '%" + searchText + "%')*/ " +
                       "   )";
            }

            return sql;
        }

        public async Task<Tasc> Get(int taskId)
        {
            var sql = GET_SQL.Replace("{taskId}", taskId.ToString());
            var dataSet = await _sqlExecutor.GetDataSet(sql);
            var taskRow = dataSet.GetFirstTableRow();
            if (taskRow == null)
            {
                return null;
            }
            var subTaskTable = dataSet.Tables[1];
            var subTasks = subTaskTable.Convert(ConvertSubTask);

            return ConvertToTask(taskRow, subTasks);
        }

        public async Task SaveCompletion(SubTask subTask)
        {
            using (var transaction = await Transaction.Start())
            {
                var task = subTask.Task;
                var parameters = new[]
                {
                    SpParameter.Create(TaskColumn.STATUS, task.Status.Code),
                    SpParameter.Create(task.Id),
                    SpParameter.ModifiedBy()
                };
                await _spExecutor.Execute("dbo.spTask_Update", parameters, transaction);

                parameters = new[]
                {
                    SpParameter.Create(SubTaskColumn.STATUS, subTask.Status.Code),
                    SpParameter.Create(subTask.Id),
                    SpParameter.ModifiedBy()
                };
                await _spExecutor.Execute("dbo.spSubTask_Complete", parameters, transaction);

                transaction.Commit();
            }
        }

        public async Task SaveQaCompletion(SubTask subTask)
        {
            using (var transaction = await Transaction.Start())
            {
                var task = subTask.Task;
                var parameters = new[]
                {
                    SpParameter.Create(TaskColumn.STATUS, task.Status.Code),
                    SpParameter.Create(task.Id),
                    SpParameter.ModifiedBy()
                };
                await _spExecutor.Execute("dbo.spTask_Update", parameters, transaction);

                parameters = new[]
                {
                    SpParameter.Create(SubTaskColumn.STATUS, subTask.Status.Code),
                    SpParameter.Create(subTask.Id),
                    SpParameter.ModifiedBy()
                };
                await _spExecutor.Execute("dbo.spSubTask_QaComplete", parameters, transaction);

                transaction.Commit();
            }
            await _domainEventDispatcher.DispatchAsync(subTask);
            await _domainEventDispatcher.DispatchAsync(subTask.Task);
        }

        public async Task UpdateAssignee(int taskId, IUser assignee)
        {
            var parameters = new[]
            {
                SpParameter.Create(TaskColumn.ASSIGNEE_ID, assignee.Id),
                SpParameter.Create(taskId),
                SpParameter.ModifiedBy()
            };
            await _spExecutor.Execute("dbo.spTask_Update", parameters);
        }

        public async Task UpdateQaAssignee(int taskId, IUser assignee)
        {
            var parameters = new[]
            {
                SpParameter.Create(TaskColumn.QA_ASSIGNEE_ID, assignee.Id),
                SpParameter.Create(taskId),
                SpParameter.ModifiedBy()
            };
            await _spExecutor.Execute("dbo.spTask_Update", parameters);
        }

        public async Task DumpTask(int taskId)
        {
            var parameters = new[]
            {                
                SpParameter.Create(taskId),
                SpParameter.ModifiedBy()
            };
            await _spExecutor.Execute("dbo.spTask_Dump", parameters);
        }

        public async Task AppendSubTask(SubTask subTask)
        {
            var subTaskId = SpParameter.CreateInOut(0);
            var parameters = new[]
            {
                SpParameter.Create(SubTaskColumn.TITLE, subTask.Title),
                SpParameter.Create(SubTaskColumn.CODE, subTask.Type.Code),
                SpParameter.Create(SubTaskColumn.SORT_NO, subTask.ItemId),
                SpParameter.Create(SubTaskColumn.TASK_ID, subTask.Task.Id),
                subTaskId,
                SpParameter.ModifiedBy()
            };
            await _spExecutor.Execute("dbo.spSubTask_Create", parameters);
        }

        private SubTask ConvertSubTask(IRowData record)
        {
            var id = record.AsInt(RefColumn.ID);
            var title = record.AsString(TaskColumn.TITLE);
            var type = SubTaskType.Parse(record.AsString(SubTaskColumn.CODE));
            var sortNo = record.AsInt("SortNo");

            var status = record.AsString("Status");
            var subTask = SubTask.Create(id, title, type, SubTaskStatus.Parse(status), sortNo);

            if (status == SubTaskStatus.InProcess.Code)
            {                
                return subTask;
            }

            if (status == SubTaskStatus.Completed.Code)
            {
                var completionDate = record.AsDateTimeStrict(SubTaskColumn.COMPLETION_DATE);
                var completedById = new UserId(record.AsInt("CompletedBy"));
                var completedByUserName = record.AsString("CompletedByUserName");
                var completedByName = record.AsString("CompletedByName");
                var user = User.Create(completedById, completedByUserName, completedByName);                

                subTask.Completion = TaskCompletion.Create(completionDate, user);
            }
            else if (status == SubTaskStatus.QaCompleted.Code || status == SubTaskStatus.Rejected.Code || status == SubTaskStatus.Misdirected.Code)
            {
                var completionDate = record.AsDateTimeStrict(SubTaskColumn.COMPLETION_DATE);
                var completedById = new UserId(record.AsInt("CompletedBy"));
                var completedByUserName = record.AsString("CompletedByUserName");
                var completedByName = record.AsString("CompletedByName");
                var user = User.Create(completedById, completedByUserName, completedByName);

                subTask.Completion = TaskCompletion.Create(completionDate, user);

                var qaCompletionDate = record.AsDateTimeStrict(SubTaskColumn.QA_COMPLETION_DATE);
                var qaCompletedById = new UserId(record.AsInt("QaCompletedBy"));
                var qaCompletedByUserName = record.AsString("QaCompletedByUserName");
                var qaCompletedByName = record.AsString("QaCompletedByName");
                var qaUser = User.Create(qaCompletedById, qaCompletedByUserName, qaCompletedByName);                

                subTask.QaCompletion = TaskCompletion.Create(qaCompletionDate, qaUser);
            }

            return subTask;
        }

        private Tasc ConvertToTask(IRowData record, IList<SubTask> subTasks)
        {
            var id = record.AsInt(RefColumn.ID);
            var inquiryId = record.AsInt(TaskColumn.INQUIRY_ID);
            var personId = new PersonId(record.AsInt(TaskColumn.PERSON_ID));
            var title = record.AsString(TaskColumn.TITLE);

            var statusStr = record.AsString(TaskColumn.STATUS);
            var status = TascStatus.Parse(statusStr);

            var isQaComplete = record.AsBool(TaskColumn.IS_QA_COMPLETE);

            var assignee = GetAssignee(record);
            var qaAssignee = GetQaAssignee(record);

            var dueDate = record.AsDateTimeStrict(TaskColumn.DUE_DATE);
            var createDate = record.AsDateTimeStrict(TaskColumn.CREATE_DATE);

            var taskTypeStr = record.AsString(TaskColumn.TYPE);
            var taskType = TaskType.Create(taskTypeStr);

            var contractId = new ContractId(record.AsInt(TaskColumn.CONTRACT_ID));
            return new Tasc(id, title, createDate, dueDate, status, taskType, subTasks, assignee, qaAssignee, inquiryId, personId, contractId, isQaComplete);
        }

        private TaskSnapshot ConvertToTaskSnapshot(IRowData record)
        {
            var id = record.AsInt(RefColumn.ID);
            var title = record.AsString(TaskColumn.TITLE);
            var personId = new PersonId(record.AsInt(TaskColumn.PERSON_ID));
            var firstName = record.AsString("FirstName");
            var lastName = record.AsString("LastName");

            var statusStr = record.AsString(TaskColumn.STATUS);
            var status = TascStatus.Parse(statusStr);
            var isQaComplete = record.AsBool(TaskColumn.IS_QA_COMPLETE);

            var assignee = GetAssignee(record);
            var qaAssignee = GetQaAssignee(record);

            var taskTypeStr = record.AsString(TaskColumn.TYPE);
            var taskType = TaskType.Parse(taskTypeStr);

            var dueDate = record.AsDateTime(TaskColumn.DUE_DATE);
            var createDate = record.AsDateTimeStrict(TaskColumn.CREATE_DATE);
            return new TaskSnapshot(id, title, status, assignee, qaAssignee, dueDate, createDate, isQaComplete, taskType, personId, firstName, lastName);
        }

        private static IUser GetAssignee(IRowData row)
        {
            var assigneeId = new UserId(row.AsInt(TaskColumn.ASSIGNEE_ID));
            var userName = row.AsString(TaskColumn.ASSIGNEE_USER_NAME);
            var name = row.AsString(TaskColumn.ASSIGNEE_NAME);
            return User.Create(assigneeId, userName, name);
        }

        private static IUser GetQaAssignee(IRowData row)
        {
            const string PREFIX = "QA";
            var assigneeId = new UserId(row.AsInt(PREFIX + TaskColumn.ASSIGNEE_ID));
            var userName = row.AsString(PREFIX + TaskColumn.ASSIGNEE_USER_NAME);
            var name = row.AsString(PREFIX + TaskColumn.ASSIGNEE_NAME);
            return User.Create(assigneeId, userName, name);
        }
    }
}
