﻿using System;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Letters;
using Scra.Model.ServiceMembers;

namespace Scra.DataAccess.Letters
{
    public class LetterRepository : ILetterRepository
    {
        private readonly SqlExecutor _sqlExecutor;

        private const string GET_BENEFIT_INFORMATION = @"Select B.ID As BenefitId
                , A.ID As ActiveDutyId
                , C.ID As ContractId
                , D.ID As BenefitDetailId
                , A.StartDate As ActiveDutyStartDate
                , A.EndDate As ActiveDutyEndDate
                , D.BenefitEffectiveDate
                , D.ExpectedRemovalDate As BenefitExpectedRemovalDate
                , D.BenefitRemovedDate
                , CASE WHEN ISNULL(C.ProductName, '') = '' THEN T.SUB_PRODUCT_NAME ELSE C.ProductName END as 'SUB_PRODUCT_NAME'
                , CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as 'AccountNumber'
                , T.SCRA_Code
                , C.OpenDate
                , C.CloseDate

            from Benefit As B
            join ActiveDuty As A On A.ID = B.ActiveDutyId
            left join BenefitDetail As D On D.BenefitId = B.ID
            join Contract As C On C.ID = B.ContractID
            JOIN ContractType T ON C.ContractTypeId = T.ID
            Where C.IsDeleted = 0 and B.ID = {BenefitId}";

        private const string GER_PREVIOUS_ACTIVEDUTY = @"SELECT ID
                  ,BranchOfServiceID
                  ,StartDate
                  ,EndDate
                  ,NoticeDate
                  ,Timestamp
                  ,ModifiedBy
                  ,PersonID
	              , ROW_NUMBER() OVER (ORDER BY StartDate) AS 'Row_Counter' into TempActiveDuty
	            from ActiveDuty
	            where PersonId in ( select PersonID from ActiveDuty where ID = {ActiveDutyId})
                  
            Select * from TempActiveDuty where Row_Counter in (Select Row_Counter - 1  from TempActiveDuty where ID = {ActiveDutyId})
            drop table TempActiveDuty";

        public LetterRepository(SqlExecutor sqlExecutor)
        {
            _sqlExecutor = sqlExecutor;
        }

        public async Task<LetterList> GetList()
        {
            const string QUERY = "SELECT [ID],[LetterCode],[LetterName],[LetterNumber],[LetterLongDesc] FROM dbo.[Letter_DATA] ORDER BY [LetterNumber]";
            var items = await _sqlExecutor.Execute(QUERY, Convert);
            return LetterList.Create(items);
        }

        public async Task<string> LoadTemplate(int number)
        {
            var query = "SELECT CONVERT(varchar(max), Template, 0) As Template" +
                        " FROM [dbo].[Letter_DATA]" +
                        " where LetterNumber = " + number;
           
            return await _sqlExecutor.ExecuteOne(query, ToLetterTemplate);
        }

        public async Task<BenefitLetterTemplate> GetBenefitInformation(int id)
        {
            var sql = GET_BENEFIT_INFORMATION.Replace("{BenefitId}", id.ToString());

            return await _sqlExecutor.ExecuteOne(sql, ToBenefitLetterTemplate);
        }

        public async Task<ActiveDuty> GetPriorActiveDuty(int id)
        {
            var sql = GER_PREVIOUS_ACTIVEDUTY.Replace("{ActiveDutyId}", id.ToString());

            return await _sqlExecutor.ExecuteOne(sql, ConvertActiveDuty);
        }

        private ActiveDuty ConvertActiveDuty(IRowData row)
        {
            var id = row.AsInt("ID");
            var branchOfServiceId = row.AsInt("BranchOfServiceID");
            var startDate = row.AsDateTime("StartDate");
            var endDate = row.AsDateTime("EndDate");
            var noticeDate = row.AsDateTime("NoticeDate");
            var personId = row.AsInt("PersonId");

            return ActiveDuty.Create(id, personId, branchOfServiceId, startDate, endDate, noticeDate);
        }

        private BenefitLetterTemplate ToBenefitLetterTemplate(IRowData row)
        {
            return new BenefitLetterTemplate()
            {
                BenefitId = row.AsInt("BenefitId"),
                ActiveDutyId = row.AsInt("ActiveDutyId"),
                ContractId = row.AsInt("ContractId"),
                BenefitDetailId = row.AsInt("BenefitDetailId"),
                ActiveDutyStartDate = row.AsDateTime("ActiveDutyStartDate"),
                AceiveDutyEndDate = row.AsDateTime("ActiveDutyEndDate"),
                BenefitEffectiveDate = row.AsDateTime("BenefitEffectiveDate"),
                BenefitExpectedRemovalDate = row.AsDateTime("BenefitExpectedRemovalDate"),
                BenefitRemovedDate = row.AsDateTime("BenefitRemovedDate"),
                SUB_PRODUCT_NAME = row.AsString("SUB_PRODUCT_NAME"),
                AccountNumber = row.AsString("AccountNumber"),
                SCRA_Code = row.AsString("SCRA_Code"),
                OpenDate = row.AsDateTime("OpenDate"),
                CloseDate = row.AsDateTime("CloseDate"),
            };
        }

        private string ToLetterTemplate(IRowData row)
        {
            var content = row.AsString("Template");
            return content;
        }

        private Letter Convert(IRowData record)
        {
            return Letter.Create(record.AsInt(RefColumn.ID), record.AsString(LetterColumn.CODE), record.AsString(LetterColumn.NAME),
                record.AsInt(LetterColumn.NUMBER), record.AsString(LetterColumn.DESCRIPTION)
            );
        }
    }
}

    
