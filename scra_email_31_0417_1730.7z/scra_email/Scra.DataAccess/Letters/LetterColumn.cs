﻿namespace Scra.DataAccess.Letters
{
    internal static class LetterColumn
    {
        public const string CODE = "LetterCode";
        public const string NAME = "LetterName";
        public const string NUMBER = "LetterNumber";
        public const string DESCRIPTION = "LetterLongDesc";
    }
}