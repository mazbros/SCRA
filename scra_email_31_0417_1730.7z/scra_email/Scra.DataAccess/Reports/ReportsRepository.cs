﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Reports;

namespace Scra.DataAccess.Reports
{
    public class ReportsRepository : IReportsRepository
    {
        private readonly SpExecutor _spExecutor;

        public ReportsRepository(SpExecutor spExecutor)
        {
            _spExecutor = spExecutor;
        }

        public async Task<IEnumerable<WeeklyControlReportItem>> Load(DateTime? reportDate)
        {
            var results = new List<WeeklyControlReportItem>();
            var reportDateParameter = SpParameter.Create("ReportDate", reportDate);
            var data =  await _spExecutor.GetDataTable("dbo.spWeeklyReport_Load", reportDateParameter);
            
            foreach (DataRow dr in data.Rows)
            {
                var item = WeeklyControlReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }

        public async Task<IEnumerable<object>> Load(string reportName)
        {
            var data = await _spExecutor.GetDataTableNp("dbo.sp" + reportName + "_Report");
            var results = new List<object>();

            switch (reportName)
            {
                case "30DaysList":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = ThirtyDaysListReportItem.Create(dr);
                        results.Add(item);
                    }
                break;
                case "ViewLetterHistory":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = ViewLetterHistoryReportItem.Create(dr);
                        results.Add(item);
                    }
                break;
                case "Servicemember_Expired_Denied_Active":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = ServicememberExpiredDeniedActiveReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
                case "Servicemember_Promo_Rate_End":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = ServicememberPromoRateEndReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
                case "Servicemember_Monthly_Incoming_GN_Letter_Sent":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = ServicememberMonthlyIncomingGnLetterSentReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
                case "DMDC_Validation":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = DmdcValidationReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
                case "Inquiries":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = InquiriesReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
                case "Affiliate":
                    foreach (DataRow dr in data.Rows)
                    {
                        var item = AffiliateReportItem.Create(dr);
                        results.Add(item);
                    }
                    break;
            }

            return results;
        }

        public async Task<IEnumerable<TaskStatusReportItem>> Load(string interval, DateTime? reportDate, string taskType)
        {
            var results = new List<TaskStatusReportItem>();
            
            var parameters = new []
            {
                SpParameter.Create("Interval", interval),
                SpParameter.Create("ReportDate", reportDate),
                SpParameter.Create("TaskType", taskType)
            };
            var data =  await _spExecutor.GetDataTable("dbo.spTaskStatus_Report", parameters);
            
            foreach (DataRow dr in data.Rows)
            {
                var item = TaskStatusReportItem.Create(dr);

                results.Add(item);
            }

            return results;
        }
    }
}
