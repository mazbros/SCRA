﻿namespace Scra.DataAccess.Persons
{
    public static class PersonNoteColumn
    {
        public const string PERSON_ID = "PersonId";
        public const string TEXT = "Comment";
        public const string TIMESTAMP = "Timestamp";
        public const string MODIFIED_BY_ID = "ModifiedBy";
        public const string MODIFIED_BY_NAME = "ModifiedByName";
    }
}