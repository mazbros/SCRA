﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.DomainEvents;
using Scra.Model.Exceptions;
using Scra.Model.InquiryTypes;
using Scra.Model.Logs;
using Scra.Model.Persons;

namespace Scra.DataAccess.Persons
{
    internal class PersonRepository : IPersonRepository
    {
        private readonly SpExecutor _spExecutor;
        private readonly IDomainEventDispatcher _domainEventDispatcher;
        private readonly ILogger _logger;

        public PersonRepository(SpExecutor spExecutor, IDomainEventDispatcher domainEventDispatcher, ILogger logger)
        {
            _spExecutor = spExecutor;
            _domainEventDispatcher = domainEventDispatcher;
            _logger = logger;
        }        
        
        public async Task Save(Person person, bool updateContracts=false)
        {
            var id = SpParameter.CreateInOut(person.Id);
            var parameters = new[]
            {
                SpParameter.Create(PersonColumn.FIRST_NAME, person.Name.First),
                SpParameter.Create(PersonColumn.MIDDLE_INITIAL, person.Name.Middle),
                SpParameter.Create(PersonColumn.LAST_NAME, person.Name.Last),
                SpParameter.Create(PersonColumn.SSN, person.Ssn.Value),
                SpParameter.Create(PersonColumn.DOB, person.Dob),
                SpParameter.Create(AddressColumn.ADDRESS1, person.Address.Address1),
                SpParameter.Create(AddressColumn.ADDRESS2, person.Address.Address2),
                SpParameter.Create(AddressColumn.CITY, person.Address.City),
                SpParameter.Create(AddressColumn.STATE, person.Address.State),
                SpParameter.Create(AddressColumn.ZIP, person.Address.ZipCode.Value),
                SpParameter.Create(PersonColumn.PHONE, person.Contacts.Phone.Value),
                SpParameter.Create(PersonColumn.EMAIL, person.Contacts.Email),
                SpParameter.Create(PersonColumn.CONTACT_METHOD_ID, person.ContactMethod.Id),
                SpParameter.ModifiedBy(),
                SpParameter.Create(PersonColumn.F_NUMBER, person.FNumber.ToString()),
                SpParameter.Create(PersonColumn.SEARCH, CreateSearchText(person)),
                SpParameter.Create(PersonColumn.ORIGIN, person.Origin),
                //SpParameter.Create("UpdateContracts", updateContracts?1:0),
                id
            };

            await _spExecutor.Execute("dbo.spPerson_Update", parameters);

            person.Id = new PersonId((int)id.Value);            
        }

        public async Task<Person> SavePerson(Person person, bool updateContracts = false)
        {
            var id = SpParameter.CreateInOut(person.Id);
            var parameters = new[]
            {
                SpParameter.Create(PersonColumn.FIRST_NAME, person.Name.First),
                SpParameter.Create(PersonColumn.MIDDLE_INITIAL, person.Name.Middle),
                SpParameter.Create(PersonColumn.LAST_NAME, person.Name.Last),
                SpParameter.Create(PersonColumn.SSN, person.Ssn.Value),
                SpParameter.Create(PersonColumn.DOB, person.Dob),
                SpParameter.Create(AddressColumn.ADDRESS1, person.Address.Address1),
                SpParameter.Create(AddressColumn.ADDRESS2, person.Address.Address2),
                SpParameter.Create(AddressColumn.CITY, person.Address.City),
                SpParameter.Create(AddressColumn.STATE, person.Address.State),
                SpParameter.Create(AddressColumn.ZIP, person.Address.ZipCode.Value),
                SpParameter.Create(PersonColumn.PHONE, person.Contacts.Phone.Value),
                SpParameter.Create(PersonColumn.EMAIL, person.Contacts.Email),
                SpParameter.Create(PersonColumn.CONTACT_METHOD_ID, person.ContactMethod.Id),
                SpParameter.ModifiedBy(),
                SpParameter.Create(PersonColumn.F_NUMBER, person.FNumber.ToString()),
                SpParameter.Create(PersonColumn.SEARCH, CreateSearchText(person)),
                SpParameter.Create(PersonColumn.ORIGIN, person.Origin),
                //SpParameter.Create("UpdateContracts", updateContracts?1:0),
                id
            };

            await _spExecutor.Execute("dbo.spPerson_Update", parameters);

            person.Id = new PersonId((int)id.Value);

            return person;
        }

        public async Task<Person> Get(PersonId personId)
        {
            if (personId.IsEmpty())
            {
                return null;
            }

            var id = SpParameter.Create(personId);
            var dataSet = await _spExecutor.GetDataSet("dbo.spPerson_Get", id);
            var model = await ConvertToPerson(dataSet);
            return model;
        }

        public async Task<Person> RemoteGet(Ssn ssn, FNumber fNumber)
        {
            var parameters = new[]
            {
                SpParameter.Create("FNo", fNumber.Code),
                SpParameter.Create("SSN", ssn.Value)
            };

            try
            {
                var dataSet = await _spExecutor.GetDataSet("dbo.spPerson_RemoteFetch", parameters);
                var model = await ConvertRemoteToPersonAsync(dataSet);
                return model;
            }
            catch (SqlException ex)
            {
                _logger.Error(ex, "RemoteGet");
                return null;
            }
        }

        public async Task<IList<PersonSnapshot>> Sort(string search, string selectedHeaderName, string direction)
        {
            var parameters = new[]
            {
                SpParameter.Create(PersonColumn.SEARCH, search),
                SpParameter.Create("SortBy", selectedHeaderName),
                SpParameter.Create("SortDir", direction)
            };
            
            return await _spExecutor.GetRecords("dbo.spPerson_SortedList", parameters, ConvertToPersonSnapshot);
        }

        public Task<IList<PersonSnapshot>> Load(string search)
        {
            var searchParameter = SpParameter.Create(PersonColumn.SEARCH, search);
            return _spExecutor.GetRecords("dbo.spPerson_List", searchParameter, ConvertToPersonSnapshot);
        }

        public Task<IList<PersonSnapshot>> LoadAll(string search)
        {
            var searchParameter = SpParameter.Create(PersonColumn.SEARCH, search);
            return _spExecutor.GetRecords("dbo.spPerson_List_noFilter", searchParameter, ConvertToPersonSnapshotWithOrigin);
        }

        public async Task Save(DependentLink link)
        {
            var id = SpParameter.CreateInOut(link.Id);
            var parameters = new[]
            {
                SpParameter.Create(DependentLinkColumn.FROM_ID, link.FromId),
                SpParameter.Create(DependentLinkColumn.TO_ID, link.ToId),
                SpParameter.Create(DependentLinkColumn.START_DATE, link.StartDate),
                SpParameter.Create(DependentLinkColumn.END_DATE, link.EndDate),
                SpParameter.Create(DependentLinkColumn.DEPENDENT_TYPE_ID, link.Type.Id),
                id,
                SpParameter.ModifiedBy()
            };

            try
            {
                await _spExecutor.Execute("dbo.spPersonLinkDependent", parameters);
                link.Id = (int)id.Value;
            }
            catch (SqlException ex)
            {
                if (ex.ToString().Contains("UC_PersonToPersonLink"))
                {
                    throw new UserException("Dependent is already added.");
                }
                throw;
            }

            
        }

        private string CreateSearchText(Person person)
        {
            var dob= string.Format("{0:M/d/yy}|{0:MM/dd/yyyy}", person.Dob);
            return !string.IsNullOrEmpty(person.Name.Middle)
                ? person.Name.LastFirstName + "|" + 
                  person.Name.FullName + "|" + 
                  person.Name.First + "|" + 
                  person.Name.Last + "|" +
                  person.Name.First + " " + person.Name.Last + "|" + 
                  person.Address.GetFull() + "|" + 
                  dob 
                : person.Name.LastFirstName + "|" + 
                  person.Name.First + "|" + 
                  person.Name.Last + "|" + 
                  person.Name.First + " " + person.Name.Last + "|" + 
                  person.Address.GetFull() + "|" + 
                  dob;
        }

        private async Task<Person> ConvertRemoteToPersonAsync(DataSet set)
        {
            var personRow = set.GetFirstTableRow();
            if (personRow == null)
            {
                return null;
            }

            var name = GetName(personRow);
            var address = GetAddress(personRow);
            var ssn = GetSsn(personRow);
            var dob = GetDob(personRow);
            var contacts = GetContacts(personRow);
            var fNumber = GetFNumber(personRow);
            var origin = personRow.AsString(PersonColumn.ORIGIN);

            return await PersonFactory.CreateAsync(name, address, dob, ssn, contacts, fNumber, origin);
        }

        private async Task<Person> ConvertToPerson(DataSet set)
        {
            var personRow = set.GetFirstTableRow();
            var dependentsTable = set.Tables[1];

            var id = new PersonId(personRow.AsInt(RefColumn.ID));
            var name = GetName(personRow);
            var address = GetAddress(personRow);
            var ssn = GetSsn(personRow);
            var dob = GetDob(personRow);
            var contacts = GetContacts(personRow);
            var fNumber = GetFNumber(personRow);
            var origin = personRow.AsString(PersonColumn.ORIGIN);

            var contactMethod = await GetMethod(personRow);
            var dependents = await ConvertToDependentLinks(dependentsTable, id);

            return PersonFactory.Create(id, name, address, dob, ssn, dependents, contactMethod, contacts, fNumber, origin);
        }

        private static async Task<ContactMethod> GetMethod(IRowData personRow)
        {
            var contactMethodList = await ContactMethodList.GetInstance();
            var contactMethodId = personRow.AsInt(PersonColumn.CONTACT_METHOD_ID);
            return contactMethodList.Get(contactMethodId);
        }

        private async Task<IList<DependentLink>> ConvertToDependentLinks(DataTable table, PersonId personId)
        {
            var res = new List<DependentLink>();
            var dependentTypeList = await DependentTypeList.GetInstance();
            foreach (DataRow tableRow in table.Rows)
            {
                var row = RowDataFactory.Create(tableRow);
                res.Add(ConvertToDependentLinks(row, dependentTypeList, personId));
            }
            return res;
        }

        private DependentLink ConvertToDependentLinks(IRowData row, DependentTypeList dependentTypeList, PersonId personId)
        {
            var id = row.AsInt(DependentLinkColumn.ID);
            var typeId = row.AsInt(DependentLinkColumn.DEPENDENT_TYPE_ID);
            var type = dependentTypeList.Get(typeId);
            return DependentLinkFactory.Create(
                id,
                type,
                personId,
                new PersonId(row.AsInt(DependentLinkColumn.PERSON_ID)),
                row.AsDateTime(DependentLinkColumn.START_DATE), 
                row.AsDateTime(DependentLinkColumn.END_DATE));
        }

        private PersonSnapshot ConvertToPersonSnapshotWithOrigin(IRowData record)
        {
            var id = new PersonId(record.AsInt(RefColumn.ID));
            var name = GetName(record);
           
            var origin = GetOrigin(record);

            return PersonFactory.CreateSnapshot(id, name, origin);
        }

        private InquiryType GetOrigin(IRowData record)
        {
            return InquiryType.Parse(record.AsString("Origin"));
        }

        private PersonSnapshot ConvertToPersonSnapshot(IRowData record)
        {
            var id = new PersonId(record.AsInt(RefColumn.ID));
            var name = GetName(record);
            var address = GetAddress(record);
            var ssn = GetSsn(record);
            var fNumber = GetFNumber(record);

            return PersonFactory.CreateSnapshot(id, name, address, ssn, fNumber);
        }

        private static Ssn GetSsn(IRowData record)
        {
            var str = record.AsString(PersonColumn.SSN);
            return Ssn.Parse(str);
        }

        private static FNumber GetFNumber(IRowData record)
        {
            var str = record.AsString(PersonColumn.F_NUMBER);
            return FNumber.Parse(str);
        }

        private static DateTime? GetDob(IRowData record)
        {
            return record.AsDateTime(PersonColumn.DOB);
        }
        private PersonName GetName(IRowData record)
        {
            return PersonName.Create(record.AsString(PersonColumn.FIRST_NAME),
                record.AsString(PersonColumn.MIDDLE_INITIAL), record.AsString(PersonColumn.LAST_NAME));
        }

        private PersonContacts GetContacts(IRowData record)
        {
            var rawPhone = record.AsString(PersonColumn.PHONE);
            var phone = PhoneNumber.Parse(rawPhone);
            return PersonContacts.Create(phone, record.AsString(PersonColumn.EMAIL));
        }

        private Address GetAddress(IRowData record)
        {
            var zipStr = record.AsString(AddressColumn.ZIP);
            var zip = ZipCode.Parse(zipStr);
            return Address.Create(record.AsString(AddressColumn.ADDRESS1), 
                record.AsString(AddressColumn.ADDRESS2), 
                record.AsString(AddressColumn.CITY), 
                GetState(record),
                zip);
        }

        private AddressState GetState(IRowData record)
        {
            return AddressState.Parse(record.AsString(AddressColumn.STATE));
        }
    }
}