﻿namespace Scra.DataAccess.Version
{
    internal class VersionColumn
    {
        public const string VERSION = "Version";
    }
}