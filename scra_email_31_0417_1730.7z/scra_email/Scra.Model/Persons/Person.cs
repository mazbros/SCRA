﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.DomainEvents;
using Scra.Model.ServiceMembers;
using Scra.Model.Tools;

namespace Scra.Model.Persons
{
    public class Person : IDomainEventHolder
    {
        public PersonId Id { get; set; }
        public PersonName Name { get; private set; }
        public Ssn Ssn { get; set; }
        public Address Address { get; set; }
        public PersonContacts Contacts { get; set; }
        public DateTime? Dob { get; set; }
        public IReadOnlyCollection<DependentLink> DependentLinks { get; set; }
        public ContactMethod ContactMethod { get; set; }
        public FNumber FNumber { get; private set; }
        public IList<IDomainEvent> DomainEvents { get; private set; }
        public string Origin { get; set; }

        public Person(PersonId id, PersonName name, Ssn ssn, Address address, ContactMethod contactMethod, PersonContacts contacts, FNumber fNumber, string origin)
        {
            DomainEvents = new List<IDomainEvent>();
            Id = id;
            Name = name;
            Ssn = ssn;
            Address = address;
            ContactMethod = contactMethod;
            Contacts = contacts;
            FNumber = fNumber;
            Origin = origin;
        }

        public Task<ServiceMember> GetServiceMember()
        {
            var serviceMemberRepository = Di.Get<IServiceMemberRepository>();
            return serviceMemberRepository.Get(Id);
        }

        public async Task<ActiveDuty> GetLastActiveDuty()
        {
            var serviceMembers = new List<ServiceMember> { await GetServiceMember() };

            foreach (var dependentLink in DependentLinks)
            {
                var dependent = await dependentLink.GetDependent();
                var serviceMember = await dependent.GetServiceMember();
                if (serviceMember != null)
                {
                    serviceMembers.Add(serviceMember);
                }
            }

            var activeDuties = serviceMembers
                .Select(x => x.GetLastActiveDuty())
                .Where(x => x != null)
                .OrderBy(x => x.StartDate)
                .ToList();

            var activeDuty = activeDuties.FirstOrDefault(x => x.EndDate == null);
            if (activeDuty != null)
            {
                return activeDuty;
            }

            return activeDuties
                .OrderByDescending(x => x.StartDate)
                .FirstOrDefault();
        }

        public void ChangeFNumber(FNumber newNumber)
        {
            if (newNumber.IsEmpty() || newNumber == FNumber)
            {
                return;
            }

            FNumber = newNumber;
            DomainEvents.Add(new FNumberChangedEvent(this));   //IGOR Important
        }

        public static async Task<Person> Import(Ssn ssn, FNumber fNumber)
        {
            var repo = Di.Get<IPersonRepository>();
            var person = await repo.RemoteGet(ssn, fNumber);
            if (person == null)
            {
                return null;
            }

            await repo.Save(person);

            return await repo.Get(person.Id);
        }
    }
}
