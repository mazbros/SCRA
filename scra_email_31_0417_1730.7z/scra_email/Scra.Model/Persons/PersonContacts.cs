﻿namespace Scra.Model.Persons
{
    public class PersonContacts
    {
        public PhoneNumber Phone { get; set; }
        public string Email { get; set; }

        private PersonContacts()
        {
        }

        public static PersonContacts Empty()
        {
            return new PersonContacts();
        }

        public static PersonContacts Create(PhoneNumber phone, string email)
        {
            return new PersonContacts { Phone = phone, Email = (email ?? "").ToLower() };
        }
    }
}