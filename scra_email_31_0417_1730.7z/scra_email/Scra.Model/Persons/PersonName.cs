﻿using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public class PersonName
    {
        public string First { get; set; }
        public string Middle { get; set; }
        public string Last { get; set; }

        public string FullName
        {
            get
            {
                return string.Format("{0} {1} {2}", First, Middle, Last).Replace("  ", " ").Trim();
            }
        }

        public static PersonName Empty()
        {
            return new PersonName();
        }

        public bool IsEmpty()
        {
            return First.IsEmpty() && Last.IsEmpty();
        }

        public bool IsNotEmpty()
        {
            return !IsEmpty();
        }

        public static PersonName Create(string f, string m, string l)
        {
            return new PersonName{First = f, Middle = m, Last = l};
        }

        public string LastFirstName
        {
            get
            {
                return string.Format("{2}, {0} {1}", First, Middle, Last).Replace("  ", " ").Trim();
            }
        }

        public override string ToString()
        {
            return FullName;
        }
    }
}