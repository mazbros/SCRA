﻿using System;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public struct FNumber : IEquatable<FNumber>
    {
        private readonly string _code;
        public string Code
        {
            get { return _code; }
        }

        private FNumber(string fNumber)
        {
            _code = (fNumber ?? "").Replace(" ", "");
        }

        public bool IsEmpty()
        {
            return Code.IsEmpty();
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public bool Equals(FNumber other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is FNumber))
            {
                return false;
            }            
            return Equals((FNumber)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator == (FNumber obj1, FNumber obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator != (FNumber obj1, FNumber obj2)
        {
            return !(obj1 == obj2);
        }

        public static FNumber Empty()
        {
            return new FNumber("");
        }

        public static FNumber Parse(string fNumber)
        {
            return new FNumber(fNumber);
        }

        public static bool CheckFormat(string fNumber)
        {
            var msg = "The customer number should start \nwith letter F or J followed by 9 digit, \npadded with 0 on the left \n(e.g. F000000001)";

            if (fNumber.Length != 10)
                throw new UserException(msg);

            if(fNumber[0] != 'F' && fNumber[0] != 'f' && fNumber[0] != 'J' && fNumber[0] != 'j')
                throw new UserException(msg);

            return true;
        }
    }
}