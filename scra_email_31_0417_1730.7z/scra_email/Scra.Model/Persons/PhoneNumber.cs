﻿using System;
using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public struct PhoneNumber : IEquatable<PhoneNumber>
    {
        private const int RAW_LENGTH = 10;
        private const string EMPTY_VALUE = "0000000000";
        private const string DELIMITER = "-";

        public string Value;

        public string GetDisplay()
        {
            var text = Value ?? EMPTY_VALUE;
            return text.Substring(0, 3) + DELIMITER + text.Substring(3, 3) + DELIMITER + text.Substring(6, 4);
        }

        private PhoneNumber(string number)
        {
            Value = number;
        }

        public override string ToString()
        {
            return Value;
        }

        public static PhoneNumber Empty()
        {
            return new PhoneNumber(EMPTY_VALUE);
        }

        public static PhoneNumber Parse(string number)
        {
            if (!IsValid(number))
            {
                return Empty();
            }

            number = ToRaw(number);
            return new PhoneNumber(number);
        }

        private static bool IsValid(string zip)
        {
            if (zip.IsEmpty())
            {
                return false;
            }

            return ToRaw(zip).Length == RAW_LENGTH;
        }

        private static string ToRaw(string zip)
        {
            return zip.Replace(DELIMITER, "");
        }

        public override int GetHashCode()
        {
            return (Value != null ? Value.GetHashCode() : 0);
        }

        public bool Equals(PhoneNumber other)
        {
            return Value == other.Value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is PhoneNumber))
            {
                return false;
            }
            return Equals((PhoneNumber)obj);
        }

        public static bool operator ==(PhoneNumber obj1, PhoneNumber obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(PhoneNumber obj1, PhoneNumber obj2)
        {
            return !(obj1 == obj2);
        }
    }
}