﻿using System;
using Scra.Model.Extensions;

namespace Scra.Model.Persons
{
    public struct ZipCode : IEquatable<ZipCode>
    {
        private const int RAW_LENGTH_9 = 9;
        private const int RAW_LENGTH_5 = 5;
        private const string EMPTY_ROUTE = "0000";
        private const string EMPTY_VALUE = "00000" + EMPTY_ROUTE;

        public readonly string Value;

        public string GetDisplay()
        {
            var text = Value ?? EMPTY_VALUE;
            if (text.Length == RAW_LENGTH_5)
                return text + "-" + EMPTY_ROUTE;

            return text.Substring(0, 5) + "-" + text.Substring(5, 4);
        }

        private ZipCode(string zip)
        {
            Value = zip;
        }

        public override string ToString()
        {
            return Value;
        }

        public static ZipCode Empty()
        {
            return new ZipCode(EMPTY_VALUE);
        }

        public static ZipCode Parse(string zip)
        {
            if (!IsValid(zip))
            {
                return Empty();
            }

            zip = ToRaw(zip);
            return new ZipCode(zip);
        }

        private static bool IsValid(string zip)
        {
            if (zip.IsEmpty())
            {
                return false;
            }

            return ToRaw(zip).Length == RAW_LENGTH_9 | ToRaw(zip).Length == RAW_LENGTH_5;
        }

        private static string ToRaw(string zip)
        {
            return zip.Replace("-", "");
        }

        public override int GetHashCode()
        {
            return (Value != null ? Value.GetHashCode() : 0);
        }

        public bool Equals(ZipCode other)
        {
            return Value == other.Value;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ZipCode))
            {
                return false;
            }
            return Equals((ZipCode)obj);
        }

        public static bool operator ==(ZipCode obj1, ZipCode obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(ZipCode obj1, ZipCode obj2)
        {
            return !(obj1 == obj2);
        }
    }
}