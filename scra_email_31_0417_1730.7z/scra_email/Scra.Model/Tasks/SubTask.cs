﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.DomainEvents;
using Scra.Model.Inquiries;
using Scra.Model.Tools;

namespace Scra.Model.Tasks
{
    public class SubTask : IDomainEventHolder
    {
        private SubTask(int id, string title, SubTaskType type, SubTaskStatus status ,TaskCompletion completion, TaskCompletion qaCompletion)
        {
            DomainEvents = new List<IDomainEvent>();
            Id = id;
            Title = title;
            Status = status;
            Completion = completion;
            QaCompletion = qaCompletion;
            Type = type;
        }

        private SubTask(int id, string title, SubTaskType type, SubTaskStatus status, int itemId)
        {
            DomainEvents = new List<IDomainEvent>();
            Id = id;
            Title = title;
            Status = status;            
            Type = type;
            ItemId = itemId;
        }

        public int Id { get; set; }
        public int ItemId { get; set; }
        public string Title { get; private set; }
        public SubTaskStatus Status { get; set; }
        public SubTaskType Type { get; private set; }


        public TaskCompletion Completion { get; set; }
        public TaskCompletion QaCompletion { get; set; }


        public IList<IDomainEvent> DomainEvents { get; private set; }
        public Tasc Task { get; set; }

        public static SubTask CreateNew(string title)
        {
            return new SubTask(0, title, SubTaskType.Empty, SubTaskStatus.InProcess,TaskCompletion.None, TaskCompletion.None);
        }

        public static SubTask CreateNew(SubTaskType type)
        {
            return new SubTask(0, type.Name, type, SubTaskStatus.InProcess, TaskCompletion.None, TaskCompletion.None);
        }

        public static SubTask CreateNew(string title, SubTaskType type)
        {
            return new SubTask(0, title, type, SubTaskStatus.InProcess, TaskCompletion.None, TaskCompletion.None);
        }

        public static SubTask Create(int id, string title, SubTaskType type, SubTaskStatus status, int itemId)
        {
            return new SubTask(id, title, type, status, itemId);
        }

        public async Task Complete()
        {            
            Status = SubTaskStatus.Completed;

            if (Type == SubTaskType.AcknowledgeInquiry)
            {
                DomainEvents.Add(new InquiryAcknowledgeEvent(Task.InquiryId));
            }

            Task.UpdateStatus();
            var repository = Di.Get<ITaskRepository>();
            await repository.SaveCompletion(this);
        }

        public async Task CompleteQa()
        {            
            Status = SubTaskStatus.QaCompleted;

            Task.UpdateStatus();
            var repository = Di.Get<ITaskRepository>();
            await repository.SaveQaCompletion(this);
        }

        public async Task RejectQa()
        {
            Status = SubTaskStatus.Rejected;
            Task.UpdateStatus();
            Task.ToRejected();
            var repository = Di.Get<ITaskRepository>();
            await repository.SaveCompletion(this);
            await repository.SaveQaCompletion(this);

            await repository.AppendSubTask(this);
        }

        public async Task Misdirected()
        {
            Status = SubTaskStatus.Misdirected;
            Task.UpdateStatus();
            Task.ToMisdirected();
            var repository = Di.Get<ITaskRepository>();
            await repository.SaveCompletion(this);
            await repository.SaveQaCompletion(this);
        }
    }
}