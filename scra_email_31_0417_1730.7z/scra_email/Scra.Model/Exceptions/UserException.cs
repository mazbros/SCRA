﻿namespace Scra.Model.Exceptions
{
    public class UserException : AppException
    {
        public UserException(string message) : base(message)
        {
        }
    }

    public class BreakException : AppException
    {
        public BreakException(string message) : base(message)
        {
        }
    }
}