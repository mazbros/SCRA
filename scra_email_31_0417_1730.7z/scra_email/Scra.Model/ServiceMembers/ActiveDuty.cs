﻿using System;
using Scra.Model.BranchOfServices;
using Scra.Model.Persons;

namespace Scra.Model.ServiceMembers
{
    public class ActiveDuty
    {
        public static ActiveDuty Create(PersonId personId)
        {
            return new ActiveDuty {PersonId = personId };
        }


        public static ActiveDuty Create(int id, int personId, int branchOfServiceId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate)
        {
            return new ActiveDuty
            {
                Id = id,
                PersonId = new PersonId(personId),
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
            };
        }

        public static ActiveDuty Create(int id, PersonId personId, DateTime? startDate, DateTime? endDate, DateTime? noticeDate, BranchOfService branchOfService)
        {
            return new ActiveDuty
            {
                PersonId = personId,
                Id = id,
                StartDate = startDate,
                EndDate = endDate,
                NoticeDate = noticeDate,
                BranchOfService = branchOfService
            };
        }

        public int Id { get; set; }
        public PersonId PersonId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? NoticeDate { get; set; }
        public BranchOfService BranchOfService { get; set; }
        public ServiceMember ServiceMember { get; set; }
    }
}