﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Contracts
{
    public struct ContractCategory : IEquatable<ContractCategory>
    {
        private readonly string _code;
        private readonly string _name;

        public string Name
        {
            get { return _name; }
        }

        public string Code
        {
            get { return _code; }
        }

        public static readonly ContractCategory ConsumerLoan = new ContractCategory("consumer_loan", "Consumer Loan");
        public static readonly ContractCategory CreditCard = new ContractCategory("credit_card", "Credit Card");
        public static readonly ContractCategory Mortgage = new ContractCategory("mortgage", "Mortgage");
        public static readonly ContractCategory Commercial = new ContractCategory("commercial", "Commercial Loan");
        public static readonly ContractCategory Auto = new ContractCategory("auto", "Auto");
        public static readonly ContractCategory SafeDepositBox = new ContractCategory("safe_dep_box", "Safe Deposit Box");
        public static readonly ContractCategory Other = new ContractCategory("other", "Other");
        public static readonly ContractCategory Empty = new ContractCategory("empty","");
        private static readonly Dictionary<string, ContractCategory> Map =
            new[] {Empty, ConsumerLoan, CreditCard, Mortgage, Commercial, Auto, SafeDepositBox, Other }.ToDictionary(x => x.Code, x => x);

        private ContractCategory(string code, string name)
        {
            _name = name;
            _code = code;
        }

        public static ContractCategory Parse(string code)
        {
            if (code == null)
            {
                return Other;
            }

            ContractCategory category;
            if (Map.TryGetValue(code, out category))
            {
                return category;
            }
            
            return new ContractCategory(code, code);
        }

        public override int GetHashCode()
        {
            return Code != null ? Code.GetHashCode() : 0;
        }

        public bool Equals(ContractCategory other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ContractCategory))
            {
                return false;
            }
            return Equals((ContractCategory)obj);
        }

        public override string ToString()
        {
            return Code;
        }

        public static bool operator ==(ContractCategory obj1, ContractCategory obj2)
        {
            return obj1.Equals(obj2);
        }

        public static bool operator !=(ContractCategory obj1, ContractCategory obj2)
        {
            return !(obj1 == obj2);
        }
    }
}