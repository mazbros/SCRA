﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.Model.Tasks;

namespace Scra.Model.Contracts
{
    public interface IBenefitRepository
    {
        Task<IList<Benefit>> LoadByContract(ContractId contractId);
        Task<Benefit> LoadById(int benefitId);
        Task Save(Benefit benefit);
        Task<int> GetBenefitByTask(SubTask subTask);
        Task<IList<Benefit>> LoadByPerson(int id);
        Task<IList<BenefitEvent>> LoadEvent(int personId);
    }
}