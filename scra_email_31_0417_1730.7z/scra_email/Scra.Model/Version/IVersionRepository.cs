﻿using System.Threading.Tasks;

namespace Scra.Model.Version
{
    public interface IVersionRepository
    {        
        Task<DbVersion> GetDbVersion();
        Task<string> GetDbName();
    }
}