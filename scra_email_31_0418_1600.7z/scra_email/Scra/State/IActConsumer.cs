﻿using System.Collections.Generic;

namespace Scra.State
{
    public interface IActConsumer
    {
        void Consume(IList<IAct> acts);
    }
}