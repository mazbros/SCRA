﻿using System;

namespace Scra.State
{
    public interface IStateListenerSubscriber
    {
        void SubscribeStateListener(Action<AppState> executor);
    }
}