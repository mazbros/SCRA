﻿using System;
using System.Windows;
using Scra.Model.Exceptions;

namespace Scra.Controls.MessageDialog
{
    public interface IMessageDialog
    {
        void Error(Exception ex, string message);

        void Error(Exception ex, MessageDialogImage image);

        void Warning(string message);        

        void Warning(string message, bool skipLogging);

        void Warning(UserException ex);

        MessageBoxResult Confirmation(string message);

        MessageBoxResult ConfirmationBinary(string message);
    }
}
