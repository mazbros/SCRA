﻿using System.Windows;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    public partial class CheckBlock
    {
        public CheckBlock()
        {
            InitializeComponent();

            var user = Di.Get<IUser>();
            IsCheckBoxEnabled = !user.Type.Equals(UserType.Guest);
        }

        public bool IsCheckBoxEnabled
        {
            get { return (bool)GetValue(IsCheckBoxEnabledProperty); }
            set { SetValue(IsCheckBoxEnabledProperty, value); }
        }
        public static readonly DependencyProperty IsCheckBoxEnabledProperty = DependencyProperty.Register(
            "IsCheckBoxEnabled", typeof(bool), typeof(CheckBlock), new PropertyMetadata(null));

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(CheckBlock), new PropertyMetadata(""));

        public string EditWidth
        {
            get { return (string)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(string), typeof(CheckBlock), new PropertyMetadata("*"));

        public bool Value
        {
            get { return (bool)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }
        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
            "Value", typeof(bool), typeof(CheckBlock), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }
}
