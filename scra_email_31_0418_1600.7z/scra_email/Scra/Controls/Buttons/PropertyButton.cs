﻿using System.Windows.Controls;

namespace Scra.Controls.Buttons
{
    class PropertyButton : Button
    {
    }
}
