﻿using System.Windows;
using System.Windows.Markup;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Controls
{
    [ContentProperty("AdditionalContent")]
    public partial class CustomBlock
    {
        public CustomBlock()
        {
            InitializeComponent();

            var user = Di.Get<IUser>();
            IsDropdownEnabled = !user.Type.Equals(UserType.Guest);
        }

        public string LabelName
        {
            get { return (string)GetValue(LabelNameProperty); }
            set { SetValue(LabelNameProperty, value); }
        }
        public static readonly DependencyProperty LabelNameProperty = DependencyProperty.Register(
            "LabelName", typeof(string), typeof(CustomBlock), new PropertyMetadata(""));

        public int EditWidth
        {
            get { return (int)GetValue(EditWidthProperty); }
            set { SetValue(EditWidthProperty, value); }
        }
        public static readonly DependencyProperty EditWidthProperty = DependencyProperty.Register(
            "EditWidth", typeof(int), typeof(CustomBlock), new PropertyMetadata(200));

        public bool IsDropdownEnabled
        {
            get { return (bool)GetValue(IsDropdownEnabledProperty); }
            set { SetValue(IsDropdownEnabledProperty, value); }
        }
        public static readonly DependencyProperty IsDropdownEnabledProperty = DependencyProperty.Register(
            "IsDropdownEnabled", typeof(bool), typeof(CustomBlock), new PropertyMetadata(null));


        public object AdditionalContent
        {
            get { return GetValue(AdditionalContentProperty); }
            set { SetValue(AdditionalContentProperty, value); }
        }
        public static readonly DependencyProperty AdditionalContentProperty =
            DependencyProperty.Register("AdditionalContent", typeof(object), typeof(CustomBlock),
                new PropertyMetadata(null));
    }
}
