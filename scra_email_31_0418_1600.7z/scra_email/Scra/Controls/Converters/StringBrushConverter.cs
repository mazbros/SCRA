﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Scra.Controls.Converters
{
    public class StringBrushConverter : IValueConverter
    {
        private readonly BrushConverter _brushConverter;

        public StringBrushConverter()
        {
            _brushConverter = new BrushConverter();
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null ? _brushConverter.ConvertFromString(value.ToString()) : null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
