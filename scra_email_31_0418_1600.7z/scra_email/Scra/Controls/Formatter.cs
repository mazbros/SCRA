﻿using System;
using System.Globalization;

namespace Scra.Controls
{
    public static class Formatter
    {
        public static DateTime Minimum = System.DateTime.MinValue;

        public static string DateTime(DateTime? date)
        {
            return string.Format("{0:MM/dd/yyyy hh:mm tt}", date);
        }

        public static decimal Percent(decimal rate)
        {
            return decimal.Round(rate, 2);
        }

        public static decimal Money(decimal value)
        {
            return decimal.Round(value, 2);
        }

        public static string Date(DateTime? date)
        {
            if (date == null || date.Value == System.DateTime.MinValue)
            {
                return "";
            }

            return string.Format("{0:MM/dd/yyyy}", date);
        }

        public static string Range(DateTime? from, DateTime? to)
        {
            return Date(from) + " - " + Date(to);
        }

        public static bool IsValidDate(string text)
        {
            var parsed = ParseDate(text);
            return parsed != null;
        }

        public static DateTime? ParseDate(string text)
        {
            var format = "MM/dd/yyyy hh:mm tt";
            DateTime parsed;
            if (System.DateTime.TryParseExact(text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed))
            {
                if (parsed == Minimum)
                {
                    return null;
                }
                return parsed;
            }

            return null;
        }
    }
}
