﻿using System;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace Scra.Controls
{
    public  class TextBoxInputBehavior : Behavior<TextBox>
    {
        const NumberStyles VALID_NUMBER_STYLES = NumberStyles.AllowDecimalPoint |
                                               NumberStyles.AllowThousands |
                                               NumberStyles.AllowLeadingSign;

        public TextBoxInputBehavior()
        {
            TextInputMode = TextBoxInputMode.None;
            JustPositiveDecimalInput = false;
        }

        
        public static readonly DependencyProperty JustPositivDecimalInputProperty =
            DependencyProperty.Register("JustPositivDecimalInput", typeof(bool),
                typeof(TextBoxInputBehavior), new FrameworkPropertyMetadata(false));

        
        public static readonly DependencyProperty TextInputModeProperty = DependencyProperty.Register(
            "TextInputMode", typeof(TextBoxInputMode), typeof(TextBoxInputBehavior), new FrameworkPropertyMetadata(TextBoxInputMode.None));

        public bool JustPositiveDecimalInput
        {
            get { return (bool) GetValue(JustPositivDecimalInputProperty); }
            set { SetValue(JustPositivDecimalInputProperty, value); }
        }

        public TextBoxInputMode TextInputMode
        {
            get { return (TextBoxInputMode)GetValue(TextInputModeProperty);} 
            set { SetValue(TextInputModeProperty, value);}
        }
        
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.PreviewTextInput += AssociatedObjectPreviewTextInput;
            AssociatedObject.PreviewKeyDown += AssociatedObjectPreviewKeyDown;

            DataObject.AddPastingHandler(AssociatedObject, Pasting);

        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.PreviewTextInput -= AssociatedObjectPreviewTextInput;
            AssociatedObject.PreviewKeyDown -= AssociatedObjectPreviewKeyDown;

            DataObject.RemovePastingHandler(AssociatedObject, Pasting);
        }

        private void Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(string)))
            {
                var pastedText = (string) e.DataObject.GetData(typeof(string));

                if (!IsValidInput(GetText(pastedText)))
                {
                    SystemSounds.Beep.Play();
                    e.CancelCommand();
                }
            }
            else
            {
                SystemSounds.Beep.Play();
                e.CancelCommand();
            }
        }

        private void AssociatedObjectPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                if (!IsValidInput(GetText(" ")))
                {
                    SystemSounds.Beep.Play();
                    e.Handled = true;
                }
            }
        }

        private void AssociatedObjectPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!IsValidInput(GetText(e.Text)))
            {
                SystemSounds.Beep.Play();
                e.Handled = true;
            }
        }

        private string GetText(string input)
        {
            var txt = AssociatedObject;
            var realText = txt.Text.Remove(txt.SelectionStart, txt.SelectionLength);
            var newText = realText.Insert(txt.CaretIndex, input);

            return newText;
        }

        private bool IsValidInput(string input)
        {
            switch (TextInputMode)
            {
                case TextBoxInputMode.None:
                    return true;
                case TextBoxInputMode.DigitInput:
                    return CheckIsDigit(input);

                case TextBoxInputMode.DecimalInput:
                    decimal d;
                    //wen mehr als ein Komma
                    if (input.ToCharArray().Where(x => x == ',').Count() > 1)
                        return false;

                    if (input.Contains("-"))
                    {
                        //minus einmal am anfang zulässig
                        if (!JustPositiveDecimalInput && input.IndexOf("-", StringComparison.Ordinal) == 0 && input.Length == 1)
                            return true;
                        var result = decimal.TryParse(input, VALID_NUMBER_STYLES, CultureInfo.CurrentCulture, out d);
                        return result;
                    }
                    else
                    {
                        var result = decimal.TryParse(input, VALID_NUMBER_STYLES, CultureInfo.CurrentCulture, out d);
                        return result;
                    }


                default: throw new ArgumentException("Unknown TextBoxInputMode");

            }
        }

        private static bool CheckIsDigit(string wert)
        {
            return wert.ToCharArray().All(char.IsDigit);
        }
    }

}

public enum TextBoxInputMode
    {
        None,
        DecimalInput,
        DigitInput
    }




