﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Extensions;
using Scra.Model.Reports;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Tools;
using Scra.Views.Shell;

namespace Scra.Views.Reports
{
    public class ReportsListViewModel : BaseViewModel
    {
        private readonly IReportsRepository _repository;
        private readonly IMessageDialog _messageDialog;
        private readonly ShellViewModel _shellViewModel;

        private List<WeeklyControlReportItem> _items;
        private List<ThirtyDaysListReportItem> _reportLines;
        private List<ViewLetterHistoryReportItem> _letterReportLines;
        private List<ServicememberExpiredDeniedActiveReportItem> _servicememberExpiredDeniedActiveReportLines;
        private List<ServicememberPromoRateEndReportItem> _servicememberPromoRateEndReportLines;
        private List<ServicememberMonthlyIncomingGnLetterSentReportItem> _servicememberMonthlyIncomingGnLetterSentReportLines;
        private List<DmdcValidationReportItem> _dmdcValidationReportLines;
        private List<InquiriesReportItem> _inquiriesReportLines;
        private List<AffiliateReportItem> _affiliateReportLines;
        private List<TaskStatusReportItem> _taskStatusReportItems;
        private TaskType _selectedTaskType;
        private string _interval;
        private Visibility _visibility;

        public ReportsListViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _shellViewModel = Di.Get<ShellViewModel>();
            _repository = Di.Get<IReportsRepository>();
            _messageDialog = Di.Get<IMessageDialog>();

            OnViewLoaded = OnLoaded;

            RunWeeklyControlReportCommand = new Command(RunWeeklyControlReport);
            Run30DaysListReportCommand = new Command(Run30DaysListReport);
            RunViewLetterHistoryReportCommand = new Command(RunViewLetterHistoryReport);
            RunServicememberExpiredDeniedActiveReportCommand = new Command(RunServicememberExpiredDeniedActiveReport);
            RunServicememberPromoRateEndReportCommand = new Command(RunServicememberPromoRateEndReport);
            RunServicememberMonthlyIncomingGnLetterSentCommand = new Command(RunServicememberMonthlyIncomingGnLetterSentReport);
            RunWeeklyTaskStatusReportCommand = new Command(RunTaskStatusReport);
            RunDmdcValidationCommand = new Command(RunDmdcValidationReport);
            RunInquiriesCommand = new Command(RunInquiriesReport);
            RunAffiliateCommand = new Command(RunAffiliateReport);

            TaskTypes = new ObservableCollection<TaskType>(TaskType.TaskTypeList().ToList());
        }

        public ICommand RunWeeklyControlReportCommand { get; set; }
        public ICommand Run30DaysListReportCommand { get; set; }
        public ICommand RunViewLetterHistoryReportCommand { get; set; }
        public ICommand RunServicememberExpiredDeniedActiveReportCommand { get; set; }
        public ICommand RunServicememberPromoRateEndReportCommand { get; set; }
        public ICommand RunServicememberMonthlyIncomingGnLetterSentCommand { get; set; }
        public ICommand RunWeeklyTaskStatusReportCommand { get; set; }
        public ICommand RunDmdcValidationCommand { get; set; }
        public ICommand RunInquiriesCommand { get; set; }
        public ICommand RunAffiliateCommand { get; set; }

        public Visibility IsDateVisible
        {
            get { return _visibility; } 
            set {SetProperty(ref _visibility, value); }
        }

        public List<WeeklyControlReportItem> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public List<ThirtyDaysListReportItem> ThirtyDaysListReportLines
        {
            get { return _reportLines; }
            set { SetProperty(ref _reportLines, value); }
        }

        public List<ViewLetterHistoryReportItem> ViewLetterHistoryReportLines
        {
            get { return _letterReportLines; }
            set { SetProperty(ref _letterReportLines, value); }
        }

        public List<ServicememberExpiredDeniedActiveReportItem> ServicememberExpiredDeniedActiveReportLines
        {
            get { return _servicememberExpiredDeniedActiveReportLines; }
            set { SetProperty(ref _servicememberExpiredDeniedActiveReportLines, value); }
        }

        public List<ServicememberPromoRateEndReportItem> ServicememberPromoRateEndReportLines
        {
            get { return _servicememberPromoRateEndReportLines; }
            set { SetProperty(ref _servicememberPromoRateEndReportLines, value); }
        }

        public List<ServicememberMonthlyIncomingGnLetterSentReportItem> ServicememberMonthlyIncomingGnLetterSentReportLines
        {
            get { return _servicememberMonthlyIncomingGnLetterSentReportLines; }
            set { SetProperty(ref _servicememberMonthlyIncomingGnLetterSentReportLines, value); }
        }

        public List<DmdcValidationReportItem> DmdcValidationReportLines
        {
            get { return _dmdcValidationReportLines; }
            set { SetProperty(ref _dmdcValidationReportLines, value); }
        }

        public List<InquiriesReportItem> InquiriesReportLines
        {
            get { return _inquiriesReportLines; }
            set { SetProperty(ref _inquiriesReportLines, value); }
        }

        public List<AffiliateReportItem> AffiliateReportLines
        {
            get { return _affiliateReportLines; }
            set { SetProperty(ref _affiliateReportLines, value); }
        }

        public ObservableCollection<TaskType> TaskTypes { get; set; }

        public List<TaskStatusReportItem> TaskStatusReportLines
        {
            get { return _taskStatusReportItems; }
            set { SetProperty(ref _taskStatusReportItems, value); }
        }

        public TaskType SelectedTaskType
        {
            get { return _selectedTaskType; }
            set { SetProperty(ref _selectedTaskType, value); }
        }

        public string Interval
        {
            get { return _interval; }
            set
            {
                SetProperty(ref _interval, value); 
                _visibility = value == "Weekly" || value == "Monthly" ? Visibility.Visible : Visibility.Collapsed;
                ReportDate2 = value == "Weekly" || value == "Monthly" ? ReportDate2 : null;
                UpdateAll();
            }
        }

        public DateTime? ReportDate { get; set; }

        public DateTime? ReportDate2 { get; set; }

        public DateTime? RunDate { get; set; }

        private void OnLoaded()
        {
            _selectedTaskType = TaskType.ALL;
            _interval = "Weekly";
            _visibility = Visibility.Visible;
            UpdateAll();
        }

        private async void RunWeeklyControlReport()
        {
            RunDate = ReportDate;
            if (RunDate != null)
            {
                _shellViewModel.IsUiBusy = true;

                var items = await _repository.Load(RunDate);
                Items = items.AsEnumerable().ToList();
                if (Items.Count > 0)
                {
                    var exportData = BuildReportString(Items);

                    _shellViewModel.IsUiBusy = false;

                    ExportToFile(exportData, "Weekly_Control_Report");
                }
                else
                {
                    _shellViewModel.IsUiBusy = false;
                    _messageDialog.Warning("There is nothing to report. Please try the other date.");
                }
            }
            else
            {
                _messageDialog.Warning("Please select date");
            }
        }

        private async void Run30DaysListReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "30DaysList";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<ThirtyDaysListReportItem>();

            ThirtyDaysListReportLines = list.AsEnumerable().ToList();

            if (ThirtyDaysListReportLines.Count > 0)
            {
                var exportData = BuildReportString(ThirtyDaysListReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunViewLetterHistoryReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "ViewLetterHistory";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<ViewLetterHistoryReportItem>();

            ViewLetterHistoryReportLines = list.AsEnumerable().ToList();

            if (ViewLetterHistoryReportLines.Count > 0)
            {
                var exportData = BuildReportString(ViewLetterHistoryReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunServicememberExpiredDeniedActiveReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "Servicemember_Expired_Denied_Active";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<ServicememberExpiredDeniedActiveReportItem>();

            ServicememberExpiredDeniedActiveReportLines = list.AsEnumerable().ToList();

            if (ServicememberExpiredDeniedActiveReportLines.Count > 0)
            {
                var exportData = BuildReportString(ServicememberExpiredDeniedActiveReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;
                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunServicememberPromoRateEndReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "Servicemember_Promo_Rate_End";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<ServicememberPromoRateEndReportItem>();

            ServicememberPromoRateEndReportLines = list.AsEnumerable().ToList();

            if (ServicememberPromoRateEndReportLines.Count > 0)
            {
                var exportData = BuildReportString(ServicememberPromoRateEndReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunServicememberMonthlyIncomingGnLetterSentReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "Servicemember_Monthly_Incoming_GN_Letter_Sent";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<ServicememberMonthlyIncomingGnLetterSentReportItem>();

            ServicememberMonthlyIncomingGnLetterSentReportLines = list.AsEnumerable().ToList();

            if (ServicememberMonthlyIncomingGnLetterSentReportLines.Count > 0)
            {
                var exportData = BuildReportString(ServicememberMonthlyIncomingGnLetterSentReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunTaskStatusReport()
        {
            RunDate = ReportDate2;

            if (RunDate != null || Interval == "All")
            {
                _shellViewModel.IsUiBusy = true;

                const string REPORT_NAME = "Task_Status";
                var items = await _repository.Load(Interval, ReportDate2, SelectedTaskType.Code);
                var objList = (IList)items;
                var list = objList.Cast<TaskStatusReportItem>();

                TaskStatusReportLines = list.AsEnumerable().ToList();

                if (TaskStatusReportLines.Count > 0)
                {
                    var exportData = BuildReportString(TaskStatusReportLines);

                    _shellViewModel.IsUiBusy = false;

                    var strMonth = Interval == "Monthly" ? "_" + string.Format("{0:MMMyyyy}", RunDate) : string.Empty;

                    ExportToFile(exportData, Interval + "_" + REPORT_NAME + strMonth);
                }
                else
                {
                    _shellViewModel.IsUiBusy = false;

                    _messageDialog.Warning("There is nothing to report. Please try other date.");
                }
            }
            else
            {
                if (Interval == "Weekly" || Interval == "Monthly")
                {
                    _messageDialog.Warning("Please select date");
                }
            }
        }

        private async void RunDmdcValidationReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "DMDC_Validation";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<DmdcValidationReportItem>();

            DmdcValidationReportLines = list.AsEnumerable().ToList();

            if (DmdcValidationReportLines.Count > 0)
            {
                var exportData = BuildReportString(DmdcValidationReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunInquiriesReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "Inquiries";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<InquiriesReportItem>();

            InquiriesReportLines = list.AsEnumerable().ToList();

            if (InquiriesReportLines.Count > 0)
            {
                var exportData = BuildReportString(InquiriesReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private async void RunAffiliateReport()
        {
            _shellViewModel.IsUiBusy = true;

            const string REPORT_NAME = "Affiliate";
            var items = await _repository.Load(REPORT_NAME);
            var objList = (IList)items;
            var list = objList.Cast<AffiliateReportItem>();

            AffiliateReportLines = list.AsEnumerable().ToList();

            if (AffiliateReportLines.Count > 0)
            {
                var exportData = BuildReportString(AffiliateReportLines);

                _shellViewModel.IsUiBusy = false;

                ExportToFile(exportData, REPORT_NAME);
            }
            else
            {
                _shellViewModel.IsUiBusy = false;

                _messageDialog.Warning("There is nothing to report. Please try again later.");
            }
        }

        private void ExportToFile(string exportData, string fileName)
        {
            var date = RunDate != null && fileName.StartsWith("Weekly") ? (DateTime)RunDate : DateTime.Today;

            var firstDayOfWeek = DateExtension.FirstDayOfWeek(date).ToString("MMdd");
            var lastDayOfWeek = DateExtension.LastDayOfWeek(date).ToString("MMddyyyy");
            var interval = firstDayOfWeek + "-" + lastDayOfWeek;

            var today = date.ToString("MMddyyyy");

            var FileName = fileName + "_" + (fileName.StartsWith("Weekly") ? interval : today) + ".csv";
            var TempFolder = DirectoryUtility.GetTempDirectory();
            var filePath = Path.Combine(TempFolder, FileName);

            if (FileHelper.IsFileLocked(filePath))
            {
                var message = string.Format("File {0} is locked. Please, close the file and repeat export.", filePath);
                _messageDialog.Warning(message);
            }
            else
            {
                File.WriteAllText(filePath, exportData);
                FileHelper.Open(filePath);
            }
        }

        private static string BuildReportString(IEnumerable obj)
        {
            var builder = new StringBuilder();
            var type = obj.GetType().GetTypeInfo().GenericTypeArguments[0];
            var header = type.GetProperties().Aggregate(string.Empty,
                (current, prop) => current + (prop.GetCustomAttribute<DisplayNameAttribute>().DisplayName + ","));
            builder.AppendLine(header.Substring(0, header.Length - 1));

            foreach (var item in obj)
            {
                var row = item.GetType().GetProperties().Aggregate("\"", (current, prop) => current + (prop.GetValue(item, null) + "\",\""));
                builder.AppendLine(row.Substring(0, row.Length - 2));
            }

            return builder.ToString();
        }
    }
}