﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Model.Tasks;
using Scra.Model.Users;

namespace Scra.Views.LeftPanel
{
    public class CompleteSubTaskItem
    {
        public string Title { get; set; }
        public string CompletionDate { get; set; }
        public string CompleteBy { get; set; }
        public bool IsQaPerformed { get; set; }
        public bool IsQaComplete { get; set; }
        public bool IsRejected { get; set; }
        public string QaCompleteBy { get; set; }
        public string QaCompletionDate { get; set; }
        public ICommand QaDoneCommand { get; set; }
        public ICommand QaRejectCommand { get; set; }
        public ICommand TitleClicked { get; set; }
        public bool IsQaAvailable { get; set; }
        public bool IsQaToolTipVisible { get; set; }

        public static CompleteSubTaskItem Create(SubTask item, Action qaDone, Action qaReject, IUser currentUser, Tasc tasc, Action loadRelatedPage)
        {
            var status = item.Status;
            var completion = item.Completion;
            var qaCompletion = item.QaCompletion;  
            
            var isQaReady = status == SubTaskStatus.Completed;
            var isQaAvailable = isQaReady && tasc.QaAssignee.Id == currentUser.Id;

            var completeSubTaskItem = new CompleteSubTaskItem()
            {
                Title = item.ItemId + ". " + item.Title,
                TitleClicked = new Command(loadRelatedPage),
                
                IsQaToolTipVisible = isQaReady && !isQaAvailable,
                CompletionDate = completion == null ? null : Formatter.DateTime(completion.Time),
                CompleteBy = completion == null ? null : completion.User.DisplayName,

                IsQaAvailable = isQaAvailable,                
                IsQaPerformed = status == SubTaskStatus.QaCompleted || status == SubTaskStatus.Rejected,
                IsQaComplete = status == SubTaskStatus.QaCompleted,
                IsRejected = status == SubTaskStatus.Rejected,

                QaCompletionDate = qaCompletion == null ? null : Formatter.DateTime(qaCompletion.Time),
                QaCompleteBy = qaCompletion == null ? null : qaCompletion.User.DisplayName,
                QaDoneCommand = new Command(qaDone),
                QaRejectCommand = new Command(qaReject),
            };
            return completeSubTaskItem;
        }        
    }
}