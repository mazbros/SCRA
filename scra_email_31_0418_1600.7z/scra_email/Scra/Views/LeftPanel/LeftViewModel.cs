﻿using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Tools;
using Scra.State;

namespace Scra.Views.LeftPanel
{
    public class LeftViewModel : BaseViewModel
    {
        private BaseViewModel _currentModel;
        private int _currentTaskId;
        private Visibility _frameVisibility;
        private AppNavigator _navigator;
        public ICommand CloseCommand { get; set; }
        public ICommand RefreshCommand { get; set; }
        

        public LeftViewModel()
        {
            _navigator = Di.Get<AppNavigator>();
            RefreshCommand = new Command(RefreshPanel);
            CloseCommand = new Command(CloseLeftPanel);
            FrameVisibility = Visibility.Collapsed;
        }

        private void RefreshPanel()
        {            
            ((TaskItemsViewModel)CurrentModel).ReloadTask();
        }

        private void CloseLeftPanel()
        {
            FrameVisibility = Visibility.Collapsed;
        }

        public BaseViewModel CurrentModel
        {
            get { return _currentModel; }
            set { SetProperty(ref _currentModel, value); }
        }

        public Visibility FrameVisibility
        {
            get { return _frameVisibility; }
            set { SetProperty(ref _frameVisibility, value); }
        }

        public void Load()
        {
            var store = Di.Get<IAppStore>();
            store.SubscribeCommand(Act.SHOW_TASK, ShowTask);
        }

        private async void ShowTask(IAct obj)
        {
            var act = (ShowTaskAct)obj;
            _currentTaskId = act.TaskId;

            if (_currentTaskId == 0)
            {
                FrameVisibility = Visibility.Collapsed;
                return;
            }

            FrameVisibility = Visibility.Visible;
            var vm = new TaskItemsViewModel();
            CurrentModel = vm;
            await vm.Load(act.TaskId);
        }
    }
}
