﻿using System.Windows.Controls;
using System.Windows.Input;

namespace Scra.Views.PersonDashboard
{
    public partial class PersonMilitaryWidget
    {
        public PersonMilitaryWidget()
        {
            InitializeComponent();
        }

        public PersonMilitaryWidgetModel GetViewModel()
        {
            return (PersonMilitaryWidgetModel)DataContext;
        }

        private void ActiveDutyList_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            //var listBox = (ItemsControl) sender;            
            //GetViewModel().SelectActiveDutyCommand.Execute(listBox);
        }
    }
}
