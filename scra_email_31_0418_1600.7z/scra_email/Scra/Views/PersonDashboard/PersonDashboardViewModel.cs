﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Views.Shell;

namespace Scra.Views.PersonDashboard
{
    public class PersonDashboardViewModel : BaseViewModel
    {
        private readonly IPersonRepository _repository;
        private readonly AppNavigator _navigator;
        private ShellViewModel _shellViewModel;
        private PersonId _personId;
        private string _fullName;
        private string _address1;
        private string _address2;
        private string _phone;
        private string _email;
        private string _fNumber;
        private string _ssn;
        private readonly IMessageDialog _messageDialog;
        private const string TITLE = "Attach Files";
        private const string FILE_CATEGORY = "Person";

        public PersonDashboardViewModel()
        {
            if (InDesignMode())
            {
                return;
            }

            _repository = Di.Get<IPersonRepository>();
            _navigator = Di.Get<AppNavigator>();
            _messageDialog = Di.Get<IMessageDialog>();
            _shellViewModel = Di.Get<ShellViewModel>();

            OnViewLoaded = OnLoaded;
            EditCommand = new Command(Edit);
            AddNewActiveDutyCommand = new Command(AddNewActiveDuty);
        }

        public ICommand EditCommand { get; set; }
        public ICommand AddNewActiveDutyCommand { get; set; }

        public string FullName
        {
            get { return _fullName; }
            set { SetProperty(ref _fullName, value); }
        }

        public string Address1
        {
            get { return _address1; }
            set { SetProperty(ref _address1, value); }
        }

        public string Address2
        {
            get { return _address2; }
            set { SetProperty(ref _address2, value); }
        }

        public string Phone
        {
            get { return _phone; }
            set { SetProperty(ref _phone, value); }
        }

        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }

        public string FNumber
        {
            get { return _fNumber; }
            set { SetProperty(ref _fNumber, value); }
        }

        public string Ssn
        {
            get { return _ssn; }
            set { SetProperty(ref _ssn, value); }
        }

        public PersonMilitaryWidgetModel MilitaryWidget { get; set; }
        public DependentsWidgetModel DependentsWidget { get; set; }
        public TaskWidgetModel TaskWidget { get; set; }
        public ContractsWidgetModel ContractsWidget { get; set; }
        public PersonDocumentListWidget PersonFileList { get; set; }
        public PersonDocumentListWidget PersonNoteList { get; set; }
        public CommunicationWidgetModel CommunicationList { get; set; }

        private void AddNewActiveDuty()
        {
            _navigator.ActiveDuty(_personId);
        }

        private void Edit()
        {
            _navigator.PersonEdit(_personId);
        }

        private async void OnLoaded()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var args = (IdArgs) Arguments;
                _personId = new PersonId(args.Id);

                var model = await GetModel();
                FillView(model);

                var tasks = new[]
                {
                    MilitaryWidget.Load(model),
                    DependentsWidget.Load(model),
                    ContractsWidget.Load(model),
                    TaskWidget.Load(model),
                    PersonFileList.Load(model, FILE_CATEGORY, TITLE),
                    PersonNoteList.Load(model),
                    CommunicationList.Load(model)
                };
                await Task.WhenAll(tasks);
                _shellViewModel.IsUiBusy = false;
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during loading person's information.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private void FillView(Person model)
        {
            FullName = model.Name.FullName;
            Address1 = model.Address.GetStreetAndApartment();
            Address2 = model.Address.GetCityZipState();
            Phone = model.Contacts.Phone.GetDisplay();
            Email = model.Contacts.Email;
            FNumber = model.FNumber.ToString();
            Ssn = model.Ssn.GetDisplay();
        }

        private async Task<Person> GetModel()
        {
            if (_personId.IsEmpty())
            {
                return await PersonFactory.Create();
            }

            return await _repository.Get(_personId);
        }
    }
}
