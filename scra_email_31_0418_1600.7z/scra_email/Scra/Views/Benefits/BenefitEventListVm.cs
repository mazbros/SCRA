﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.Buttons;
using Scra.Model.Contracts;
using Scra.Model.Extensions;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Formatter = Scra.Controls.Formatter;

namespace Scra.Views.Benefits
{
    public class BenefitEventListVm : BaseControlModel
    {
        private BenefitEvent _selectedBenefitEvent;

        public BenefitEventListVm()
        {
            LeftDoubleClicked = new Command(SelectBenefitEvent);
        }

        private BenefitEventListVm(Action<BenefitEvent> itemSelected, 
                                    Action<BenefitEvent> addBenefit,
                                    Action<BenefitEvent, TaskType> editBenefit,
                                    Action<BenefitEvent> contactCustomer,
                                    Action<BenefitEvent> extendBenefit,
                                    Action<BenefitEvent> removeBenefit,
                                    Action<BenefitEvent> denyBenefit,
                                    Action<BenefitEvent> editContract)
        {
            var user = Di.Get<IUser>();
            IsBenefitEditable = user.Type.Equals(UserType.Guest);

            LeftDoubleClickedAction = itemSelected;
            ContractCommand = new Command(() => editContract(LatestBenefitEvent));

            ActionProps = new MultiButtonProps(new[]
            {
                new MultiButtonProps.Item("Eligible", ()=>addBenefit(LatestBenefitEvent)),
                new MultiButtonProps.Item("Add Promotional Rate", ()=>editBenefit(LatestBenefitEvent, TaskType.ADD_PROMOTIONAL_RATE)),
                new MultiButtonProps.Item("Remove Promotional Rate", ()=>editBenefit(LatestBenefitEvent, TaskType.REMOVE_PROMOTIONAL_RATE)),
                new MultiButtonProps.Item("Remediation Reimbursement", ()=>editBenefit(LatestBenefitEvent, TaskType.REMEDIATION_REIMBURSEMENT)),
                new MultiButtonProps.Item("Communicate", ()=>contactCustomer(LatestBenefitEvent)),
                new MultiButtonProps.Item("Extend Benefit", ()=>extendBenefit(LatestBenefitEvent)),
                new MultiButtonProps.Item("Remove Benefit", ()=>removeBenefit(LatestBenefitEvent)),
                new MultiButtonProps.Item("Deny Benefit", ()=>denyBenefit(LatestBenefitEvent)),
            });
        }

        public static BenefitEventListVm Create(List<BenefitEvent> events, 
                                                Action<BenefitEvent> itemSelected, 
                                                Action<BenefitEvent> addBenefit, 
                                                Action<BenefitEvent, TaskType> editBenefit,
                                                Action<BenefitEvent> contactCustomer, 
                                                Action<BenefitEvent> extendBenefit, 
                                                Action<BenefitEvent> removeBenefit, 
                                                Action<BenefitEvent> denyBenefit,
                                                Action<BenefitEvent> editContract)
        {
            var contract = events.FirstOrDefault();
            string productName = ContractCategory.Parse(contract.SCRA_Code).Name + " - " + contract.SubProductName;

            var contractListItem = new BenefitEventListVm(itemSelected, addBenefit, editBenefit, contactCustomer, extendBenefit, removeBenefit, denyBenefit, editContract)
            {
                LatestBenefitEvent = contract,
                BenefitEventList = events,
                ProductName = productName,
                HasProduct = true,
                ContractNo = contract.ContractNo,
                AccountNum = contract.AccountNumber,
                OpenDate = Formatter.Date(contract.OpenDate),
                CloseDate = Formatter.Date(contract.CloseDate),
                IsBenefitEditable = true,   
                ContractId = contract.ContractId,
                };

            return contractListItem;
        }

        public static BenefitEventListVm Create(Benefit benefit, Action showTask)
        {
            var contractListItem = new BenefitEventListVm()
            {
                HasProduct = false,
                NoContractLabel = "Request denied due to no product",
                Status = benefit.Status.Name,
                IsBenefitEditable = false,
                NoContractClicked = new Command(showTask),
                
            };

            return contractListItem;
        }

        private void SelectBenefitEvent()
        {
            LeftDoubleClickedAction(SelectedBenefitEvent);
        }


        public List<BenefitEvent> BenefitEventList { get; set; }

        public BenefitEvent SelectedBenefitEvent
        {
            get { return _selectedBenefitEvent;}
            set
            {
                SetProperty(ref _selectedBenefitEvent, value);
                SelectBenefitEvent();
            }
        }


        public BenefitEvent LatestBenefitEvent { get; set; }
        public MultiButtonProps ActionProps { get; set; }
        public ICommand LeftDoubleClicked { get; set; }
        public Action<BenefitEvent> LeftDoubleClickedAction { get; set; }
        public int ContractId { get; set; }
        public string NoContractLabel { get; set; }
        public ICommand NoContractClicked { get; set; }

        public Benefit Benefit { get; set; }
        public Contract Contract { get; set; }
        public string Status { get; set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }
        public string ContractNo { get; set; }
        public string AccountNum { get; set; }
        public string ProductName { get; set; }

        public bool IsBenefitEditable { get; set; }
        public ICommand ContractCommand { get; set; }
        public string ActiveDutyPeriods { get; set; }
        public bool HasProduct { get; set; }
    }
}