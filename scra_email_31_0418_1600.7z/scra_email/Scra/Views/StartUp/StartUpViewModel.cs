﻿using System;
using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Configs;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Tools;
using Scra.Services;
using Scra.Tools;

namespace Scra.Views.StartUp
{
    public class StartUpViewModel : BaseViewModel
    {
        private string _softwareVersion;
        private readonly VersionControlService _versionControlService;
        private readonly UserAuthenticationService _userAuthenticationService;
        private readonly SetupConfigService _setupConfigService;
        private readonly SetupDomainHandlerService _setupDomainHandlerService;
        private IMessageDialog _message;
        private AppNavigator _navigator;

        public StartUpViewModel()
        {
            OnViewLoaded = StartApp;
            SoftwareVersion = "Software Version: " + AppConfig.VersionString();
            _versionControlService = new VersionControlService();
            _userAuthenticationService = new UserAuthenticationService();
            _setupConfigService = new SetupConfigService();
            _setupDomainHandlerService = new SetupDomainHandlerService();

            _message = Di.Get<IMessageDialog>();
            _navigator = Di.Get<AppNavigator>();
        }

        public string SoftwareVersion
        {
            get { return _softwareVersion; }
            set { SetProperty(ref _softwareVersion, value); }
        }

        private void StartApp()
        {
            var initTask = Initialize();
            var delayTask = Task.Delay(1000);

            Task
                .WhenAll(initTask, delayTask)
                .ContinueWith(t => ShowShell());
        }

        private async Task Initialize()
        {
            try
            {
                _setupConfigService.Setup();
                await _userAuthenticationService.Authenticate();
                await _versionControlService.CheckVersion();
                _setupDomainHandlerService.Setup();
            }
            catch (UserException ex)
            {
                _message.Warning(ex);
                _navigator.ShutDown();
            }
            catch (Exception ex)
            {
                Di.Get<IMessageDialog>().Error(ex, "Error during initial setup.");
                Di.Get<AppNavigator>().ShutDown();
            }
        }

        private void ShowShell()
        {
            var navigator = Di.Get<AppNavigator>();
            var ui = Di.Get<IUiThread>();

            ui.Execute(() =>
            {
                navigator.Shell();
                CloseView();
            });
        }
    }
}
