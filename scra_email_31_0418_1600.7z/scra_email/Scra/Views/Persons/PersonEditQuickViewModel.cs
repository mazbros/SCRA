using System;
using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Exceptions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.Persons
{
    public class PersonEditQuickViewModel : BaseViewModel
    {
        private PhoneNumber _phone;
        private string _email;
        private readonly IPersonRepository _repository;
        private string _fName;
        private string _mName;
        private string _lName;
        private readonly IMessageDialog _messageDialog;

        public PersonEditQuickViewModel()
        {
            if (InDesignMode())
            {
                return;
            }
            _repository = Di.Get<IPersonRepository>();
            _messageDialog = Di.Get<IMessageDialog>();
            Di.Get<AppNavigator>();
            
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
        }

        public Command CancelCommand { get; set; }
        public Command SaveCommand { get; set; }

        public string FName
        {
            get { return _fName; }
            set { SetProperty(ref _fName, value); }
        }
        public string MName
        {
            get { return _mName; }
            set { SetProperty(ref _mName, value); }
        }
        public string LName
        {
            get { return _lName; }
            set { SetProperty(ref _lName, value); }
        }

        private void Cancel()
        {
            CloseView();
        }

        private async void Save()
        {
            try
            {
                var model = await GetModel();
                FillModel(model);
                Validate(model);
                var person = await _repository.SavePerson(model);

                CloseView();
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
        }

        private async Task<Person> GetModel()
        {                        
            return await PersonFactory.Create();            
        }

        public PhoneNumber Phone
        {
            get { return _phone; }
            set { SetProperty(ref _phone, value); }
        }
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }

        private void Validate(Person model)
        {
            if (model.Name.IsEmpty())
            {
                throw new UserException("Please enter a Name.");
            }
        }

        private void FillModel(Person model)
        {
            model.Name.First = FName;
            model.Name.Middle = MName;
            model.Name.Last = LName;            
            model.Contacts.Phone = Phone;
            model.Contacts.Email = Email;
        }
    }
}