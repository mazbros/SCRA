﻿namespace Scra.Views.Inquiries
{
    public partial class CreateInquiryView
    {
        public CreateInquiryView()
        {
            InitializeComponent();
            SetupViewModel();
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();            
            vm.SaveCancel = SaveCancelModule.GetViewModel();
        }

        private CreateInquiryViewModel GetViewModel()
        {
            return (CreateInquiryViewModel)DataContext;
        }
    }
}
