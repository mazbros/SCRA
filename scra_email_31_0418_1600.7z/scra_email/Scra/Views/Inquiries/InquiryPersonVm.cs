﻿using System.Threading.Tasks;
using Scra.Model.Exceptions;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Views.Inquiries
{
    public class InquiryPersonVm
    {
        private readonly string _entityName;
        private readonly IPersonRepository _repository;

        public InquiryPersonVm(string entityName)
        {
            _entityName = entityName;
            _repository = Di.Get<IPersonRepository>();
        }

        public string FName { get; set; }
        public string MName { get; set; }
        public string LName { get; set; }
        public PhoneNumber Phone { get; set; }
        public string Email { get; set; }
        public Ssn Ssn { get; set; }

        public void Validate()
        {
            if (FName.IsEmpty())
            {
                var message = string.Format("Please enter a First Name for {0}.", _entityName);
                throw new UserException(message);
            }

            if (LName.IsEmpty())
            {
                var message = string.Format("Please enter a Last Name for {0}.", _entityName);
                throw new UserException(message);
            }
        }

        public async Task<Person> ToModel(PersonId inquiringPersonId)
        {
            if (inquiringPersonId.IsEmpty())
            {
                var name = PersonName.Create(FName.Trim(), !string.IsNullOrEmpty(MName) ? MName.Trim() : MName, LName.Trim());
                var contacts = PersonContacts.Create(Phone, !string.IsNullOrEmpty(Email) ? Email.Trim() : Email);
                var model = await PersonFactory.Create(name, Ssn, contacts);
                return model;
            }

            var person = await _repository.Get(inquiringPersonId);
            FillModel(person);
            return person;
        }

        private void FillModel(Person model)
        {
            model.Name.First = FName.Trim();
            model.Name.Middle = !string.IsNullOrEmpty(MName) ? MName.Trim() : MName;
            model.Name.Last = LName.Trim();

            model.Ssn = Ssn;

            model.Contacts.Phone = Phone;
            model.Contacts.Email = !string.IsNullOrEmpty(Email) ? Email.Trim() : Email;
        }
    }
}