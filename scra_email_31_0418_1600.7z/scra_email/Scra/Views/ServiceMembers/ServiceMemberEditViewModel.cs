﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;
using Scra.Views.Shell;

namespace Scra.Views.ServiceMembers
{
    public class ServiceMemberEditViewModel : BaseViewModel
    {
        private const string NEW_RECORD = "New Record";
        private PersonId _personId;
        private readonly IPersonRepository _repository;
        private readonly ShellViewModel _shellViewModel;

        private ActiveDutyItemVm _activeDutyItemVm;
        private string _name;
        private string _address;
        private bool _isListEnabled;       
        private readonly AppNavigator _navigator;
        private readonly IDispatcher _dispatcher;

        public ServiceMemberEditViewModel()
        {
            if (InDesignMode())
            {
                return;
            }
            SubTaskIdentifier = SubTaskType.MilitaryInformation;

            _dispatcher = Di.Get<IDispatcher>();

            ActiveDutyItems = new ObservableCollection<ActiveDutyItemVm>();
            _repository = Di.Get<IPersonRepository>();
            _shellViewModel = Di.Get<ShellViewModel>();

            _navigator = Di.Get<AppNavigator>();
            OnViewLoaded = OnLoaded;
            AddNewCommand = new Command(AddNew);
            IsListEnabled = true;
        }

        public ICommand AddNewCommand { get; set; }

        public ObservableCollection<ActiveDutyItemVm> ActiveDutyItems { get; private set; }

        public ActiveDutyItemVm CurrentActiveDutyItem
        {
            get { return _activeDutyItemVm; }
            set
            {
                SetProperty(ref _activeDutyItemVm, value);
                if (value != null)
                {
                    ReloadActiveDuty(_personId, value.AdId);
                }
            }
        }

        public SubTaskType SubTaskIdentifier { get; private set; }

        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }

        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }

        public bool IsListEnabled
        {
            get { return _isListEnabled; }
            set { SetProperty(ref _isListEnabled, value); }
        }

        public bool IsAddVisible { get; set; }

        public ActiveDutyEditViewModel ActiveDuty { get; set; }

        private void AddNew()
        {
            var newItem = new ActiveDutyItemVm {Name = NEW_RECORD, AdId = 0};
            ActiveDutyItems.Add(newItem);
            CurrentActiveDutyItem = newItem;
        }

        private async void OnLoaded()
        {
            _shellViewModel.IsUiBusy = true;
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));
            var args = (ServiceMemberEditArgs)Arguments;
            _personId = args.PersonId;
            var model = await GetModel();
            await FillView(model);
            _shellViewModel.IsUiBusy = false;
        }

        private async Task FillView(Person person)
        {
            Name = person.Name.FullName;
            Address = person.Address.GetFull();

            var sm = await person.GetServiceMember();
            ActiveDutyItems.Update(sm.ActiveDuties.Select(ActiveDutyItemVm.Create));

            CurrentActiveDutyItem = ActiveDutyItems.LastOrDefault();
            if (CurrentActiveDutyItem == null)
            {
                AddNew();
            }

            IsAddVisible = false;
            UpdateAll();
        }

        private async void ReloadActiveDuty(PersonId personId, int activeDutyId)
        {
            await ActiveDuty.Load(personId, activeDutyId, StartEdit, StopEdit);
        }

        private void StartEdit()
        {
            IsListEnabled = false;
            IsAddVisible = false;
        }

        private void StopEdit(ActiveDuty activeDuty)
        {
            IsListEnabled = true;
            IsAddVisible = true;

            if (activeDuty == null)
            {
                if (CurrentActiveDutyItem.Name == NEW_RECORD)
                {
                    if (ActiveDutyItems.Count > 1)
                    {
                        ActiveDutyItems.Remove(CurrentActiveDutyItem);
                        CurrentActiveDutyItem = ActiveDutyItems.Last();
                    }
                    else
                    {
                        _navigator.PersonDashboard(_personId);
                    }
                }
            }
            else
            {
                OnLoaded();
            }
        }

        private Task<Person> GetModel()
        {
            return _repository.Get(_personId);
        }
    }
}
