﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Scra.AppCore;
using Scra.Controls.MessageDialog;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.State;

namespace Scra.Views.Tasks
{
    public class TaskAssigneeControlModelFactory
    {
        private readonly ITaskRepository _repository;
        private readonly IUser _currentUser;
        private readonly IDispatcher _dispatcher;
        private readonly IMessageDialog _message;
        private Action _reload;

        private IUser QaAssignee { get; set; }
        public IUser TaskAssignee { get; set; }

        public TaskAssigneeControlModelFactory(ITaskRepository repository, IUser currentUser)
        {
            _repository = repository;
            _currentUser = currentUser;
            _dispatcher = Di.Get<IDispatcher>();
            _message = Di.Get<IMessageDialog>();
        }

        public BaseControlModel Create(TaskSnapshot task, UserList userList, Action reload)
        {
            _reload = reload;
            var isTextMode = task.Status == TascStatus.QaCompleted || task.Status == TascStatus.Misdirected;
            var assignee = task.Assignee;
            if (_currentUser.IsAdmin)
            {
                return new TaskAssigneeAdminControlModel(task.Id, assignee, isTextMode, UpdateAction, userList);
            }
            isTextMode = task.Status == TascStatus.Completed || assignee != null;
            return new TaskAssigneeControlModel(task.Id, assignee, _currentUser, isTextMode, UpdateAction);
        }

        public BaseControlModel CreateQa(TaskSnapshot task, UserList userList, Action reload)
        {
            _reload = reload;
            var isTextMode = task.Status == TascStatus.QaCompleted || task.Status == TascStatus.Misdirected;
            QaAssignee = task.QaAssignee;
            TaskAssignee = task.Assignee;

            if (!_currentUser.Type.Equals(UserType.Guest))
            {
                return new TaskAssigneeAdminControlModel(task.Id, QaAssignee, isTextMode, UpdateQaAction, userList);
            }
            return new TaskAssigneeAdminControlModel(task.Id, QaAssignee, true, UpdateQaAction, userList);
        }

        private async Task UpdateAction(int taskId, IUser assignee)
        {            
            var taskList = await _repository.Load(new LoadTasksFilter() { TaskId = taskId }, string.Empty);
            var task = taskList.FirstOrDefault(i => i.Id == taskId);

            if (task != null && (assignee.Id == task.QaAssignee.Id && task.QaAssignee.Id.IsNotEmpty()))
            {
                var message = "Task agent cannot be the same as QA agent";
                _message.Warning(message);
            }
            else
            {
                await _repository.UpdateAssignee(taskId, assignee);                
            }            
            _dispatcher.Dispatch(new ReloadTaskAct(taskId));
            _reload();
        }

        private async Task UpdateQaAction(int taskId, IUser assignee)
        {
            var taskList = await _repository.Load(new LoadTasksFilter() { TaskId = taskId }, string.Empty);
            var task = taskList.FirstOrDefault(i => i.Id == taskId);

            if (task != null && (task.Assignee.Id == assignee.Id && task.Assignee.Id.IsNotEmpty()))
            {
                var message = "QA agent cannot be the same as Task agent";
                _message.Warning(message);
            }
            else
            {
                await _repository.UpdateQaAssignee(taskId, assignee);                
            }
            _dispatcher.Dispatch(new ReloadTaskAct(taskId));
            _reload();
        }
    }
}