﻿namespace Scra.Configs
{
    public class AppConfig
    {
        private static int _version = 31;

        public static string DbName { get; set; }
        public static bool IsDebug { get; set; }

        public static int Version
        {
            get { return _version; }
            set { _version = value; }
        }

        public static string VersionString()
        {
            return "V" + Version;
        }        
    }
}
