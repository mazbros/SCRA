﻿using Scra.AppCore;

namespace Scra.Views.Reports
{
    public class ReportsListViewModel : BaseViewModel
    {
    }
}