﻿using System.Collections.Generic;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    public class LoadTasksFilter
    {
        public bool HideAssigned { get; set; }
        public List<TascStatus> Statuses { get; set; }
        public PersonId PersonId { get; set; }
        public ContractId ContractId { get; set; }
        public int TaskId { get; set; }
        public UserId AssigneeId { get; set; }
        public UserId QaAssigneeId { get; set; }
    }
}