﻿using Scra.Model.DomainEvents;
using System.Collections.Generic;

namespace Scra.Model
{
    public interface IDomainEventHolder
    {
        IList<IDomainEvent> DomainEvents { get; }
    }
}