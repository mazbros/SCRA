﻿using System;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Model.Dependents
{
    public class DependentLink
    {
        public int Id { get; set; }

        public PersonId FromId { get; set; }
        public PersonId ToId { get; set; }

        public DependentType Type { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public Task<Person> GetDependent()
        {
            var repo = Di.Get<IPersonRepository>();
            return repo.Get(ToId);
        }
    }
}