﻿using System;
using Scra.Model.Tasks;

namespace Scra.Model.Contracts
{
    public class BenefitEvent   
    {
        public int BenefitId { get; set; }
        public int ActiveDutyId { get; set; }
        public int ContractId { get; set; }
        public int TaskId { get; set; }
        public BenefitStatus BenefitStatus { get; set; }
        public string DenialReason { get; set; }
        public DateTime? BenefitDate { get; set; }
        public DateTime? ActiveDutyStartDate { get; set; }
        public DateTime? ActiveDutyEndDate { get; set; }
        public string SubProductName { get; set; }
        public string AccountNumber { get; set; }
        public string ContractNo { get; set; }
        public string SCRA_Code { get; set; }
        public DateTime? OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public TaskType TaskType { get; set; }
        public TascStatus TaskStatus { get; set; }
    }
}