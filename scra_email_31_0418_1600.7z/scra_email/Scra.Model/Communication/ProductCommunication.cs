﻿using System;
using Scra.Model.Persons;

namespace Scra.Model.Communication
{
    public class ProductCommunication
    {
        public PersonId PersonId { get; set; }
        public int BenefitId { get; set; }
        public DateTime? CommunicationDate { get; set; }
        public int ResponseMethodId { get; set; }
        public string ResponseText { get; set; }
        public int LetterId { get; set; }
        public int CommunicationId { get; set; }
        public int TaskId { get; set; }

        public ProductCommunication()
        {

        }

        public ProductCommunication(int communicationId, PersonId personId,
                            int benefitId,
                            DateTime? communicationDate,
                            int responseMethodId,
                            string responseText,
                            int letterId,
                            int taskId)
        {
            CommunicationId = communicationId;
            PersonId = personId;
            BenefitId = benefitId;
            CommunicationDate = communicationDate;
            ResponseMethodId = responseMethodId;
            ResponseText = responseText;
            LetterId = letterId;
            TaskId = taskId;
        }

        public ProductCommunication(PersonId personId, int benefitId)
        {
            PersonId = personId;
            BenefitId = benefitId;
        }

        public bool IsEmpty()
        {
            if (CommunicationId == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}