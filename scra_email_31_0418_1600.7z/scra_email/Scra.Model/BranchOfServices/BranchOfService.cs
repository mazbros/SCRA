﻿namespace Scra.Model.BranchOfServices
{
    public class BranchOfService
    {
        public int Id { get; private set; }
        public string Name { get; private set; }
        public bool IsReserve { get; private set; }

        private BranchOfService()
        {
        }

        public static BranchOfService Create(int id, string name, bool isReserve)
        {
            return new BranchOfService{ Id = id, Name = name, IsReserve = isReserve};
        }
    }
}