﻿using System.ComponentModel;
using System.Data;

namespace Scra.Model.Reports
{
    public class AffiliateReportItem
    {
        //[DisplayName("Date")]
        //public string Date { get; set; }

        [DisplayName("Status")]
        public string Status { get; set; }

        [DisplayName("Person Requesting First Name")]
        public string PersonRequestingFirstName { get; set; }

        [DisplayName("Person Requesting Last Name")]
        public string PersonRequestingLastName { get; set; }

        [DisplayName("Servicemember ID")]
        public string ServicememberId { get; set; }

        [DisplayName("Servicemember First Name")]
        public string ServicememberFirstName { get; set; }

        [DisplayName("Servicemember Middle Initial")]
        public string ServicememberMiddleInitial { get; set; }

        [DisplayName("Servicemember Last Name")]
        public string ServicememberLastName { get; set; }

        [DisplayName("Log Request Done")]
        public string LogRequestDone { get; set; }

        [DisplayName("Log Request Completed By")]
        public string LogRequestCompletedBy { get; set; }

        //[DisplayName("Enter Details Done")]
        //public string EnterDetailsDone { get; set; }

        //[DisplayName("Enter Details Completed By")]
        //public string EnterDetailsCompletedBy { get; set; }

        //[DisplayName("Respond To Requester Done")]
        //public string RespondToRequesterDone { get; set; }

        //[DisplayName("Respond To Requester Completed By")]
        //public string RespondToRequesterCompletedBy { get; set; }

        //[DisplayName("Save All Records Done")]
        //public string SaveAllRecordsDone { get; set; }

        //[DisplayName("Save All Records Completed By")]
        //public string SaveAllRecordsCompletedBy { get; set; }

        //[DisplayName("Log Request Rejected")]
        //public string LogRequestRejected { get; set; }

        //[DisplayName("Log Request Rejected By")]
        //public string LogRequestRejectedBy { get; set; }

        //[DisplayName("Enter Details Rejected")]
        //public string EnterDetailsRejected { get; set; }

        //[DisplayName("Enter Details Rejected By")]
        //public string EnterDetailsRejectedBy { get; set; }

        //[DisplayName("Respond To Requester Rejected")]
        //public string RespondToRequesterRejected { get; set; }

        //[DisplayName("Respond To Requester Rejected By")]
        //public string RespondToRequesterRejectedBy { get; set; }

        //[DisplayName("Save All Records Rejected")]
        //public string SaveAllRecordsRejected { get; set; }

        //[DisplayName("Save All Records Rejected By")]
        //public string SaveAllRecordsRejectedBy { get; set; }

        //[DisplayName("QA Log Request Done")]
        //public string QaLogRequestDone { get; set; }

        //[DisplayName("QA Log Request Completed By")]
        //public string QaLogRequestCompletedBy { get; set; }

        //[DisplayName("QA Enter Details Done")]
        //public string QaEnterDetailsDone { get; set; }

        //[DisplayName("QA Enter Details Completed By")]
        //public string QaEnterDetailsCompletedBy { get; set; }

        //[DisplayName("QA Respond To Requester Done")]
        //public string QaRespondToRequesterDone { get; set; }

        //[DisplayName("QA Respond To Requester Completed By")]
        //public string QaRespondToRequesterCompletedBy { get; set; }

        //[DisplayName("QA Save All Records Done")]
        //public string QaSaveAllRecordsDone { get; set; }

        //[DisplayName("QA Save All Records Completed By")]
        //public string QaSaveAllRecordsCompletedBy { get; set; }
 
        [DisplayName("SCUSA Sent Date 1")]
        public string ScusaSentDate1 { get; set; }

        [DisplayName("SCUSA Sent Date 2")]
        public string ScusaSentDate2 { get; set; }

        [DisplayName("SCUSA Confirmation Date")]
        public string ScusaConfirmationDate { get; set; }
 
        [DisplayName("Completed")]
        public string Completed { get; set; }
 
        [DisplayName("Response Date")]
        public string ResponseDate { get; set; }

        [DisplayName("Response Method")]
        public string ResponseMethod { get; set; }
        
        [DisplayName("Response Text")]
        public string ResponseText { get; set; }
        
        [DisplayName("Description")]
        public string Description { get; set; }

        [DisplayName("Comment")]
        public string Comment { get; set; }
 
       

       

       

        //[DisplayName("Identification Method")]
        //public string IdentificationMethod { get; set; }

        //[DisplayName("DMDC Validation Date")]
        //public string DmdcValidationDate { get; set; }

       

        public static AffiliateReportItem Create(DataRow dr)
        {
            var item = new AffiliateReportItem
            {
                //Date = string.Format("{0:MM/dd/yyyy}", dr["Date"]),
                Status = dr["Status"].ToString(),

                PersonRequestingFirstName = dr["PersonRequestingFirstName"].ToString(),
                PersonRequestingLastName = dr["PersonRequestingLastName"].ToString(),

                ServicememberId = dr["ServicememberId"].ToString(),
                ServicememberFirstName = dr["ServicememberFirstName"].ToString(),
                ServicememberMiddleInitial = dr["ServicememberMiddleInitial"].ToString(),
                ServicememberLastName = dr["ServicememberLastName"].ToString(),
                
                LogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["LogRequestDone"]),
                LogRequestCompletedBy = dr["LogRequestCompletedBy"].ToString(),
                //EnterDetailsDone = string.Format("{0:MM/dd/yyyy}", dr["EnterDetailsDone"]),
                //EnterDetailsCompletedBy = dr["EnterDetailsCompletedBy"].ToString(),
                //RespondToRequesterDone = string.Format("{0:MM/dd/yyyy}", dr["RespondToRequesterDone"]),
                //RespondToRequesterCompletedBy = dr["RespondToRequesterCompletedBy"].ToString(),
                //SaveAllRecordsDone = string.Format("{0:MM/dd/yyyy}", dr["SaveAllRecordsDone"]),
                //SaveAllRecordsCompletedBy = dr["SaveAllRecordsCompletedBy"].ToString(),

                //LogRequestRejected = string.Format("{0:MM/dd/yyyy}", dr["LogRequestRejected"]),
                //LogRequestRejectedBy = dr["LogRequestRejectedBy"].ToString(),
                //EnterDetailsRejected = string.Format("{0:MM/dd/yyyy}", dr["EnterDetailsRejected"]),
                //EnterDetailsRejectedBy = dr["EnterDetailsRejectedBy"].ToString(),
                //RespondToRequesterRejected = string.Format("{0:MM/dd/yyyy}", dr["RespondToRequesterRejected"]),
                //RespondToRequesterRejectedBy = dr["RespondToRequesterRejectedBy"].ToString(),
                //SaveAllRecordsRejected = string.Format("{0:MM/dd/yyyy}", dr["SaveAllRecordsRejected"]),
                //SaveAllRecordsRejectedBy = dr["SaveAllRecordsRejectedBy"].ToString(),

                //QaLogRequestDone = string.Format("{0:MM/dd/yyyy}", dr["QaLogRequestDone"]),
                //QaLogRequestCompletedBy = dr["QaLogRequestCompletedBy"].ToString(),
                //QaEnterDetailsDone = string.Format("{0:MM/dd/yyyy}", dr["QaEnterDetailsDone"]),
                //QaEnterDetailsCompletedBy = dr["QaEnterDetailsCompletedBy"].ToString(),
                //QaRespondToRequesterDone = string.Format("{0:MM/dd/yyyy}", dr["QaRespondToRequesterDone"]),
                //QaRespondToRequesterCompletedBy = dr["QaRespondToRequesterCompletedBy"].ToString(),
                //QaSaveAllRecordsDone = string.Format("{0:MM/dd/yyyy}", dr["QaSaveAllRecordsDone"]),
                //QaSaveAllRecordsCompletedBy = dr["QaSaveAllRecordsCompletedBy"].ToString(),

                Description = dr["Description"].ToString(),
                Comment = dr["Comment"].ToString(),
                ResponseText = dr["ResponseText"].ToString(),
                ResponseDate = string.Format("{0:MM/dd/yyyy}", dr["ResponseDate"]),
                ResponseMethod = dr["ResponseMethod"].ToString(),

                ScusaSentDate1 = string.Format("{0:MM/dd/yyyy}", dr["ScusaSentDate1"]),
                ScusaSentDate2 = string.Format("{0:MM/dd/yyyy}", dr["ScusaSentDate2"]),
                ScusaConfirmationDate = string.Format("{0:MM/dd/yyyy}", dr["ScusaConfirmationDate"]),

                //IdentificationMethod = dr["IdentificationMethod"].ToString(),
                //DmdcValidationDate = string.Format("{0:MM/dd/yyyy}", dr["DmdcValidationDate"])

                Completed = dr["Completed"].ToString()
            };

            return item;
        }
    }
}