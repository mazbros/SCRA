﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Scra.Model.Reports
{
    public interface IReportsRepository
    {
        Task<IEnumerable<WeeklyControlReportItem>> Load(DateTime? reportDate);
        Task<IEnumerable<object>> Load(string reportName);
        Task<IEnumerable<TaskStatusReportItem>> Load(string interval, DateTime? reportDate, string taskType);
    }
}