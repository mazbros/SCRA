﻿using System;
using System.Threading.Tasks;
using Scra.Model.Communication;
using Scra.Model.Exceptions;

namespace Scra.Model.Letters
{
    public class Letter
    {
        public int  Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int Number { get; set; }
        public string LongDescription { get; set; }
        public ILetterTemplate Template { get; set; }

        public static readonly Letter Empty  = new Letter();
        

        public Letter()
        {
            
        }

        public static Letter Create(int id, string code, string name, int number, string longDescription)
        {
            return new Letter { Id = id, Code = code, Name= name, Number = number, LongDescription = longDescription};
        }

        public bool IsEmpty()
        {
            return Id == 0;
        }

        public async Task<Letter> GenerateLetter(object arg)
        {
            try
            {
                var argument = (ProductCommunication) arg;
                Template = GetLetterType();
                await Template.LoadTemplate(Number);
                return await Template.Generate(this, argument);
            }            
            catch (UserException e)
            {
                throw new UserException(e.Message);
            }
            catch (Exception e)
            {
                throw new UserException("Can not generate selected letter, there is no template uploaded!");
            }
        }

        private ILetterTemplate GetLetterType()
        {            
            if (Number == 101)
            {
                return RequestRcdTemplate.Create();
            }
            if (Number == 102)
            {
                return IneligibleTemplate.Create();
            }
            if (Number == 104)
            {
                return ExpiringTemplate.Create();
            }
            if (Number == 105)
            {
                return RemovedTemplate.Create();
            }        
            if (Number == 109)
            {
                return GreatNewsTemplate.Create();
            }
            if (Number == 110)
            {
                return BenefitExtensionTemplate.Create();
            }
            if (Number == 111)
            {
                return CorrectionTemplate.Create();
            }
            if (Number == 112)
            {
                return PotentiallyEligibleTemplate.Create();
            }
            return null;
        }
    }
}
