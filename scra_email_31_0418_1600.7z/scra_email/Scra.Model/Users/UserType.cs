﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Scra.Model.Users
{
    public struct UserType : IEquatable<UserType>
    {
        private readonly string _code;
        private readonly string _name;

        public string Code
        {
            get { return _code; }
        }
        public string Name
        {
            get { return _name; }
        }
        public string Display
        {
            get { return Name; }
        }

        public static readonly UserType Admin = new UserType("admin", "Admin");
        public static readonly UserType Regular = new UserType("regular", "Regular");
        public static readonly UserType Guest = new UserType("guest", "Guest");

        private static readonly Dictionary<string, UserType> Map = new[] { Admin, Regular, Guest }.ToDictionary(x => x.Code, x => x);

        private UserType(string code, string name)
        {
            _code = code;
            _name = name;
        }
        public static UserType Parse(string code)
        {
            UserType status;
            if (Map.TryGetValue(code, out status))
            {
                return status;
            }
            return Guest;
        }

        public bool Equals(UserType other)
        {
            return Code == other.Code;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is UserType))
            {
                return false;
            }
            return Equals((UserType)obj);
        }
    }
}