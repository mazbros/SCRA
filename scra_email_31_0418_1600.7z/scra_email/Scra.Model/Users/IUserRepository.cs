﻿using System.Threading.Tasks;

namespace Scra.Model.Users
{
    public interface IUserRepository
    {
        Task<User> Get(string userName);
        Task<User> GetOrCreate(string userName, bool isAdmin);
        Task<UserList> GetList();
    }
}