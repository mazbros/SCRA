﻿namespace Scra.Model.DomainEvents
{
    public interface IDomainEvent
    {

    }
}