﻿using System.Threading.Tasks;

namespace Scra.Model.DomainEvents
{
    public interface IDomainEventHandler
    {
        Task HandleAsync(IDomainEvent domainEvent);
    }
}