﻿namespace Scra.DataAccess
{
    public static class RefColumn
    {
        public const string ID = "Id";
        public const string PERSON_ID = "PersonId";
        public const string ACTIVE_DUTY_ID = "ActiveDutyId";
        public const string NAME = "Name";
        public const string USER_NAME = "UserName";
        public const string MODIFIED_BY = "ModifiedBy";
    }
}