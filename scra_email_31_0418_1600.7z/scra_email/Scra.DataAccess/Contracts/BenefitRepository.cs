﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.DataAccess.Extensions;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.Tasks;

namespace Scra.DataAccess.Contracts
{
    internal class BenefitRepository : IBenefitRepository
    {
        private const string LOAD_SQL = @"
SELECT	Id, ContractID, PersonID, ActiveDutyID, IsPromo, StartDate, EndDate, 
        Status, DenialReason, TaskID
FROM	dbo.Benefit
WHERE   {WHERE}
ORDER	BY StartDate, Id";

        private const string GET_BENEFIT_BY_TASK = @"
SELECT Benefit.ID As BenefitID
  FROM Benefit
  Where TaskID = (
select SubTask.TaskID
from SubTask
where {ID})";

        private const string GET_BENEFIT_EVENTS = @"
Select B.ID As BenefitId
		, B.ActiveDutyId
		, C.ID As ContractId
		, B.TaskId
		, B.Status As BenefitStatus
		, B.DenialReason
        , B.Timestamp As BenefitDate
		, A.StartDate As ActiveDutyStartDate
		, A.EndDate As ActiveDutyEndDate
        , C.ContractNo
		, CASE WHEN ISNULL(C.ProductName, '') = '' THEN CT.SUB_PRODUCT_NAME ELSE C.ProductName END as 'SUB_PRODUCT_NAME'
		, CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as 'AccountNumber'
		, CT.SCRA_Code
		, C.OpenDate
		, C.CloseDate
		, T.TaskType
        , T.Status As TaskStatus

	from Benefit As B
	right join Contract C On B.ContractID = C.ID 
	join ContractType CT ON C.ContractTypeId = CT.ID
	left join ActiveDuty As A On A.ID = B.ActiveDutyId
	left join Task T On B.TaskID = T.ID
	Where C.PersonID in (Select P.ID As PersonId
							from Person P
							where P.ID  in (Select ToID from PersonToPersonLink where FromID = {PersonId}) OR P.ID  in (Select FromID from PersonToPersonLink where ToID = {PersonId}) OR P.ID = {PersonId}
						)
	order by B.Timestamp desc";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public BenefitRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public Task<IList<Benefit>> LoadByContract(ContractId contractId)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "ContractID=" + contractId);
            return _sqlExecutor.Execute(sql, Convert);
        }

        public Task<Benefit> LoadById(int benefitId)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "ID=" + benefitId);            
            return _sqlExecutor.ExecuteOne(sql, Convert); 
        }

        public Task<IList<Benefit>> LoadByPerson(int id)
        {
            var sql = LOAD_SQL.Replace("{WHERE}", "PersonId=" + id);
            return _sqlExecutor.Execute(sql, Convert);
        }

        public async Task<IList<BenefitEvent>> LoadEvent(int id)
        {
            var sql = GET_BENEFIT_EVENTS.Replace("{PersonId}", id.ToString());
            return await _sqlExecutor.Execute(sql, ToBenefitEvent);
        }

        private BenefitEvent ToBenefitEvent(IRowData row)
        {
            var benefitStatus = BenefitStatus.Parse(row.AsString("BenefitStatus"));
            var taskType = TaskType.Parse(row.AsString("TaskType"));
            var taskStatus = TascStatus.Parse(row.AsString("TaskStatus"));

            return new BenefitEvent()
            {
                BenefitId = row.AsInt("BenefitId"),
                ActiveDutyId = row.AsInt("ActiveDutyId"),
                ContractId = row.AsInt("ContractId"),
                TaskId = row.AsInt("TaskID"),
                BenefitStatus = benefitStatus,
                DenialReason = row.AsString("DenialReason"),
                BenefitDate = row.AsDateTime("BenefitDate"),
                ActiveDutyStartDate = row.AsDateTime("ActiveDutyStartDate"),
                ActiveDutyEndDate = row.AsDateTime("ActiveDutyEndDate"),
                SubProductName = row.AsString("SUB_PRODUCT_NAME"),
                AccountNumber = row.AsString("AccountNumber"),
                ContractNo = row.AsString("ContractNo"),
                SCRA_Code = row.AsString("SCRA_Code"),
                OpenDate = row.AsDateTime("OpenDate"),
                CloseDate = row.AsDateTime("CloseDate"),
                TaskType = taskType,
                TaskStatus = taskStatus,
            };
        }


        public async Task Save(Benefit benefit)
        {
            if (benefit.Id.IsNew())
            {
                await Create(benefit);
            }

            await Update(benefit);
        }

        public async Task<int> GetBenefitByTask(SubTask subTask)
        {
            var sql = GET_BENEFIT_BY_TASK.Replace("{ID}", "SubTask.ID = " + subTask.Id);
            var result = await _sqlExecutor.GetDataSet(sql);

            var row = result.GetFirstTableRow();
            return row != null ? row.AsInt("BenefitID") : 0;
        }

        private Benefit Convert(IRowData row)
        {
            var id = row.AsInt(RefColumn.ID);
            var contractId = new ContractId(row.AsInt(BenefitColumn.CONTRACT_ID));
            var personId = row.AsInt(BenefitColumn.PERSON_ID);
            var adId = row.AsInt(BenefitColumn.ACTIVE_DUTY_ID);
            var isPromo = row.AsBool(BenefitColumn.IS_PROMO);
            var startDate = row.AsDateTime(BenefitColumn.START_DATE);
            var endDate = row.AsDateTime(BenefitColumn.END_DATE);
            var statusCode = row.AsString(BenefitColumn.STATUS);
            var status = BenefitStatus.Parse(statusCode);
            var denialReason = row.AsString(BenefitColumn.DENIAL_REASON);
            var taskId = row.AsInt(BenefitColumn.TASK_ID);
            return new Benefit(id, contractId, new PersonId(personId), adId, isPromo, startDate, endDate, status, denialReason, taskId);
        }

        private async Task Update(Benefit model)
        {
            var parameters = new[]
            {
                SpParameter.Create(BenefitColumn.STATUS, model.Status.Code),
                SpParameter.Create(BenefitColumn.DENIAL_REASON, model.DenialReason),
                SpParameter.Create(BenefitColumn.START_DATE, model.StartDate),
                SpParameter.Create(BenefitColumn.END_DATE, model.EndDate),
                SpParameter.Create(BenefitColumn.TASK_ID, model.TaskId),
                SpParameter.ModifiedBy(),
                SpParameter.Create(model.Id)
            };

            await _spExecutor.Execute("dbo.spBenefit_Update", parameters);
        }

        private async Task Create(Benefit model)
        {
            var id = SpParameter.CreateInOut(model.Id);
            var parameters = new[]
            {
                SpParameter.Create(BenefitColumn.CONTRACT_ID, model.ContractId),
                SpParameter.Create(BenefitColumn.ACTIVE_DUTY_ID, model.ActiveDutyId),
                SpParameter.Create(BenefitColumn.PERSON_ID, model.PersonId.Value),
                SpParameter.Create(BenefitColumn.STATUS, model.Status.Code),
                SpParameter.Create(BenefitColumn.DENIAL_REASON, model.DenialReason),
                SpParameter.Create(BenefitColumn.IS_PROMO, model.IsPromo),
                SpParameter.Create(BenefitColumn.START_DATE, model.StartDate),
                SpParameter.Create(BenefitColumn.END_DATE, model.EndDate),
                SpParameter.ModifiedBy(),
                id
            };

            await _spExecutor.Execute("dbo.spBenefit_Create", parameters);

            model.Id = (int)id.Value;
        }
    }
}
