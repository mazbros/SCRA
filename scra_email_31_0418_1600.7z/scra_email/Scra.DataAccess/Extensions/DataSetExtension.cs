﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Scra.DataAccess.Core;

namespace Scra.DataAccess.Extensions
{
    internal static class DataSetExtension
    {
        public static IRowData GetFirstTableRow(this DataSet set)
        {
            if (set.Tables.Count == 0)
            {
                return null;
            }
            var table = set.Tables[0];
            if (table.Rows.Count == 0)
            {
                return null;
            }
            return RowDataFactory.Create(table.Rows[0]);
        }

        public static IRowData GetSecondTableRow(this DataSet set)
        {
            var table = set.Tables[1];
            return RowDataFactory.Create(table.Rows[0]);
        }

        public static IEnumerable<IRowData> ToRows(this DataTable table)
        {
            foreach (DataRow tableRow in table.Rows)
            {
                yield return RowDataFactory.Create(tableRow);
            }
        }

        public static IList<TResult> Convert<TResult>(this DataTable table, Func<IRowData, TResult> converter)
        {
            return table.ToRows().Select(converter).ToList();
        }
    }
}