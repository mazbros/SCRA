﻿namespace Scra.DataAccess.Persons
{
    internal static class PersonColumn
    {
        public const string FIRST_NAME = "FirstName";
        public const string MIDDLE_INITIAL = "MiddleInitial";
        public const string LAST_NAME = "LastName";
        public const string DOB = "Dob";
        public const string SSN = "Ssn";
        public const string SEARCH = "Search";
        public const string PHONE = "Phone";
        public const string EMAIL = "Email";
        public const string CONTACT_METHOD_ID = "ContactMethodID";
        public const string F_NUMBER = "FNumber";
        public const string ORIGIN = "Origin";
    }
}