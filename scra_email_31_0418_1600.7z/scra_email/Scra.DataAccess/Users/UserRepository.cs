﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Users;

namespace Scra.DataAccess.Users
{
    internal class UserRepository : IUserRepository
    {
        private const string INSERT_SQL = @"
INSERT INTO Employee(UserName,Active,Name,IsAdmin) VALUES('{UserName}',1,'{UserName}',{IsAdmin})";
        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public UserRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public async Task<User> Get(string userName)
        {
            var userNamePar = SpParameter.Create(UserColumn.USER_NAME, userName);
            var table = await _spExecutor.GetDataTable("dbo.spEmployee_GetOrCreate", userNamePar);
            var row = RowDataFactory.Create(table.Rows[0]);
            return Convert(row);
        }

        public async Task<User> GetOrCreate(string userName, bool isAdmin)
        {
            var user = await Get(userName);
            if (user != null)
            {
                return user;
            }

            await Insert(userName, isAdmin);
            return await Get(userName);
        }

        public async Task<UserList> GetList()
        {
            var query = "SELECT ID, UserName, Name, Active, Type " +
                        "FROM dbo.Employee " +
                        "ORDER BY Name";

            var items = await _sqlExecutor.Execute(query, Convert);
            return UserList.Create(items);
        }

        private async Task Insert(string userName, bool isAdmin)
        {
            var sql = INSERT_SQL.Replace("{UserName}", userName).Replace("{IsAdmin}", isAdmin ? "1" : "0");
            await _sqlExecutor.Execute(sql);
        }

        private User Convert(IRowData row)
        {
            var id = new UserId(row.AsInt(UserColumn.ID));
            var userName = row.AsString(UserColumn.USER_NAME);
            var name = row.AsString(UserColumn.NAME);
            var active = row.AsBool(UserColumn.ACTIVE);
            var typeStr = row.AsString(UserColumn.TYPE);
            var type = UserType.Parse(typeStr);            
            return new User(id, userName, name, active, type);
        }
    }
}
