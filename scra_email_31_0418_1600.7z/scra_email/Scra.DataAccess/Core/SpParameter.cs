﻿using System;
using System.Data;
using System.Data.SqlClient;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.DataAccess.Core
{
    internal static class SpParameter
    {
        public static SqlParameter CreateInOut(int id)
        {
            return CreateInOut("ID", id);
        }

        public static SqlParameter CreateInOut(IRefId entity)
        {
            return CreateInOut(entity.Value);
        }

        public static SqlParameter Create(int id)
        {
            return new SqlParameter("ID", SqlDbType.Int) { Value = id };
        }

        public static SqlParameter Create(IRefId entity)
        {
            return Create(entity.Value);
        }

        public static SqlParameter Create(string name, string value)
        {
            return new SqlParameter(name, SqlDbType.VarChar) {Value = value ?? ""};
        }

        public static SqlParameter Create(string name, int value)
        {
            return new SqlParameter(name, SqlDbType.Int) {Value = value};
        }

        public static SqlParameter Create(string name, decimal value)
        {
            return new SqlParameter(name, SqlDbType.Decimal) { Value = value };
        }

        public static SqlParameter Create(string name, IRefId entity)
        {
            return Create(name, entity.Value);
        }

        public static SqlParameter Create(string name, bool value)
        {
            return new SqlParameter(name, SqlDbType.Bit) { Value = value };
        }

        public static SqlParameter Create(string name, byte[] data)
        {
            return new SqlParameter(name, SqlDbType.VarBinary) { Value = data };
        }

        public static SqlParameter CreateInOut(string name, int value)
        {
            return new SqlParameter(name, SqlDbType.Int) { Value = value, Direction = ParameterDirection.InputOutput };
        }

        public static SqlParameter Create(string name, DateTime? value)
        {
            return new SqlParameter(name, SqlDbType.DateTime) { Value = value };
        }

        public static SqlParameter ModifiedBy()
        {
            return ModifiedBy(Di.Get<IUser>());
        }

        public static SqlParameter ModifiedBy(IUser user)
        {
            return Create("ModifiedBy", user.Id);
        }
    }
}