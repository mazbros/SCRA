USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spGetPersonEditHistory]    Script Date: 03/11/2020 11:22:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/11/2020>
-- Description:	<Get person edit history>
-- =============================================
CREATE PROCEDURE [dbo].[spGetPersonEditHistory] 
	@PersonId INT,
	@Timestamp datetime
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

	IF @Timestamp < (SELECT max([Timestamp]) FROM [Person] WHERE [ID] = @PersonId) BEGIN

		SELECT	P.[ID], P.[FirstName], P.[LastName], P.[MiddleInitial],
				P.[SSN], P.[DOB], P.[Address1], P.[Address2], P.[City],
				P.[State], P.[Zip], P.[Phone], P.[Email], C.[Name] as ContactMethod,
				P.[Timestamp], E.[Name] As ModifiedBy, CM.[FNumber]
		FROM
			(SELECT [ID], [FirstName], [LastName], [MiddleInitial],
					[SSN], [DOB], [Address1], [Address2], [City], 
					[State], [Zip], [Phone], [Email], [ContactMethodID], 
					[Timestamp], [ModifiedBy], [Origin]
				FROM [Person] WHERE ID = @PersonId
			UNION
			SELECT TOP 1 [ID], [FirstName], [LastName], [MiddleInitial],
						 [SSN], [DOB], [Address1], [Address2], [City], 
						 [State], [Zip], [Phone], [Email], [ContactMethodID], 
						 [Timestamp], [ModifiedBy], [Origin]
				FROM [hist].[Person] WHERE ID = @PersonId ORDER BY [Timestamp] DESC) P
			LEFT JOIN [ContactMethod] C ON C.[ID] = P.[ContactMethodID]
			LEFT JOIN [Employee] E ON E.[ID] = P.[ModifiedBy]
			LEFT JOIN [Customer] CM ON CM.[PersonID] = P.[ID]	
			ORDER BY [Timestamp] DESC;
			
	END
    
END

GO

/****** Object:  StoredProcedure [dbo].[spGetBenefitByTaskId]    Script Date: 03/11/2020 11:22:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/11/2020>
-- Description:	<Get benefit by task id>
-- =============================================
CREATE PROCEDURE [dbo].[spGetBenefitByTaskId]
	@TaskId INT
WITH RECOMPILE
AS
BEGIN
	
	SET NOCOUNT ON;

	SELECT	[ID], [BenefitIntervalId], [ContractID], 
			[Timestamp], [ModifiedBy], [PersonID],
			[ActiveDutyID], [IsPromo], [StartDate],
			[EndDate], [Status], [DenialReason],
			[TaskID]
	FROM [dbo].[Benefit]
	WHERE [TaskID] = @TaskId;
    
END

GO

/****** Object:  StoredProcedure [dbo].[spLoadBenefit]    Script Date: 03/11/2020 11:22:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/11/2020>
-- Description:	<Load benefit>
-- =============================================
CREATE PROCEDURE [dbo].[spLoadBenefit]
	@ContractID INT = NULL,
	@BenefitID	INT = NULL,
	@PersonID	INT = NULL
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @SQL varchar(max)
	SET @SQL = '
	SELECT	[ID], [BenefitIntervalId], [ContractID], 
			[PersonID], [ActiveDutyID], [IsPromo], 
			[StartDate], [EndDate], [Status], 
			[DenialReason], [TaskID]
	FROM [dbo].[Benefit]
	WHERE '
	IF @ContractID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[ContractID] = ' + CAST(@ContractID as varchar(16))
	END
	IF @BenefitID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[ID] = ' + CAST(@BenefitID as varchar(16))
	END
	IF @PersonID IS NOT NULL BEGIN
	   SET @SQL = @SQL + '[PersonID] = ' + CAST(@PersonID as varchar(16))
	END
	SET @SQL = @SQL + '
	ORDER	BY [StartDate], [ID];'
	
	EXEC (@SQL);
	
END

GO

