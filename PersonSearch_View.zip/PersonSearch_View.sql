USE [SCRA_DB_TEST_50]
GO

/****** Object:  View [dbo].[PersonSearch]    Script Date: 5/18/2020 7:07:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[PersonSearch]
AS
SELECT     TOP (100) PERCENT p.ID, 
					  CASE WHEN LEN(LastName) > 0 THEN RTRIM(ISNULL(LastName, '')) + ', ' ELSE '' END + RTRIM(ISNULL(p.FirstName, '')) 
                      + CASE WHEN LEN(MiddleInitial) > 0 THEN ' ' + RTRIM(ISNULL(MiddleInitial, '')) ELSE '' END + '|' + RTRIM(ISNULL(p.FirstName, '')) 
                      + '|' + RTRIM(ISNULL(p.LastName, '')) + '|' + RTRIM(ISNULL(p.FirstName, '')) + CASE WHEN LEN(MiddleInitial) 
                      > 0 THEN ' ' + RTRIM(ISNULL(MiddleInitial, '')) ELSE '' END + CASE WHEN LEN(LastName) > 0 THEN ' ' + RTRIM(ISNULL(LastName, '')) 
                      ELSE '' END + '|' + CASE WHEN LEN(LastName) > 0 THEN RTRIM(ISNULL(LastName, '')) + ' ' + RTRIM(ISNULL(FirstName, '')) 
                      + '|' + RTRIM(ISNULL(p.FirstName, '')) + ' ' + RTRIM(ISNULL(p.LastName, ''))
                      + '|' + RTRIM(ISNULL(p.LastName, '')) + ' ' + RTRIM(ISNULL(p.FirstName, ''))
                      ELSE '' END + '|' + CASE WHEN LEN(Address1) > 0 THEN RTRIM(ISNULL(Address1, '')) + ', ' ELSE '' END + CASE WHEN LEN(Address2) 
                      > 0 THEN RTRIM(ISNULL(Address2, '')) + ', ' ELSE '' END + CASE WHEN LEN(City) > 0 THEN RTRIM(ISNULL(City, '')) 
                      + ', ' ELSE '' END + CASE WHEN LEN([State]) > 0 THEN RTRIM(ISNULL([State], '')) + ', ' ELSE '' END + COALESCE (CASE LEN(Zip) 
                      WHEN 9 THEN SUBSTRING(Zip, 1, 5) + '-' + SUBSTRING(Zip, 6, 4) WHEN 5 THEN Zip + '-0000' WHEN 0 THEN '00000-0000' ELSE Zip + '-0000' END, 
                      '00000-0000') + '|' + CASE WHEN ISNULL(DOB, '') = '' THEN '' ELSE CONVERT(VARCHAR(10), DOB, 101) END + '|' + CASE WHEN ISNULL(SSN, '') 
                      = '' THEN '' ELSE CASE WHEN LEN(SSN) = 9 THEN SUBSTRING(SSN, 1, 3) + '-' + SUBSTRING(SSN, 4, 2) + '-' + SUBSTRING(SSN, 6, 4) 
                      ELSE '' END END + '|' + COALESCE (c.FNumber, '') + '|id=' + cast(p.ID as varchar(16)) + 
                      CASE WHEN ISNULL(p.City,'') <> '' THEN '|city=' + p.City ELSE '|' END +
                      CASE WHEN ISNULL(p.[State],'') <> '' THEN '|state=' + p.[State] ELSE '' END
                      + '|'
                      AS Search
FROM         dbo.Person AS p LEFT OUTER JOIN
                      dbo.Customer AS c ON p.ID = c.PersonID
ORDER BY p.ID

GO



