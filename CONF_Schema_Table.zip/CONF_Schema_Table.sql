USE [SCRA_DB_TEST_50]
GO

/****** Object:  Table [conf].[SLA_Reports_List]    Script Date: 03/23/2020 15:17:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE SCHEMA [conf]
GO

CREATE TABLE [conf].[SLA_Reports_List](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


