USE [SCRA_DB_TEST_50]
GO

/****** Object:  Table [conf].[SLA_Reports_List]    Script Date: 03/23/2020 15:17:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE SCHEMA [conf]
GO

CREATE TABLE [conf].[SLA_Reports_List](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL
) ON [PRIMARY]

GO
SET IDENTITY_INSERT [conf].[SLA_Reports_List] ON
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (1, N'Benefit_Applied', 1)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (2, N'Reservists_Benefits_Applied', 2)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (3, N'Benefits_Removed', 3)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (4, N'Letter', 4)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (5, N'Request_Received_Letter', 5)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (6, N'Denied_Ineligible_Letter', 6)
INSERT [conf].[SLA_Reports_List] ([ID], [Name], [SortIndex]) VALUES (7, N'Benefits_To_Review', 7)
SET IDENTITY_INSERT [conf].[SLA_Reports_List] OFF

SET ANSI_PADDING OFF
GO


