﻿using System.Threading.Tasks;

namespace Scra.Model.ContactMethods
{
    public interface IContactMethodRepository
    {
        Task<ContactMethodList> GetList();
    }
}