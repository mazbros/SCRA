﻿using System;
using System.Threading.Tasks;
using Scra.Model.ContactMethods;
using Scra.Model.Dependents;
using Scra.Model.InquiryTypes;
using Scra.Model.Persons;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Model.Inquiries
{
    public class Inquiry
    {
        public int Id { get; set; }
        public ContactMethod ContactMethod { get; private set; }
        public PersonId PersonInquiringId { get; private set; }
        public PersonId ServicememberId { get; private set; }
        public IUser Agent { get; private set; }
        public DateTime InquiryDate { get; set; }
        public string Description { get; set; }
        public InquiryType InquiryType { get; set; }
        public DependentType DependentType { get; set; }
        public string Comment { get; set; }
        public InquiryScusa Scusa { get; private set; }
        public InquiryResponse Response { get; private set; }
        public DateTime? AcknowledgeDate { get; private set; }
        public bool IsCompleted { get; set; }
        public IdentificationMethod IdentificationMethod { get; set; }
        public bool IsOnActiveDuty { get; set; }
        public DateTime? DmdcValidationDate { get; set; }

        public Inquiry(int id, PersonId personInquiringId, PersonId servicememberId, ContactMethod contactMethod,
            IUser agent, DateTime inquiryDate, string description, InquiryType inquiryType, DependentType dependentType,
            InquiryScusa scusa, InquiryResponse response, string comment, DateTime? acknowledgeDate, bool isCompleted,
            IdentificationMethod identificationMethod, bool isOnActiveDuty, DateTime? dmdcValidationDate)
        {
            Id = id;
            PersonInquiringId = personInquiringId;
            ServicememberId = servicememberId;
            Agent = agent;
            InquiryDate = inquiryDate;
            Description = description;
            ContactMethod = contactMethod;
            InquiryType = inquiryType;
            DependentType = dependentType;
            Scusa = scusa;
            Response = response;
            Comment = comment;
            AcknowledgeDate = acknowledgeDate;
            IsCompleted = isCompleted;
            IdentificationMethod = identificationMethod;
            IsOnActiveDuty = isOnActiveDuty;
            DmdcValidationDate = dmdcValidationDate;
        }

        public Inquiry(PersonId personInquiringId, PersonId servicememberId, ContactMethod contactMethod, IUser agent, DateTime inquiryDate, string description, 
            InquiryType inquiryType, DependentType dependentType, IdentificationMethod identificationMethod)
        {
            PersonInquiringId = personInquiringId;
            ServicememberId = servicememberId;
            Agent = agent;
            ContactMethod = contactMethod;
            InquiryDate = inquiryDate;
            Description = description;
            InquiryType = inquiryType;
            DependentType = dependentType;
            Response = new InquiryResponse();
            Scusa = new InquiryScusa();
            IdentificationMethod = identificationMethod;
        }

        public async Task<PersonName> GetServiceMember()
        {
            var name = await GetPersonName(ServicememberId);
            if (name.IsNotEmpty())
            {
                return name;
            }
            return await GetPersonInquiring();
        }

        public Task<PersonName> GetPersonInquiring()
        {
            return GetPersonName(PersonInquiringId);
        }

        private async Task<PersonName> GetPersonName(PersonId personId)
        {
            var repo = Di.Get<IPersonRepository>();
            var person = await repo.Get(personId);
            return person == null ? PersonName.Empty() : person.Name;
        }
    }
}