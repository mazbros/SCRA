﻿using System;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.Tools;

namespace Scra.Model.Contracts
{
    public class ContractSnapshot
    {
        public ContractId Id { get; set; }
        public PersonName PersonName { get; private set; }
        public ContractType Type { get; private set; }
        public DateTime OpenDate { get; private set; }
        public DateTime? CloseDate { get; private set; }
        public string LegacyNo { get; private set; }
        public string CardNo { get; private set; }
        public int Center { get; private set; }
        public int Product { get; private set; }
        public string ContractNo { get; private set; }
        public PersonId PersonId { get; private set; }
        public string DependentType { get; private set; }

        public ContractSnapshot(ContractId id, PersonName personName, ContractType type, DateTime openDate,
            DateTime? closeDate, string contractNo, string legacyNo, string cardNo, int center, int product, PersonId personId, string dependentType)
        {
            Id = id;
            PersonName = personName;
            Type = type;
            OpenDate = openDate;
            CloseDate = closeDate;
            ContractNo = contractNo;
            LegacyNo = legacyNo;
            CardNo = cardNo;
            Center = center;
            Product = product;
            PersonId = personId;
            DependentType = dependentType;
        }

        public Task<Contract> GetFull()
        {
            var repo = Di.Get<IContractRepository>();
            return repo.Get(Id);
        }
    }
}