﻿using System;
using System.Threading.Tasks;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;

namespace Scra.Model.Contracts
{
    public class Benefit
    {
        public int Id { get; set; }
        public BenefitStatus Status { get; private set; }
        public ContractId ContractId { get; private set; }
        public PersonId PersonId { get; private set; }
        public int ActiveDutyId { get; set; }
        public bool IsPromo { get; private set; }
        public DateTime? StartDate { get; private set; }
        public DateTime? EndDate { get; private set; }
        public string DenialReason { get; set; }
        public int TaskId { get; set; }

        public Benefit(int id, ContractId contractId, PersonId personId, int activeDutyId, bool isPromo,
            DateTime? startDate, DateTime? endDate, BenefitStatus status, string denialReason, int taskId)
        {
            Id = id;
            ContractId = contractId;
            PersonId = personId;
            ActiveDutyId = activeDutyId;
            IsPromo = isPromo;
            StartDate = startDate;
            EndDate = endDate;
            Status = status;
            DenialReason = denialReason;
            TaskId = taskId;
        }

        public static Benefit Create(int contractId, int activeDutyId, int personId, BenefitStatus benefitStatus, int taskId)
        {
            return new Benefit(0, new ContractId(contractId), new PersonId(personId), activeDutyId, false, null, null, benefitStatus, null, taskId);
        }

        public static Benefit Create(ContractId contractId, ActiveDuty activeDuty, PersonId personId, BenefitStatus benefitStatus)
        {
            var activeDutyId = activeDuty != null ? activeDuty.Id : 0;
            return new Benefit(0, contractId, personId, activeDutyId, false, null, null, benefitStatus, null, 0);
        }

        public static Benefit CreateBenefitWithNoProduct(PersonId personId, ActiveDuty activeDuty, string denialReason, int taskId)
        {
            var activeDutyId = activeDuty != null ? activeDuty.Id : 0;
            return new Benefit(0, ContractId.Empty, personId, activeDutyId, false, null, null, BenefitStatus.Denied, denialReason, taskId);
        }

        public async Task<Tasc> AddBenefit()
        {
            var taskFactory = Di.Get<ITascFactory>();
            var task = await taskFactory.AddBenefit(ContractId);
            await ChangeStatus(task.Id);
            return task;
        }

        public async Task<Tasc> EditBenefit(TaskType taskType)
        {
            var taskFactory = Di.Get<ITascFactory>();
            var task = await taskFactory.EditBenefit(ContractId, taskType);
            await ChangeStatus(task.Id);
            //await CopyBenefitDetail();
            return task;
        }

        public async Task<Tasc> ContactCustomer()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.ContactCustomer(ContractId);
            await ChangeStatus(task.Id);
            return task;
        }

        public async Task<Tasc> RemoveBenefit()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.RemoveBenefit(ContractId);
            await ChangeStatus(task.Id);
            return task;
        }

        public async Task<Tasc> ExtendBenefit()
        {
            var taskFactory = Di.Get<ITascFactory>();
            var task = await taskFactory.ExtendBenefit(ContractId);
            await ChangeStatus(task.Id);
            return task;
        }


        public async Task<Tasc> DenyBenefit()
        {
            var tascFactory = Di.Get<ITascFactory>();
            var task = await tascFactory.DenyBenefit(ContractId);
            await ChangeStatus(task.Id);
            return task;
        }

        private async Task CopyBenefitDetail()
        {
            var repo = Di.Get<IBenefitDetailRepository>();
            var benefitDetail = await repo.GetLastDetail(Id);

            if (benefitDetail == null)
                return;

            var newBenefitDetail = BenefitDetail.Copy(benefitDetail);
            newBenefitDetail.BenefitId = Id;

            await repo.Save(newBenefitDetail);
        }

        public async Task ChangeStatus(BenefitStatus status)
        {
            Status = status;
            var repo = Di.Get<IBenefitRepository>();
            await repo.Save(this);
        }

        public async Task ChangeStatus(int id)
        {            
            var repo = Di.Get<IBenefitRepository>();
            TaskId = id;
            await repo.Save(this);
        }
    }
}
