﻿using System.Collections.Generic;

namespace Scra.Model.Tasks
{
    public class TaskTemplate
    {
        public string Title { get; }
        public IList<string> SubTasks { get; }

        public TaskTemplate(string title, IList<string> subTasks)
        {
            Title = title;
            SubTasks = subTasks;
        }
    }
}