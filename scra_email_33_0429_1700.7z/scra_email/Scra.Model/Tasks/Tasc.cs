﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Contracts;
using Scra.Model.DomainEvents;
using Scra.Model.Extensions;
using Scra.Model.Persons;
using Scra.Model.Users;

namespace Scra.Model.Tasks
{
    public class Tasc : IDomainEventHolder
    {
        public int Id { get; set; }
        public string Title { get; private set; }
        public DateTime CreateDate { get; private set; }
        public DateTime DueDate { get; private set; }
        public TascStatus Status { get; private set; }
        public TaskType Type { get; private set; }
        public PersonId PersonId { get; private set; }
        public ContractId ContractId { get; private set; }
        public bool IsQaComplete { get; private set; }
        public int InquiryId { get; private set; }
        public IUser ModifiedBy { get; private set; }
        public IUser Assignee { get; private set; }
        public IUser QaAssignee { get; private set; }
        public IReadOnlyCollection<SubTask> SubTasks { get; private set; }
        public IList<IDomainEvent> DomainEvents { get; private set; }

        public Tasc(int id, string title, DateTime createDate, DateTime dueDate, TascStatus status, TaskType type, IList<SubTask> subTasks,
            IUser assignee, IUser qaAssignee,
            int inquiryId, PersonId personId, ContractId contractId, bool isQaComplete)
        {
            Id = id;
            Title = title;
            CreateDate = createDate;
            DueDate = dueDate;
            Status = status;
            Type = type;
            Assignee = assignee;
            QaAssignee = qaAssignee;
            InquiryId = inquiryId;
            PersonId = personId;
            ContractId = contractId;
            IsQaComplete = isQaComplete;
            AcceptSubTasks(subTasks);
            DomainEvents = new List<IDomainEvent>();
        }

        public Tasc(int id, string title, DateTime createDate, DateTime dueDate, TascStatus status, TaskType type, IList<SubTask> subTasks, 
            IUser modifiedBy, IUser assignee, IUser qaAssignee,
            int inquiryId, PersonId personId, ContractId contractId, bool isQaComplete)
        {
            Id = id;
            Title = title;
            CreateDate = createDate;
            DueDate = dueDate;
            Status = status;
            Type = type;
            ModifiedBy = modifiedBy;
            Assignee = assignee;
            QaAssignee = qaAssignee;
            InquiryId = inquiryId;
            PersonId = personId;
            ContractId = contractId;
            IsQaComplete = isQaComplete;
            AcceptSubTasks(subTasks);
            DomainEvents = new List<IDomainEvent>();
        }

        public void UpdateStatus()
        {
            var rejectedItems = SubTasks.Where(x => x.Status == SubTaskStatus.Rejected).Select(x => x.ItemId).Distinct().ToList();
            var fixedSubTasks = new List<SubTask>();
            
            foreach (var rejectedItem in rejectedItems)
            {
                var item = rejectedItem;
                var subTask = SubTasks.FirstOrDefault(x => x.ItemId == item && (x.Status != SubTaskStatus.Rejected));
                fixedSubTasks.Add(subTask);
            }

            if (fixedSubTasks.Count > 0 && fixedSubTasks.All(x => x != null && x.Status == SubTaskStatus.QaCompleted))
            {
                Status = TascStatus.QaCompleted;
            }
            else if (fixedSubTasks.Count > 0 && fixedSubTasks.All(x => x != null && x.Status != SubTaskStatus.InProcess))
            {
                Status = TascStatus.Completed;
            }

            var qaCompletedItems = SubTasks.Where(y => y.Status == SubTaskStatus.QaCompleted).Select(x => x.ItemId).OrderBy(x => x).ToList();
            var itemIds = SubTasks.Select(x => x.ItemId).Distinct().OrderBy(x => x).ToList();

            if (itemIds.Except(qaCompletedItems).ToList().Count == 0)
                Status = TascStatus.QaCompleted;
            

            if (AreAllSubTasksCompleted(SubTasks))
            {
                Status = TascStatus.Completed;
            }

            if (AreAllSubTasksQaCompleted(SubTasks))
            {
                Status = TascStatus.QaCompleted;
                IsQaComplete = true;
                DomainEvents.Add(new TaskCompleteEvent(this));
            }
        }

        private bool AnySubTaskDone(IReadOnlyCollection<SubTask> subTasks)
        {
            return subTasks.Any(x => x.Status == SubTaskStatus.InProcess);            
        }

        private bool AreAllSubTasksQaCompleted(IReadOnlyCollection<SubTask> subTasks)
        {
            return subTasks.All(x => x.Status == SubTaskStatus.QaCompleted);
        }

        private bool AreAllSubTasksCompleted(IReadOnlyCollection<SubTask> subTasks)
        {
            if (subTasks.All(x => x.Status == SubTaskStatus.Completed))
            {
                return true;
            }
            return false;
            
        }

        public void ToRejected()
        {
            Status = TascStatus.Rejected;
        }

        private void AcceptSubTasks(IList<SubTask> subTasks)
        {
            SubTasks = subTasks.AsReadOnly();
            foreach (var subTask in SubTasks)
            {
                subTask.Task = this;
            }
        }

        public void ToMisdirected()
        {
            Status = TascStatus.Misdirected;
        }

        private TascStatus GetStatus(IReadOnlyCollection<SubTask> subTasks)
        {
            if (subTasks.Any(x => x.Status == SubTaskStatus.InProcess))
            {
                if (subTasks.All(x => x.Status == SubTaskStatus.InProcess))
                {
                    return TascStatus.Created;
                }
                return TascStatus.InProcess;
            }

            return TascStatus.Completed;
        }

        private bool GetQaCompletion(IReadOnlyCollection<SubTask> subTasks)
        {
            return subTasks.All(x => x.Status == SubTaskStatus.QaCompleted);
        }
    }
}
