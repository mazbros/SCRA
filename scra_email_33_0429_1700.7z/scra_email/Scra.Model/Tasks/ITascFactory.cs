﻿using System.Threading.Tasks;
using Scra.Model.Contracts;
using Scra.Model.Inquiries;
using Scra.Model.Persons;

namespace Scra.Model.Tasks
{
    public interface ITascFactory
    {
        Task<Tasc> CreateRequest(Inquiry inquiry);

        Task<Tasc> AddBenefit(ContractId contractId);
        Task<Tasc> EditBenefit(ContractId contractId, TaskType taskType);
        Task<Tasc> RemoveBenefit(ContractId contractId);
        Task<Tasc> DenyBenefit(ContractId benefitContractId);
        Task<Tasc> DenyBenefit(PersonId personId);
        Task<Tasc> ContactCustomer(ContractId contractId);
        Task<Tasc> ExtendBenefit(ContractId contractId);
    }
}