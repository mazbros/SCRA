﻿namespace Scra.Model.Version
{
    public class DbVersion
    {
        public DbVersion(int dbVersion)
        {
            Version = dbVersion;
        }
        public int Version { get; set; }
    }
}
