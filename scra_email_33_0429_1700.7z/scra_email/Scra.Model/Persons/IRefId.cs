﻿namespace Scra.Model.Persons
{
    public interface IRefId
    {
        int Value { get; }
    }
}