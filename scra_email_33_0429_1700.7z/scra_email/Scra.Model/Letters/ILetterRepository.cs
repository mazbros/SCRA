﻿using System;
using System.Threading.Tasks;
using Scra.Model.ServiceMembers;

namespace Scra.Model.Letters
{
    public interface ILetterRepository
    {
        Task<LetterList> GetList();
        Task<string> LoadTemplate(int number);
        Task<BenefitLetterTemplate> GetBenefitInformation(int id);
        Task<ActiveDuty> GetPriorActiveDuty(int id);
    }
}