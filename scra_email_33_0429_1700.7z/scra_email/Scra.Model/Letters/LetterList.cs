﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Scra.Model.Extensions;
using Scra.Model.Tools;

namespace Scra.Model.Letters
{
    public class LetterList
    {
        private IReadOnlyCollection<Letter> _letters;
        private IDictionary<int, Letter> _idNameMap;
        private static LetterList _instance;

        private LetterList()
        {
        }

        public static LetterList Create(IList<Letter> letters)
        {
            letters.Insert(0,Letter.Empty);
            return new LetterList
            {
                _letters = letters.AsReadOnly(),
                _idNameMap = letters.ToDictionary(x => x.Id, x => x)
            };
        }

        public IReadOnlyCollection<Letter> All()
        {
            return _letters;
        }

        public Letter Get(int letterId)
        {
            if (letterId != 0)
            {
                return _idNameMap[letterId];
            }

            return Letter.Empty;
        }

        public static async Task<LetterList> GetInstance()
        {
            if (_instance == null)
            {
                var repo = Di.Get<ILetterRepository>();
                _instance = await repo.GetList();
            }

            return _instance;
        }

        public Letter Default()
        {
            return _letters.First();
        }

        public Letter Empty()
        {
            return Letter.Empty;
        }
    }
}
