﻿using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Model.Letters;
using Scra.Model.Tools;
using Scra.Tests.Tools;

namespace Scra.Tests
{
    public class LetterTests
    {
        private ILetterRepository _letterRepository;

        [Test]
        public async Task Get_Letter_List()
        {
            await Tester.Init();
            _letterRepository = Di.Get<ILetterRepository>();


            var l = await _letterRepository.GetList();

        }

    }
}
