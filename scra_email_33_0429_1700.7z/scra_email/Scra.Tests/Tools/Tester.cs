﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Configs;
using Scra.Model.BranchOfServices;
using Scra.Model.Contracts;
using Scra.Model.Persons;
using Scra.Model.ServiceMembers;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Model.Users;
using Scra.Services;

namespace Scra.Tests.Tools
{
    public class Tester
    {
        private readonly NameGenerator _nameGenerator;

        public Tester()
        {
            _nameGenerator = new NameGenerator();
        }

        public static async Task<Tester> Init()
        {
            var tester = new Tester();
            await tester.InitAsync();
            return tester;
        }

        public async Task<Person> CreatePerson()
        {
            var name = _nameGenerator.Next();
            var person = await PersonFactory.CreateAsync(name, Address.Empty(), null, Ssn.Empty(), PersonContacts.Empty(), FNumber.Empty(), string.Empty);
            var repository = Di.Get<IPersonRepository>();
            await repository.Save(person);

            return person;
        }

        public async Task<Contract> CreateContract(PersonId personId, ContractCategory category)
        {
            var contractTypeRepository = Di.Get<IContractTypeRepository>();
            var creditCards = await contractTypeRepository.Load(category);
            var creditCardType = creditCards.First();
            var contract = Contract.CreateRemote(creditCardType, "123456","007", "1234-5678-2143-6587",0,0, DateTime.Today.AddYears(-5), null, ContractCategory.Empty, string.Empty);

            contract = Contract.CopyFromRemote(personId, contract);

            var contractRepository = Di.Get<IContractRepository>();
            await contractRepository.Save(contract);

            return contract;
        }

        public async Task<ActiveDuty> CreateActiveDuty(PersonId personId)
        {
            var branchOfServiceList = await BranchOfServiceList.GetInstance();
            var activeDuty = ActiveDuty.Create(personId);
            activeDuty.BranchOfService = branchOfServiceList.All().First();
            activeDuty.StartDate = DateTime.Now.AddMonths(-3);
            var serviceMemberRepository = Di.Get<IServiceMemberRepository>();
            await serviceMemberRepository.Save(activeDuty);

            return activeDuty;
        }

        public async Task<Tasc> GetTask(ContractId contractId)
        {
            var taskRepository = Di.Get<ITaskRepository>();
            var tasks = await taskRepository.Load(new LoadTasksFilter { ContractId = contractId }, string.Empty);
            Assert.AreEqual(1, tasks.Count);
            return await tasks.First().GetFull();
        }

        private async Task InitAsync()
        {
            DiScraModule.Register();
            new SetupConfigService().Setup();
            new SetupDomainHandlerService().Setup();

            var userRepository = Di.Get<IUserRepository>();
            var user = await userRepository.GetOrCreate("Tester", true);
            Di.Set<IUser>(user);
        }
    }
}