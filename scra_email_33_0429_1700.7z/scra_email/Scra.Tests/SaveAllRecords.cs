﻿using System.Threading.Tasks;
using NUnit.Framework;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.Tests.Tools;

namespace Scra.Tests
{
    public class SaveAllRecords
    {
        private ITaskRepository _repository;


        [Test]
        public async Task Load_Task_By_Person()
        {
            await Tester.Init();
            Init();
            var currentTasc = await _repository.Get(389);
        }

        private void Init()
        {
            _repository = Di.Get<ITaskRepository>();
        }

        [Test]
        public void SubTaskType_Parse_Person_Dashboard()
        {
            var b = SubTaskType.Parse("person_dashboard");
            Assert.AreEqual(b, SubTaskType.PersonDashboard);
        }

        [Test]
        public void SubTaskType_Parse_Communication()
        {
            var c = SubTaskType.Parse("communication");
            Assert.Equals(c, SubTaskType.Communication);
        }
    }
}
