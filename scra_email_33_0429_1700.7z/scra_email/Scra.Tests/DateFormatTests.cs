﻿using System;
using NUnit.Framework;
using Scra.Controls;

namespace Scra.Tests
{
    public class DateFormatTests
    {
        [Test]
        public void Parse_should_find_date_and_time_when_pass_am_time()
        {
            var time = Formatter.ParseDate("12/10/2013 11:22 AM");
            Assert.AreEqual(new DateTime(2013, 12, 10, 11, 22, 0), time);
        }

        [Test]
        public void Parse_should_find_date_and_time_when_pass_pm_time()
        {
            var time = Formatter.ParseDate("12/10/2013 11:22 PM");
            Assert.AreEqual(new DateTime(2013, 12, 10, 23, 22, 0), time);
        }

        [Test]
        public void Parse_should_return_null_when_month_is_out_of_range()
        {
            var time = Formatter.ParseDate("22/10/2013 11:22 AM");
            Assert.Null(time);
        }
    }
}
