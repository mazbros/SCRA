﻿using System.Threading.Tasks;
using Scra.DataAccess.Core;
using Scra.Model.Contracts;

namespace Scra.DataAccess.Contracts
{
    internal class BenefitDetailRepository : IBenefitDetailRepository
    {
        private const string GET_SQL = @"
SELECT	*
FROM	dbo.BenefitDetail
WHERE   {WHERE}";

        private const string GET_LAST_DETAIL_SQL = @"
Select * from BenefitDetail
	where BenefitId in(
		Select B.ID As BenefitId
			from Benefit B 
			where B.ContractID = (select ContractId from benefit where ID = {BenefitId} )
			) order by Timestamp desc";

        private readonly SpExecutor _spExecutor;
        private readonly SqlExecutor _sqlExecutor;

        public BenefitDetailRepository(SpExecutor spExecutor, SqlExecutor sqlExecutor)
        {
            _spExecutor = spExecutor;
            _sqlExecutor = sqlExecutor;
        }

        public Task<BenefitDetail> Get(int benefitId)
        {
            var sql = GET_SQL.Replace("{WHERE}", "BenefitId=" + benefitId);
            return _sqlExecutor.ExecuteOne(sql, Convert);
        }

        public Task<BenefitDetail> GetLastDetail(int benefitId)
        {
            var sql = GET_LAST_DETAIL_SQL.Replace("{BenefitId}", benefitId.ToString());
            return _sqlExecutor.ExecuteOne(sql, Convert);
        }

        public async Task Save(BenefitDetail model)
        {
            var id = SpParameter.Create(model.Id);
            var parameters = new[]
            {
                SpParameter.Create(BenefitDetailColumn.BENEFIT_ID, model.BenefitId),
                SpParameter.Create(BenefitDetailColumn.CURRENT_RATE, model.CurrentRate),
                SpParameter.Create(BenefitDetailColumn.BLOCK_41, model.Block41),
                SpParameter.Create(BenefitDetailColumn.DMI_SENT_DATE, model.DmiSentDate),
                SpParameter.Create(BenefitDetailColumn.CONFIRMATION_RECEIVED_DATE, model.ConfirmationReceivedDate),
                SpParameter.Create(BenefitDetailColumn.IS_PROMOTIONAL_OFFER, model.IsPromotionalOffer),
                SpParameter.Create(BenefitDetailColumn.PROMOTION_END_DATE, model.PromotionEndDate),
                SpParameter.Create(BenefitDetailColumn.IS_RATE_CAP_PERFORMED, model.IsRateCapPerformed),
                SpParameter.Create(BenefitDetailColumn.IS_FEE_WAIVED, model.IsFeeWaived),
                SpParameter.Create(BenefitDetailColumn.FEE_REFUNDED_AMOUNT, model.FeeRefundAmount),
                SpParameter.Create(BenefitDetailColumn.FEE_REFUNDED_DATE, model.DateFeesRefunded),
                SpParameter.Create(BenefitDetailColumn.IS_STATEMENTS_PENDING, model.IsStatementsPending),
                SpParameter.Create(BenefitDetailColumn.STATEMENTS_DATE, model.StatementDate),
                SpParameter.Create(BenefitDetailColumn.IS_INTEREST_ADJUSTMENT_CALCULATED, model.IsInterestAdjustmentCalculated),
                SpParameter.Create(BenefitDetailColumn.INTEREST_REFUNDED_AMOUNT, model.InterestRefunded),
                SpParameter.Create(BenefitDetailColumn.INTEREST_REFUNDED_DATE, model.RefundDate),
                SpParameter.Create(BenefitDetailColumn.BENEFIT_APPLIED_DATE, model.BenefitAppliedDate),
                SpParameter.Create(BenefitDetailColumn.DATE_BENEFIT_EXPECTED, model.DateBenefitExpected),
                SpParameter.Create(BenefitDetailColumn.BENEFIT_EFFECTIVE_DATE, model.BenefitEffectiveDate),
                SpParameter.Create(BenefitDetailColumn.EXPECTED_REMOVAL_DATE, model.ExpectedRemovalDate),
                SpParameter.Create(BenefitDetailColumn.BENEFIT_REMOVED_DATE, model.BenefitRemovedDate),
                SpParameter.ModifiedBy(),
                id
            };

            await _spExecutor.Execute("dbo.spBenefitDetail_Update", parameters);

            model.Id = (int)id.Value;
        }

        private BenefitDetail Convert(IRowData row)
        {
            var id = row.AsInt(RefColumn.ID);
            var benefitId = row.AsInt(BenefitDetailColumn.BENEFIT_ID);
            var currentRate = row.AsDecimal(BenefitDetailColumn.CURRENT_RATE);
            var block41 = row.AsBool(BenefitDetailColumn.BLOCK_41);
            var dmiSentDate = row.AsDateTime(BenefitDetailColumn.DMI_SENT_DATE);
            var confirmationReceivedDate = row.AsDateTime(BenefitDetailColumn.CONFIRMATION_RECEIVED_DATE);
            var isPromotionalOffer = row.AsBool(BenefitDetailColumn.IS_PROMOTIONAL_OFFER);
            var promotionEndDate = row.AsDateTime(BenefitDetailColumn.PROMOTION_END_DATE);
            var isRateCapPerformed = row.AsBool(BenefitDetailColumn.IS_RATE_CAP_PERFORMED);
            var isFeeWaived = row.AsBool(BenefitDetailColumn.IS_FEE_WAIVED);
            var feeRefundedAmount = row.AsDecimal(BenefitDetailColumn.FEE_REFUNDED_AMOUNT);
            var feeRefundedDate = row.AsDateTime(BenefitDetailColumn.FEE_REFUNDED_DATE);
            var isStatementsPending = row.AsBool(BenefitDetailColumn.IS_STATEMENTS_PENDING);
            var statementDate = row.AsDateTime(BenefitDetailColumn.STATEMENTS_DATE);
            var isInterestAdjustmentCalculated = row.AsBool(BenefitDetailColumn.IS_INTEREST_ADJUSTMENT_CALCULATED);
            var refundAmount = row.AsDecimal(BenefitDetailColumn.INTEREST_REFUNDED_AMOUNT);
            var refundDate = row.AsDateTime(BenefitDetailColumn.INTEREST_REFUNDED_DATE);
            var benefitAppliedDate = row.AsDateTime(BenefitDetailColumn.BENEFIT_APPLIED_DATE);
            var dateBenefitExpected= row.AsDateTime(BenefitDetailColumn.DATE_BENEFIT_EXPECTED);
            var benefitEffectiveDate = row.AsDateTime(BenefitDetailColumn.BENEFIT_EFFECTIVE_DATE);
            var expectedRemovalDate = row.AsDateTime(BenefitDetailColumn.EXPECTED_REMOVAL_DATE);
            var benefitRemovedDate = row.AsDateTime(BenefitDetailColumn.BENEFIT_REMOVED_DATE);
            return new BenefitDetail(id, benefitId, currentRate, block41, dmiSentDate, confirmationReceivedDate,
                isPromotionalOffer, promotionEndDate, isRateCapPerformed, isFeeWaived, feeRefundedAmount, feeRefundedDate,
                isStatementsPending, statementDate, isInterestAdjustmentCalculated, refundAmount, refundDate, benefitAppliedDate,
                dateBenefitExpected,benefitEffectiveDate, expectedRemovalDate, benefitRemovedDate);
        }
    }
}