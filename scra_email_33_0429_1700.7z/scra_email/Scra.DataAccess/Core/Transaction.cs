﻿using System.Data.SqlClient;
using System.Threading.Tasks;
using Scra.DataAccess.Configs;
using Scra.Model.Tools;

namespace Scra.DataAccess.Core
{
    internal class Transaction : ITransaction
    {
        private SqlConnection _connection;
        private SqlTransaction _transaction;

        public static async Task<ITransaction> Start()
        {
            var config = Di.Get<IDbConfig>();
            var connection = new SqlConnection(config.ConnectionString);
            await connection.OpenAsync();
            var transaction = connection.BeginTransaction();
            return new Transaction{ _connection = connection, _transaction = transaction };
        }

        public void Dispose()
        {
            if (_transaction != null)
            {
                _transaction.Dispose();
            }
            if (_connection != null)
            {
                _connection.Dispose();
            }
        }

        public void Commit()
        {
            _transaction.Commit();
            if (_connection != null)
            {
                _connection.Dispose();
            }
        }

        public SqlConnection GetConnection()
        {
            return _connection;
        }

        public SqlTransaction GetTransaction()
        {
            return _transaction;
        }
    }
}