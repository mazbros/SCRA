﻿namespace Scra.DataAccess.Tasks
{
    public static class SubTaskColumn
    {
        public const string STATUS = "Status";
        public const string TITLE = "Title";
        public const string CODE = "Code";
        public const string SORT_NO = "SortNo";
        public const string TASK_ID = "TaskID";
        public const string COMPLETION_DATE = "CompletionDate";
        public const string QA_COMPLETION_DATE = "QaCompletionDate";
        public const string IS_QA_COMPLETE = "IsQaComplete";
        public const string IS_COMPLETE = "IsComplete";
    }
}