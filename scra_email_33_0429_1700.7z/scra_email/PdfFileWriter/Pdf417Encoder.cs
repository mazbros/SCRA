﻿/////////////////////////////////////////////////////////////////////
//
//	PdfFileWriter
//	PDF File Write C# Class Library.
//
//	Pdf417Encoder
//	PDF417 Barcode Encoder.
//
//	Uzi Granot
//	Version: 1.0
//	Date: April 1, 2013
//	Copyright (C) 2013-2019 Uzi Granot. All Rights Reserved
//
//	PdfFileWriter C# class library and TestPdfFileWriter test/demo
//  application are free software.
//	They is distributed under the Code Project Open License (CPOL).
//	The document PdfFileWriterReadmeAndLicense.pdf contained within
//	the distribution specify the license agreement and other
//	conditions and notes. You must read this document and agree
//	with the conditions specified in order to use this software.
//
//	For version history please refer to PdfDocument.cs
//
/////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Numerics;
using System.Text;

namespace PdfFileWriter
{
	/// <summary>
	/// PDF417 Encoding control
	/// </summary>
	public enum Pdf417EncodingControl
	{
	/// <summary>
	/// Auto encoding control
	/// </summary>
	Auto,

	/// <summary>
	/// Encode all as bytes
	/// </summary>
	ByteOnly,

	/// <summary>
	/// Encode all as text and bytes
	/// </summary>
	TextAndByte,
	}

/// <summary>
/// PDF417 Error correction level
/// </summary>
public enum ErrorCorrectionLevel
	{
	/// <summary>
	/// Error correction level 0 (2 correction codewords)
	/// </summary>
	Level_0,
	/// <summary>
	/// Error correction level 1 (4 correction codewords)
	/// </summary>
	Level_1,
	/// <summary>
	/// Error correction level 2 (8 correction codewords)
	/// </summary>
	Level_2,
	/// <summary>
	/// Error correction level 3 (16 correction codewords)
	/// </summary>
	Level_3,
	/// <summary>
	/// Error correction level 4 (32 correction codewords)
	/// </summary>
	Level_4,
	/// <summary>
	/// Error correction level 5 (64 correction codewords)
	/// </summary>
	Level_5,
	/// <summary>
	/// Error correction level 6 (128 correction codewords)
	/// </summary>
	Level_6,
	/// <summary>
	/// Error correction level 7 (256 correction codewords)
	/// </summary>
	Level_7,
	/// <summary>
	/// Error correction level 8 (512 correction codewords)
	/// </summary>
	Level_8,
	/// <summary>
	/// Recommended level less one
	/// </summary>
	AutoLow,
	/// <summary>
	/// Recomended level based on number of codewords
	/// </summary>
	AutoNormal,
	/// <summary>
	/// Recommended level plus one
	/// </summary>
	AutoMedium,
	/// <summary>
	/// Recommended level plus two
	/// </summary>
	AutoHigh
	}

internal enum Pdf417EncodingMode
	{
	Byte,
	Text,
	Numeric,
	}

internal enum TextEncodingMode
	{
	Upper,
	Lower,
	Mixed,
	Punct,
	ShiftUpper,
	ShiftPunct,
	}

/// <summary>
/// PDF417 Encoder
/// </summary>
public class Pdf417Encoder : Pdf417Base
	{
	// white and black brushes
	//internal static SolidBrush BrushWhite = new SolidBrush(Color.White);
	//internal static SolidBrush BrushBlack = new SolidBrush(Color.Black);

	// text reversed lookup tables
	internal static byte[] TextToUpper = new byte[128];
	internal static byte[] TextToLower = new byte[128];
	internal static byte[] TextToMixed = new byte[128];
	internal static byte[] TextToPunct = new byte[128];

	static Pdf417Encoder()
		{
		// upper case subtable
		for(int Index = 0; Index < 128; Index++) TextToUpper[Index] = 127;
		for(int Index = 0; Index < 26; Index++) TextToUpper['A' + Index] = (byte) Index;
		TextToUpper[' '] = 26;

		// lower case subtable
		for(int Index = 0; Index < 128; Index++) TextToLower[Index] = 127;
		for(int Index = 0; Index < 26; Index++) TextToLower['a' + Index] = (byte) Index;
		TextToLower[' '] = 26;

		// mixed case subtable
		for(int Index = 0; Index < 128; Index++) TextToMixed[Index] = 127;
		for(int Index = 0; Index < 25; Index++) TextToMixed[MixedToText[Index]] = (byte) Index;
		TextToMixed[' '] = 26;

		// punctuation case subtable
		for(int Index = 0; Index < 128; Index++) TextToPunct[Index] = 127;
		for(int Index = 0; Index < 29; Index++) TextToPunct[PunctToText[Index]] = (byte) Index;
		return;
		}

	/// <summary>
	/// Encoding control
	/// </summary>
	public Pdf417EncodingControl EncodingControl
		{
		get
			{
			return _EncodingControl;
			}
		set
			{
			// test symbol encoding
			if(value != Pdf417EncodingControl.Auto &&
				value != Pdf417EncodingControl.ByteOnly &&
				value != Pdf417EncodingControl.TextAndByte)
					throw new ApplicationException("PDF417 Encoding control must be Auto,\r\n" +
													"ByteOnly or TextAndByte. Default is Auto.");

			// save error correction level
			_EncodingControl = value;
			return;
			}
		}
	private Pdf417EncodingControl _EncodingControl = Pdf417EncodingControl.Auto;

	/// <summary>
	/// Error correction level
	/// </summary>
	public ErrorCorrectionLevel ErrorCorrection
		{
		get
			{
			return _ErrorCorrection;
			}
		set
			{
			// test error correction
			if(value < ErrorCorrectionLevel.Level_0 || value > ErrorCorrectionLevel.AutoHigh)
				throw new ApplicationException("PDF417 Error correction request is invalid.\r\n" +
												"Default is Auto normal.");

			// save error correction level
			_ErrorCorrection = value;
			return;
			}
		}
	private ErrorCorrectionLevel _ErrorCorrection = ErrorCorrectionLevel.AutoNormal;

	/// <summary>
	/// Width of narrow bar in pixels
	/// </summary>
	public int NarrowBarWidth
		{
		get
			{
			return _BarWidthPix;
			}
		set
			{
			if(value < 1 || value > 100)
				throw new ApplicationException("PDF417 Narrow bar width must be one or more\r\n" +
												"Default is two.");
			_BarWidthPix = value;
			if(_RowHeightPix < 3 * value) _RowHeightPix = 3 * value;
			if(_QuietZonePix < 2 * value) _QuietZonePix = 2 * value;
			return;	
			}
		}
	internal int _BarWidthPix = 2;

	/// <summary>
	/// Row height in pixels
	/// </summary>
	public int RowHeight
		{
		get
			{
			return _RowHeightPix;
			}
		set
			{
			if(value < 3 * _BarWidthPix || value > 300)
				throw new ApplicationException("PDF417 Row height must be at least 3 times narrow bar.\r\n" +
												"Default is six.");
			_RowHeightPix = value;
			return;	
			}
		}
	internal int _RowHeightPix = 6;

	/// <summary>
	/// Quiet zone around the barcode in pixels
	/// </summary>
	public int QuietZone
		{
		get
			{
			return _QuietZonePix;
			}
		set
			{
			if(value < 2 * _BarWidthPix || value > 200)
				throw new ApplicationException("PDF417 Quiet zone must be at least 2 times narrow bar.\r\n" +
												"Default is four.");
			_QuietZonePix = value;
			return;	
			}
		}
	internal int _QuietZonePix = 4;

	/// <summary>
	/// Default number of data columns
	/// </summary>
	public int DefaultDataColumns
		{
		get
			{
			return _DefaultDataColumns;
			}
		set
			{
			if(value < DataColumnsMin || value > DataColumnsMax)
				throw new ApplicationException("PDF417 Default data columns must be 1 to 30.\r\n" +
												"Default is three.");
			_DefaultDataColumns = value;
			return;	
			}
		}
	internal int _DefaultDataColumns = 3;

	/// <summary>
	/// ISO character set ISO-8859-n (n=1 to 9, 13 an 15)
	/// </summary>
	public string GlobalLabelIDCharacterSet
		{
		get
			{
			return _GlobalLabelIDCharacterSet;
			}
		set
			{
			if(string.IsNullOrWhiteSpace(value))
				{
				_GlobalLabelIDCharacterSet = null;
				return;
				}

			if(string.Compare(value.Substring(0, 9), "ISO-8859-", true) != 0 ||
				!int.TryParse(value.Substring(9), out int Part) || Part < 1 || Part > 9 && Part != 13 && Part != 15)
				{
				throw new ApplicationException("PDF417 Character set code in error.\r\n" +
												"Must be ISO-8859-n (1-9, 13, 15).\r\n" +
												"Default is ISO-8859-1.");
				}
			_GlobalLabelIDCharacterSet = value;
			_GlobalLabelIDCharacterSetNo = Part + 2;
			return;
			}
		}

	/// <summary>
	/// Global label ID user defined
	/// </summary>
	public int GlobalLabelIDUserDefined
		{
		get
			{
			return _GlobalLabelIDUserDefined;
			}
		set
			{
			if(value != 0 && (value < 810900 || value > 811799))
				throw new ApplicationException("PDF417 Global label identifier user defined value.\r\n" +
												"Must be 810900 to 811799 or zero\r\n" +
												"Default is not used or zero value");
			_GlobalLabelIDUserDefined = value;
			return;
			}
		}

	/// <summary>
	/// Global label ID general purpose
	/// </summary>
	public int GlobalLabelIDGeneralPurpose
		{
		get
			{
			return _GlobalLabelIDGeneralPurpose;
			}
		set
			{
			if(value != 0 && (value < 900 || value > 810899))
				throw new ApplicationException("PDF417 Global label identifier general purpose value.\r\n" +
												"Must be 900 to 810899 or zero\r\n" +
												"Default is not used or zero value");
			_GlobalLabelIDGeneralPurpose = value;
			return;
			}
		}

	/// <summary>
	/// Returns the barcode width in terms of narrow bars
	/// </summary>
	public int Columns
		{
		get
			{
			// data columns plus row indicators plus start and stop columns
			return ModulesInCodeword * (DataColumns + 4) + 1;
			}
		}

	/// <summary>
	/// Barcode image width in pixels
	/// </summary>
	public int ImageWidth
		{
		get
			{
			return _BarWidthPix * Columns + 2 * _QuietZonePix;
			}
		}

	/// <summary>
	/// Barcode image height in pixels
	/// </summary>
	public int ImageHeight
		{
		get
			{
			return _RowHeightPix * DataRows + 2 * _QuietZonePix;
			}
		}

	/// <summary>
	/// Encode unicode string
	/// </summary>
	/// <param name="StringData">Input string</param>
	public void Encode
			(
			string StringData
			)
		{
		// argument error
		if(string.IsNullOrEmpty(StringData))
			throw new ApplicationException("PDF417 Input barcode data string is null or empty.");

		// save argument
		BarcodeStringData = StringData;

		// convert string to byte array
		Encoding ISO = Encoding.GetEncoding(_GlobalLabelIDCharacterSet ?? "ISO-8859-1");
		byte[] UtfBytes = Encoding.UTF8.GetBytes(StringData);
		byte[] IsoBytes = Encoding.Convert(Encoding.UTF8, ISO, UtfBytes);

		// encode binary data
		Encode(IsoBytes);
		return;
		}

	/// <summary>
	/// Encode binary bytes array
	/// </summary>
	/// <param name="BinaryData">Input byte array</param>
	public void Encode
			(
			byte[] BinaryData
			)
		{
		// test data segments array
		if(BinaryData == null || BinaryData.Length == 0)
			throw new ApplicationException("PDF417 Input binary barcode data is null or empty");

		// save data segments array
		BarcodeBinaryData = BinaryData;

		// data encoding
		DataEncoding();

  		// set error correction level for no padding
		SetErrorCorrectionLevel();

		// DatacodewordsCount includes the data length codeword
		// this calculation adds DataColumns - 1 for rounding up
		int DataColumns = _DefaultDataColumns;
		int DataRows = (DataCodewords.Count + ErrorCorrectionLength + DataColumns - 1) / DataColumns;

		// if data rows exceeds the maximum allowed,
		// adjust data columns to reduce the number of rows
		if(DataRows > DataRowsMax)
			{
			DataRows = DataRowsMax;
			DataColumns = (DataCodewords.Count + ErrorCorrectionLength + DataRows - 1) / DataRows;
			if(DataColumns > DataColumnsMax) throw new ApplicationException("PDF417 Data overflow");
			}

		// exit
		this.DataRows = DataRows;
		this.DataColumns = DataColumns;
		return;
		}

	private void SetErrorCorrectionLevel()
		{
		// fixed error correction
		if(_ErrorCorrection >= ErrorCorrectionLevel.Level_0 && _ErrorCorrection <= ErrorCorrectionLevel.Level_8)
			{
			// error correction level
			ErrorCorrectionLevel = _ErrorCorrection;
			}
		else
			{
			// recommended normal values
			int DataLength = DataCodewords.Count;
			if(DataLength <= 40) ErrorCorrectionLevel = ErrorCorrectionLevel.Level_2;
			else if(DataLength <= 160) ErrorCorrectionLevel = ErrorCorrectionLevel.Level_3;
			else if(DataLength <= 320) ErrorCorrectionLevel = ErrorCorrectionLevel.Level_4;
			else if(DataLength <= 863) ErrorCorrectionLevel = ErrorCorrectionLevel.Level_5;
			else ErrorCorrectionLevel = ErrorCorrectionLevel.Level_6;

			if(_ErrorCorrection == ErrorCorrectionLevel.AutoLow) ErrorCorrectionLevel--;
			else if(_ErrorCorrection == ErrorCorrectionLevel.AutoMedium) ErrorCorrectionLevel++;
			else if(_ErrorCorrection == ErrorCorrectionLevel.AutoHigh) ErrorCorrectionLevel += 2;
			}

		// number of error correction codewords
		ErrorCorrectionLength = 1 << ((int) ErrorCorrectionLevel + 1);
		return;
		}

	private void DataEncoding()
		{
		// create empty codewords array
		DataCodewords = new List<int>();

		// add the data codewords length codeword
		DataCodewords.Add(0);

		// character set
		if(_GlobalLabelIDCharacterSet != null)
			{
			int Part = int.Parse(_GlobalLabelIDCharacterSet.Substring(9));
			DataCodewords.Add(GliCharacterSet);
			DataCodewords.Add(Part + 2);
			}

		// general purpose
		if(_GlobalLabelIDGeneralPurpose != 0)
			{
			DataCodewords.Add(GliGeneralPurpose);

			// (G2 + 1) * 900 + G3
			int G2 = Math.DivRem(_GlobalLabelIDGeneralPurpose, 900, out int G3) - 1;
			DataCodewords.Add(G2);
			DataCodewords.Add(G3);
			}

		// user defined
		if(_GlobalLabelIDUserDefined != 0)
			{
			DataCodewords.Add(GliUserDefined);
			DataCodewords.Add(_GlobalLabelIDUserDefined - 810900);
			}

		// barcode data pointer
		BarcodeDataPos = 0;
		BarcodeDataLength = BarcodeBinaryData.Length;

		// requested data encoding is byte only
		if(_EncodingControl == Pdf417EncodingControl.ByteOnly)
			{
			EncodeByteSegment(BarcodeDataLength);
			return;
			}

		// User selected encoding mode is auto or text plus byte (no numeric)
		// set the default encoding mode and text sub mode
		Pdf417EncodingMode = Pdf417EncodingMode.Text;
		TextEncodingMode = TextEncodingMode.Upper;

		// scan the barcode data
		while(BarcodeDataPos < BarcodeDataLength)
			{
			// test for numeric encoding if request is auto
			if(_EncodingControl == Pdf417EncodingControl.Auto)
				{
				// count consequtive digits at this point
				int Digits = CountDigits();
				if(Digits >= 13)
					{
					EncodeNumericSegment(Digits);
					continue;
					}
				}

			// count text
			int TextChars = CountText();
			if(TextChars >= 5)
				{
				EncodeTextSegment(TextChars);
				continue;
				}

			// count binary
			int Bytes = CountBytes();

			// encode binary
			EncodeByteSegment(Bytes);
			}
		return;
		}

	private int CountDigits()
		{
		int Ptr;
		for(Ptr = BarcodeDataPos; Ptr < BarcodeDataLength && BarcodeBinaryData[Ptr] >= '0' && BarcodeBinaryData[Ptr] <= '9'; Ptr++);
		return Ptr - BarcodeDataPos;
		}

	private int CountText()
		{
		int DigitsCount = 0;
		int Ptr;
		for(Ptr = BarcodeDataPos; Ptr < BarcodeDataLength; Ptr++)
			{
			// current character
			int Chr = BarcodeBinaryData[Ptr];

			// not part of text subset
			if(Chr < ' ' && Chr != '\r' && Chr != '\n' && Chr != '\t' || Chr > '~') break;

			// not a digits
			if(Chr < '0' || Chr > '9')
				{
				DigitsCount = 0;
				continue;
				}

			// digit
			DigitsCount++;

			// we have less than 13 digits
			if(DigitsCount < 13) continue;

			// terminate text mode if there is a block of 13 digits
			Ptr -= 12;
			break;
			}

		// return textbytes
		return Ptr - BarcodeDataPos;
		}

	private int CountPunctuation
			(
			int CurrentTextCount
			)
		{
		int Count = 0;
		while(CurrentTextCount > 0)
			{
			int NextChr = BarcodeBinaryData[BarcodeDataPos + Count];
			int NextCode = TextToPunct[NextChr];
			if(NextCode == 127) return 0;
			Count++;
			if(Count == 3) return 3;	
			}
		return 0;
		}

	private int CountBytes()
		{
		int TextCount = 0;
		int Ptr;
		for(Ptr = BarcodeDataPos; Ptr < BarcodeDataLength; Ptr++)
			{
			// current character
			int Chr = BarcodeBinaryData[Ptr];

			// not part of text subset
			if(Chr < ' ' && Chr != '\r' && Chr != '\n' && Chr != '\t' || Chr > '~')
				{
				TextCount = 0;
				continue;
				}

			// update text count
			TextCount++;

			// we have less than 5 text characters
			if(TextCount < 5) continue;

			// terminate binary mode if there is a block of 5 text characters
			Ptr -= 4;
			break;
			}

		return Ptr - BarcodeDataPos;
		}

	private void EncodeNumericSegment
			(
			int TotalCount
			)
		{
		// set numeric mode
		DataCodewords.Add(SwitchToNumericMode);
		Pdf417EncodingMode = Pdf417EncodingMode.Numeric;

		while(TotalCount > 0)
			{
			// work in segment no more than 44 digits
			int SegCount = Math.Min(TotalCount, 44);

			// build a string with initial value 1
			StringBuilder SegStr = new StringBuilder("1");

			// add data digits
			for(int Index = 0; Index < SegCount; Index++) SegStr.Append((char) BarcodeBinaryData[BarcodeDataPos++]);

			// convert to big integer
			BigInteger Temp = BigInteger.Parse(SegStr.ToString());

			// find the highest factor
			int Fact;
			for(Fact = 0; Fact < 15 && Temp >= FactBigInt900[Fact]; Fact++);

			// convert to module 900
			for(int Index = Fact - 1; Index > 0; Index--)
				{
				DataCodewords.Add((int) BigInteger.DivRem(Temp, FactBigInt900[Index], out Temp));
				}
			DataCodewords.Add((int) Temp);

			// update total count
			TotalCount -= SegCount;
			}
 		return;
		}

	private void EncodeTextSegment
			(
			int TotalCount
			)
		{
		// note first time this is the default
		if(Pdf417EncodingMode != Pdf417EncodingMode.Text)
			{
			DataCodewords.Add(SwitchToTextMode);
			Pdf417EncodingMode = Pdf417EncodingMode.Text;
			TextEncodingMode = TextEncodingMode.Upper;
			}

		List<int> Temp = new List<int>();
		int Code;

		while(TotalCount > 0)
			{
			int Chr = BarcodeBinaryData[BarcodeDataPos++];
			TotalCount--;

			switch(TextEncodingMode)
				{
				case TextEncodingMode.Upper:
					Code = TextToUpper[Chr];
					if(Code != 127)
						{
						Temp.Add(Code);
						continue;
						}
					Code = TextToLower[Chr];
					if(Code != 127)
						{
						Temp.Add(27); // Lower Latch
						Temp.Add(Code);
						TextEncodingMode = TextEncodingMode.Lower;
						continue;
						}
					Code = TextToMixed[Chr];
					if(Code != 127)
						{
						Temp.Add(28); // Mixed Latch
						Temp.Add(Code);
						TextEncodingMode = TextEncodingMode.Mixed;
						continue;
						}
					Code = TextToPunct[Chr];
					if(Code != 127)
						{
						// count how many more punctuations after this one
						int PunctCount = CountPunctuation(TotalCount);

						// if next character is panctuation too, we latch to punctuation
						if(PunctCount > 0)
							{
							Temp.Add(28); // mixed latch
							Temp.Add(25); // punctuation latch
							Temp.Add(Code);
							TextEncodingMode = TextEncodingMode.Punct;
							continue;
							}

						// one to three punctuation marks at this point
						Temp.Add(29); // punctuation shift
						Temp.Add(Code);
						continue;
						}
					throw new ApplicationException("Program error: Text upper submode.");

				case TextEncodingMode.Lower:
					Code = TextToLower[Chr];
					if(Code != 127)
						{
						Temp.Add(Code);
						continue;
						}
					Code = TextToUpper[Chr];
					if(Code != 127)
						{
						Temp.Add(27); // upper shift
						Temp.Add(Code);
						continue;
						}
					Code = TextToMixed[Chr];
					if(Code != 127)
						{
						Temp.Add(28); // mixed Latch
						Temp.Add(Code);
						TextEncodingMode = TextEncodingMode.Mixed;
						continue;
						}
					Code = TextToPunct[Chr];
					if(Code != 127)
						{
						// count how many more punctuations after this one
						int PunctCount = CountPunctuation(TotalCount);

						// if next character is panctuation too, we latch to punctuation
						if(PunctCount > 0)
							{
							Temp.Add(28); // mixed latch
							Temp.Add(25); // punctuation latch
							Temp.Add(Code);
							TextEncodingMode = TextEncodingMode.Punct;
							continue;
							}

						// one to three punctuation marks at this point
						Temp.Add(29); // punctuation shift
						Temp.Add(Code);
						continue;
						}
					throw new ApplicationException("Program error: Text lower submode.");

				case TextEncodingMode.Mixed:
					Code = TextToMixed[Chr];
					if(Code != 127)
						{
						Temp.Add(Code);
						continue;
						}
					Code = TextToLower[Chr];
					if(Code != 127)
						{
						Temp.Add(27); // lower Latch
						Temp.Add(Code);
						TextEncodingMode = TextEncodingMode.Lower;
						continue;
						}
					Code = TextToUpper[Chr];
					if(Code != 127)
						{
						Temp.Add(28); // upper latch
						Temp.Add(Code);
						TextEncodingMode = TextEncodingMode.Upper;
						continue;
						}
					Code = TextToPunct[Chr];
					if(Code != 127)
						{
						// count how many more punctuations after this one
						int PunctCount = CountPunctuation(TotalCount);

						// if next character is panctuation too, we latch to punctuation
						if(PunctCount > 0)
							{
							Temp.Add(25); // punctuation latch
							Temp.Add(Code);
							TextEncodingMode = TextEncodingMode.Punct;
							continue;
							}

						// single punctuation
						Temp.Add(29); // punctuation shift
						Temp.Add(Code);
						continue;
						}
					throw new ApplicationException("Program error: Text mixed submode.");

				case TextEncodingMode.Punct:
					Code = TextToPunct[Chr];
					if(Code != 127)
						{
						Temp.Add(Code);
						continue;
						}
					Temp.Add(29); // upper latch
					TextEncodingMode = TextEncodingMode.Upper;
					goto case TextEncodingMode.Upper;
				}
			}

		// convert to codewords
		int TempEnd = Temp.Count & ~1;
		for(int Index = 0; Index < TempEnd; Index += 2)
			{
			DataCodewords.Add(30 * Temp[Index] + Temp[Index + 1]);
			}
		if((Temp.Count & 1) != 0)
			{
			DataCodewords.Add(30 * Temp[TempEnd] + 29);
			}
		return;
		}

	private void EncodeByteSegment
			(
			int Count
			)
		{
		// special case one time shift
		if(Count == 1 && Pdf417EncodingMode == Pdf417EncodingMode.Text)
			{
			DataCodewords.Add(ShiftToByteMode);
			DataCodewords.Add(BarcodeBinaryData[BarcodeDataPos++]);
			return;
			}

		// add shift to byte mode code
		DataCodewords.Add(Count % 6 == 0 ? SwitchToByteModeForSix : SwitchToByteMode);

		// set byte encoding mode
		Pdf417EncodingMode = Pdf417EncodingMode.Byte;

		// end position
		int EndPos = BarcodeDataPos + Count;

		// encode six data bytes into five codewords
		if(Count >= 6)
			{
			while((EndPos - BarcodeDataPos) >= 6)
				{
				// load 6 data bytes into temp long integer
				long Temp = ((long) BarcodeBinaryData[BarcodeDataPos++] << 40) |
					((long) BarcodeBinaryData[BarcodeDataPos++] << 32) |
					((long) BarcodeBinaryData[BarcodeDataPos++] << 24) |
					((long) BarcodeBinaryData[BarcodeDataPos++] << 16) |
					((long) BarcodeBinaryData[BarcodeDataPos++] << 8) |
					BarcodeBinaryData[BarcodeDataPos++];

				// convert to 4 digits base 900 number
				for(int Index = 4; Index > 0; Index--)
					{
					DataCodewords.Add((int) Math.DivRem(Temp, Fact900[Index], out Temp));
					}

				// add the fifth one
				DataCodewords.Add((int) Temp);
				}
			}

		// encode the last 5 oe less bytes
		while(BarcodeDataPos < EndPos)
			{
			DataCodewords.Add(BarcodeBinaryData[BarcodeDataPos++]);
			}
		return;
		}

	/// <summary>
	/// Create barcode bool matrix
	/// </summary>
	/// <returns>Black and white matrix</returns>
	public bool[,] BarcodeMatrix()
		{
		// create empty codewords array
		Codewords = new int[DataRows * DataColumns];

		// length of data codewords plus length codeword
		int DataLength = DataCodewords.Count;

		// move data codewords
		for(int Index = 0; Index < DataLength; Index++) Codewords[Index] = DataCodewords[Index];

		// calculate padding
		int PaddingCodewordsCount = DataRows * DataColumns - DataCodewords.Count - ErrorCorrectionLength;

		// we need padding
		for(int Index = 0; Index < PaddingCodewordsCount; Index++) Codewords[DataLength++] = SwitchToTextMode;

		// set length (codewords plus padding)
		Codewords[0] = DataLength;

		// calculate error correction and move it to codewords array
		CalculateErrorCorrection();

		// create outout boolean matrix (Black=true, White=false)
		bool[,] Pdf417Matrix = new bool[DataRows, Columns];

		// last data row
		int LastRow = DataRows - 1;

		// fill output boolean matrix
		int StopCol = Columns - StopPatternLen;
		int RightRowIndCol = StopCol - ModulesInCodeword;
		for(int Row = 0; Row < DataRows; Row++)
			{
			// move start codeword
			for(int Col = 0; Col < StartPatternLen; Col++) Pdf417Matrix[Row, Col] = StartCodeword[Col];

			// move stop codeword
			for(int Col = 0; Col < StopPatternLen; Col++) Pdf417Matrix[Row, StopCol + Col] = StopCodeword[Col];

			// calculate left and right row indicators
			int LeftRowInd = 30 * (Row / 3);
			int RightRowInd = LeftRowInd;
			int Cluster = Row % 3;
			if(Cluster == 0)
				{
				LeftRowInd += LastRow / 3;
				RightRowInd += base.DataColumns - 1;
				}
			else if(Cluster == 1)
				{
				LeftRowInd += ((int) ErrorCorrectionLevel * 3) + (LastRow % 3);
				RightRowInd += LastRow / 3;
				}
			else
				{
				LeftRowInd += base.DataColumns - 1;
				RightRowInd += ((int) ErrorCorrectionLevel * 3) + (LastRow % 3);
				}

			// move left and right row indicators to barcode matrix
			CodewordToModules(Row, StartPatternLen, LeftRowInd, Pdf417Matrix);
			CodewordToModules(Row, RightRowIndCol, RightRowInd, Pdf417Matrix);

			// loop for all codewords of this row
			for(int Col = 0; Col < base.DataColumns; Col++)
				{
				// code word pointer
				int Ptr = base.DataColumns * Row + Col;

				// move codeword to barcode matrix
				CodewordToModules(Row, ModulesInCodeword * (Col + 2), Codewords[Ptr], Pdf417Matrix);
				}
			}

		// exit
		return Pdf417Matrix;
		}

	/// <summary>
	/// convert black and white matrix to image
	/// </summary>
	/// <param name="Pdf417Matrix">Barcode matrix</param>
	/// <returns>Balck and white image</returns>
	public bool[,] BlackAndWhiteBoolImage
			(
			bool[,] Pdf417Matrix
			)
		{
		// Pdf417Matrix width and height
		int MatrixWidth = Columns;
		int MatrixHeight = DataRows;
 
		// output matrix size in pixels all matrix elements are white (false)
		bool[,] BWImage = new bool[ImageHeight, ImageWidth];

		int XOffset = _QuietZonePix;
		int YOffset = _QuietZonePix;

		// convert result matrix to output matrix
		for(int Row = 0; Row < MatrixHeight; Row++)
			{
			for(int Col = 0; Col < MatrixWidth; Col++)
				{
				// bar is black
				if(Pdf417Matrix[Row, Col])
					{
					for(int Y = 0; Y < RowHeight; Y++)
						for(int X = 0; X < _BarWidthPix; X++) BWImage[YOffset + Y, XOffset + X] = true;
					}
				XOffset += _BarWidthPix;
				}
			XOffset = _QuietZonePix;
			YOffset += RowHeight;
			}
		return BWImage;
		}

/*
	public Bitmap BitmapImage
			(
			bool[,] Pdf417Matrix
			)
		{
		// Pdf417Matrix width and height
		int MatrixWidth = Columns;
		int MatrixHeight = DataRows;
 
		// create picture object and make it white
		Bitmap Image = new Bitmap(ImageWidth, ImageHeight);
		Graphics Graphics = Graphics.FromImage(Image);
		Graphics.FillRectangle(BrushWhite, 0, 0, ImageWidth, ImageHeight);

		int XOffset = _QuietZonePix;
		int YOffset = _QuietZonePix;

		// convert result matrix to output matrix
		for(int Row = 0; Row < MatrixHeight; Row++)
			{
			for(int Col = 0; Col < MatrixWidth; Col++)
				{
				// bar is black
				if(Pdf417Matrix[Row, Col]) Graphics.FillRectangle(BrushBlack, XOffset, YOffset, _BarWidthPix, RowHeight);
				XOffset += _BarWidthPix;
				}
			XOffset = _QuietZonePix;
			YOffset += RowHeight;
			}
		return Image;
		}
*/
	private void CalculateErrorCorrection()
		{
		// shortcut for the selected error correction table
		int[] ErrCorrTable = ErrorCorrectionTables[(int) ErrorCorrectionLevel];

		// create empty error correction array
		ErrCorrCodewords = new int[ErrorCorrectionLength];

		// pointer to last error correction codeword
		int ErrorCorrectionEnd = ErrorCorrectionLength - 1;

		// do the magic polynomial divide
		int DataCodewordsLength = Codewords[0];
		for(int CWIndex = 0; CWIndex < DataCodewordsLength; CWIndex++)
			{
			int Temp = (Codewords[CWIndex] + ErrCorrCodewords[ErrorCorrectionEnd]) % MOD;
			for(int Index = ErrorCorrectionEnd; Index > 0; Index--)
				{
				ErrCorrCodewords[Index] = (MOD + ErrCorrCodewords[Index - 1] - Temp * ErrCorrTable[Index]) % MOD;
				}
			ErrCorrCodewords[0] = (MOD - Temp * ErrCorrTable[0]) % MOD;
			}

		// last step of the division
		for(int Index = ErrorCorrectionEnd; Index >= 0; Index--)
			{
			ErrCorrCodewords[Index] = (MOD - ErrCorrCodewords[Index]) % MOD;
			}

		// copy error codewords in reverse order
		for(int Index = 0; Index < ErrorCorrectionLength; Index++)
			Codewords[DataCodewordsLength + Index] = ErrCorrCodewords[ErrorCorrectionEnd - Index];

		// move error correction
		return;		
		}

	private void CodewordToModules
			(
			int Row,
			int Col,
			int Codeword,
			bool[,] Matrix
			)
		{
		// translate to modules
		int Modules = CodeWordTable[Row % 3, Codeword];

		int Mask = 0x10000;
		for(int Index = 0; Index < ModulesInCodeword; Index++)
			{
			Matrix[Row, Col + Index] = (Modules & Mask) != 0;
			Mask >>= 1;
			}
		return;
		}

/*
Documentation for the quadratic equation solution below
-------------------------------------------------------
ImageWidth = _BarWidthPix * (ModulesInCodeword * (DataColumns + 4) + 1) + 2 * _QuietZonePix;
ImageHeight = _RowHeightPix * DataRows + 2 * _QuietZonePix;

Ratio = ImageWidth / ImageHeight;

Ratio * (_RowHeightPix * DataRows + 2 * _QuietZonePix) = _BarWidthPix * (ModulesInCodeword * (DataColumns + 4) + 1) + 2 * _QuietZonePix

Ratio * _RowHeightPix * DataRows + 2 * Ratio * _QuietZonePix =
	 _BarWidthPix * ModulesInCodeword * (DataColumns + 4) + _BarWidthPix + 2 * _QuietZonePix

Ratio * _RowHeightPix * DataRows + 2 * Ratio * _QuietZonePix =
	 _BarWidthPix * ModulesInCodeword * DataColumns + 4 * _BarWidthPix * ModulesInCodeword + _BarWidthPix + 2 * _QuietZonePix

Ratio * _RowHeightPix * DataRows - _BarWidthPix * ModulesInCodeword * DataColumns =
	 4 * _BarWidthPix * ModulesInCodeword + _BarWidthPix + 2 * _QuietZonePix - 2 * Ratio * _QuietZonePix

DataRows * DataColumns = DataCodewords.Count + ErrorCorrectionLength

Total = DataCodewords.Count + ErrorCorrectionLength

DataRows * DataColumns = Total

A = _BarWidthPix * ModulesInCodeword
B = _BarWidthPix * (4 * ModulesInCodeword + 1) + 2 * _QuietZonePix * (1 - Ratio)
C = Ratio * _RowHeightPix

C * DataRows - A * DataColumns = B;
C * Total / DataColumns - A * DataColumns = B;
A * DataColumns**2 + B * DataColumns - C * Total = 0;
*/

	/// <summary>
	/// Adjust rows and columns to achive weight to height ratio
	/// </summary>
	/// <param name="Ratio">Requested width to height ratio</param>
	/// <returns>Success or failure result</returns>
	public bool WidthToHeightRatio
			(
			double Ratio
			)
		{
		try
			{
			// total of data and error correction but no padding
			int Total = DataCodewords.Count + ErrorCorrectionLength;

			double A = _BarWidthPix * ModulesInCodeword;
			double B = _BarWidthPix * (4 * ModulesInCodeword + 1) - 2 * _QuietZonePix * (Ratio - 1);
			double C = Total * Ratio * _RowHeightPix;

			// initial guess for columns
			double Columns = (-B + Math.Sqrt(B * B + 4 * A * C)) / (2 * A);

			// calculated data columns and rows to meet the width to height ratio
			// this calculation adds DataColumns - 1 for rounding up
			int DataColumns = (int) Math.Round(Columns, 0, MidpointRounding.AwayFromZero);
			if(DataColumns < DataColumnsMin || DataColumns > DataColumnsMax) return false;

			int DataRows = (Total + DataColumns - 1) / DataColumns;
			if(DataRows < DataRowsMin || DataRows > DataRowsMax) return false;

			// set rows and columns
			this.DataColumns = DataColumns;
			this.DataRows = DataRows;
			return true;
			}
		catch
			{
			return false;
			}
		}

	/// <summary>
	/// Set number of data columns and data rows 
	/// </summary>
	/// <param name="DataColumns">Data columns</param>
	/// <returns>Success or failure result</returns>
	public bool SetDataColumns
			(
			int DataColumns
			)
		{
		try
			{
			// columns outside valid range
			if(DataColumns < DataColumnsMin || DataColumns > DataColumnsMax) return false;

			// calculate rows
			int DataRows = (DataCodewords.Count + ErrorCorrectionLength + DataColumns - 1) / DataColumns;
			if(DataRows < DataRowsMin || DataRows > DataRowsMax) return false;

			// set rows and columns
			this.DataColumns = DataColumns;
			this.DataRows = DataRows;
			return true;
			}
		catch
			{
			return false;
			}
		}

	/// <summary>
	/// Set number of data rows and data columns 
	/// </summary>
	/// <param name="DataRows">Data rowss</param>
	/// <returns>Success or failure result</returns>
	public bool SetDataRows
			(
			int DataRows
			)
		{
		try
			{
			// rows outside valid range
			if(DataRows < DataRowsMin || DataRows > DataRowsMax) return false;

			// calculate columns
			int DataColumns = (DataCodewords.Count + ErrorCorrectionLength + DataRows - 1) / DataRows;
			if(DataColumns < DataColumnsMin || DataColumns > DataColumnsMax) return false;

			// set rows and columns
			this.DataColumns = DataColumns;
			this.DataRows = DataRows;
			return true;
			}
		catch
			{
			return false;
			}
		}
	}
}
