USE [SCRA_DB]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_158]') AND parent_object_id = OBJECT_ID(N'[dbo].[EconomicConcept]'))
ALTER TABLE [dbo].[EconomicConcept] DROP CONSTRAINT [FK_158]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EconomicConcept]') AND type in (N'U'))
DROP TABLE [dbo].[EconomicConcept]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_146]') AND parent_object_id = OBJECT_ID(N'[dbo].[Benefit]'))
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_146]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_64]') AND parent_object_id = OBJECT_ID(N'[dbo].[Benefit]'))
ALTER TABLE [dbo].[Benefit] DROP CONSTRAINT [FK_64]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Benefit]') AND type in (N'U'))
DROP TABLE [dbo].[Benefit]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BenefitStatus]') AND type in (N'U'))
DROP TABLE [dbo].[BenefitStatus]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_184]') AND parent_object_id = OBJECT_ID(N'[dbo].[ActiveDuty]'))
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_184]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_185]') AND parent_object_id = OBJECT_ID(N'[dbo].[ActiveDuty]'))
ALTER TABLE [dbo].[ActiveDuty] DROP CONSTRAINT [FK_185]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ActiveDuty]') AND type in (N'U'))
DROP TABLE [dbo].[ActiveDuty]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_176]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMemberDocument]'))
ALTER TABLE [dbo].[ServiceMemberDocument] DROP CONSTRAINT [FK_176]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceMemberDocument]') AND type in (N'U'))
DROP TABLE [dbo].[ServiceMemberDocument]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_166]') AND parent_object_id = OBJECT_ID(N'[dbo].[DMDCSearchHistory]'))
ALTER TABLE [dbo].[DMDCSearchHistory] DROP CONSTRAINT [FK_166]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DMDCSearchHistory]') AND type in (N'U'))
DROP TABLE [dbo].[DMDCSearchHistory]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_130]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMemberToCustomerLink]'))
ALTER TABLE [dbo].[ServiceMemberToCustomerLink] DROP CONSTRAINT [FK_130]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_134]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMemberToCustomerLink]'))
ALTER TABLE [dbo].[ServiceMemberToCustomerLink] DROP CONSTRAINT [FK_134]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_138]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMemberToCustomerLink]'))
ALTER TABLE [dbo].[ServiceMemberToCustomerLink] DROP CONSTRAINT [FK_138]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceMemberToCustomerLink]') AND type in (N'U'))
DROP TABLE [dbo].[ServiceMemberToCustomerLink]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_53]') AND parent_object_id = OBJECT_ID(N'[dbo].[Contract]'))
ALTER TABLE [dbo].[Contract] DROP CONSTRAINT [FK_53]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Contract]') AND type in (N'U'))
DROP TABLE [dbo].[Contract]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_236]') AND parent_object_id = OBJECT_ID(N'[dbo].[Communication]'))
ALTER TABLE [dbo].[Communication] DROP CONSTRAINT [FK_236]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Communication]') AND type in (N'U'))
DROP TABLE [dbo].[Communication]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_228]') AND parent_object_id = OBJECT_ID(N'[dbo].[Letter]'))
ALTER TABLE [dbo].[Letter] DROP CONSTRAINT [FK_228]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Letter]') AND type in (N'U'))
DROP TABLE [dbo].[Letter]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_219]') AND parent_object_id = OBJECT_ID(N'[dbo].[Request]'))
ALTER TABLE [dbo].[Request] DROP CONSTRAINT [FK_219]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Request]') AND type in (N'U'))
DROP TABLE [dbo].[Request]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_206]') AND parent_object_id = OBJECT_ID(N'[dbo].[Customer]'))
ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK_206]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customer]') AND type in (N'U'))
DROP TABLE [dbo].[Customer]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_210]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMember]'))
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_210]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_97]') AND parent_object_id = OBJECT_ID(N'[dbo].[ServiceMember]'))
ALTER TABLE [dbo].[ServiceMember] DROP CONSTRAINT [FK_97]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ServiceMember]') AND type in (N'U'))
DROP TABLE [dbo].[ServiceMember]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_214]') AND parent_object_id = OBJECT_ID(N'[dbo].[Person]'))
ALTER TABLE [dbo].[Person] DROP CONSTRAINT [FK_214]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_244]') AND parent_object_id = OBJECT_ID(N'[dbo].[Person]'))
ALTER TABLE [dbo].[Person] DROP CONSTRAINT [FK_244]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Person]') AND type in (N'U'))
DROP TABLE [dbo].[Person]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Employee]') AND type in (N'U'))
DROP TABLE [dbo].[Employee]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DependentType]') AND type in (N'U'))
DROP TABLE [dbo].[DependentType]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BranchOfService]') AND type in (N'U'))
DROP TABLE [dbo].[BranchOfService]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NotificationMethod]') AND type in (N'U'))
DROP TABLE [dbo].[NotificationMethod]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hist].[Person]') AND type in (N'U'))
DROP TABLE [hist].[Person]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hist].[ServiceMember]') AND type in (N'U'))
DROP TABLE [hist].[ServiceMember]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_269]') AND parent_object_id = OBJECT_ID(N'[dbo].[Note]'))
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_269]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_274]') AND parent_object_id = OBJECT_ID(N'[dbo].[Note]'))
ALTER TABLE [dbo].[Note] DROP CONSTRAINT [FK_274]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Note]') AND type in (N'U'))
DROP TABLE [dbo].[Note]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_130]') AND parent_object_id = OBJECT_ID(N'[dbo].[PersonToPersonLink]'))
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_130]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_294]') AND parent_object_id = OBJECT_ID(N'[dbo].[PersonToPersonLink]'))
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_294]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_297]') AND parent_object_id = OBJECT_ID(N'[dbo].[PersonToPersonLink]'))
ALTER TABLE [dbo].[PersonToPersonLink] DROP CONSTRAINT [FK_297]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PersonToPersonLink]') AND type in (N'U'))
DROP TABLE [dbo].[PersonToPersonLink]
GO

--************************************** [PersonToPersonLink]

CREATE TABLE [dbo].[PersonToPersonLink](
	[ID]				INT NOT NULL IDENTITY(1,1),
	[DependentTypeID]	INT NOT NULL,
	[FromID]			INT NOT NULL,
	[ToID]				INT NOT NULL,
	[StartDate]			DATE NULL,
	[EndDate]			DATE NULL,
	[Timestamp]			DATETIME NOT NULL,
 CONSTRAINT [PK_ServiceMemberToCustomerLink] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_130] FOREIGN KEY([DependentTypeID])
REFERENCES [dbo].[DependentType] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_130]
GO
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_294] FOREIGN KEY([FromID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_294]
GO
ALTER TABLE [dbo].[PersonToPersonLink]  WITH CHECK ADD  CONSTRAINT [FK_297] FOREIGN KEY([ToID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[PersonToPersonLink] CHECK CONSTRAINT [FK_297]
GO




--************************************** [Note]

CREATE TABLE [dbo].[Note](
	[ID] [int] NOT NULL IDENTITY(1,1),
	[EmployeeID] [int] NOT NULL,
	[PersonID] [int] NOT NULL,
	[Comment] [nvarchar](max) NOT NULL,
	[Timestamp] [datetime] NOT NULL,
 CONSTRAINT [PK_Note] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Note]  WITH CHECK ADD  CONSTRAINT [FK_269] FOREIGN KEY([EmployeeID])
REFERENCES [dbo].[Employee] ([ID])
GO
ALTER TABLE [dbo].[Note] CHECK CONSTRAINT [FK_269]
GO
ALTER TABLE [dbo].[Note]  WITH CHECK ADD  CONSTRAINT [FK_274] FOREIGN KEY([PersonID])
REFERENCES [dbo].[Person] ([ID])
GO
ALTER TABLE [dbo].[Note] CHECK CONSTRAINT [FK_274]
GO

--************************************** [Employee]

CREATE TABLE [Employee]
(
 [ID] INT NOT NULL IDENTITY(1,1),
 [UserName] VARCHAR(255) NULL,

 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

SET IDENTITY_INSERT [dbo].[Employee] ON
INSERT [dbo].[Employee] ([ID], [UserName]) VALUES (1, N'n123456')
INSERT [dbo].[Employee] ([ID], [UserName]) VALUES (2, N'n234098')
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO

--************************************** [DependentType]

CREATE TABLE [DependentType]
(
 [ID]   INT NOT NULL IDENTITY(1,1),
 [Type] VARCHAR(50) NULL ,

 CONSTRAINT [PK_DependentType] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

SET IDENTITY_INSERT [dbo].[DependentType] ON
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (1, N'Service Member')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (2, N'Spouse')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (3, N'Dependent')
INSERT [dbo].[DependentType] ([ID], [Type]) VALUES (4, N'Other')
SET IDENTITY_INSERT [dbo].[DependentType] OFF
GO

--************************************** [BranchOfService]

CREATE TABLE [BranchOfService]
(
 [ID]     INT NOT NULL IDENTITY(1,1),
 [Branch] VARCHAR(50) NOT NULL ,

 CONSTRAINT [PK_BranchOfService] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

SET IDENTITY_INSERT [dbo].[BranchOfService] ON
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (1, N'Air Force')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (2, N'Air Force National Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (3, N'Air Force Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (4, N'Army')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (5, N'Army National Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (6, N'Army Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (7, N'Coast Guard')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (8, N'Coast Guard Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (9, N'Marine Corps')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (10, N'Marine Corps Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (11, N'Navy')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (12, N'Navy Reserve')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (13, N'NOAA')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (14, N'Public Health Service')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (15, N'Army Cadet')
INSERT [dbo].[BranchOfService] ([ID], [Branch]) VALUES (16, N'Air National Guard')
SET IDENTITY_INSERT [dbo].[BranchOfService] OFF
GO

--************************************** [NotificationMethod]

CREATE TABLE [NotificationMethod]
(
 [ID]     INT NOT NULL IDENTITY(1,1),
 [Method] VARCHAR(50) NULL ,

 CONSTRAINT [PK_NotificationMethods] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

SET IDENTITY_INSERT [dbo].[NotificationMethod] ON
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (1, N'Phone')
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (2, N'Email')
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (3, N'DMDC')
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (4, N'Letter')
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (5, N'Fax')
INSERT [dbo].[NotificationMethod] ([ID], [Method]) VALUES (6, N'LOB')
SET IDENTITY_INSERT [dbo].[NotificationMethod] OFF
GO

--************************************** [Person]

CREATE TABLE [Person]
(
 [ID]                   INT NOT NULL IDENTITY(1,1),
 [FirstName]            VARCHAR(255) NULL ,
 [LastName]             VARCHAR(255) NULL ,
 [MiddleInitial]        VARCHAR(255) NULL ,
 [SSN]                  VARCHAR(255) NULL ,
 [DOB]                  DATE NULL ,
 [Address1]             VARCHAR(255) NULL ,
 [Address2]             VARCHAR(255) NULL ,
 [City]                 VARCHAR(255) NULL ,
 [State]                VARCHAR(255) NULL ,
 [Zip]                  VARCHAR(255) NULL ,
 [Phone]                VARCHAR(255) NULL ,
 [Email]                VARCHAR(255) NULL ,
 [NotificationMethodID] INT NOT NULL ,
 [EmployeeID]           INT NOT NULL ,
 [Timestamp]			DATETIME NULL,
 [Search]				VARCHAR(MAX) NULL,

 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_214] FOREIGN KEY ([NotificationMethodID])
  REFERENCES [NotificationMethod]([ID]),
 CONSTRAINT [FK_244] FOREIGN KEY ([EmployeeID])
  REFERENCES [Employee]([ID])
);
GO

--************************************** [Communication]

CREATE TABLE [Communication]
(
 [ID]       INT NOT NULL IDENTITY(1,1),
 [PersonID] INT NOT NULL ,

 CONSTRAINT [PK_Communication] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_236] FOREIGN KEY ([PersonID])
  REFERENCES [Person]([ID])
);
GO

--************************************** [Letter]

CREATE TABLE [Letter]
(
 [ID]       INT NOT NULL IDENTITY(1,1),
 [Template] VARCHAR(255) NOT NULL ,
 [PersonID] INT NOT NULL ,

 CONSTRAINT [PK_Letter] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_228] FOREIGN KEY ([PersonID])
  REFERENCES [Person]([ID])
);
GO

--************************************** [Request]

CREATE TABLE [Request]
(
 [ID]       INT NOT NULL IDENTITY(1,1),
 [PersonID] INT NOT NULL ,

 CONSTRAINT [PK_Request] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_219] FOREIGN KEY ([PersonID])
  REFERENCES [Person]([ID])
);
GO

--************************************** [Customer]

CREATE TABLE [Customer]
(
 [ID]       INT NOT NULL IDENTITY(1,1),
 [FNumber]  VARCHAR(10) NULL ,
 [PersonID] INT NOT NULL ,

 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_206] FOREIGN KEY ([PersonID])
  REFERENCES [Person]([ID])
);
GO

--************************************** [ServiceMember]

CREATE TABLE [ServiceMember]
(
 [ID]                           INT NOT NULL IDENTITY(1,1),
 [DateOfContact]                DATE NULL ,
 [LOBContact]                   VARCHAR(50) NULL ,
 [EIDFutureCallUp]              DATE NULL ,
 [MilitaryOrdersReceived]       DATE NULL ,
 [VerifyBySCRAorMilitaryOrders] VARCHAR(50) NOT NULL ,
 [BranchOfServiceID]            INT NOT NULL ,
 [ActiveAccountEligible]        BIT NOT NULL ,
 [PersonID]                     INT NOT NULL ,
 [Timestamp]					DATETIME NOT NULL,

 CONSTRAINT [PK_ServiceMember] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_210] FOREIGN KEY ([PersonID])
  REFERENCES [Person]([ID])
);
GO

--************************************** [ActiveDuty]

CREATE TABLE [ActiveDuty]
(
 [ID]					INT NOT NULL IDENTITY(1,1),
 [ServiceMemberID]		INT NOT NULL ,
 [BranchOfServiceID]	INT NOT NULL,
 [StartDate]			DATE NULL ,
 [EndDate]				DATE NULL ,
 [ExpectedEndDate]		DATE NULL,
 [NoticeDate]			DATE NULL,
 [Timestamp]			DATETIME,

 CONSTRAINT [PK_ActiveDuty] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_184] FOREIGN KEY ([ServiceMemberID])
  REFERENCES [ServiceMember]([ID]),
  CONSTRAINT [FK_185] FOREIGN KEY ([BranchOfServiceID])
  REFERENCES [BranchOfService]([ID])
);
GO

--************************************** [ServiceMemberDocument]

CREATE TABLE [ServiceMemberDocument]
(
 [ID]              INT NOT NULL IDENTITY(1,1),
 [ServiceMemberID] INT NOT NULL ,

 CONSTRAINT [PK_ServiceMemberDocument] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_176] FOREIGN KEY ([ServiceMemberID])
  REFERENCES [ServiceMember]([ID])
);
GO

--************************************** [DMDCSearchHistory]

CREATE TABLE [DMDCSearchHistory]
(
 [ID]              INT NOT NULL IDENTITY(1,1),
 [ServiceMemberID] INT NOT NULL ,
 [SearchDate]      DATE NOT NULL ,

 CONSTRAINT [PK_DMDCSearchHistory] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_166] FOREIGN KEY ([ServiceMemberID])
  REFERENCES [ServiceMember]([ID])
);
GO

--************************************** [ServiceMemberToCustomerLink]

CREATE TABLE [ServiceMemberToCustomerLink]
(
 [ID]              INT NOT NULL IDENTITY(1,1),
 [CustomerID]      INT NOT NULL ,
 [ServiceMemberID] INT NOT NULL ,
 [DependentType]   INT NOT NULL ,

 CONSTRAINT [PK_ServiceMemberToCustomerLink] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_130] FOREIGN KEY ([DependentType])
  REFERENCES [DependentType]([ID]),
 CONSTRAINT [FK_134] FOREIGN KEY ([CustomerID])
  REFERENCES [Customer]([ID]),
 CONSTRAINT [FK_138] FOREIGN KEY ([ServiceMemberID])
  REFERENCES [ServiceMember]([ID])
);
GO

--************************************** [Contract]

CREATE TABLE [Contract]
(
 [ID]         INT NOT NULL IDENTITY(1,1),
 [CustomerID] INT NOT NULL ,

 CONSTRAINT [PK_Contract] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_53] FOREIGN KEY ([CustomerID])
  REFERENCES [Customer]([ID])
);
GO

--************************************** [EconomicConcept]

CREATE TABLE [EconomicConcept]
(
 [ID]         INT NOT NULL IDENTITY(1,1),
 [ContractID] INT NOT NULL ,

 CONSTRAINT [PK_EconomicConcept] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_158] FOREIGN KEY ([ContractID])
  REFERENCES [Contract]([ID])
);
GO

--************************************** [Benefit]

CREATE TABLE [Benefit]
(
 [ID]         INT NOT NULL IDENTITY(1,1),
 [CustomerID] INT NOT NULL ,
 [ContractID] INT NOT NULL ,

 CONSTRAINT [PK_Benefit] PRIMARY KEY CLUSTERED ([ID] ASC),
 CONSTRAINT [FK_64] FOREIGN KEY ([CustomerID])
  REFERENCES [Customer]([ID]),
 CONSTRAINT [FK_146] FOREIGN KEY ([ContractID])
  REFERENCES [Contract]([ID])
);
GO

--************************************** [BenefitStatus]

CREATE TABLE [BenefitStatus]
(
 [ID]       INT NOT NULL IDENTITY(1,1),
 [Status]	VARCHAR(255) NOT NULL ,
 
 CONSTRAINT [PK_BenefitStatus] PRIMARY KEY CLUSTERED ([ID] ASC)
);
GO

SET IDENTITY_INSERT [dbo].[BenefitStatus] ON
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (1, N'Approved')
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (2, N'Denied')
INSERT [dbo].[BenefitStatus] ([ID], [Status]) VALUES (3, N'Pending')
SET IDENTITY_INSERT [dbo].[BenefitStatus] OFF
GO

--************************************** [hist].[Person]

CREATE TABLE [hist].[Person](
	[HistoryID] BIGINT NOT NULL IDENTITY(1,1),
	[ID] [int] NOT NULL,
	[FirstName] [varchar](255) NULL,
	[LastName] [varchar](255) NULL,
	[MiddleInitial] [varchar](255) NULL,
	[SSN] [varchar](255) NULL,
	[DOB] [date] NULL,
	[Address1] [varchar](255) NULL,
	[Address2] [varchar](255) NULL,
	[City] [varchar](255) NULL,
	[State] [varchar](255) NULL,
	[Zip] [varchar](255) NULL,
	[Phone] [varchar](255) NULL,
	[Email] [varchar](255) NULL,
	[NotificationMethodID] [int] NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[Timestamp] [datetime] NULL
) ON [PRIMARY]

GO

--************************************* [hist].[ServiceMember]

CREATE TABLE [hist].[ServiceMember](
	[HistoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID] [int] NOT NULL,
	[DateOfContact] [date] NULL,
	[LOBContact] [varchar](255) NULL,
	[EIDFutureCallUp] [date] NULL,
	[MilitaryOrdersReceived] [date] NULL,
	[VerifyBySCRAorMilitaryOrders] [varchar](255) NOT NULL,
	[BranchOfServiceID] [int] NOT NULL,
	[ActiveAccountEligible] [bit] NULL,
	[PersonID] [int] NOT NULL,
	[Timestamp] [datetime] NULL,
 CONSTRAINT [PK_HistoryServiceMember] PRIMARY KEY CLUSTERED 
(	[HistoryID] ASC ) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--************************************** [hist].[ActiveDuty]

CREATE TABLE [hist].[ActiveDuty]
(
 [ActiveDutyID]			BIGINT NOT NULL IDENTITY(1,1),
 [ID]					INT NOT NULL ,
 [ServiceMemberID]		INT NOT NULL ,
 [BranchOfServiceID]	INT NOT NULL,
 [StartDate]			DATE NULL ,
 [EndDate]				DATE NULL ,
 [ExpectedEndDate]		DATE NULL,
 [NoticeDate]			DATE NULL,
 [Timestamp]			DATETIME,

 CONSTRAINT [PK_ActiveDutyHistory] PRIMARY KEY CLUSTERED ([ActiveDutyID] ASC)
);
GO

--************************************** [hist].[PersonToPersonLink]

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hist].[PersonToPersonLink]') AND type in (N'U'))
DROP TABLE [hist].[PersonToPersonLink]
GO

CREATE TABLE [hist].[PersonToPersonLink]
(
	[HistoryID]			BIGINT NOT NULL IDENTITY(1,1),
	[ID]				INT NULL,
	[DependentTypeID]	INT NULL,
	[FromID]			INT NULL,
	[ToID]				INT NULL,
	[StartDate]			DATE NULL,
	[EndDate]			DATE NULL,
	[Timestamp]			DATETIME NULL,
 CONSTRAINT [PK_PersoToPersonLinkHistory] PRIMARY KEY CLUSTERED 
(	[HistoryID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]




