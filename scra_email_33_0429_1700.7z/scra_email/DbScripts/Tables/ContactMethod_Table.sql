USE [SCRA_DB]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_214]') AND parent_object_id = OBJECT_ID(N'[dbo].[Person]'))
ALTER TABLE [dbo].[Person] DROP CONSTRAINT [FK_214]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ContactMethod]') AND type in (N'U'))
DROP TABLE [dbo].[ContactMethod]
GO

CREATE TABLE [dbo].[ContactMethod](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](255) NULL,
	[SortIndex] [int] NULL,
 CONSTRAINT [PK_ContactMethod] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Person]  WITH CHECK ADD  CONSTRAINT [FK_214] FOREIGN KEY([ContactMethodID])
REFERENCES [dbo].[ContactMethod] ([ID])
GO

ALTER TABLE [dbo].[Person] CHECK CONSTRAINT [FK_214]
GO


SET IDENTITY_INSERT [dbo].[ContactMethod] ON
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (1, N'Phone',1)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (2, N'Email',2)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (3, N'Letter',3)
INSERT [dbo].[ContactMethod] ([ID], [Name], [SortIndex]) VALUES (4, N'Internal',4)
SET IDENTITY_INSERT [dbo].[ContactMethod] OFF
GO
