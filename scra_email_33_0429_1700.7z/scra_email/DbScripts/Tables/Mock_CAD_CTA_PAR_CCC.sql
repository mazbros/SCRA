TRUNCATE TABLE [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC]

DECLARE @Center INT, @Product INT, @ContractNo INT, @LocalAcct varchar(19)

DECLARE	Get_Contracts CURSOR 
FOR SELECT  [IDCENT]
      ,[IDPROD]
      ,[IDCONTRN]
  FROM [CUSTDASH].[OLD].[CAD_CONTR_M_S]
GROUP BY [IDCENT]
      ,[IDPROD]
      ,[IDCONTRN]
ORDER BY [IDCENT]
      ,[IDPROD]
      ,[IDCONTRN] 

DECLARE @count smallint
SELECT @count = 1

OPEN Get_Contracts
FETCH NEXT FROM Get_Contracts INTO @Center, @Product, @ContractNo


WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
	
		SET @LocalAcct = '231372691' + CAST(REPLICATE('0',10-LEN(@count)) as varchar) + CAST(@count as varchar)

		INSERT INTO [SAS_Persona_Cor_Anon].[DATA].[CAD_CTA_PAR_CCC]
           ([H1564_IDEMPR]
           ,[H1564_IDCENT]
           ,[H1564_IDPROD]
           ,[H1564_IDCONTRN]
           ,[H1564_CTOLOCAL])
        VALUES
			(317,
			@Center,
			@Product,
			@ContractNo,
			@LocalAcct)
	END
	FETCH NEXT FROM Get_Contracts INTO @Center, @Product, @ContractNo
	SELECT @count = @count + 1
END

CLOSE Get_Contracts
DEALLOCATE Get_Contracts
GO

