USE [SCRA_DB]
GO

IF OBJECT_ID('dbo.spPerson_List') IS NULL
    EXEC('CREATE PROCEDURE dbo.spPerson_List AS SET NOCOUNT ON;')
GO

ALTER PROCEDURE dbo.spPerson_List
	@Search varchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	IF @Search IS NULL BEGIN
		SET @Search = ISNULL(@Search,'')
	END ELSE BEGIN
		SET @Search = @Search
	END

	SELECT TOP 50 [ID]
      ,[FirstName]
      ,[LastName]
      ,[MiddleInitial]
      ,[SSN]
      ,[DOB]
      ,[Address1]
      ,[Address2]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Phone]
      ,[Email]
      ,[NotificationMethodID]
      ,[EmployeeID]
      ,[Timestamp]
  FROM [dbo].[Person]
  WHERE [FirstName] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[LastName] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[SSN] LIKE '%'+RTRIM(LTRIM(@Search))+'%' OR
		[DOB] LIKE '%'+RTRIM(LTRIM(@Search))+'%'	
  ORDER BY [FirstName], [LastName]	
    
END
GO
