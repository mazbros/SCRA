USE [SCRA_DB]
GO

IF OBJECT_ID('dbo.spPerson_Get') IS NULL
    EXEC('CREATE PROCEDURE dbo.spPerson_Get AS SET NOCOUNT ON;')
GO

ALTER PROCEDURE dbo.spPerson_Get
	@ID int
AS
BEGIN
	SET NOCOUNT ON;

	SELECT [ID]
      ,[FirstName]
      ,[LastName]
      ,[MiddleInitial]
      ,[SSN]
      ,[DOB]
      ,[Address1]
      ,[Address2]
      ,[City]
      ,[State]
      ,[Zip]
      ,[Phone]
      ,[Email]
      ,[NotificationMethodID]
      ,[EmployeeID]
      ,[Timestamp]
  FROM [dbo].[Person]
  WHERE [ID] = @ID
    
END
GO
