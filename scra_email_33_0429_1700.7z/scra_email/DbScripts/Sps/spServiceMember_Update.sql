USE [SCRA_DB]
GO

IF OBJECT_ID('dbo.spServiceMember_Update') IS NULL
    EXEC('CREATE PROCEDURE dbo.spServiceMember_Update AS SET NOCOUNT ON;')
GO

ALTER PROCEDURE dbo.spServiceMember_Update
(	
	@BranchOfServiceID		INT,
	@PersonID				INT,
	@StartDate				DATE,
	@EndDate				DATE,
	@ExpectedEndDate			DATE,
	@NoticeDate				DATE,
	@ActiveDutyID			INT OUTPUT
)
AS
BEGIN
	SET NOCOUNT ON
	
	DECLARE @ID INT
	SET @ID = (SELECT [ID] FROM [dbo].[ServiceMember] WHERE [PersonID] = @PersonID)
	
	IF @ID IS NULL BEGIN
	
		INSERT INTO [dbo].[ServiceMember]
           ( [PersonID]
            ,[Timestamp])
		VALUES
           ( @PersonID
            ,GETDATE())
		
		SET @ID = SCOPE_IDENTITY()
			   
		INSERT INTO [dbo].[ActiveDuty]
			(
				[ServiceMemberID]
				,[BranchOfServiceID]
				,[StartDate]
				,[EndDate]
				,[ExpectedEndDate]
				,[NoticeDate]
				,[Timestamp])
			VALUES
				(@ID
				,@BranchOfServiceID
				,@StartDate
				,@EndDate
				,@ExpectedEndDate
				,@NoticeDate
				,GETDATE())
				
			SET @ActiveDutyID = SCOPE_IDENTITY()
	
	END ELSE BEGIN
		
		INSERT INTO [hist].[ServiceMember]
           ( [ID]
			,[PersonID]
            ,[Timestamp])
		SELECT [ID]
			  ,[PersonID]
			  ,[Timestamp]
		  FROM [dbo].[ServiceMember]
		WHERE [PersonID] = @PersonID
		
		UPDATE [dbo].[ServiceMember]
			SET [PersonID] = @PersonID
			   ,[Timestamp] = GETDATE()
	 		WHERE [ID] = @ID
	 		
	   INSERT INTO [hist].[ActiveDuty]
           ([ID]
           ,[ServiceMemberID]
           ,[BranchOfServiceID]
           ,[StartDate]
           ,[EndDate]
           ,[ExpectedEndDate]
           ,[NoticeDate]
           ,[Timestamp])
			SELECT [ID]
			  ,[ServiceMemberID]
			  ,[BranchOfServiceID]
			  ,[StartDate]
			  ,[EndDate]
			  ,[ExpectedEndDate]
			  ,[NoticeDate]
			  ,[Timestamp]
		  FROM [dbo].[ActiveDuty]
		WHERE [ID] = @ActiveDutyID
		
		UPDATE [dbo].[ActiveDuty]
		   SET [ServiceMemberID] = @ID
			  ,[BranchOfServiceID] = @BranchOfServiceID
			  ,[StartDate] = @StartDate
			  ,[EndDate] = @EndDate
			  ,[ExpectedEndDate] = @ExpectedEndDate
			  ,[NoticeDate] = @NoticeDate
			  ,[Timestamp] = GETDATE()
		WHERE [ID] = @ActiveDutyID

	END
	
	SELECT @ActiveDutyID
	
END
GO