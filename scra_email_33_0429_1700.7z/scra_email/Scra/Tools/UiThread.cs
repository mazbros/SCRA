﻿using System;
using System.Windows;

namespace Scra.Tools
{
    public class UiThread : IUiThread
    {
        private readonly Action<Action> _executeInUi;

        public UiThread()
        {
            if (Application.Current == null)
            {
                _executeInUi = act => act();    
            }
            else
            {
                _executeInUi = Application.Current.Dispatcher.Invoke;
            }
        }

        public void Execute(Action action)
        {
            if (Application.Current.Dispatcher.CheckAccess())
            {
                action();
            }
            else
            {
                _executeInUi(action);
            }
        }
    }
}