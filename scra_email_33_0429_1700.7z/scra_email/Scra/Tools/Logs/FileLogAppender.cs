﻿using System;
using System.IO;

namespace Scra.Tools.Logs
{
    public class FileLogAppender : ILogAppender
    {
        private StreamWriter _stream;

        public void Log(ILogRecord record)
        {
            var message = Format(record);
            GetStream().WriteLine(message);
        }

        private string Format(ILogRecord record)
        {
            var time = string.Format("{0:HH:mm:ss}", DateTime.Now);
            var message = time + " " + record.Severity + " " + record.Message;

            var exception = record.Exception;
            if (exception != null)
            {
                if (exception is AggregateException)
                {
                    exception = exception.InnerException;
                }

                message += "\r\n "+ exception;
            }
            return message;
        }

        private StreamWriter GetStream()
        {
            if (_stream == null)
            {
                var filename = string.Format("scra_log_{0:yy-MM-dd}.txt", DateTime.Now);
                _stream = new StreamWriter(filename, true) {AutoFlush = true};
                var message = string.Format("\r\n\r\n\r\n{0:HH:mm:ss} NEW SESSION", DateTime.Now);
                _stream.WriteLine(message);
            }
            return _stream;
        }

        public void Close()
        {
            if (_stream != null)
            {
                _stream.Dispose();
            }
        }
    }
}