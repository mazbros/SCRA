﻿using System;
using System.Windows;

namespace Scra.Views.Utilities
{
    /// <summary>
    /// Interaction logic for WaitingView.xaml
    /// </summary>
    public partial class WaitingView
    {
        public WaitingView()
        {
            InitializeComponent();
        }

        private void myGif_MediaEnded(object sender, RoutedEventArgs e)
        {
            MyGif.Position = new TimeSpan(0, 0, 1);
            MyGif.Play();
        }
    }
}
