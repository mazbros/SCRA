﻿using System;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls.Buttons;
using Scra.Model.Files;
using Scra.Model.Tools;
using Scra.Model.Users;

namespace Scra.Views.Files
{
    public class FileAttachmentVm : BaseViewModel
    {       
        private MultiButtonProps _actionProps;

        public string FileName { get; set; }

        public MultiButtonProps ActionProps
        {
            get { return _actionProps; }
            set { SetProperty(ref _actionProps, value); }
        }

        public ICommand ViewCommand { get; set; }

        public FileAttachmentVm Create(FileAttachmentSnapshot attachment, Action view, Action download, Action delete, Action<FileAttachmentSnapshot> view2)
        {
            var user = Di.Get<IUser>();
            if (user.Type.Equals(UserType.Admin) || user.Type.Equals(UserType.Regular))
            {
                return new FileAttachmentVm
                {
                    FileName = attachment.FileName,
                    ViewCommand = new Command(() => view2(attachment)),
                    ActionProps = new MultiButtonProps(new[]
                    {
                        new MultiButtonProps.Item("View", view),
                        new MultiButtonProps.Item("Download", download),
                        new MultiButtonProps.Item("Delete", delete),
                    })

                };
            }

            return new FileAttachmentVm
            {
                FileName = attachment.FileName,
                ViewCommand = new Command(() => view2(attachment)),
                ActionProps = new MultiButtonProps(new[]
                {
                    new MultiButtonProps.Item("View", view),
                    new MultiButtonProps.Item("Download", download),
                })

            };

        }
    }
}