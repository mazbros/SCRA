﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Scra.AppCore;
using Scra.Controls;
using Scra.Controls.MessageDialog;
using Scra.Model.Contracts;
using Scra.Model.Exceptions;
using Scra.Model.Tasks;
using Scra.Model.Tools;
using Scra.State;
using Scra.Views.Shell;

namespace Scra.Views.Benefits
{
    public class MortgageDetailsViewModel: BaseViewModel
    {
        private readonly IBenefitDetailRepository _benefitDetailRepository;
        private readonly AppNavigator _navigator;
        private readonly IMessageDialog _messageDialog;
        private BenefitDetail _detail;
        private Benefit _benefit;
        private int _benefitId;
        private readonly IBenefitRepository _benefitRepository;
        private ShellViewModel _shellViewModel;
        private readonly IDispatcher _dispatcher;


        public MortgageDetailsViewModel()
        {
            SubTaskIdentifier = SubTaskType.MortgageDetail;


            _benefitDetailRepository = Di.Get<IBenefitDetailRepository>();
            _navigator = Di.Get<AppNavigator>();
            _messageDialog = Di.Get<IMessageDialog>();
            _benefitRepository = Di.Get<IBenefitRepository>();
            _shellViewModel = Di.Get<ShellViewModel>();
            _dispatcher = Di.Get<IDispatcher>();

            OnViewLoaded = Load;
            SaveCommand = new Command(Save);
            CancelCommand = new Command(Cancel);
        }

        private void Cancel()
        {
            Load();
        }


        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public decimal CurrentRate { get; set; }
        public DateTime? DmiSentDate { get; set; }
        public DateTime? ConfirmationReceivedDate { get; set; }
        public DateTime? BenefitEffectiveDate { get; set; }
        public SubTaskType SubTaskIdentifier { get; set; }
        public ContractSnapshotViewModel ContractSnapshot { get; set; }

        private async void Save()
        {
            try
            {
                _shellViewModel.IsUiBusy = true;
                var model = FillModel();
                Validate();
                await _benefitDetailRepository.Save(model);
                _shellViewModel.IsUiBusy = false;
                await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_UNLOCK, SubTaskIdentifier));               
            }
            catch (UserException ex)
            {
                _messageDialog.Warning(ex);
            }
            catch (Exception ex)
            {
                _messageDialog.Error(ex, "Error during saving.");
            }
            finally
            {
                _shellViewModel.IsUiBusy = false;
            }
        }

        private BenefitDetail FillModel()
        {
            var model = GetModel();
            model.CurrentRate = CurrentRate;
            model.DmiSentDate = DmiSentDate;
            model.ConfirmationReceivedDate = ConfirmationReceivedDate;
            model.BenefitEffectiveDate = BenefitEffectiveDate;
            return model;
        }

        private BenefitDetail GetModel()
        {
            if (_detail != null)
            {
                return _detail;
            }
            return BenefitDetail.CreateMortgage(_benefitId);
        }

        private void Validate()
        {
        }

        private async void Load()
        {
            _shellViewModel.IsUiBusy = true;
            _benefitId = ((IdArgs)Arguments).Id;
            _benefit = await _benefitRepository.LoadById(_benefitId);
            _detail = await _benefitDetailRepository.Get(_benefit.Id);

            await Reload();
        }

        private async Task Reload()
        {
            FillView(_detail);
            await ContractSnapshot.Load(_benefit.ContractId, _benefit.PersonId, _benefitId);
            _shellViewModel.IsUiBusy = false;
            await _dispatcher.DispatchAsync(new Act(Act.TASK_DONE_LOCK, SubTaskIdentifier));
        }

        private void FillView(BenefitDetail model)
        {
            if (model == null)
            {
                return;
            }

            CurrentRate = Formatter.Percent(model.CurrentRate);
            DmiSentDate = model.DmiSentDate;
            ConfirmationReceivedDate = model.ConfirmationReceivedDate;
            BenefitEffectiveDate = model.BenefitEffectiveDate;
            UpdateAll();
        }
    }
}
