﻿namespace Scra.Views.ServiceMembers
{
    public partial class ServiceMemberEditView
    {
        public ServiceMemberEditView()
        {
            InitializeComponent();

            SetupViewModel();            
        }

        private void SetupViewModel()
        {
            var vm = GetViewModel();
            vm.ActiveDuty = ActiveDutyView.GetViewModel();
        }

        public ServiceMemberEditViewModel GetViewModel()
        {
            return (ServiceMemberEditViewModel)DataContext;
        }
    }
}
