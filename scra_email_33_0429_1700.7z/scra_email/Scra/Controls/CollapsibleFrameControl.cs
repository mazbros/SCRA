using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms.VisualStyles;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Scra.Controls
{
    public class CollapsibleFrameControl : ContentControl
    {
        public CollapsibleFrameControl()
        {
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            TextBlock txt = (TextBlock)Template.FindName("MyTextBlock", this);
            txt.MouseUp += OnTitleClick;
        }

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        public static readonly DependencyProperty TitleProperty = DependencyProperty.Register(
            "Title",
            typeof(string),
            typeof(CollapsibleFrameControl),
            new PropertyMetadata(default(string))
        );

        public SolidColorBrush TitleBackground
        {
            get { return (SolidColorBrush)GetValue(TitleBackgroundProperty); }
            set { SetValue(TitleBackgroundProperty, value); }
        }

        public static readonly DependencyProperty TitleBackgroundProperty = DependencyProperty.Register(
            "TitleBackground",
            typeof(SolidColorBrush),
            typeof(CollapsibleFrameControl),
            new PropertyMetadata(new SolidColorBrush(Colors.LightGray))
        );

        public Visibility ContentVisibility
        {
            get { return (Visibility)GetValue(ContentVisibilityProperty); }
            set { SetValue(ContentVisibilityProperty, value); }
        }

        public static readonly DependencyProperty ContentVisibilityProperty = DependencyProperty.Register(
            "ContentVisibility",
            typeof(Visibility),
            typeof(CollapsibleFrameControl),
            new PropertyMetadata(Visibility.Visible)
        );

        public void OnTitleClick(object sender, RoutedEventArgs e)
        {
            ToggleVisibility();
        }

        private void ToggleVisibility()
        {
            var polygon = (Polygon)Template.FindName("MyPolygon", this);

            if (ContentVisibility == Visibility.Visible)
            {
                polygon.Points = PointCollection.Parse("0,2.5 5,10 10,2.5");
                ContentVisibility = Visibility.Collapsed;
            }
            else
            {
                polygon.Points = PointCollection.Parse("0,7.5 5,0 10,7.5");
                ContentVisibility = Visibility.Visible;
            }
        }
    }
}