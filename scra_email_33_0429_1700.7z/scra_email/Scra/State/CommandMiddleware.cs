﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scra.Model.Logs;

namespace Scra.State
{
    public class CommandMiddleware<TState> : IStoreMiddleware<TState>, ICommandSubscriber
    {
        private readonly ILogger _logger;
        private readonly Dictionary<string, List<Action<IAct>>> _actExecutors;

        public CommandMiddleware(ILogger logger)
        {
            _logger = logger;
            _actExecutors = new Dictionary<string, List<Action<IAct>>>();
        }

        public Action SubscribeCommand(string act, Action<IAct> actExecutor)
        {
            if (!_actExecutors.ContainsKey(act))
            {
                _actExecutors.Add(act, new List<Action<IAct>>());
            }
            var executors = _actExecutors[act];
            executors.Add(actExecutor);

            return () => UnSubscribeCommand(act, actExecutor);
        }

        public void UnSubscribeCommand(string act, Action<IAct> action)
        {
            if (!_actExecutors.ContainsKey(act))
            {
                return;
            }
            var executors = _actExecutors[act];
            executors.Remove(action);
        }

        public void Execute(IList<IAct> acts, TState state)
        {
            foreach (var act in acts)
            {
                _logger.Debug(act.ToString());
                ExecuteAct(act);
            }
        }

        private void ExecuteAct(IAct act)
        {
            try
            {
                if (!_actExecutors.ContainsKey(act.Code))
                {
                    return;
                }

                var executors = _actExecutors[act.Code];
                executors.ToList().ForEach(x => x(act));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Executing " + act);
            }
        }
    }
}