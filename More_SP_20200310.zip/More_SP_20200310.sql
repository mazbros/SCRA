USE [SCRA_DB]
GO

/****** Object:  StoredProcedure [dbo].[spGetPriorActiveDuty]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get prior active duty>
-- =============================================
CREATE PROCEDURE [dbo].[spGetPriorActiveDuty] 
	@ActiveDutyId INT
AS
BEGIN

	SET NOCOUNT ON;

	;WITH CTE AS 
	(SELECT [ID]
           ,[BranchOfServiceID]
           ,[StartDate]
           ,[EndDate]
           ,[NoticeDate]
           ,[Timestamp]
           ,[ModifiedBy]
           ,[PersonID]
           ,ROW_NUMBER() OVER (ORDER BY [StartDate]) AS [Row_Counter]
	 FROM [ActiveDuty]
		WHERE [PersonId] IN (SELECT [PersonID] FROM [ActiveDuty] WHERE [ID] = @ActiveDutyId)
	)
                  
    SELECT * FROM CTE WHERE [Row_Counter] IN (SELECT [Row_Counter] - 1 FROM CTE WHERE ID = @ActiveDutyId)

END

GO

/****** Object:  StoredProcedure [dbo].[spGetBenefitInformation]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get benefit information>
-- =============================================
CREATE PROCEDURE [dbo].[spGetBenefitInformation]
	@BenefitId INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT B.ID as [BenefitId]
         , A.ID as [ActiveDutyId]
         , C.ID as [ContractId]
         , D.ID as [BenefitDetailId]
         , A.StartDate as [ActiveDutyStartDate]
         , A.EndDate as [ActiveDutyEndDate]
         , D.BenefitEffectiveDate
         , D.ExpectedRemovalDate as [BenefitExpectedRemovalDate]
         , D.BenefitRemovedDate
         , dbo.fnProductSubName(C.ID) as [SUB_PRODUCT_NAME]      
         , CASE WHEN ISNULL(C.LegacyNo, '') = '' THEN C.CardNo ELSE C.LegacyNo END as [AccountNumber]
         , T.SCRA_Code
         , C.OpenDate
         , C.CloseDate
    FROM [Benefit] as B
            LEFT JOIN [ActiveDuty] as A ON A.ID = B.ActiveDutyId
            LEFT JOIN [BenefitDetail] as D ON D.BenefitId = B.ID
            JOIN [Contract] as C ON C.ID = B.ContractID
            JOIN ContractType T ON C.ContractTypeId = T.ID
    WHERE C.IsDeleted = 0 AND B.ID = @BenefitId;

END

GO

/****** Object:  StoredProcedure [dbo].[spLoadLetterTemplate]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Load letter template>
-- =============================================
CREATE PROCEDURE [dbo].[spLoadLetterTemplate]
	@id INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT CONVERT(varchar(max), [Template], 0) as [Template] 
		FROM [dbo].[Letter_DATA] 
			WHERE LetterNumber = @id;

END

GO

/****** Object:  StoredProcedure [dbo].[spGetLetterList]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get letter list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetLetterList] 
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT [ID], [LetterCode], [LetterName], [LetterNumber], [LetterLongDesc] 
		FROM [dbo].[Letter_DATA] 
			ORDER BY [LetterNumber];
			
END

GO

/****** Object:  StoredProcedure [dbo].[spGetDependentTypeList]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey mazur>
-- Create date: <03/10/2020>
-- Description:	<Get dependent type list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetDependentTypeList]
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT [ID], [Type] FROM [dbo].[DependentType] ORDER BY [Type];
    
END

GO

/****** Object:  StoredProcedure [dbo].[spGetFile]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get file>
-- =============================================
CREATE PROCEDURE [dbo].[spGetFile] 
	@fileId int
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT [FileName], [FileContent] FROM [dbo].[File] WHERE [ID] = @fileId;
	
END

GO

/****** Object:  StoredProcedure [dbo].[spGetFileList]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get list of files>
-- =============================================
CREATE PROCEDURE [dbo].[spGetFileList]
	@id INT
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT [ID], [FileName], [Timestamp] FROM [dbo].[File] 
		WHERE [ID] IN (SELECT [FileId] FROM [dbo].[DocumentLink] 
							WHERE [EntityId] = @id)
        AND [IsDeleted] = 0;
	
END

GO

/****** Object:  StoredProcedure [dbo].[spGetVerifiedByList]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get verified by list>
-- =============================================
CREATE PROCEDURE [dbo].[spGetVerifiedByList] 
WITH RECOMPILE
AS
BEGIN

	SET NOCOUNT ON;

	SELECT [ID], [VerifiedBy] FROM [dbo].[VerifiedByItem] ORDER BY [ID];
	
END

GO

/****** Object:  StoredProcedure [dbo].[spGetBranchList]    Script Date: 03/10/2020 17:01:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Aleksey Mazur>
-- Create date: <03/10/2020>
-- Description:	<Get list of service branches>
-- =============================================
CREATE PROCEDURE [dbo].[spGetBranchList] 
WITH RECOMPILE	
AS
BEGIN

	SET NOCOUNT ON;
	
	SELECT [ID], [Branch], [IsReserve] FROM [dbo].[BranchOfService] ORDER BY [Branch];

END

GO

